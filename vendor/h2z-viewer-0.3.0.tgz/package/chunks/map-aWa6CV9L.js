import * as k from "three";
import { legacyLook as jr } from "../h2z-viewer-compat.js";
import { OrbitControls as Xr } from "three/addons/controls/OrbitControls.js";
import { GLTFLoader as Kr } from "three/addons/loaders/GLTFLoader.js";
import { DRACOLoader as Yr } from "three/addons/loaders/DRACOLoader.js";
const Zr = "dark-pad", Qr = "深色墙板", Jr = 1, et = "墙板（wallPad）地图区：楼层压暗略带蓝灰、所有房间名分级显示、本房间橙色、会议室占用 / 空闲、灯开关。2026-11-02 定稿（Smart 总部 1F 验收）。", rt = { background: "#090909", exposure: 0.18, pixelRatio: [1.5, 2] }, tt = { tone: { dim: 0.55, tint: "#1c2536", mix: 0.25 }, roles: {}, slots: {} }, at = { font: '"PingFang SC","Microsoft YaHei",sans-serif', size: 13, fontScale: [1, 1.55], room: { bg: "rgba(12,17,26,.72)", fg: "#c9d3e0", border: "rgba(255,255,255,.08)", weight: 500 }, mine: { bg: "#ff8a3d", fg: "#ffffff", tag: "当前", scale: 1.25, fill: "#ff8a3d", fillOpacity: 0.3, edge: "#ff8a3d" }, meeting: { bg: "rgba(12,17,26,.86)", fg: "#ffffff", scale: 1.08 }, busy: { color: "#ff5a5a", text: "占用", badge: "#d93838" }, free: { color: "#3ddc84", text: "空闲", badge: "#1f9d5a" }, lightOn: "#ffd23f", lightOff: "#a7b0bd", panel: "#090909", marker: { bg: "rgba(12,17,26,.86)", fg: "#e5ebf3", border: "rgba(255,255,255,.12)", missing: "#ff5a5a" } }, nt = { mode: "plan", focusMinSpan: 26, focusRoomScale: 1.8, margin: 1.12 }, ot = {
  id: Zr,
  name: Qr,
  version: Jr,
  description: et,
  scene: rt,
  materials: tt,
  overlay: at,
  camera: nt
}, it = "light-ops", st = "浅色运维", xt = 1, ct = "BuildingOS 运维页现在的样子（FloorMapView）：模型原色、默认天空和曝光；标签白底深字、选中蓝、告警红。", ft = {}, lt = { roles: {}, slots: {} }, ht = { font: '"PingFang SC","Microsoft YaHei",sans-serif', panel: "#eef2f7", size: 12, fontScale: [1, 1.4], room: { bg: "rgba(255,255,255,.95)", fg: "#303133", border: "#c0c4cc", weight: 400 }, mine: { bg: "#409eff", fg: "#ffffff", tag: "当前", scale: 1.2, fill: "#409eff", fillOpacity: 0.35, edge: "#409eff" }, meeting: { bg: "rgba(255,255,255,.92)", fg: "#303133", scale: 1.05 }, busy: { color: "#f56c6c", text: "占用", badge: "#f56c6c", bg: "#fef0f0", fg: "#c45656" }, free: { color: "#67c23a", text: "空闲", badge: "#67c23a" }, marker: { bg: "rgba(255,255,255,.92)", fg: "#303133", border: "#ffffff", missing: "#f56c6c" }, lightOn: "#e6a23c", lightOff: "#909399" }, ut = { mode: "three", focusMinSpan: 26, focusRoomScale: 1.8, margin: 1.12 }, dt = {
  id: it,
  name: st,
  version: xt,
  description: ct,
  scene: ft,
  materials: lt,
  overlay: ht,
  camera: ut
}, vt = Object.freeze({ "dark-pad": ot, "light-ops": dt });
function pt(o) {
  return o ? typeof o == "string" ? vt[o] || null : typeof o == "object" ? o : null : null;
}
const Bt = Object.freeze(["floor", "room", "wall", "glass", "door", "linework", "furniture", "marker"]), mt = { slab: "floor", rooms: "room", structure: "wall", glass: "glass", circulation: "door", cad: "linework", furniture: "furniture" }, Ct = (o) => mt[o] || (String(o).startsWith("dev-") ? "marker" : null);
function At(o) {
  const i = /* @__PURE__ */ new Map(), r = (e) => (Array.isArray(e.material) ? e.material : [e.material]).filter(Boolean);
  for (const [e, s] of Object.entries(o.model?.semantics?.materialRoles || {})) {
    const x = o.materials?.get(e);
    x && Bt.includes(s) && i.set(x, s);
  }
  for (const e of o.layerDefs || []) {
    const s = Ct(e.id);
    if (s)
      for (const x of e.targets || []) {
        let C = [];
        try {
          C = o._targets(x) || [];
        } catch {
          C = [];
        }
        for (const d of C) for (const c of r(d.mesh)) i.has(c) || i.set(c, s);
      }
  }
  return i;
}
const Et = (o) => o == null ? null : new k.Color(o);
function gt(o, i) {
  const r = pt(i);
  o._themeOrig || (o._themeOrig = {
    palette: { ...o.palette },
    exposure: o.renderer.toneMappingExposure,
    pixelRatio: o.renderer.getPixelRatio(),
    colors: /* @__PURE__ */ new Map()
  }, o.scene.traverse((n) => {
    if (n.isMesh)
      for (const f of Array.isArray(n.material) ? n.material : [n.material])
        f && !o._themeOrig.colors.has(f) && o._themeOrig.colors.set(f, { color: f.color?.clone(), emissive: f.emissive?.clone(), opacity: f.opacity, transparent: f.transparent });
  }));
  const e = o._themeOrig;
  o._theme = r;
  const s = r?.scene?.background;
  o.palette = s ? { ...e.palette, skyDay: s, skyNight: s, studioSky: s } : { ...e.palette }, o.renderer.toneMappingExposure = r?.scene?.exposure ?? e.exposure;
  const x = r?.scene?.pixelRatio;
  Array.isArray(x) ? o.renderer.setPixelRatio(Math.min(x[1], Math.max(x[0], window.devicePixelRatio || 1))) : typeof x == "number" ? o.renderer.setPixelRatio(x) : o.renderer.setPixelRatio(e.pixelRatio), o._resize?.();
  const C = r?.materials?.tone, d = Et(C?.tint), c = r?.materials?.slots || {}, t = r?.materials?.roles || {}, a = At(o), h = new Set(Object.keys(o.model?.semantics?.materialStates || {}).map((n) => o.materials?.get(n)).filter(Boolean));
  return o._themeMaterials = () => {
    for (const [n, f] of e.colors) {
      h.has(n) || (f.color && n.color && n.color.copy(f.color), f.emissive && n.emissive && n.emissive.copy(f.emissive)), n.opacity = f.opacity, n.transparent = f.transparent, C && n.color && (C.dim !== void 0 && n.color.multiplyScalar(C.dim), d && n.color.lerp(d, C.mix ?? 0.25), n.emissive && C.dim !== void 0 && !h.has(n) && n.emissive.multiplyScalar(C.dim));
      for (const v of [t[a.get(n)], c[n.name]])
        v && (v.color !== void 0 && n.color && n.color.set(v.color).convertSRGBToLinear(), v.dim !== void 0 && n.color && n.color.multiplyScalar(v.dim), v.opacity !== void 0 && (n.opacity = v.opacity, n.transparent = v.opacity < 1));
      n.needsUpdate = !0;
    }
  }, o.environment?.(o.weather, o.hour), o.emit?.("theme", r ? r.id : null), r;
}
function w0(o) {
  if (o.userData && o.userData.semantic) return o.userData.semantic;
  const i = o.name || "", r = i.indexOf("|");
  return r > 0 ? i.slice(0, r) : null;
}
function Ft(o = []) {
  const i = /* @__PURE__ */ new Map(), r = (e, s) => e.forEach((x) => {
    i.set(x.id, { ...x, parent: s }), x.children && r(x.children, x.id);
  });
  return r(o, null), i;
}
function We(o, i, r) {
  for (let e = i; e; e = o.get(e)?.parent) if (e === r) return !0;
  return !1;
}
const Dt = {
  id: "campus-life",
  version: 1,
  create(o, i, r = {}) {
    const e = { time: { value: 0 }, cloud: { value: 0.43 }, night: { value: 0 }, dusk: { value: 0 }, flatMix: { value: 0 }, flatColor: { value: new k.Color(16777215) } }, s = new k.Mesh(new k.SphereGeometry(1100, 32, 16), new k.ShaderMaterial({
      side: k.BackSide,
      depthWrite: !1,
      uniforms: e,
      vertexShader: "varying vec3 vWorld; void main(){vWorld=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}",
      fragmentShader: `varying vec3 vWorld; uniform float time; uniform float cloud; uniform float night; uniform float dusk; uniform float flatMix; uniform vec3 flatColor;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      float fbm(vec2 p){float v=0.;float a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+13.5;a*=.5;}return v;}
      void main(){vec3 d=normalize(vWorld);float h=max(d.y,0.);vec3 color=mix(vec3(.72,.81,.87),vec3(.16,.39,.66),pow(h,.45));
      color=mix(color,mix(vec3(.91,.59,.39),vec3(.29,.33,.54),pow(h,.4)),dusk*.82);
      vec2 uv=d.xz/(max(d.y,.06)+.24)*2.6+vec2(time*.004,0.);float n=fbm(uv);float c=smoothstep(.68-cloud*.42,.79-cloud*.33,n)*smoothstep(-.02,.16,d.y);
      color=mix(color,mix(vec3(.69,.76,.8),vec3(1.),smoothstep(.4,.8,n)),c*.93);
      color=mix(color,vec3(.016,.033,.085)+h*.02,night*.98);
      float star=step(.9978,hash(floor(d.xz/(d.y+.2)*850.)))*smoothstep(.1,.5,h);color+=star*night*.7;
      color=mix(color,flatColor,flatMix);
      gl_FragColor=vec4(color,1.);}`
    }));
    s.name = "campus-life-sky", s.frustumCulled = !1, s.renderOrder = -1e3, o.scene.add(s);
    const x = new k.Group();
    x.name = "campus-life-traffic", o.scene.add(x);
    const C = 32, d = new k.BoxGeometry(1, 1, 1), c = new k.MeshStandardMaterial({ color: 16777215, roughness: 0.48, metalness: 0.25 }), t = new k.MeshStandardMaterial({ color: 3162698, roughness: 0.38, metalness: 0.25 }), a = new k.MeshStandardMaterial({ color: 2369322, roughness: 0.9 }), h = new k.InstancedMesh(d, c, C), n = new k.InstancedMesh(d, t, C), f = new k.InstancedMesh(d, a, C * 4);
    for (const A of [h, n, f])
      A.frustumCulled = !1, A.castShadow = !0, x.add(A);
    const v = [13029070, 5073019, 7568252, 11907753, 8803919], m = Array.from({ length: C }, (A, E) => {
      const y = E < 20, b = E % 2 ? 1 : -1;
      return { axis: y ? "x" : "z", dir: b, speed: 7 + E * 7 % 9, position: -280 + E % (y ? 20 : 12) * (y ? 28 : 46), initial: -280 + E % (y ? 20 : 12) * (y ? 28 : 46), lane: y ? b > 0 ? 71 : 83 : b > 0 ? 109 : 119 };
    }), p = new k.Matrix4(), g = new k.Quaternion(), l = new k.Vector3(), u = new k.Vector3();
    function B() {
      m.forEach((A, E) => {
        const y = A.axis === "x" ? A.position : A.lane, b = A.axis === "z" ? A.position : A.lane, S = A.axis === "x" ? A.dir > 0 ? Math.PI / 2 : -Math.PI / 2 : A.dir > 0 ? 0 : Math.PI;
        g.setFromAxisAngle(new k.Vector3(0, 1, 0), S);
        const F = (D, _, w, P, O, W, T, G) => {
          l.set(y + w * Math.cos(S) + O * Math.sin(S), P, b - w * Math.sin(S) + O * Math.cos(S)), p.compose(l, g, u.set(W, T, G)), D.setMatrixAt(_, p);
        };
        F(h, E, 0, 0.65, 0, 1.9, 0.8, 4.4), F(n, E, 0, 1.25, -0.2, 1.65, 0.6, 2.4);
        for (let D = 0; D < 4; D++) F(f, E * 4 + D, D % 2 ? 0.95 : -0.95, 0.35, D < 2 ? -1.35 : 1.35, 0.25, 0.55, 0.65);
        h.setColorAt(E, new k.Color(v[E % v.length]));
      });
      for (const A of [h, n, f]) A.instanceMatrix.needsUpdate = !0;
    }
    return B(), s.position.copy(o.camera.position), r.sky === !1 && (s.visible = !1), {
      kind: "campus-life",
      cars: m,
      sky: s,
      traffic: x,
      environment({ weather: A, hour: E, night: y }) {
        e.night.value = y ? 1 : 0, e.dusk.value = !y && (E < 8 || E > 17) ? 1 : 0, e.cloud.value = A === "sunny" ? 0.4 : A === "cloudy" ? 0.95 : 1.4, s.visible = !o.studioOn && r.sky !== !1;
      },
      update(A) {
        if (s.position.copy(o.camera.position), e.time.value += A, x.visible = o.layerState?.[r.vehicleLayer || "vehicles"] !== !1, !!x.visible) {
          for (const E of m)
            E.position += E.dir * E.speed * A, E.position > 290 && (E.position = -290), E.position < -290 && (E.position = 290);
          B();
        }
      },
      dispose() {
        o.scene.remove(s, x), s.geometry.dispose(), s.material.dispose(), d.dispose(), c.dispose(), t.dispose(), a.dispose();
      }
    };
  }
}, yt = {
  id: "precipitation",
  version: 1,
  create(o, i, r = {}) {
    const e = r.count || 600, s = r.min || [-130, 0, -170], x = r.max || [130, 150, 130];
    let C = 1234567;
    const d = () => (C = C * 16807 % 2147483647) / 2147483647, c = new Float32Array(e * 3);
    for (let n = 0; n < e; n++) for (let f = 0; f < 3; f++) c[n * 3 + f] = s[f] + d() * (x[f] - s[f]);
    const t = new k.BufferGeometry();
    t.setAttribute("position", new k.BufferAttribute(c, 3));
    const a = new k.Points(t, new k.PointsMaterial({ color: r.color ?? 14479359, size: 0.55, transparent: !0, opacity: 0.7 }));
    a.visible = !1, o.scene.add(a);
    let h = "sunny";
    return {
      environment(n) {
        h = n.weather, a.visible = h === "rain" || h === "snow", a.material.size = h === "snow" ? 1.1 : 0.45;
      },
      update(n) {
        if (a.visible) {
          for (let f = 1; f < c.length; f += 3)
            c[f] -= n * (h === "snow" ? 5 : 65), c[f] < s[1] && (c[f] = x[1]);
          t.attributes.position.needsUpdate = !0;
        }
      },
      dispose() {
        o.scene.remove(a), t.dispose(), a.material.dispose();
      }
    };
  }
}, bt = {
  id: "traffic",
  version: 1,
  create(o, i, r = {}) {
    const e = Array.isArray(r.ids) ? r.ids : [], s = Array.isArray(r.v) ? r.v : [r.v || 8], x = (p) => {
      const g = Number(s[0]) || 8, l = Number(s[1] ?? g) || g, u = p * 37 % 100 / 100;
      return g + (l - g) * u;
    }, C = Array.isArray(r.wrap) && r.wrap.length === 2 ? r.wrap.map(Number) : [-400, 400], d = String(r.layer || "vehicles"), c = /* @__PURE__ */ new Map(), t = o.root;
    t && t.traverse((p) => {
      if (!p.isMesh) return;
      const g = p.userData && p.userData.semantic || (p.name || "").split("|")[0];
      g && (c.has(g) || c.set(g, []), c.get(g).push(p));
    });
    const a = [];
    let h = 0;
    const n = new k.Box3(), f = new k.Vector3(), v = new k.Vector3();
    for (const p of e) {
      const g = c.get(p);
      if (!g || !g.length) continue;
      n.makeEmpty();
      for (const A of g) n.expandByObject(A);
      n.getSize(f), n.getCenter(v);
      const l = f.x > f.z ? "x" : "z", u = h % 2 ? 1 : -1, B = new k.Group();
      B.name = p, g[0].parent && g[0].parent.add(B);
      for (const A of g) B.add(A);
      a.push({ node: B, axis: l, dir: u, speed: x(h), base: B.position.clone() }), h++;
    }
    let m = !1;
    return {
      kind: "traffic",
      cars: a,
      update(p) {
        if (!(!(!o.layerState || o.layerState[d] !== !1) || m))
          for (const l of a)
            l.node.position[l.axis] += l.dir * l.speed * p, l.node.position[l.axis] > C[1] && (l.node.position[l.axis] = C[0]), l.node.position[l.axis] < C[0] && (l.node.position[l.axis] = C[1]);
      },
      pause(p) {
        m = !!p;
      },
      reset() {
        for (const p of a) p.node.position.copy(p.base);
      },
      dispose() {
      }
    };
  }
}, Te = "varying vec3 vWorld; void main(){ vWorld = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }", qe = `varying vec3 vWorld;
uniform float time; uniform float cloud; uniform float night; uniform float dusk; uniform vec3 sunDir; uniform vec3 ground; uniform float groundMix; uniform float flatMix; uniform vec3 flatColor;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p){ float v = 0.; float a = .5; for (int i = 0; i < 5; i++){ v += a * noise(p); p = p * 2.03 + 13.5; a *= .5; } return v; }
void main(){
  vec3 d = normalize(vWorld); float h = max(d.y, 0.);
  vec3 color = mix(vec3(.74, .83, .89), vec3(.18, .41, .70), pow(h, .45));
  color = mix(color, mix(vec3(.93, .62, .40), vec3(.30, .34, .55), pow(h, .4)), dusk * .82);
  float sd = max(dot(d, normalize(sunDir)), 0.);
  color += vec3(1., .93, .78) * (pow(sd, 900.) * 6. + pow(sd, 12.) * .18) * (1. - night);
  vec2 uv = d.xz / (max(d.y, .06) + .24) * 2.6 + vec2(time * .004, 0.);
  float n = fbm(uv); float c = smoothstep(.68 - cloud * .42, .79 - cloud * .33, n) * smoothstep(-.02, .16, d.y);
  color = mix(color, mix(vec3(.70, .77, .81), vec3(1.), smoothstep(.4, .8, n)), c * .9);
  color = mix(color, vec3(.016, .033, .085) + h * .02, night * .98);
  float star = step(.9978, hash(floor(d.xz / (d.y + .2) * 850.))) * smoothstep(.1, .5, h); color += star * night * .7;
  // 地平线以下：地面色（玻璃里反出来的是地面，不是天空）
  // groundMix=1（只用于烘环境贴图）：地面色；=0（看得见的天空）：延续地平线雾色，免得小场地边缘外露出一条地面色带
  vec3 haze = mix(mix(vec3(.74, .83, .89), vec3(.93, .62, .40), dusk * .6), vec3(.03, .05, .1), night * .95);
  vec3 g = mix(haze, mix(ground, ground * .12, night), groundMix);
  color = mix(color, g, 1. - smoothstep(-.08, 0., d.y));   // smoothstep 的两个边界必须递增，反着写在部分驱动上是未定义（会出黑）
  color = mix(color, flatColor, flatMix);
  gl_FragColor = vec4(color, 1.);
}`, _t = {
  id: "sky",
  version: 1,
  create(o, i, r = {}) {
    const e = Number(r.radius) || 1500, s = {
      time: { value: 0 },
      cloud: { value: r.cloud ?? 0.4 },
      night: { value: 0 },
      dusk: { value: 0 },
      sunDir: { value: new k.Vector3(-0.5, 0.7, 0.4) },
      ground: { value: new k.Color().setHex(parseInt(String(r.ground || "#5a6352").replace("#", ""), 16), k.LinearSRGBColorSpace) },
      // 着色器里的颜色按原值输出（天空色也是这么写的），不做线性化
      groundMix: { value: 0 },
      flatMix: { value: 0 },
      flatColor: { value: new k.Color(16777215) }
    }, x = { ...s, groundMix: { value: 1 } }, C = new k.ShaderMaterial({ side: k.BackSide, depthWrite: !1, uniforms: s, vertexShader: Te, fragmentShader: qe }), d = new k.Mesh(new k.SphereGeometry(e, 48, 24), C);
    d.name = "sky@1", d.frustumCulled = !1, d.renderOrder = -1e3, o.scene.add(d);
    const c = new k.Scene(), t = new k.ShaderMaterial({ side: k.BackSide, depthWrite: !1, uniforms: x, vertexShader: Te, fragmentShader: qe }), a = new k.Mesh(new k.SphereGeometry(100, 48, 24), t);
    c.add(a);
    const h = Number(r.envSize) || 256, n = new k.WebGLCubeRenderTarget(h, { type: k.HalfFloatType }), f = new k.CubeCamera(1, 1e3, n);
    c.add(f);
    const v = new k.PMREMGenerator(o.renderer);
    let m = null;
    const p = r.envDefault ?? 0.3, g = r.envSlots || {};
    function l() {
      o.sun && s.sunDir.value.copy(o.sun.position).normalize(), f.update(o.renderer, c);
      const u = v.fromCubemap(n.texture);
      m && m.dispose(), m = u, o.scene.environment = o.studioOn ? null : m.texture;
      for (const [B, A] of o.materials || [])
        !A || !("envMapIntensity" in A) || (A.envMapIntensity = g[B] ?? p, A.envMap && g[B] !== void 0 && (A.envMap = null), A.needsUpdate = !0);
    }
    return {
      kind: "sky",
      sky: d,
      environment({ weather: u, hour: B, night: A }) {
        s.night.value = A ? 1 : 0, s.dusk.value = !A && (B < 8 || B > 17) ? 1 : 0, s.cloud.value = u === "sunny" ? r.cloud ?? 0.4 : u === "cloudy" ? 0.95 : 1.4, d.visible = !o.studioOn, l();
      },
      update(u) {
        d.position.copy(o.camera.position), s.time.value += u;
      },
      dispose() {
        o.scene.remove(d), o.scene.environment === m?.texture && (o.scene.environment = null), d.geometry.dispose(), a.geometry.dispose(), C.dispose(), t.dispose(), n.dispose(), m && m.dispose(), v.dispose();
      }
    };
  }
}, wt = { "precipitation@1": yt, "campus-life@1": Dt, "traffic@1": bt, "sky@1": _t };
function Le(o) {
  let i = (o >>> 0) + 1831565813;
  return i = Math.imul(i ^ i >>> 15, i | 1), i ^= i + Math.imul(i ^ i >>> 7, i | 61), ((i ^ i >>> 14) >>> 0) / 4294967296;
}
const kt = {
  build(o, i = {}, { palette: r = {} } = {}) {
    const e = i.semantic || "racks", s = i.floorY || 0, x = i.height || 9, C = i.beams || [1.8, 3.6, 5.4, 7.2], d = i.fill ?? 0.7, c = i.seed || 1, t = { upright: 3108784, beam: 15694380, cargo: 13215610, cargo2: 14467995, ...i.colors || {} }, a = (l, u, B = {}) => {
      const A = new k.MeshStandardMaterial({ color: r[l] === void 0 ? u : r[l], roughness: 0.75, ...B });
      return A.color.convertSRGBToLinear(), A.name = l, A;
    }, h = new k.BoxGeometry(1, 1, 1), n = { "rack.upright": [], "rack.beam": [], "rack.cargo": [], "rack.cargo2": [] }, f = (l, u, B, A, E, y) => new k.Matrix4().compose(new k.Vector3(l, u, B), new k.Quaternion(), new k.Vector3(A, E, y)), v = /* @__PURE__ */ new Set(), m = i.keepout || [], p = (i.bays || []).filter(([l, u, B, A]) => !m.some(([E, y, b]) => Math.abs(E - l) < B / 2 + b && Math.abs(y - u) < A / 2 + b));
    p.forEach(([l, u, B, A], E) => {
      for (const S of [-1, 1]) for (const F of [-1, 1]) {
        const D = l + S * (B / 2 - 0.04), _ = u + F * (A / 2), w = Math.round(D * 50) + "," + Math.round(_ * 50);
        v.has(w) || (v.add(w), n["rack.upright"].push(f(D, s + x / 2, _, 0.08, x, 0.08)));
      }
      for (const S of [...C, x - 0.1]) for (const F of [-1, 1]) n["rack.beam"].push(f(l + F * (B / 2 - 0.04), s + S, u, 0.06, 0.12, A - 0.08));
      const y = A > 3.3 ? 3 : A > 2 ? 2 : 1, b = A / y;
      [0, ...C].forEach((S, F) => {
        for (let D = 0; D < y; D++) {
          const _ = Le(c * 7919 + E * 131 + F * 17 + D);
          if (_ > d) continue;
          const w = 0.85 + Le(E * 31 + F * 7 + D * 3 + c) * 0.45;
          n[_ < d / 2 ? "rack.cargo" : "rack.cargo2"].push(f(l, s + S + 0.07 + w / 2, u - A / 2 + b * (D + 0.5), B * 0.86, w, Math.min(1.1, b * 0.86)));
        }
      });
    });
    const g = [];
    for (const [l, u] of Object.entries(n)) {
      if (!u.length) continue;
      const B = a(l, l === "rack.upright" ? t.upright : l === "rack.beam" ? t.beam : l === "rack.cargo" ? t.cargo : t.cargo2, l === "rack.upright" ? { metalness: 0.3 } : {}), A = new k.InstancedMesh(h, B, u.length);
      u.forEach((E, y) => A.setMatrixAt(y, E)), A.name = e + "|" + l, A.userData.semantic = e, A.userData.generated = "racks@1", A.castShadow = l === "rack.upright", A.receiveShadow = !0, o.add(A), g.push(A);
    }
    return { meshes: g, stats: { bays: p.length, removed: (i.bays || []).length - p.length, instances: Object.values(n).reduce((l, u) => l + u.length, 0) } };
  }
}, St = { "racks@1": kt };
function Mt(o) {
  const i = document.createElement("canvas");
  i.width = 512, i.height = 1024;
  const r = i.getContext("2d"), e = r.createLinearGradient(0, 0, 0, 1024);
  e.addColorStop(0, "#14282d"), e.addColorStop(0.3, "#243c40"), e.addColorStop(0.55, "#698185"), e.addColorStop(0.82, "#334c50"), e.addColorStop(1, "#172d31"), r.fillStyle = e, r.fillRect(0, 0, 512, 1024);
  for (let t = 0; t < 3; t++) {
    const a = t * 341;
    r.fillStyle = "rgba(10,23,27,.6)", r.fillRect(0, a + 6, 512, 43);
    for (let h = -64; h < 576; h += 64)
      r.strokeStyle = "rgba(16,31,34,.65)", r.lineWidth = 5, r.beginPath(), r.moveTo(h, a + 38), r.lineTo(h + 52, a + 105), r.lineTo(h + 52, a + 319), r.stroke(), r.strokeStyle = "rgba(166,189,187,.32)", r.lineWidth = 2, r.beginPath(), r.moveTo(h + 7, a + 40), r.lineTo(h + 59, a + 105), r.lineTo(h + 59, a + 319), r.stroke();
    r.fillStyle = "rgba(157,173,170,.4)", r.fillRect(0, a + 274, 512, 14), r.fillStyle = "rgba(13,29,32,.75)", r.fillRect(0, a + 291, 512, 11), r.strokeStyle = "rgba(30,48,51,.6)", r.lineWidth = 3;
    for (let h = 18; h < 512; h += 85)
      r.strokeRect(h, a + 145, 48, 99), r.strokeRect(h + 7, a + 152, 34, 84);
  }
  for (let t = 0; t < 4; t++) {
    const a = t * 128;
    r.fillStyle = t % 2 ? "rgba(142,175,180,.09)" : "rgba(8,32,38,.12)", r.fillRect(a, 0, 128, 1024), r.fillStyle = "rgba(7,23,29,.7)", r.fillRect(a, 0, 5, 1024), r.fillRect(a + 120, 0, 4, 1024), r.fillStyle = "rgba(176,205,205,.42)", r.fillRect(a + 7, 0, 2, 1024), r.fillRect(a + 116, 0, 2, 1024);
    for (let h = 0; h < 1024; h += 170.5)
      r.fillStyle = "rgba(12,31,36,.55)", r.fillRect(a, h, 128, 4), r.fillStyle = "rgba(163,191,194,.36)", r.fillRect(a, h + 5, 128, 2);
  }
  const s = r.createLinearGradient(0, 0, 512, 600);
  s.addColorStop(0, "rgba(192,222,233,.03)"), s.addColorStop(0.48, "rgba(169,201,211,.18)"), s.addColorStop(1, "rgba(130,169,183,0)"), r.fillStyle = s, r.fillRect(0, 0, 512, 1024);
  const x = new k.CanvasTexture(i);
  x.colorSpace = k.SRGBColorSpace, x.wrapS = k.RepeatWrapping, x.anisotropy = o ? Math.min(8, o.capabilities.getMaxAnisotropy()) : 8;
  const C = [];
  for (let t = 0; t < 6; t++) {
    const a = document.createElement("canvas");
    a.width = a.height = 256;
    const h = a.getContext("2d"), n = h.createLinearGradient(0, 0, 0, 256);
    n.addColorStop(0, "#688bad"), n.addColorStop(0.5, "#b5cbd4"), n.addColorStop(0.63, "#829491"), n.addColorStop(1, "#344941"), h.fillStyle = n, h.fillRect(0, 0, 256, 256);
    for (let f = 0; f < 12; f++) {
      const v = (f * 83 + t * 39) % 256, m = 20 + f * 37 % 105, p = h.createRadialGradient(v, m, 2, v, m, 36);
      p.addColorStop(0, "rgba(245,250,250,.4)"), p.addColorStop(1, "rgba(245,250,250,0)"), h.fillStyle = p, h.fillRect(0, 0, 256, 256);
    }
    C.push(a);
  }
  const d = new k.CubeTexture(C);
  d.colorSpace = k.SRGBColorSpace, d.needsUpdate = !0;
  const c = new k.MeshStandardMaterial({
    color: 12966873,
    map: x,
    roughness: 0.28,
    metalness: 0.22,
    envMap: d,
    envMapIntensity: 0.32,
    emissive: 6652535,
    emissiveMap: x,
    emissiveIntensity: 0
  });
  return c.color.convertSRGBToLinear(), c.name = "facade.glass", { facadeGlass: c, facadeTexture: x, reflection: d };
}
function Rt() {
  const i = [], r = [(C, d) => [1, -d, -C], (C, d) => [-1, -d, C], (C, d) => [C, 1, d], (C, d) => [C, -1, -d], (C, d) => [C, -d, 1], (C, d) => [-C, -d, -1]], e = (C, d, c) => C.map((t, a) => t + (d[a] - t) * c);
  for (const C of r) {
    const d = document.createElement("canvas");
    d.width = d.height = 256;
    const c = d.getContext("2d"), t = c.createImageData(256, 256);
    for (let a = 0; a < 256; a++) for (let h = 0; h < 256; h++) {
      let [n, f, v] = C(2 * (h + 0.5) / 256 - 1, 2 * (a + 0.5) / 256 - 1);
      const m = Math.hypot(n, f, v);
      n /= m, f /= m, v /= m;
      const p = Math.atan2(v, n), g = Math.max(0, Math.min(1, f));
      let l = e([202, 215, 221], [96, 139, 181], Math.sqrt(g));
      const u = Math.max(0, Math.sin(p * 3 + f * 8) * Math.sin(p * 7 - f * 13)) * 0.25;
      f > 0 && (l = e(l, [242, 244, 243], u));
      const B = Math.max(0, n * -0.65 + v * 0.76) * Math.exp(-Math.pow((f - 0.23) * 3, 2)) * 0.1;
      l = e(l, [248, 221, 179], B);
      const A = Math.floor((p + Math.PI) * 3), E = (p + Math.PI) * 3 % 1, y = 0.08 + 0.43 * (0.5 + 0.5 * Math.sin(A * 13.7));
      if (f < y && E > 0.09 && E < 0.9) {
        const S = 0.5 + 0.5 * Math.sin(A * 4.3);
        l = e([57, 73, 82], [133, 151, 159], S), E % 0.28 < 0.015 && (l = e(l, [211, 224, 230], 0.18));
      }
      f < -0.65 && (l = e([30, 43, 45], [67, 82, 82], Math.max(0, 1 + f)));
      const b = (a * 256 + h) * 4;
      for (let S = 0; S < 3; S++) t.data[b + S] = l[S];
      t.data[b + 3] = 255;
    }
    c.putImageData(t, 0, 0), i.push(d);
  }
  const s = new k.CubeTexture(i);
  s.colorSpace = k.SRGBColorSpace, s.needsUpdate = !0;
  const x = new k.MeshStandardMaterial({ color: 8690083, metalness: 0.35, roughness: 0.32, envMap: s, envMapIntensity: 0.62 });
  return x.color.convertSRGBToLinear(), x.name = "wangchao.glass", { glass: x, reflection: s };
}
function zt(o) {
  const i = /* @__PURE__ */ new Map(), r = (s, x) => (i.has(s) || i.set(s, x()), i.get(s)), e = {
    smartFacade: () => r("smartFacade", () => Mt(o)),
    towerGlass: () => r("towerGlass", () => Rt()),
    /** 按槽名取预设材质；没有对应预设时返回 null（加载器保留文件里的材质） */
    bySlot(s) {
      return s === "facade.glass" ? e.smartFacade().facadeGlass : s === "wangchao.glass" ? e.towerGlass().glass : null;
    },
    dispose() {
      for (const s of i.values()) for (const x of Object.values(s)) x && x.dispose && x.dispose();
      i.clear();
    }
  };
  return e;
}
const Ht = Object.freeze([
  "focus",
  "reset",
  "top",
  "orbit",
  "pause",
  "view",
  "labels",
  "studio",
  "environment",
  "snapshots",
  "theme",
  "select",
  "explodeFloor",
  "closeFloor",
  "mode",
  "layer",
  "router",
  "roomHighlight",
  "planView",
  "highlight"
]), Pt = {
  fov: 43,
  near: 1,
  far: 1800,
  pixelRatioMax: 1.65,
  exposure: 0.85,
  controls: { minDistance: 40, maxDistance: 850, maxPolarAngle: Math.PI * 0.485, autoRotateSpeed: 0.45 },
  sun: { color: 16772824, position: [-100, 180, 100], shadowMapSize: 2048, shadowExtent: 210, shadowFar: 600, shadowBias: -3e-4 },
  hemisphere: { sky: 14151423, ground: 5924432 },
  sky: { day: 11060956, night: 595237, overcast: 9018281, studio: 16777215 },
  fog: { normal: 9e-4, fog: 7e-3 },
  lights: { sun: [2.4, 0.9, 0.15], ambient: [1.3, 0.5] }
  // [晴, 阴, 夜] / [日, 夜]，r115 艺术家单位
};
class Ie {
  /**
   * @param {HTMLElement} container
   * @param {object} opts
   *   - emit(type, payload)       事件出口（labels / stats / snapshots / select）
   *   - palette                   主题场景调色板（skyDay / skyNight / studioSky / studioGround 等）
   *   - studio                    初始是否纯白背景
   *   - emitSelect                点击楼栋时是否发 select 事件（Smart 现状为 false，只聚焦）
   *   - supports                  当前模型声明支持的能力（can() 的依据）
   */
  constructor(i, r = {}) {
    this.container = i, this.opts = r, this.emit = r.emit || (() => {
    }), this.palette = r.palette || {}, this.supports = new Set(r.supports || []), this.renderer = new k.WebGLRenderer({ antialias: !0, preserveDrawingBuffer: !0 }), this.presets = zt(this.renderer), this.scene = new k.Scene(), r.legacyLook !== !1 && jr(this.scene), this.behaviors = [], this._disposables = [], this.paused = !1, this.disposed = !1, this.fly = null, this.weather = "sunny", this.hour = 14, this.studioOn = !!r.studio, this._frames = 0, this._statsAt = performance.now(), this._labelsAt = 0, this._last = performance.now();
  }
  /** 装入模型：{ root, model: { viewer, home, semantics }, slots? } */
  setModel({ root: i, model: r }) {
    const e = { ...Pt, ...r.viewer || {} };
    this.cfg = e, this.model = r;
    const s = this.renderer;
    s.setPixelRatio(Math.min(devicePixelRatio, e.pixelRatioMax)), s.outputColorSpace = k.SRGBColorSpace, s.toneMapping = k.ACESFilmicToneMapping, s.toneMappingExposure = e.exposure, s.shadowMap.enabled = !0, s.shadowMap.type = k.PCFShadowMap, this.container.appendChild(s.domElement), this.camera = new k.PerspectiveCamera(e.fov, 1, e.near, e.far);
    const x = this.controls = new Xr(this.camera, s.domElement);
    x.enableDamping = !0, Object.assign(x, e.controls);
    const C = e.sun;
    this.sun = new k.DirectionalLight(C.color, 2.4), this.sun.position.set(...C.position), this.sun.castShadow = !0, this.sun.shadow.mapSize.set(C.shadowMapSize, C.shadowMapSize), Object.assign(this.sun.shadow.camera, { left: -C.shadowExtent, right: C.shadowExtent, top: C.shadowExtent, bottom: -C.shadowExtent, near: 1, far: C.shadowFar }), this.sun.shadow.bias = C.shadowBias, this.ambient = new k.HemisphereLight(e.hemisphere.sky, e.hemisphere.ground, 1.3), this.scene.add(this.sun, this.ambient), this.root = i, this.scene.add(i), this.generated = [];
    for (const c of r.semantics?.generators || []) {
      const t = St[c.plugin];
      t && this.generated.push(t.build(i, c.params, { palette: this.palette }));
    }
    this.index = Ft(r.semantics?.tree), this.cameras = new Map((r.semantics?.cameras || []).map((c) => [c.id, c])), this.materials = /* @__PURE__ */ new Map(), i.traverse((c) => {
      c.isMesh && (Array.isArray(c.material) ? c.material : [c.material]).forEach((t) => {
        t && t.name && !this.materials.has(t.name) && this.materials.set(t.name, t);
      });
    }), this._materialBase = new Map([...this.materials].map(([c, t]) => [c, { color: t.color && t.color.clone(), emissiveIntensity: t.emissiveIntensity, roughness: t.roughness }])), this.sets = /* @__PURE__ */ new Map();
    for (const [c, t] of Object.entries(r.semantics?.instanceSets || {}))
      this.sets.set(c, { name: c, parent: t.parent, ids: t.ids, index: new Map(t.ids.map((a, h) => [a, h])), meshes: [], base: /* @__PURE__ */ new Map() });
    i.traverse((c) => {
      if (!c.isInstancedMesh) return;
      const t = w0(c), a = t && t[0] === "@" ? this.sets.get(t.slice(1)) : null;
      a && (c.userData.instanceSet = a.name, a.meshes.push(c), a.base.set(c, c.instanceMatrix.array.slice()));
    }), this.pickable = [], i.traverse((c) => {
      if (!c.isMesh) return;
      const t = c.userData.instanceSet && this.sets.get(c.userData.instanceSet), a = this.index.get(t ? t.parent : w0(c));
      a && a.pickable !== !1 && this.pickable.push(c);
    }), this.layerDefs = r.semantics?.layers || [], this.layerState = Object.fromEntries(this.layerDefs.map((c) => [c.id, c.default !== !1])), this.modes = r.semantics?.modes || [], this.modeId = this.modes[0]?.id || null;
    for (const c of r.semantics?.behaviors || []) {
      const t = wt[c.plugin];
      t && this.behaviors.push(t.create(this, c, c.params));
    }
    this.overlay = new k.Group(), this.overlay.name = "highlight-overlay", this.scene.add(this.overlay), this._layerCover = /* @__PURE__ */ new Map();
    for (const c of this.layerDefs) for (const t of c.targets || []) for (const a of this._targets(t))
      a.instance === void 0 && (this._layerCover.has(a.mesh) || this._layerCover.set(a.mesh, /* @__PURE__ */ new Set()), this._layerCover.get(a.mesh).add(c.id));
    this._applyLayers(), this._onDown = (c) => {
      this._down = [c.clientX, c.clientY], this.fly = null;
    }, this._onUp = (c) => this._click(c), s.domElement.addEventListener("pointerdown", this._onDown), s.domElement.addEventListener("pointerup", this._onUp), this._resize = () => {
      const c = this.container.clientWidth, t = Math.max(1, this.container.clientHeight);
      s.setSize(c, t), this.camera.aspect = c / t, this.camera.updateProjectionMatrix();
    }, this._observer = new ResizeObserver(this._resize), this._observer.observe(this.container), this._resize();
    const d = r.home || this.cameras.get("home");
    return this.home = { position: new k.Vector3(...d.position), target: new k.Vector3(...d.target) }, this.camera.position.copy(this.home.position), x.target.copy(this.home.target), x.update(), this.environment(), this._animate = this._animate.bind(this), this._frame = requestAnimationFrame(this._animate), this._snapshotTimer = setTimeout(() => this.snapshots(), 500), this;
  }
  can(i) {
    return this.supports.has(i);
  }
  // ---------------- 环境 ----------------
  _pick(i, r) {
    return this.palette[i] === void 0 ? r : this.palette[i];
  }
  environment(i = "sunny", r = 14) {
    this.hour = r, this.weather = i;
    const e = r < 6 || r > 19, s = this.cfg.sky;
    this.scene.background = new k.Color(this.studioOn ? this._pick("studioSky", s.studio) : e ? this._pick("skyNight", s.night) : i === "sunny" ? this._pick("skyDay", s.day) : s.overcast), this.scene.fog = new k.FogExp2(this.scene.background, i === "fog" ? this.cfg.fog.fog : this.cfg.fog.normal);
    const x = this.cfg.lights;
    this.sun.intensity = e ? x.sun[2] : i === "sunny" ? x.sun[0] : x.sun[1], this.ambient.intensity = e ? x.ambient[1] : x.ambient[0], this.sun.position.set(Math.cos(r / 24 * Math.PI * 2) * 160, 80 + Math.sin(r / 24 * Math.PI) * 120, 100), this._applyMaterialStates({ night: e, weather: i, studio: this.studioOn }), this._themeMaterials && this._themeMaterials();
    for (const C of this.behaviors) C.environment && C.environment({ weather: i, hour: r, night: e });
    return !0;
  }
  _applyMaterialStates(i) {
    const r = this.model.semantics?.materialStates || {};
    for (const [e, s] of Object.entries(r)) {
      const x = this.materials.get(e);
      if (!x) continue;
      const C = this._materialBase.get(e), d = (c) => {
        for (const [t, a] of Object.entries(c || {}))
          t === "color" ? x.color.set(this._pick(a, 16777215)).convertSRGBToLinear() : x[t] = a;
      };
      s.studio && C.color && x.color.copy(C.color), d(s.default), i.night && d(s.night), i.weather === "rain" && d(s.rain), i.weather === "snow" && d(s.snow), i.weather === "fog" && d(s.fog), i.studio && d(s.studio);
    }
  }
  /** 主题（皮肤）：名字（内置，见 themes/）或主题对象；null = 恢复模型原样。返回生效的主题。见 docs/THEME.md */
  theme(i) {
    return i === void 0 ? this._theme || null : gt(this, i);
  }
  studio(i) {
    return this.studioOn = !!i, this.environment(this.weather, this.hour), !0;
  }
  // ---------------- 相机 ----------------
  _flyTo(i) {
    this.controls.autoRotate = !1, this.fly = { position: new k.Vector3(...i.position), target: new k.Vector3(...i.target) };
  }
  focus(i) {
    const r = this._focusMode(i);
    r && r !== this.modeId && this.mode(r, { keepCamera: !0 });
    const e = this.cameras.get("focus:" + i) || this._autoFrame(i);
    return e ? (this._flyTo(e), this.index.get(i)?.type === "device" && this.highlight([i]), this.opts.emitSelect && this.emit("select", this._selectPayload(i)), !0) : !1;
  }
  /** 语义节点（或其祖先）上的 focusMode：聚焦前先切到该模式（例如库内设备先去顶） */
  _focusMode(i) {
    return this._inherit(i, "focusMode");
  }
  /** 沿语义树向上找第一个设置了 key 的节点 */
  _inherit(i, r) {
    for (let e = i; e; e = this.index.get(e)?.parent) {
      const s = this.index.get(e);
      if (s && s[r] !== void 0) return s[r];
    }
  }
  /** 没有命名机位时按包围盒取景：沿当前视线方向后退，保证俯角 */
  _autoFrame(i) {
    const r = this.boundsOf(i);
    if (!r) return null;
    let e = r.getCenter(new k.Vector3()), s = r.getSize(new k.Vector3()).length();
    const x = this._inherit(i, "focusDistance");
    if (x) {
      const a = this.boundsOf(i, { first: !0 });
      a && (e = a.getCenter(new k.Vector3()));
    }
    let C = this.camera.position.clone().sub(this.controls.target);
    const d = this._inherit(i, "focusFrom"), c = d && this._targets(i).find((a) => a.instance !== void 0);
    if (c) {
      const a = new k.Matrix4();
      c.mesh.getMatrixAt(c.instance, a), a.premultiply(c.mesh.matrixWorld), C = new k.Vector3().setFromMatrixColumn(a, d === "z" ? 2 : 0), C.y = 0;
    }
    C.lengthSq() < 1e-6 && C.set(1, 1, 1), C.normalize(), C.y < 0.45 && (C.y = 0.45, C.normalize());
    const t = Math.max(x || s * 1.6 + 2.2, (this.controls.minDistance || 0) * 1.05);
    return { position: e.clone().addScaledVector(C, t).toArray(), target: e.toArray() };
  }
  /** 语义 id（楼、分组、单台设备）的世界包围盒 */
  boundsOf(i, { first: r = !1 } = {}) {
    const e = new k.Box3(), s = new k.Box3(), x = new k.Matrix4();
    let C = !1;
    const d = this._targets(i).filter((c) => c.mesh.visible);
    for (const c of r ? d.slice(0, 1) : d) {
      const t = c.mesh.geometry;
      t.boundingBox || t.computeBoundingBox(), c.mesh.updateMatrixWorld(), c.instance !== void 0 ? (c.mesh.getMatrixAt(c.instance, x), s.copy(t.boundingBox).applyMatrix4(x).applyMatrix4(c.mesh.matrixWorld)) : c.mesh.isInstancedMesh ? (c.mesh.boundingBox || c.mesh.computeBoundingBox(), s.copy(c.mesh.boundingBox).applyMatrix4(c.mesh.matrixWorld)) : s.copy(t.boundingBox).applyMatrix4(c.mesh.matrixWorld), e.union(s), C = !0;
    }
    return C ? e : null;
  }
  /** 一个语义 id 覆盖的渲染对象：普通网格整件；实例集整件（分组）或单个实例（单台设备） */
  _targets(i) {
    const r = [];
    return this.root.traverse((e) => {
      if (!e.isMesh) return;
      const s = e.userData.instanceSet && this.sets.get(e.userData.instanceSet);
      if (s)
        if (We(this.index, s.parent, i)) r.push({ mesh: e });
        else {
          const x = s.index.get(i);
          x !== void 0 && r.push({ mesh: e, instance: x });
        }
      else We(this.index, w0(e), i) && r.push({ mesh: e });
    }), r;
  }
  _selectPayload(i) {
    const r = this.index.get(i);
    return r ? { id: i, type: r.type, name: r.name, ...r.props || {} } : { id: i };
  }
  reset() {
    return this.fly = { position: this.home.position.clone(), target: this.home.target.clone() }, this.controls.autoRotate = !1, !0;
  }
  top() {
    const i = this.cameras.get("top");
    return i ? (this.controls.autoRotate = !1, this.fly = { position: new k.Vector3(...i.position), target: this.home.target.clone() }, !0) : !1;
  }
  orbit(i) {
    return this.controls.autoRotate = i, this.fly = null, !0;
  }
  pause(i) {
    return this.paused = i, this._frames = 0, this._statsAt = performance.now(), !0;
  }
  /** 不带参数：读当前机位；带参数：平滑飞过去（演示模式每页的视角） */
  view(i) {
    if (!i) return { camera: this.camera.position.toArray(), target: this.controls.target.toArray() };
    const r = i.position, e = i.target;
    !Array.isArray(r) || r.length < 3 || (this.controls.autoRotate = !1, this.fly = { position: new k.Vector3(r[0], r[1], r[2]), target: Array.isArray(e) && e.length >= 3 ? new k.Vector3(e[0], e[1], e[2]) : this.controls.target.clone() });
  }
  snapshots() {
    const i = [...this.cameras.values()].filter((x) => x.id.startsWith("snapshot-"));
    if (!i.length) return !1;
    const r = this.camera.position.clone(), e = [], s = this.renderer;
    if (!s.domElement.width || !s.domElement.height)
      return (this._snapshotTries = (this._snapshotTries || 0) + 1) <= 20 && !this.disposed && (this._snapshotTimer = setTimeout(() => this.snapshots(), 500)), !1;
    for (const x of i) {
      this.camera.position.set(...x.position), this.camera.lookAt(...x.target), s.render(this.scene, this.camera);
      const C = document.createElement("canvas");
      C.width = 480, C.height = 270, C.getContext("2d").drawImage(s.domElement, 0, 0, 480, 270), e.push(C.toDataURL("image/jpeg", 0.82));
    }
    return this.camera.position.copy(r), this.camera.lookAt(this.controls.target), s.render(this.scene, this.camera), this.emit("snapshots", e), !0;
  }
  // ---------------- 拾取 / 高亮 / 显隐 ----------------
  pickAt(i, r) {
    const e = this.renderer.domElement.getBoundingClientRect(), s = new k.Raycaster();
    s.setFromCamera(new k.Vector2((i - e.left) / e.width * 2 - 1, -(r - e.top) / e.height * 2 + 1), this.camera);
    const x = s.intersectObjects(this.pickable.filter((c) => c.visible))[0];
    if (!x) return null;
    const C = x.object.userData.instanceSet && this.sets.get(x.object.userData.instanceSet);
    return { id: C && x.instanceId !== void 0 ? C.ids[x.instanceId] : w0(x.object), point: x.point.toArray(), object: x.object, instanceId: x.instanceId };
  }
  _click(i) {
    if (!this._down || Math.hypot(i.clientX - this._down[0], i.clientY - this._down[1]) > 5) return;
    const r = this.pickAt(i.clientX, i.clientY);
    r && this.focus(r.id);
  }
  /** 覆盖层高亮（不替换原材质）。ids 为空数组时清除 */
  highlight(i = [], r = {}) {
    if (this.overlay.children.slice().forEach((C) => this.overlay.remove(C)), !i.length) return !0;
    const e = new k.MeshBasicMaterial({ color: r.color || 16738816, transparent: !0, opacity: r.opacity ?? 0.35, polygonOffset: !0, polygonOffsetFactor: -1, depthWrite: !1 }), s = new k.Matrix4(), x = /* @__PURE__ */ new Set();
    for (const C of i) for (const d of this._targets(C)) {
      const c = d.mesh;
      if (!c.visible) continue;
      const t = c.uuid + ":" + (d.instance ?? "*");
      if (x.has(t)) continue;
      x.add(t), c.updateMatrixWorld();
      let a;
      d.instance !== void 0 ? (a = new k.Mesh(c.geometry, e), c.getMatrixAt(d.instance, s), a.matrix.multiplyMatrices(c.matrixWorld, s)) : c.isInstancedMesh ? (a = new k.InstancedMesh(c.geometry, e, c.count), a.instanceMatrix = c.instanceMatrix, a.matrix.copy(c.matrixWorld), a.frustumCulled = !1) : (a = new k.Mesh(c.geometry, e), a.matrix.copy(c.matrixWorld)), a.matrixAutoUpdate = !1, a.renderOrder = 10, this.overlay.add(a);
    }
    return this.overlay.children.length > 0;
  }
  setVisible(i, r) {
    let e = 0;
    const s = new k.Matrix4().makeScale(0, 0, 0);
    for (const x of this._targets(i)) {
      if (e++, x.instance === void 0) {
        x.mesh.visible = r;
        continue;
      }
      const C = this.sets.get(x.mesh.userData.instanceSet).base.get(x.mesh);
      r ? x.mesh.setMatrixAt(x.instance, new k.Matrix4().fromArray(C, x.instance * 16)) : x.mesh.setMatrixAt(x.instance, s), x.mesh.instanceMatrix.needsUpdate = !0, x.mesh.boundingSphere = null, x.mesh.boundingBox = null;
    }
    return e > 0;
  }
  /** 图层：不带参数读全部开关；带参数设置一个 */
  layer(i, r) {
    return i !== void 0 && typeof r == "boolean" && i in this.layerState && (this.layerState[i] = r, this._applyLayers(), this.emit("layers", { ...this.layerState })), { ...this.layerState };
  }
  _applyLayers() {
    for (const [i, r] of this._layerCover) i.visible = [...r].every((e) => this.layerState[e]);
  }
  /** 模式：不带参数读当前模式；带参数切换（图层组合 + 机位） */
  mode(i, { keepCamera: r = !1 } = {}) {
    if (i === void 0) return this.modeId;
    const e = this.modes.find((s) => s.id === i);
    if (!e) return this.modeId;
    this.modeId = i;
    for (const [s, x] of Object.entries(e.layers || {})) s in this.layerState && (this.layerState[s] = x);
    if (this._applyLayers(), this.emit("layers", { ...this.layerState }), !r && e.camera) {
      const s = e.camera === "home" ? { position: this.home.position.toArray(), target: this.home.target.toArray() } : this.cameras.get(e.camera);
      s && this._flyTo(s);
    }
    return this.emit("mode", i), i;
  }
  // ---------------- 循环 ----------------
  _animate(i) {
    if (this.disposed) return;
    this._frame = requestAnimationFrame(this._animate);
    const r = Math.min((i - this._last) / 1e3, 0.05);
    if (this._last = i, !this.paused) {
      this.fly && (this.camera.position.lerp(this.fly.position, 0.05), this.controls.target.lerp(this.fly.target, 0.05), this.camera.position.distanceTo(this.fly.position) < 0.1 && (this.fly = null));
      for (const e of this.behaviors) e.update && e.update(r);
      this.controls.update(), this.renderer.render(this.scene, this.camera), i - this._labelsAt > 60 && (this._labelsAt = i, this.emit("labels", this.labels())), this._frames++, i - this._statsAt > 1200 && (this.emit("stats", Math.round(this._frames * 1e3 / (i - this._statsAt))), this._frames = 0, this._statsAt = i);
    }
  }
  /** 锚点投影到屏幕：[{ id, x, y, visible }]，id 为锚点指向的语义 id（与现有 onLabels 一致） */
  labels() {
    const i = this.container.clientWidth, r = this.container.clientHeight;
    return (this.model.semantics?.anchors || []).map((e) => {
      const s = new k.Vector3(...e.position).project(this.camera), x = !e.layer || this.layerState[e.layer] !== !1, C = { id: e.target, x: (s.x * 0.5 + 0.5) * i, y: (-s.y * 0.5 + 0.5) * r, visible: x && s.z > -1 && s.z < 1 };
      for (const d of ["text", "kind", "icon", "color"]) e[d] !== void 0 && (C[d] = e[d]);
      return C;
    });
  }
  /** 挂一个跟 Viewer 一起释放的东西（例：loadMap 建的 Draco 解码器 —— 它背后有 Worker 和 WASM 实例） */
  addDisposable(i) {
    return i && typeof i.dispose == "function" && this._disposables.push(i), i;
  }
  dispose() {
    this.disposed = !0, cancelAnimationFrame(this._frame), clearTimeout(this._snapshotTimer);
    for (const e of this._disposables.splice(0))
      try {
        e.dispose();
      } catch {
      }
    this._observer && this._observer.disconnect(), this.controls && this.controls.dispose();
    const i = this.renderer.domElement;
    i.removeEventListener("pointerdown", this._onDown), i.removeEventListener("pointerup", this._onUp), this.behaviors.forEach((e) => e.dispose && e.dispose());
    const r = /* @__PURE__ */ new Set();
    this.scene.traverse((e) => {
      e.geometry && r.add(e.geometry), e.material && (Array.isArray(e.material) ? e.material : [e.material]).forEach((s) => {
        r.add(s);
        for (const x of Object.values(s)) x && x.isTexture && r.add(x);
      });
    }), r.forEach((e) => e.dispose && e.dispose()), this.presets.dispose(), this.renderer.dispose(), i.remove();
  }
}
for (const o of Ht) o in Ie.prototype || (Ie.prototype[o] = function() {
  return !1;
});
var J = Uint8Array, B0 = Uint16Array, Ot = Int32Array, Dr = new J([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), yr = new J([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), Wt = new J([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), br = function(o, i) {
  for (var r = new B0(31), e = 0; e < 31; ++e)
    r[e] = i += 1 << o[e - 1];
  for (var s = new Ot(r[30]), e = 1; e < 30; ++e)
    for (var x = r[e]; x < r[e + 1]; ++x)
      s[x] = x - r[e] << 5 | e;
  return { b: r, r: s };
}, _r = br(Dr, 2), wr = _r.b, Tt = _r.r;
wr[28] = 258, Tt[258] = 28;
var qt = br(yr, 0), Lt = qt.b, me = new B0(32768);
for (var V = 0; V < 32768; ++V) {
  var f0 = (V & 43690) >> 1 | (V & 21845) << 1;
  f0 = (f0 & 52428) >> 2 | (f0 & 13107) << 2, f0 = (f0 & 61680) >> 4 | (f0 & 3855) << 4, me[V] = ((f0 & 65280) >> 8 | (f0 & 255) << 8) >> 1;
}
var F0 = (function(o, i, r) {
  for (var e = o.length, s = 0, x = new B0(i); s < e; ++s)
    o[s] && ++x[o[s] - 1];
  var C = new B0(i);
  for (s = 1; s < i; ++s)
    C[s] = C[s - 1] + x[s - 1] << 1;
  var d;
  if (r) {
    d = new B0(1 << i);
    var c = 15 - i;
    for (s = 0; s < e; ++s)
      if (o[s])
        for (var t = s << 4 | o[s], a = i - o[s], h = C[o[s] - 1]++ << a, n = h | (1 << a) - 1; h <= n; ++h)
          d[me[h] >> c] = t;
  } else
    for (d = new B0(e), s = 0; s < e; ++s)
      o[s] && (d[s] = me[C[o[s] - 1]++] >> 15 - o[s]);
  return d;
}), D0 = new J(288);
for (var V = 0; V < 144; ++V)
  D0[V] = 8;
for (var V = 144; V < 256; ++V)
  D0[V] = 9;
for (var V = 256; V < 280; ++V)
  D0[V] = 7;
for (var V = 280; V < 288; ++V)
  D0[V] = 8;
var kr = new J(32);
for (var V = 0; V < 32; ++V)
  kr[V] = 5;
var It = /* @__PURE__ */ F0(D0, 9, 1), Gt = /* @__PURE__ */ F0(kr, 5, 1), ue = function(o) {
  for (var i = o[0], r = 1; r < o.length; ++r)
    o[r] > i && (i = o[r]);
  return i;
}, a0 = function(o, i, r) {
  var e = i / 8 | 0;
  return (o[e] | o[e + 1] << 8) >> (i & 7) & r;
}, de = function(o, i) {
  var r = i / 8 | 0;
  return (o[r] | o[r + 1] << 8 | o[r + 2] << 16) >> (i & 7);
}, Ut = function(o) {
  return (o + 7) / 8 | 0;
}, ge = function(o, i, r) {
  return (i == null || i < 0) && (i = 0), (r == null || r > o.length) && (r = o.length), new J(o.subarray(i, r));
}, $t = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], Q = function(o, i, r) {
  var e = new Error(i || $t[o]);
  if (e.code = o, Error.captureStackTrace && Error.captureStackTrace(e, Q), !r)
    throw e;
  return e;
}, Nt = function(o, i, r, e) {
  var s = o.length, x = e ? e.length : 0;
  if (!s || i.f && !i.l)
    return r || new J(0);
  var C = !r, d = C || i.i != 2, c = i.i;
  C && (r = new J(s * 3));
  var t = function(d0) {
    var s0 = r.length;
    if (d0 > s0) {
      var K = new J(Math.max(s0 * 2, d0));
      K.set(r), r = K;
    }
  }, a = i.f || 0, h = i.p || 0, n = i.b || 0, f = i.l, v = i.d, m = i.m, p = i.n, g = s * 8;
  do {
    if (!f) {
      a = a0(o, h, 1);
      var l = a0(o, h + 1, 3);
      if (h += 3, l)
        if (l == 1)
          f = It, v = Gt, m = 9, p = 5;
        else if (l == 2) {
          var E = a0(o, h, 31) + 257, y = a0(o, h + 10, 15) + 4, b = E + a0(o, h + 5, 31) + 1;
          h += 14;
          for (var S = new J(b), F = new J(19), D = 0; D < y; ++D)
            F[Wt[D]] = a0(o, h + D * 3, 7);
          h += y * 3;
          for (var _ = ue(F), w = (1 << _) - 1, P = F0(F, _, 1), D = 0; D < b; ) {
            var O = P[a0(o, h, w)];
            h += O & 15;
            var u = O >> 4;
            if (u < 16)
              S[D++] = u;
            else {
              var W = 0, T = 0;
              for (u == 16 ? (T = 3 + a0(o, h, 3), h += 2, W = S[D - 1]) : u == 17 ? (T = 3 + a0(o, h, 7), h += 3) : u == 18 && (T = 11 + a0(o, h, 127), h += 7); T--; )
                S[D++] = W;
            }
          }
          var G = S.subarray(0, E), L = S.subarray(E);
          m = ue(G), p = ue(L), f = F0(G, m, 1), v = F0(L, p, 1);
        } else
          Q(1);
      else {
        var u = Ut(h) + 4, B = o[u - 4] | o[u - 3] << 8, A = u + B;
        if (A > s) {
          c && Q(0);
          break;
        }
        d && t(n + B), r.set(o.subarray(u, A), n), i.b = n += B, i.p = h = A * 8, i.f = a;
        continue;
      }
      if (h > g) {
        c && Q(0);
        break;
      }
    }
    d && t(n + 131072);
    for (var U = (1 << m) - 1, M = (1 << p) - 1, z = h; ; z = h) {
      var W = f[de(o, h) & U], H = W >> 4;
      if (h += W & 15, h > g) {
        c && Q(0);
        break;
      }
      if (W || Q(2), H < 256)
        r[n++] = H;
      else if (H == 256) {
        z = h, f = null;
        break;
      } else {
        var R = H - 254;
        if (H > 264) {
          var D = H - 257, $ = Dr[D];
          R = a0(o, h, (1 << $) - 1) + wr[D], h += $;
        }
        var N = v[de(o, h) & M], j = N >> 4;
        N || Q(3), h += N & 15;
        var L = Lt[j];
        if (j > 3) {
          var $ = yr[j];
          L += de(o, h) & (1 << $) - 1, h += $;
        }
        if (h > g) {
          c && Q(0);
          break;
        }
        d && t(n + 131072);
        var q = n + R;
        if (n < L) {
          var o0 = x - L, i0 = Math.min(L, q);
          for (o0 + n < 0 && Q(3); n < i0; ++n)
            r[n] = e[o0 + n];
        }
        for (; n < q; ++n)
          r[n] = r[n - L];
      }
    }
    i.l = f, i.p = z, i.b = n, i.f = a, f && (a = 1, i.m = m, i.d = v, i.n = p);
  } while (!a);
  return n != r.length && C ? ge(r, 0, n) : r.subarray(0, n);
}, Vt = /* @__PURE__ */ new J(0), n0 = function(o, i) {
  return o[i] | o[i + 1] << 8;
}, r0 = function(o, i) {
  return (o[i] | o[i + 1] << 8 | o[i + 2] << 16 | o[i + 3] << 24) >>> 0;
}, ve = function(o, i) {
  return r0(o, i) + r0(o, i + 4) * 4294967296;
};
function jt(o, i) {
  return Nt(o, { i: 2 }, i && i.out, i && i.dictionary);
}
var Ce = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), Xt = 0;
try {
  Ce.decode(Vt, { stream: !0 }), Xt = 1;
} catch {
}
var Kt = function(o) {
  for (var i = "", r = 0; ; ) {
    var e = o[r++], s = (e > 127) + (e > 223) + (e > 239);
    if (r + s > o.length)
      return { s: i, r: ge(o, r - 1) };
    s ? s == 3 ? (e = ((e & 15) << 18 | (o[r++] & 63) << 12 | (o[r++] & 63) << 6 | o[r++] & 63) - 65536, i += String.fromCharCode(55296 | e >> 10, 56320 | e & 1023)) : s & 1 ? i += String.fromCharCode((e & 31) << 6 | o[r++] & 63) : i += String.fromCharCode((e & 15) << 12 | (o[r++] & 63) << 6 | o[r++] & 63) : i += String.fromCharCode(e);
  }
};
function Ae(o, i) {
  if (i) {
    for (var r = "", e = 0; e < o.length; e += 16384)
      r += String.fromCharCode.apply(null, o.subarray(e, e + 16384));
    return r;
  } else {
    if (Ce)
      return Ce.decode(o);
    var s = Kt(o), x = s.s, r = s.r;
    return r.length && Q(8), x;
  }
}
var Yt = function(o, i) {
  return i + 30 + n0(o, i + 26) + n0(o, i + 28);
}, Zt = function(o, i, r) {
  var e = n0(o, i + 28), s = n0(o, i + 30), x = Ae(o.subarray(i + 46, i + 46 + e), !(n0(o, i + 8) & 2048)), C = i + 46 + e, d = Qt(o, C, s, r, r0(o, i + 20), r0(o, i + 24), r0(o, i + 42)), c = d[0], t = d[1], a = d[2];
  return [n0(o, i + 10), c, t, x, C + s + n0(o, i + 32), a];
}, Qt = function(o, i, r, e, s, x, C) {
  var d = s == 4294967295, c = x == 4294967295, t = C == 4294967295, a = i + r, h = d + c + t;
  if (e && h) {
    for (; i + 4 < a; i += 4 + n0(o, i + 2))
      if (n0(o, i) == 1)
        return [
          d ? ve(o, i + 4 + 8 * c) : s,
          c ? ve(o, i + 4) : x,
          t ? ve(o, i + 4 + 8 * (c + d)) : C,
          1
        ];
    e < 2 && Q(13);
  }
  return [s, x, C, 0];
};
function Jt(o, i) {
  for (var r = {}, e = o.length - 22; r0(o, e) != 101010256; --e)
    (!e || o.length - e > 65558) && Q(13);
  var s = n0(o, e + 8);
  if (!s)
    return {};
  var x = r0(o, e + 16), C = r0(o, e - 20) == 117853008;
  if (C) {
    var d = r0(o, e - 12);
    C = r0(o, d) == 101075792, C && (s = r0(o, d + 32), x = r0(o, d + 48));
  }
  for (var c = 0; c < s; ++c) {
    var t = Zt(o, x, C), a = t[0], h = t[1], n = t[2], f = t[3], v = t[4], m = t[5], p = Yt(o, m);
    x = v, a ? a == 8 ? r[f] = jt(o.subarray(p, p + h), { out: new J(n) }) : Q(14, "unknown compression type " + a) : r[f] = ge(o, p, p + h);
  }
  return r;
}
var pe = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function ea(o) {
  return o && o.__esModule && Object.prototype.hasOwnProperty.call(o, "default") ? o.default : o;
}
function ra(o) {
  if (Object.prototype.hasOwnProperty.call(o, "__esModule")) return o;
  var i = o.default;
  if (typeof i == "function") {
    var r = function e() {
      return this instanceof e ? Reflect.construct(i, arguments, this.constructor) : i.apply(this, arguments);
    };
    r.prototype = i.prototype;
  } else r = {};
  return Object.defineProperty(r, "__esModule", { value: !0 }), Object.keys(o).forEach(function(e) {
    var s = Object.getOwnPropertyDescriptor(o, e);
    Object.defineProperty(r, e, s.get ? s : {
      enumerable: !0,
      get: function() {
        return o[e];
      }
    });
  }), r;
}
var k0 = { exports: {} };
function ta(o) {
  throw new Error('Could not dynamically require "' + o + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var S0 = { exports: {} };
const aa = {}, na = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: aa
}, Symbol.toStringTag, { value: "Module" })), oa = /* @__PURE__ */ ra(na);
var ia = S0.exports, Ge;
function I() {
  return Ge || (Ge = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e();
    })(ia, function() {
      var r = r || (function(e, s) {
        var x;
        if (typeof window < "u" && window.crypto && (x = window.crypto), typeof self < "u" && self.crypto && (x = self.crypto), typeof globalThis < "u" && globalThis.crypto && (x = globalThis.crypto), !x && typeof window < "u" && window.msCrypto && (x = window.msCrypto), !x && typeof pe < "u" && pe.crypto && (x = pe.crypto), !x && typeof ta == "function")
          try {
            x = oa;
          } catch {
          }
        var C = function() {
          if (x) {
            if (typeof x.getRandomValues == "function")
              try {
                return x.getRandomValues(new Uint32Array(1))[0];
              } catch {
              }
            if (typeof x.randomBytes == "function")
              try {
                return x.randomBytes(4).readInt32LE();
              } catch {
              }
          }
          throw new Error("Native crypto module could not be used to get secure random number.");
        }, d = Object.create || /* @__PURE__ */ (function() {
          function l() {
          }
          return function(u) {
            var B;
            return l.prototype = u, B = new l(), l.prototype = null, B;
          };
        })(), c = {}, t = c.lib = {}, a = t.Base = /* @__PURE__ */ (function() {
          return {
            /**
             * Creates a new object that inherits from this object.
             *
             * @param {Object} overrides Properties to copy into the new object.
             *
             * @return {Object} The new object.
             *
             * @static
             *
             * @example
             *
             *     var MyType = CryptoJS.lib.Base.extend({
             *         field: 'value',
             *
             *         method: function () {
             *         }
             *     });
             */
            extend: function(l) {
              var u = d(this);
              return l && u.mixIn(l), (!u.hasOwnProperty("init") || this.init === u.init) && (u.init = function() {
                u.$super.init.apply(this, arguments);
              }), u.init.prototype = u, u.$super = this, u;
            },
            /**
             * Extends this object and runs the init method.
             * Arguments to create() will be passed to init().
             *
             * @return {Object} The new object.
             *
             * @static
             *
             * @example
             *
             *     var instance = MyType.create();
             */
            create: function() {
              var l = this.extend();
              return l.init.apply(l, arguments), l;
            },
            /**
             * Initializes a newly created object.
             * Override this method to add some logic when your objects are created.
             *
             * @example
             *
             *     var MyType = CryptoJS.lib.Base.extend({
             *         init: function () {
             *             // ...
             *         }
             *     });
             */
            init: function() {
            },
            /**
             * Copies properties into this object.
             *
             * @param {Object} properties The properties to mix in.
             *
             * @example
             *
             *     MyType.mixIn({
             *         field: 'value'
             *     });
             */
            mixIn: function(l) {
              for (var u in l)
                l.hasOwnProperty(u) && (this[u] = l[u]);
              l.hasOwnProperty("toString") && (this.toString = l.toString);
            },
            /**
             * Creates a copy of this object.
             *
             * @return {Object} The clone.
             *
             * @example
             *
             *     var clone = instance.clone();
             */
            clone: function() {
              return this.init.prototype.extend(this);
            }
          };
        })(), h = t.WordArray = a.extend({
          /**
           * Initializes a newly created word array.
           *
           * @param {Array} words (Optional) An array of 32-bit words.
           * @param {number} sigBytes (Optional) The number of significant bytes in the words.
           *
           * @example
           *
           *     var wordArray = CryptoJS.lib.WordArray.create();
           *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);
           *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);
           */
          init: function(l, u) {
            l = this.words = l || [], u != s ? this.sigBytes = u : this.sigBytes = l.length * 4;
          },
          /**
           * Converts this word array to a string.
           *
           * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex
           *
           * @return {string} The stringified word array.
           *
           * @example
           *
           *     var string = wordArray + '';
           *     var string = wordArray.toString();
           *     var string = wordArray.toString(CryptoJS.enc.Utf8);
           */
          toString: function(l) {
            return (l || f).stringify(this);
          },
          /**
           * Concatenates a word array to this word array.
           *
           * @param {WordArray} wordArray The word array to append.
           *
           * @return {WordArray} This word array.
           *
           * @example
           *
           *     wordArray1.concat(wordArray2);
           */
          concat: function(l) {
            var u = this.words, B = l.words, A = this.sigBytes, E = l.sigBytes;
            if (this.clamp(), A % 4)
              for (var y = 0; y < E; y++) {
                var b = B[y >>> 2] >>> 24 - y % 4 * 8 & 255;
                u[A + y >>> 2] |= b << 24 - (A + y) % 4 * 8;
              }
            else
              for (var S = 0; S < E; S += 4)
                u[A + S >>> 2] = B[S >>> 2];
            return this.sigBytes += E, this;
          },
          /**
           * Removes insignificant bits.
           *
           * @example
           *
           *     wordArray.clamp();
           */
          clamp: function() {
            var l = this.words, u = this.sigBytes;
            l[u >>> 2] &= 4294967295 << 32 - u % 4 * 8, l.length = e.ceil(u / 4);
          },
          /**
           * Creates a copy of this word array.
           *
           * @return {WordArray} The clone.
           *
           * @example
           *
           *     var clone = wordArray.clone();
           */
          clone: function() {
            var l = a.clone.call(this);
            return l.words = this.words.slice(0), l;
          },
          /**
           * Creates a word array filled with random bytes.
           *
           * @param {number} nBytes The number of random bytes to generate.
           *
           * @return {WordArray} The random word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.lib.WordArray.random(16);
           */
          random: function(l) {
            for (var u = [], B = 0; B < l; B += 4)
              u.push(C());
            return new h.init(u, l);
          }
        }), n = c.enc = {}, f = n.Hex = {
          /**
           * Converts a word array to a hex string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The hex string.
           *
           * @static
           *
           * @example
           *
           *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);
           */
          stringify: function(l) {
            for (var u = l.words, B = l.sigBytes, A = [], E = 0; E < B; E++) {
              var y = u[E >>> 2] >>> 24 - E % 4 * 8 & 255;
              A.push((y >>> 4).toString(16)), A.push((y & 15).toString(16));
            }
            return A.join("");
          },
          /**
           * Converts a hex string to a word array.
           *
           * @param {string} hexStr The hex string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Hex.parse(hexString);
           */
          parse: function(l) {
            for (var u = l.length, B = [], A = 0; A < u; A += 2)
              B[A >>> 3] |= parseInt(l.substr(A, 2), 16) << 24 - A % 8 * 4;
            return new h.init(B, u / 2);
          }
        }, v = n.Latin1 = {
          /**
           * Converts a word array to a Latin1 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The Latin1 string.
           *
           * @static
           *
           * @example
           *
           *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);
           */
          stringify: function(l) {
            for (var u = l.words, B = l.sigBytes, A = [], E = 0; E < B; E++) {
              var y = u[E >>> 2] >>> 24 - E % 4 * 8 & 255;
              A.push(String.fromCharCode(y));
            }
            return A.join("");
          },
          /**
           * Converts a Latin1 string to a word array.
           *
           * @param {string} latin1Str The Latin1 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);
           */
          parse: function(l) {
            for (var u = l.length, B = [], A = 0; A < u; A++)
              B[A >>> 2] |= (l.charCodeAt(A) & 255) << 24 - A % 4 * 8;
            return new h.init(B, u);
          }
        }, m = n.Utf8 = {
          /**
           * Converts a word array to a UTF-8 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-8 string.
           *
           * @static
           *
           * @example
           *
           *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);
           */
          stringify: function(l) {
            try {
              return decodeURIComponent(escape(v.stringify(l)));
            } catch {
              throw new Error("Malformed UTF-8 data");
            }
          },
          /**
           * Converts a UTF-8 string to a word array.
           *
           * @param {string} utf8Str The UTF-8 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);
           */
          parse: function(l) {
            return v.parse(unescape(encodeURIComponent(l)));
          }
        }, p = t.BufferedBlockAlgorithm = a.extend({
          /**
           * Resets this block algorithm's data buffer to its initial state.
           *
           * @example
           *
           *     bufferedBlockAlgorithm.reset();
           */
          reset: function() {
            this._data = new h.init(), this._nDataBytes = 0;
          },
          /**
           * Adds new data to this block algorithm's buffer.
           *
           * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.
           *
           * @example
           *
           *     bufferedBlockAlgorithm._append('data');
           *     bufferedBlockAlgorithm._append(wordArray);
           */
          _append: function(l) {
            typeof l == "string" && (l = m.parse(l)), this._data.concat(l), this._nDataBytes += l.sigBytes;
          },
          /**
           * Processes available data blocks.
           *
           * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.
           *
           * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.
           *
           * @return {WordArray} The processed data.
           *
           * @example
           *
           *     var processedData = bufferedBlockAlgorithm._process();
           *     var processedData = bufferedBlockAlgorithm._process(!!'flush');
           */
          _process: function(l) {
            var u, B = this._data, A = B.words, E = B.sigBytes, y = this.blockSize, b = y * 4, S = E / b;
            l ? S = e.ceil(S) : S = e.max((S | 0) - this._minBufferSize, 0);
            var F = S * y, D = e.min(F * 4, E);
            if (F) {
              for (var _ = 0; _ < F; _ += y)
                this._doProcessBlock(A, _);
              u = A.splice(0, F), B.sigBytes -= D;
            }
            return new h.init(u, D);
          },
          /**
           * Creates a copy of this object.
           *
           * @return {Object} The clone.
           *
           * @example
           *
           *     var clone = bufferedBlockAlgorithm.clone();
           */
          clone: function() {
            var l = a.clone.call(this);
            return l._data = this._data.clone(), l;
          },
          _minBufferSize: 0
        });
        t.Hasher = p.extend({
          /**
           * Configuration options.
           */
          cfg: a.extend(),
          /**
           * Initializes a newly created hasher.
           *
           * @param {Object} cfg (Optional) The configuration options to use for this hash computation.
           *
           * @example
           *
           *     var hasher = CryptoJS.algo.SHA256.create();
           */
          init: function(l) {
            this.cfg = this.cfg.extend(l), this.reset();
          },
          /**
           * Resets this hasher to its initial state.
           *
           * @example
           *
           *     hasher.reset();
           */
          reset: function() {
            p.reset.call(this), this._doReset();
          },
          /**
           * Updates this hasher with a message.
           *
           * @param {WordArray|string} messageUpdate The message to append.
           *
           * @return {Hasher} This hasher.
           *
           * @example
           *
           *     hasher.update('message');
           *     hasher.update(wordArray);
           */
          update: function(l) {
            return this._append(l), this._process(), this;
          },
          /**
           * Finalizes the hash computation.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} messageUpdate (Optional) A final message update.
           *
           * @return {WordArray} The hash.
           *
           * @example
           *
           *     var hash = hasher.finalize();
           *     var hash = hasher.finalize('message');
           *     var hash = hasher.finalize(wordArray);
           */
          finalize: function(l) {
            l && this._append(l);
            var u = this._doFinalize();
            return u;
          },
          blockSize: 16,
          /**
           * Creates a shortcut function to a hasher's object interface.
           *
           * @param {Hasher} hasher The hasher to create a helper for.
           *
           * @return {Function} The shortcut function.
           *
           * @static
           *
           * @example
           *
           *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);
           */
          _createHelper: function(l) {
            return function(u, B) {
              return new l.init(B).finalize(u);
            };
          },
          /**
           * Creates a shortcut function to the HMAC's object interface.
           *
           * @param {Hasher} hasher The hasher to use in this HMAC helper.
           *
           * @return {Function} The shortcut function.
           *
           * @static
           *
           * @example
           *
           *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);
           */
          _createHmacHelper: function(l) {
            return function(u, B) {
              return new g.HMAC.init(l, B).finalize(u);
            };
          }
        });
        var g = c.algo = {};
        return c;
      })(Math);
      return r;
    });
  })(S0)), S0.exports;
}
var M0 = { exports: {} }, sa = M0.exports, Ue;
function le() {
  return Ue || (Ue = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(sa, function(r) {
      return (function(e) {
        var s = r, x = s.lib, C = x.Base, d = x.WordArray, c = s.x64 = {};
        c.Word = C.extend({
          /**
           * Initializes a newly created 64-bit word.
           *
           * @param {number} high The high 32 bits.
           * @param {number} low The low 32 bits.
           *
           * @example
           *
           *     var x64Word = CryptoJS.x64.Word.create(0x00010203, 0x04050607);
           */
          init: function(t, a) {
            this.high = t, this.low = a;
          }
          /**
           * Bitwise NOTs this word.
           *
           * @return {X64Word} A new x64-Word object after negating.
           *
           * @example
           *
           *     var negated = x64Word.not();
           */
          // not: function () {
          // var high = ~this.high;
          // var low = ~this.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise ANDs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to AND with this word.
           *
           * @return {X64Word} A new x64-Word object after ANDing.
           *
           * @example
           *
           *     var anded = x64Word.and(anotherX64Word);
           */
          // and: function (word) {
          // var high = this.high & word.high;
          // var low = this.low & word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise ORs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to OR with this word.
           *
           * @return {X64Word} A new x64-Word object after ORing.
           *
           * @example
           *
           *     var ored = x64Word.or(anotherX64Word);
           */
          // or: function (word) {
          // var high = this.high | word.high;
          // var low = this.low | word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise XORs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to XOR with this word.
           *
           * @return {X64Word} A new x64-Word object after XORing.
           *
           * @example
           *
           *     var xored = x64Word.xor(anotherX64Word);
           */
          // xor: function (word) {
          // var high = this.high ^ word.high;
          // var low = this.low ^ word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Shifts this word n bits to the left.
           *
           * @param {number} n The number of bits to shift.
           *
           * @return {X64Word} A new x64-Word object after shifting.
           *
           * @example
           *
           *     var shifted = x64Word.shiftL(25);
           */
          // shiftL: function (n) {
          // if (n < 32) {
          // var high = (this.high << n) | (this.low >>> (32 - n));
          // var low = this.low << n;
          // } else {
          // var high = this.low << (n - 32);
          // var low = 0;
          // }
          // return X64Word.create(high, low);
          // },
          /**
           * Shifts this word n bits to the right.
           *
           * @param {number} n The number of bits to shift.
           *
           * @return {X64Word} A new x64-Word object after shifting.
           *
           * @example
           *
           *     var shifted = x64Word.shiftR(7);
           */
          // shiftR: function (n) {
          // if (n < 32) {
          // var low = (this.low >>> n) | (this.high << (32 - n));
          // var high = this.high >>> n;
          // } else {
          // var low = this.high >>> (n - 32);
          // var high = 0;
          // }
          // return X64Word.create(high, low);
          // },
          /**
           * Rotates this word n bits to the left.
           *
           * @param {number} n The number of bits to rotate.
           *
           * @return {X64Word} A new x64-Word object after rotating.
           *
           * @example
           *
           *     var rotated = x64Word.rotL(25);
           */
          // rotL: function (n) {
          // return this.shiftL(n).or(this.shiftR(64 - n));
          // },
          /**
           * Rotates this word n bits to the right.
           *
           * @param {number} n The number of bits to rotate.
           *
           * @return {X64Word} A new x64-Word object after rotating.
           *
           * @example
           *
           *     var rotated = x64Word.rotR(7);
           */
          // rotR: function (n) {
          // return this.shiftR(n).or(this.shiftL(64 - n));
          // },
          /**
           * Adds this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to add with this word.
           *
           * @return {X64Word} A new x64-Word object after adding.
           *
           * @example
           *
           *     var added = x64Word.add(anotherX64Word);
           */
          // add: function (word) {
          // var low = (this.low + word.low) | 0;
          // var carry = (low >>> 0) < (this.low >>> 0) ? 1 : 0;
          // var high = (this.high + word.high + carry) | 0;
          // return X64Word.create(high, low);
          // }
        }), c.WordArray = C.extend({
          /**
           * Initializes a newly created word array.
           *
           * @param {Array} words (Optional) An array of CryptoJS.x64.Word objects.
           * @param {number} sigBytes (Optional) The number of significant bytes in the words.
           *
           * @example
           *
           *     var wordArray = CryptoJS.x64.WordArray.create();
           *
           *     var wordArray = CryptoJS.x64.WordArray.create([
           *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
           *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
           *     ]);
           *
           *     var wordArray = CryptoJS.x64.WordArray.create([
           *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
           *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
           *     ], 10);
           */
          init: function(t, a) {
            t = this.words = t || [], a != e ? this.sigBytes = a : this.sigBytes = t.length * 8;
          },
          /**
           * Converts this 64-bit word array to a 32-bit word array.
           *
           * @return {CryptoJS.lib.WordArray} This word array's data as a 32-bit word array.
           *
           * @example
           *
           *     var x32WordArray = x64WordArray.toX32();
           */
          toX32: function() {
            for (var t = this.words, a = t.length, h = [], n = 0; n < a; n++) {
              var f = t[n];
              h.push(f.high), h.push(f.low);
            }
            return d.create(h, this.sigBytes);
          },
          /**
           * Creates a copy of this word array.
           *
           * @return {X64WordArray} The clone.
           *
           * @example
           *
           *     var clone = x64WordArray.clone();
           */
          clone: function() {
            for (var t = C.clone.call(this), a = t.words = this.words.slice(0), h = a.length, n = 0; n < h; n++)
              a[n] = a[n].clone();
            return t;
          }
        });
      })(), r;
    });
  })(M0)), M0.exports;
}
var R0 = { exports: {} }, xa = R0.exports, $e;
function ca() {
  return $e || ($e = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(xa, function(r) {
      return (function() {
        if (typeof ArrayBuffer == "function") {
          var e = r, s = e.lib, x = s.WordArray, C = x.init, d = x.init = function(c) {
            if (c instanceof ArrayBuffer && (c = new Uint8Array(c)), (c instanceof Int8Array || typeof Uint8ClampedArray < "u" && c instanceof Uint8ClampedArray || c instanceof Int16Array || c instanceof Uint16Array || c instanceof Int32Array || c instanceof Uint32Array || c instanceof Float32Array || c instanceof Float64Array) && (c = new Uint8Array(c.buffer, c.byteOffset, c.byteLength)), c instanceof Uint8Array) {
              for (var t = c.byteLength, a = [], h = 0; h < t; h++)
                a[h >>> 2] |= c[h] << 24 - h % 4 * 8;
              C.call(this, a, t);
            } else
              C.apply(this, arguments);
          };
          d.prototype = x;
        }
      })(), r.lib.WordArray;
    });
  })(R0)), R0.exports;
}
var z0 = { exports: {} }, fa = z0.exports, Ne;
function la() {
  return Ne || (Ne = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(fa, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.WordArray, C = e.enc;
        C.Utf16 = C.Utf16BE = {
          /**
           * Converts a word array to a UTF-16 BE string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-16 BE string.
           *
           * @static
           *
           * @example
           *
           *     var utf16String = CryptoJS.enc.Utf16.stringify(wordArray);
           */
          stringify: function(c) {
            for (var t = c.words, a = c.sigBytes, h = [], n = 0; n < a; n += 2) {
              var f = t[n >>> 2] >>> 16 - n % 4 * 8 & 65535;
              h.push(String.fromCharCode(f));
            }
            return h.join("");
          },
          /**
           * Converts a UTF-16 BE string to a word array.
           *
           * @param {string} utf16Str The UTF-16 BE string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf16.parse(utf16String);
           */
          parse: function(c) {
            for (var t = c.length, a = [], h = 0; h < t; h++)
              a[h >>> 1] |= c.charCodeAt(h) << 16 - h % 2 * 16;
            return x.create(a, t * 2);
          }
        }, C.Utf16LE = {
          /**
           * Converts a word array to a UTF-16 LE string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-16 LE string.
           *
           * @static
           *
           * @example
           *
           *     var utf16Str = CryptoJS.enc.Utf16LE.stringify(wordArray);
           */
          stringify: function(c) {
            for (var t = c.words, a = c.sigBytes, h = [], n = 0; n < a; n += 2) {
              var f = d(t[n >>> 2] >>> 16 - n % 4 * 8 & 65535);
              h.push(String.fromCharCode(f));
            }
            return h.join("");
          },
          /**
           * Converts a UTF-16 LE string to a word array.
           *
           * @param {string} utf16Str The UTF-16 LE string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf16LE.parse(utf16Str);
           */
          parse: function(c) {
            for (var t = c.length, a = [], h = 0; h < t; h++)
              a[h >>> 1] |= d(c.charCodeAt(h) << 16 - h % 2 * 16);
            return x.create(a, t * 2);
          }
        };
        function d(c) {
          return c << 8 & 4278255360 | c >>> 8 & 16711935;
        }
      })(), r.enc.Utf16;
    });
  })(z0)), z0.exports;
}
var H0 = { exports: {} }, ha = H0.exports, Ve;
function h0() {
  return Ve || (Ve = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(ha, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.WordArray, C = e.enc;
        C.Base64 = {
          /**
           * Converts a word array to a Base64 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The Base64 string.
           *
           * @static
           *
           * @example
           *
           *     var base64String = CryptoJS.enc.Base64.stringify(wordArray);
           */
          stringify: function(c) {
            var t = c.words, a = c.sigBytes, h = this._map;
            c.clamp();
            for (var n = [], f = 0; f < a; f += 3)
              for (var v = t[f >>> 2] >>> 24 - f % 4 * 8 & 255, m = t[f + 1 >>> 2] >>> 24 - (f + 1) % 4 * 8 & 255, p = t[f + 2 >>> 2] >>> 24 - (f + 2) % 4 * 8 & 255, g = v << 16 | m << 8 | p, l = 0; l < 4 && f + l * 0.75 < a; l++)
                n.push(h.charAt(g >>> 6 * (3 - l) & 63));
            var u = h.charAt(64);
            if (u)
              for (; n.length % 4; )
                n.push(u);
            return n.join("");
          },
          /**
           * Converts a Base64 string to a word array.
           *
           * @param {string} base64Str The Base64 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Base64.parse(base64String);
           */
          parse: function(c) {
            var t = c.length, a = this._map, h = this._reverseMap;
            if (!h) {
              h = this._reverseMap = [];
              for (var n = 0; n < a.length; n++)
                h[a.charCodeAt(n)] = n;
            }
            var f = a.charAt(64);
            if (f) {
              var v = c.indexOf(f);
              v !== -1 && (t = v);
            }
            return d(c, t, h);
          },
          _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
        };
        function d(c, t, a) {
          for (var h = [], n = 0, f = 0; f < t; f++)
            if (f % 4) {
              var v = a[c.charCodeAt(f - 1)] << f % 4 * 2, m = a[c.charCodeAt(f)] >>> 6 - f % 4 * 2, p = v | m;
              h[n >>> 2] |= p << 24 - n % 4 * 8, n++;
            }
          return x.create(h, n);
        }
      })(), r.enc.Base64;
    });
  })(H0)), H0.exports;
}
var P0 = { exports: {} }, ua = P0.exports, je;
function da() {
  return je || (je = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(ua, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.WordArray, C = e.enc;
        C.Base64url = {
          /**
           * Converts a word array to a Base64url string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @param {boolean} urlSafe Whether to use url safe
           *
           * @return {string} The Base64url string.
           *
           * @static
           *
           * @example
           *
           *     var base64String = CryptoJS.enc.Base64url.stringify(wordArray);
           */
          stringify: function(c, t) {
            t === void 0 && (t = !0);
            var a = c.words, h = c.sigBytes, n = t ? this._safe_map : this._map;
            c.clamp();
            for (var f = [], v = 0; v < h; v += 3)
              for (var m = a[v >>> 2] >>> 24 - v % 4 * 8 & 255, p = a[v + 1 >>> 2] >>> 24 - (v + 1) % 4 * 8 & 255, g = a[v + 2 >>> 2] >>> 24 - (v + 2) % 4 * 8 & 255, l = m << 16 | p << 8 | g, u = 0; u < 4 && v + u * 0.75 < h; u++)
                f.push(n.charAt(l >>> 6 * (3 - u) & 63));
            var B = n.charAt(64);
            if (B)
              for (; f.length % 4; )
                f.push(B);
            return f.join("");
          },
          /**
           * Converts a Base64url string to a word array.
           *
           * @param {string} base64Str The Base64url string.
           *
           * @param {boolean} urlSafe Whether to use url safe
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Base64url.parse(base64String);
           */
          parse: function(c, t) {
            t === void 0 && (t = !0);
            var a = c.length, h = t ? this._safe_map : this._map, n = this._reverseMap;
            if (!n) {
              n = this._reverseMap = [];
              for (var f = 0; f < h.length; f++)
                n[h.charCodeAt(f)] = f;
            }
            var v = h.charAt(64);
            if (v) {
              var m = c.indexOf(v);
              m !== -1 && (a = m);
            }
            return d(c, a, n);
          },
          _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          _safe_map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        };
        function d(c, t, a) {
          for (var h = [], n = 0, f = 0; f < t; f++)
            if (f % 4) {
              var v = a[c.charCodeAt(f - 1)] << f % 4 * 2, m = a[c.charCodeAt(f)] >>> 6 - f % 4 * 2, p = v | m;
              h[n >>> 2] |= p << 24 - n % 4 * 8, n++;
            }
          return x.create(h, n);
        }
      })(), r.enc.Base64url;
    });
  })(P0)), P0.exports;
}
var O0 = { exports: {} }, va = O0.exports, Xe;
function u0() {
  return Xe || (Xe = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(va, function(r) {
      return (function(e) {
        var s = r, x = s.lib, C = x.WordArray, d = x.Hasher, c = s.algo, t = [];
        (function() {
          for (var m = 0; m < 64; m++)
            t[m] = e.abs(e.sin(m + 1)) * 4294967296 | 0;
        })();
        var a = c.MD5 = d.extend({
          _doReset: function() {
            this._hash = new C.init([
              1732584193,
              4023233417,
              2562383102,
              271733878
            ]);
          },
          _doProcessBlock: function(m, p) {
            for (var g = 0; g < 16; g++) {
              var l = p + g, u = m[l];
              m[l] = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360;
            }
            var B = this._hash.words, A = m[p + 0], E = m[p + 1], y = m[p + 2], b = m[p + 3], S = m[p + 4], F = m[p + 5], D = m[p + 6], _ = m[p + 7], w = m[p + 8], P = m[p + 9], O = m[p + 10], W = m[p + 11], T = m[p + 12], G = m[p + 13], L = m[p + 14], U = m[p + 15], M = B[0], z = B[1], H = B[2], R = B[3];
            M = h(M, z, H, R, A, 7, t[0]), R = h(R, M, z, H, E, 12, t[1]), H = h(H, R, M, z, y, 17, t[2]), z = h(z, H, R, M, b, 22, t[3]), M = h(M, z, H, R, S, 7, t[4]), R = h(R, M, z, H, F, 12, t[5]), H = h(H, R, M, z, D, 17, t[6]), z = h(z, H, R, M, _, 22, t[7]), M = h(M, z, H, R, w, 7, t[8]), R = h(R, M, z, H, P, 12, t[9]), H = h(H, R, M, z, O, 17, t[10]), z = h(z, H, R, M, W, 22, t[11]), M = h(M, z, H, R, T, 7, t[12]), R = h(R, M, z, H, G, 12, t[13]), H = h(H, R, M, z, L, 17, t[14]), z = h(z, H, R, M, U, 22, t[15]), M = n(M, z, H, R, E, 5, t[16]), R = n(R, M, z, H, D, 9, t[17]), H = n(H, R, M, z, W, 14, t[18]), z = n(z, H, R, M, A, 20, t[19]), M = n(M, z, H, R, F, 5, t[20]), R = n(R, M, z, H, O, 9, t[21]), H = n(H, R, M, z, U, 14, t[22]), z = n(z, H, R, M, S, 20, t[23]), M = n(M, z, H, R, P, 5, t[24]), R = n(R, M, z, H, L, 9, t[25]), H = n(H, R, M, z, b, 14, t[26]), z = n(z, H, R, M, w, 20, t[27]), M = n(M, z, H, R, G, 5, t[28]), R = n(R, M, z, H, y, 9, t[29]), H = n(H, R, M, z, _, 14, t[30]), z = n(z, H, R, M, T, 20, t[31]), M = f(M, z, H, R, F, 4, t[32]), R = f(R, M, z, H, w, 11, t[33]), H = f(H, R, M, z, W, 16, t[34]), z = f(z, H, R, M, L, 23, t[35]), M = f(M, z, H, R, E, 4, t[36]), R = f(R, M, z, H, S, 11, t[37]), H = f(H, R, M, z, _, 16, t[38]), z = f(z, H, R, M, O, 23, t[39]), M = f(M, z, H, R, G, 4, t[40]), R = f(R, M, z, H, A, 11, t[41]), H = f(H, R, M, z, b, 16, t[42]), z = f(z, H, R, M, D, 23, t[43]), M = f(M, z, H, R, P, 4, t[44]), R = f(R, M, z, H, T, 11, t[45]), H = f(H, R, M, z, U, 16, t[46]), z = f(z, H, R, M, y, 23, t[47]), M = v(M, z, H, R, A, 6, t[48]), R = v(R, M, z, H, _, 10, t[49]), H = v(H, R, M, z, L, 15, t[50]), z = v(z, H, R, M, F, 21, t[51]), M = v(M, z, H, R, T, 6, t[52]), R = v(R, M, z, H, b, 10, t[53]), H = v(H, R, M, z, O, 15, t[54]), z = v(z, H, R, M, E, 21, t[55]), M = v(M, z, H, R, w, 6, t[56]), R = v(R, M, z, H, U, 10, t[57]), H = v(H, R, M, z, D, 15, t[58]), z = v(z, H, R, M, G, 21, t[59]), M = v(M, z, H, R, S, 6, t[60]), R = v(R, M, z, H, W, 10, t[61]), H = v(H, R, M, z, y, 15, t[62]), z = v(z, H, R, M, P, 21, t[63]), B[0] = B[0] + M | 0, B[1] = B[1] + z | 0, B[2] = B[2] + H | 0, B[3] = B[3] + R | 0;
          },
          _doFinalize: function() {
            var m = this._data, p = m.words, g = this._nDataBytes * 8, l = m.sigBytes * 8;
            p[l >>> 5] |= 128 << 24 - l % 32;
            var u = e.floor(g / 4294967296), B = g;
            p[(l + 64 >>> 9 << 4) + 15] = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360, p[(l + 64 >>> 9 << 4) + 14] = (B << 8 | B >>> 24) & 16711935 | (B << 24 | B >>> 8) & 4278255360, m.sigBytes = (p.length + 1) * 4, this._process();
            for (var A = this._hash, E = A.words, y = 0; y < 4; y++) {
              var b = E[y];
              E[y] = (b << 8 | b >>> 24) & 16711935 | (b << 24 | b >>> 8) & 4278255360;
            }
            return A;
          },
          clone: function() {
            var m = d.clone.call(this);
            return m._hash = this._hash.clone(), m;
          }
        });
        function h(m, p, g, l, u, B, A) {
          var E = m + (p & g | ~p & l) + u + A;
          return (E << B | E >>> 32 - B) + p;
        }
        function n(m, p, g, l, u, B, A) {
          var E = m + (p & l | g & ~l) + u + A;
          return (E << B | E >>> 32 - B) + p;
        }
        function f(m, p, g, l, u, B, A) {
          var E = m + (p ^ g ^ l) + u + A;
          return (E << B | E >>> 32 - B) + p;
        }
        function v(m, p, g, l, u, B, A) {
          var E = m + (g ^ (p | ~l)) + u + A;
          return (E << B | E >>> 32 - B) + p;
        }
        s.MD5 = d._createHelper(a), s.HmacMD5 = d._createHmacHelper(a);
      })(Math), r.MD5;
    });
  })(O0)), O0.exports;
}
var W0 = { exports: {} }, pa = W0.exports, Ke;
function Sr() {
  return Ke || (Ke = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(pa, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.WordArray, C = s.Hasher, d = e.algo, c = [], t = d.SHA1 = C.extend({
          _doReset: function() {
            this._hash = new x.init([
              1732584193,
              4023233417,
              2562383102,
              271733878,
              3285377520
            ]);
          },
          _doProcessBlock: function(a, h) {
            for (var n = this._hash.words, f = n[0], v = n[1], m = n[2], p = n[3], g = n[4], l = 0; l < 80; l++) {
              if (l < 16)
                c[l] = a[h + l] | 0;
              else {
                var u = c[l - 3] ^ c[l - 8] ^ c[l - 14] ^ c[l - 16];
                c[l] = u << 1 | u >>> 31;
              }
              var B = (f << 5 | f >>> 27) + g + c[l];
              l < 20 ? B += (v & m | ~v & p) + 1518500249 : l < 40 ? B += (v ^ m ^ p) + 1859775393 : l < 60 ? B += (v & m | v & p | m & p) - 1894007588 : B += (v ^ m ^ p) - 899497514, g = p, p = m, m = v << 30 | v >>> 2, v = f, f = B;
            }
            n[0] = n[0] + f | 0, n[1] = n[1] + v | 0, n[2] = n[2] + m | 0, n[3] = n[3] + p | 0, n[4] = n[4] + g | 0;
          },
          _doFinalize: function() {
            var a = this._data, h = a.words, n = this._nDataBytes * 8, f = a.sigBytes * 8;
            return h[f >>> 5] |= 128 << 24 - f % 32, h[(f + 64 >>> 9 << 4) + 14] = Math.floor(n / 4294967296), h[(f + 64 >>> 9 << 4) + 15] = n, a.sigBytes = h.length * 4, this._process(), this._hash;
          },
          clone: function() {
            var a = C.clone.call(this);
            return a._hash = this._hash.clone(), a;
          }
        });
        e.SHA1 = C._createHelper(t), e.HmacSHA1 = C._createHmacHelper(t);
      })(), r.SHA1;
    });
  })(W0)), W0.exports;
}
var T0 = { exports: {} }, Ba = T0.exports, Ye;
function Fe() {
  return Ye || (Ye = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(Ba, function(r) {
      return (function(e) {
        var s = r, x = s.lib, C = x.WordArray, d = x.Hasher, c = s.algo, t = [], a = [];
        (function() {
          function f(g) {
            for (var l = e.sqrt(g), u = 2; u <= l; u++)
              if (!(g % u))
                return !1;
            return !0;
          }
          function v(g) {
            return (g - (g | 0)) * 4294967296 | 0;
          }
          for (var m = 2, p = 0; p < 64; )
            f(m) && (p < 8 && (t[p] = v(e.pow(m, 1 / 2))), a[p] = v(e.pow(m, 1 / 3)), p++), m++;
        })();
        var h = [], n = c.SHA256 = d.extend({
          _doReset: function() {
            this._hash = new C.init(t.slice(0));
          },
          _doProcessBlock: function(f, v) {
            for (var m = this._hash.words, p = m[0], g = m[1], l = m[2], u = m[3], B = m[4], A = m[5], E = m[6], y = m[7], b = 0; b < 64; b++) {
              if (b < 16)
                h[b] = f[v + b] | 0;
              else {
                var S = h[b - 15], F = (S << 25 | S >>> 7) ^ (S << 14 | S >>> 18) ^ S >>> 3, D = h[b - 2], _ = (D << 15 | D >>> 17) ^ (D << 13 | D >>> 19) ^ D >>> 10;
                h[b] = F + h[b - 7] + _ + h[b - 16];
              }
              var w = B & A ^ ~B & E, P = p & g ^ p & l ^ g & l, O = (p << 30 | p >>> 2) ^ (p << 19 | p >>> 13) ^ (p << 10 | p >>> 22), W = (B << 26 | B >>> 6) ^ (B << 21 | B >>> 11) ^ (B << 7 | B >>> 25), T = y + W + w + a[b] + h[b], G = O + P;
              y = E, E = A, A = B, B = u + T | 0, u = l, l = g, g = p, p = T + G | 0;
            }
            m[0] = m[0] + p | 0, m[1] = m[1] + g | 0, m[2] = m[2] + l | 0, m[3] = m[3] + u | 0, m[4] = m[4] + B | 0, m[5] = m[5] + A | 0, m[6] = m[6] + E | 0, m[7] = m[7] + y | 0;
          },
          _doFinalize: function() {
            var f = this._data, v = f.words, m = this._nDataBytes * 8, p = f.sigBytes * 8;
            return v[p >>> 5] |= 128 << 24 - p % 32, v[(p + 64 >>> 9 << 4) + 14] = e.floor(m / 4294967296), v[(p + 64 >>> 9 << 4) + 15] = m, f.sigBytes = v.length * 4, this._process(), this._hash;
          },
          clone: function() {
            var f = d.clone.call(this);
            return f._hash = this._hash.clone(), f;
          }
        });
        s.SHA256 = d._createHelper(n), s.HmacSHA256 = d._createHmacHelper(n);
      })(Math), r.SHA256;
    });
  })(T0)), T0.exports;
}
var q0 = { exports: {} }, ma = q0.exports, Ze;
function Ca() {
  return Ze || (Ze = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), Fe());
    })(ma, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.WordArray, C = e.algo, d = C.SHA256, c = C.SHA224 = d.extend({
          _doReset: function() {
            this._hash = new x.init([
              3238371032,
              914150663,
              812702999,
              4144912697,
              4290775857,
              1750603025,
              1694076839,
              3204075428
            ]);
          },
          _doFinalize: function() {
            var t = d._doFinalize.call(this);
            return t.sigBytes -= 4, t;
          }
        });
        e.SHA224 = d._createHelper(c), e.HmacSHA224 = d._createHmacHelper(c);
      })(), r.SHA224;
    });
  })(q0)), q0.exports;
}
var L0 = { exports: {} }, Aa = L0.exports, Qe;
function Mr() {
  return Qe || (Qe = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), le());
    })(Aa, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.Hasher, C = e.x64, d = C.Word, c = C.WordArray, t = e.algo;
        function a() {
          return d.create.apply(d, arguments);
        }
        var h = [
          a(1116352408, 3609767458),
          a(1899447441, 602891725),
          a(3049323471, 3964484399),
          a(3921009573, 2173295548),
          a(961987163, 4081628472),
          a(1508970993, 3053834265),
          a(2453635748, 2937671579),
          a(2870763221, 3664609560),
          a(3624381080, 2734883394),
          a(310598401, 1164996542),
          a(607225278, 1323610764),
          a(1426881987, 3590304994),
          a(1925078388, 4068182383),
          a(2162078206, 991336113),
          a(2614888103, 633803317),
          a(3248222580, 3479774868),
          a(3835390401, 2666613458),
          a(4022224774, 944711139),
          a(264347078, 2341262773),
          a(604807628, 2007800933),
          a(770255983, 1495990901),
          a(1249150122, 1856431235),
          a(1555081692, 3175218132),
          a(1996064986, 2198950837),
          a(2554220882, 3999719339),
          a(2821834349, 766784016),
          a(2952996808, 2566594879),
          a(3210313671, 3203337956),
          a(3336571891, 1034457026),
          a(3584528711, 2466948901),
          a(113926993, 3758326383),
          a(338241895, 168717936),
          a(666307205, 1188179964),
          a(773529912, 1546045734),
          a(1294757372, 1522805485),
          a(1396182291, 2643833823),
          a(1695183700, 2343527390),
          a(1986661051, 1014477480),
          a(2177026350, 1206759142),
          a(2456956037, 344077627),
          a(2730485921, 1290863460),
          a(2820302411, 3158454273),
          a(3259730800, 3505952657),
          a(3345764771, 106217008),
          a(3516065817, 3606008344),
          a(3600352804, 1432725776),
          a(4094571909, 1467031594),
          a(275423344, 851169720),
          a(430227734, 3100823752),
          a(506948616, 1363258195),
          a(659060556, 3750685593),
          a(883997877, 3785050280),
          a(958139571, 3318307427),
          a(1322822218, 3812723403),
          a(1537002063, 2003034995),
          a(1747873779, 3602036899),
          a(1955562222, 1575990012),
          a(2024104815, 1125592928),
          a(2227730452, 2716904306),
          a(2361852424, 442776044),
          a(2428436474, 593698344),
          a(2756734187, 3733110249),
          a(3204031479, 2999351573),
          a(3329325298, 3815920427),
          a(3391569614, 3928383900),
          a(3515267271, 566280711),
          a(3940187606, 3454069534),
          a(4118630271, 4000239992),
          a(116418474, 1914138554),
          a(174292421, 2731055270),
          a(289380356, 3203993006),
          a(460393269, 320620315),
          a(685471733, 587496836),
          a(852142971, 1086792851),
          a(1017036298, 365543100),
          a(1126000580, 2618297676),
          a(1288033470, 3409855158),
          a(1501505948, 4234509866),
          a(1607167915, 987167468),
          a(1816402316, 1246189591)
        ], n = [];
        (function() {
          for (var v = 0; v < 80; v++)
            n[v] = a();
        })();
        var f = t.SHA512 = x.extend({
          _doReset: function() {
            this._hash = new c.init([
              new d.init(1779033703, 4089235720),
              new d.init(3144134277, 2227873595),
              new d.init(1013904242, 4271175723),
              new d.init(2773480762, 1595750129),
              new d.init(1359893119, 2917565137),
              new d.init(2600822924, 725511199),
              new d.init(528734635, 4215389547),
              new d.init(1541459225, 327033209)
            ]);
          },
          _doProcessBlock: function(v, m) {
            for (var p = this._hash.words, g = p[0], l = p[1], u = p[2], B = p[3], A = p[4], E = p[5], y = p[6], b = p[7], S = g.high, F = g.low, D = l.high, _ = l.low, w = u.high, P = u.low, O = B.high, W = B.low, T = A.high, G = A.low, L = E.high, U = E.low, M = y.high, z = y.low, H = b.high, R = b.low, $ = S, N = F, j = D, q = _, o0 = w, i0 = P, d0 = O, s0 = W, K = T, Y = G, y0 = L, m0 = U, b0 = M, C0 = z, he = H, A0 = R, t0 = 0; t0 < 80; t0++) {
              var e0, x0, _0 = n[t0];
              if (t0 < 16)
                x0 = _0.high = v[m + t0 * 2] | 0, e0 = _0.low = v[m + t0 * 2 + 1] | 0;
              else {
                var ye = n[t0 - 15], v0 = ye.high, E0 = ye.low, Hr = (v0 >>> 1 | E0 << 31) ^ (v0 >>> 8 | E0 << 24) ^ v0 >>> 7, be = (E0 >>> 1 | v0 << 31) ^ (E0 >>> 8 | v0 << 24) ^ (E0 >>> 7 | v0 << 25), _e = n[t0 - 2], p0 = _e.high, g0 = _e.low, Pr = (p0 >>> 19 | g0 << 13) ^ (p0 << 3 | g0 >>> 29) ^ p0 >>> 6, we = (g0 >>> 19 | p0 << 13) ^ (g0 << 3 | p0 >>> 29) ^ (g0 >>> 6 | p0 << 26), ke = n[t0 - 7], Or = ke.high, Wr = ke.low, Se = n[t0 - 16], Tr = Se.high, Me = Se.low;
                e0 = be + Wr, x0 = Hr + Or + (e0 >>> 0 < be >>> 0 ? 1 : 0), e0 = e0 + we, x0 = x0 + Pr + (e0 >>> 0 < we >>> 0 ? 1 : 0), e0 = e0 + Me, x0 = x0 + Tr + (e0 >>> 0 < Me >>> 0 ? 1 : 0), _0.high = x0, _0.low = e0;
              }
              var qr = K & y0 ^ ~K & b0, Re = Y & m0 ^ ~Y & C0, Lr = $ & j ^ $ & o0 ^ j & o0, Ir = N & q ^ N & i0 ^ q & i0, Gr = ($ >>> 28 | N << 4) ^ ($ << 30 | N >>> 2) ^ ($ << 25 | N >>> 7), ze = (N >>> 28 | $ << 4) ^ (N << 30 | $ >>> 2) ^ (N << 25 | $ >>> 7), Ur = (K >>> 14 | Y << 18) ^ (K >>> 18 | Y << 14) ^ (K << 23 | Y >>> 9), $r = (Y >>> 14 | K << 18) ^ (Y >>> 18 | K << 14) ^ (Y << 23 | K >>> 9), He = h[t0], Nr = He.high, Pe = He.low, Z = A0 + $r, c0 = he + Ur + (Z >>> 0 < A0 >>> 0 ? 1 : 0), Z = Z + Re, c0 = c0 + qr + (Z >>> 0 < Re >>> 0 ? 1 : 0), Z = Z + Pe, c0 = c0 + Nr + (Z >>> 0 < Pe >>> 0 ? 1 : 0), Z = Z + e0, c0 = c0 + x0 + (Z >>> 0 < e0 >>> 0 ? 1 : 0), Oe = ze + Ir, Vr = Gr + Lr + (Oe >>> 0 < ze >>> 0 ? 1 : 0);
              he = b0, A0 = C0, b0 = y0, C0 = m0, y0 = K, m0 = Y, Y = s0 + Z | 0, K = d0 + c0 + (Y >>> 0 < s0 >>> 0 ? 1 : 0) | 0, d0 = o0, s0 = i0, o0 = j, i0 = q, j = $, q = N, N = Z + Oe | 0, $ = c0 + Vr + (N >>> 0 < Z >>> 0 ? 1 : 0) | 0;
            }
            F = g.low = F + N, g.high = S + $ + (F >>> 0 < N >>> 0 ? 1 : 0), _ = l.low = _ + q, l.high = D + j + (_ >>> 0 < q >>> 0 ? 1 : 0), P = u.low = P + i0, u.high = w + o0 + (P >>> 0 < i0 >>> 0 ? 1 : 0), W = B.low = W + s0, B.high = O + d0 + (W >>> 0 < s0 >>> 0 ? 1 : 0), G = A.low = G + Y, A.high = T + K + (G >>> 0 < Y >>> 0 ? 1 : 0), U = E.low = U + m0, E.high = L + y0 + (U >>> 0 < m0 >>> 0 ? 1 : 0), z = y.low = z + C0, y.high = M + b0 + (z >>> 0 < C0 >>> 0 ? 1 : 0), R = b.low = R + A0, b.high = H + he + (R >>> 0 < A0 >>> 0 ? 1 : 0);
          },
          _doFinalize: function() {
            var v = this._data, m = v.words, p = this._nDataBytes * 8, g = v.sigBytes * 8;
            m[g >>> 5] |= 128 << 24 - g % 32, m[(g + 128 >>> 10 << 5) + 30] = Math.floor(p / 4294967296), m[(g + 128 >>> 10 << 5) + 31] = p, v.sigBytes = m.length * 4, this._process();
            var l = this._hash.toX32();
            return l;
          },
          clone: function() {
            var v = x.clone.call(this);
            return v._hash = this._hash.clone(), v;
          },
          blockSize: 1024 / 32
        });
        e.SHA512 = x._createHelper(f), e.HmacSHA512 = x._createHmacHelper(f);
      })(), r.SHA512;
    });
  })(L0)), L0.exports;
}
var I0 = { exports: {} }, Ea = I0.exports, Je;
function ga() {
  return Je || (Je = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), le(), Mr());
    })(Ea, function(r) {
      return (function() {
        var e = r, s = e.x64, x = s.Word, C = s.WordArray, d = e.algo, c = d.SHA512, t = d.SHA384 = c.extend({
          _doReset: function() {
            this._hash = new C.init([
              new x.init(3418070365, 3238371032),
              new x.init(1654270250, 914150663),
              new x.init(2438529370, 812702999),
              new x.init(355462360, 4144912697),
              new x.init(1731405415, 4290775857),
              new x.init(2394180231, 1750603025),
              new x.init(3675008525, 1694076839),
              new x.init(1203062813, 3204075428)
            ]);
          },
          _doFinalize: function() {
            var a = c._doFinalize.call(this);
            return a.sigBytes -= 16, a;
          }
        });
        e.SHA384 = c._createHelper(t), e.HmacSHA384 = c._createHmacHelper(t);
      })(), r.SHA384;
    });
  })(I0)), I0.exports;
}
var G0 = { exports: {} }, Fa = G0.exports, er;
function Da() {
  return er || (er = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), le());
    })(Fa, function(r) {
      return (function(e) {
        var s = r, x = s.lib, C = x.WordArray, d = x.Hasher, c = s.x64, t = c.Word, a = s.algo, h = [], n = [], f = [];
        (function() {
          for (var p = 1, g = 0, l = 0; l < 24; l++) {
            h[p + 5 * g] = (l + 1) * (l + 2) / 2 % 64;
            var u = g % 5, B = (2 * p + 3 * g) % 5;
            p = u, g = B;
          }
          for (var p = 0; p < 5; p++)
            for (var g = 0; g < 5; g++)
              n[p + 5 * g] = g + (2 * p + 3 * g) % 5 * 5;
          for (var A = 1, E = 0; E < 24; E++) {
            for (var y = 0, b = 0, S = 0; S < 7; S++) {
              if (A & 1) {
                var F = (1 << S) - 1;
                F < 32 ? b ^= 1 << F : y ^= 1 << F - 32;
              }
              A & 128 ? A = A << 1 ^ 113 : A <<= 1;
            }
            f[E] = t.create(y, b);
          }
        })();
        var v = [];
        (function() {
          for (var p = 0; p < 25; p++)
            v[p] = t.create();
        })();
        var m = a.SHA3 = d.extend({
          /**
           * Configuration options.
           *
           * @property {number} outputLength
           *   The desired number of bits in the output hash.
           *   Only values permitted are: 224, 256, 384, 512.
           *   Default: 512
           */
          cfg: d.cfg.extend({
            outputLength: 512
          }),
          _doReset: function() {
            for (var p = this._state = [], g = 0; g < 25; g++)
              p[g] = new t.init();
            this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32;
          },
          _doProcessBlock: function(p, g) {
            for (var l = this._state, u = this.blockSize / 2, B = 0; B < u; B++) {
              var A = p[g + 2 * B], E = p[g + 2 * B + 1];
              A = (A << 8 | A >>> 24) & 16711935 | (A << 24 | A >>> 8) & 4278255360, E = (E << 8 | E >>> 24) & 16711935 | (E << 24 | E >>> 8) & 4278255360;
              var y = l[B];
              y.high ^= E, y.low ^= A;
            }
            for (var b = 0; b < 24; b++) {
              for (var S = 0; S < 5; S++) {
                for (var F = 0, D = 0, _ = 0; _ < 5; _++) {
                  var y = l[S + 5 * _];
                  F ^= y.high, D ^= y.low;
                }
                var w = v[S];
                w.high = F, w.low = D;
              }
              for (var S = 0; S < 5; S++)
                for (var P = v[(S + 4) % 5], O = v[(S + 1) % 5], W = O.high, T = O.low, F = P.high ^ (W << 1 | T >>> 31), D = P.low ^ (T << 1 | W >>> 31), _ = 0; _ < 5; _++) {
                  var y = l[S + 5 * _];
                  y.high ^= F, y.low ^= D;
                }
              for (var G = 1; G < 25; G++) {
                var F, D, y = l[G], L = y.high, U = y.low, M = h[G];
                M < 32 ? (F = L << M | U >>> 32 - M, D = U << M | L >>> 32 - M) : (F = U << M - 32 | L >>> 64 - M, D = L << M - 32 | U >>> 64 - M);
                var z = v[n[G]];
                z.high = F, z.low = D;
              }
              var H = v[0], R = l[0];
              H.high = R.high, H.low = R.low;
              for (var S = 0; S < 5; S++)
                for (var _ = 0; _ < 5; _++) {
                  var G = S + 5 * _, y = l[G], $ = v[G], N = v[(S + 1) % 5 + 5 * _], j = v[(S + 2) % 5 + 5 * _];
                  y.high = $.high ^ ~N.high & j.high, y.low = $.low ^ ~N.low & j.low;
                }
              var y = l[0], q = f[b];
              y.high ^= q.high, y.low ^= q.low;
            }
          },
          _doFinalize: function() {
            var p = this._data, g = p.words;
            this._nDataBytes * 8;
            var l = p.sigBytes * 8, u = this.blockSize * 32;
            g[l >>> 5] |= 1 << 24 - l % 32, g[(e.ceil((l + 1) / u) * u >>> 5) - 1] |= 128, p.sigBytes = g.length * 4, this._process();
            for (var B = this._state, A = this.cfg.outputLength / 8, E = A / 8, y = [], b = 0; b < E; b++) {
              var S = B[b], F = S.high, D = S.low;
              F = (F << 8 | F >>> 24) & 16711935 | (F << 24 | F >>> 8) & 4278255360, D = (D << 8 | D >>> 24) & 16711935 | (D << 24 | D >>> 8) & 4278255360, y.push(D), y.push(F);
            }
            return new C.init(y, A);
          },
          clone: function() {
            for (var p = d.clone.call(this), g = p._state = this._state.slice(0), l = 0; l < 25; l++)
              g[l] = g[l].clone();
            return p;
          }
        });
        s.SHA3 = d._createHelper(m), s.HmacSHA3 = d._createHmacHelper(m);
      })(Math), r.SHA3;
    });
  })(G0)), G0.exports;
}
var U0 = { exports: {} }, ya = U0.exports, rr;
function ba() {
  return rr || (rr = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(ya, function(r) {
      /** @preserve
      			(c) 2012 by Cédric Mesnil. All rights reserved.
      
      			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
      
      			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
      			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
      
      			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
      			*/
      return (function(e) {
        var s = r, x = s.lib, C = x.WordArray, d = x.Hasher, c = s.algo, t = C.create([
          0,
          1,
          2,
          3,
          4,
          5,
          6,
          7,
          8,
          9,
          10,
          11,
          12,
          13,
          14,
          15,
          7,
          4,
          13,
          1,
          10,
          6,
          15,
          3,
          12,
          0,
          9,
          5,
          2,
          14,
          11,
          8,
          3,
          10,
          14,
          4,
          9,
          15,
          8,
          1,
          2,
          7,
          0,
          6,
          13,
          11,
          5,
          12,
          1,
          9,
          11,
          10,
          0,
          8,
          12,
          4,
          13,
          3,
          7,
          15,
          14,
          5,
          6,
          2,
          4,
          0,
          5,
          9,
          7,
          12,
          2,
          10,
          14,
          1,
          3,
          8,
          11,
          6,
          15,
          13
        ]), a = C.create([
          5,
          14,
          7,
          0,
          9,
          2,
          11,
          4,
          13,
          6,
          15,
          8,
          1,
          10,
          3,
          12,
          6,
          11,
          3,
          7,
          0,
          13,
          5,
          10,
          14,
          15,
          8,
          12,
          4,
          9,
          1,
          2,
          15,
          5,
          1,
          3,
          7,
          14,
          6,
          9,
          11,
          8,
          12,
          2,
          10,
          0,
          4,
          13,
          8,
          6,
          4,
          1,
          3,
          11,
          15,
          0,
          5,
          12,
          2,
          13,
          9,
          7,
          10,
          14,
          12,
          15,
          10,
          4,
          1,
          5,
          8,
          7,
          6,
          2,
          13,
          14,
          0,
          3,
          9,
          11
        ]), h = C.create([
          11,
          14,
          15,
          12,
          5,
          8,
          7,
          9,
          11,
          13,
          14,
          15,
          6,
          7,
          9,
          8,
          7,
          6,
          8,
          13,
          11,
          9,
          7,
          15,
          7,
          12,
          15,
          9,
          11,
          7,
          13,
          12,
          11,
          13,
          6,
          7,
          14,
          9,
          13,
          15,
          14,
          8,
          13,
          6,
          5,
          12,
          7,
          5,
          11,
          12,
          14,
          15,
          14,
          15,
          9,
          8,
          9,
          14,
          5,
          6,
          8,
          6,
          5,
          12,
          9,
          15,
          5,
          11,
          6,
          8,
          13,
          12,
          5,
          12,
          13,
          14,
          11,
          8,
          5,
          6
        ]), n = C.create([
          8,
          9,
          9,
          11,
          13,
          15,
          15,
          5,
          7,
          7,
          8,
          11,
          14,
          14,
          12,
          6,
          9,
          13,
          15,
          7,
          12,
          8,
          9,
          11,
          7,
          7,
          12,
          7,
          6,
          15,
          13,
          11,
          9,
          7,
          15,
          11,
          8,
          6,
          6,
          14,
          12,
          13,
          5,
          14,
          13,
          13,
          7,
          5,
          15,
          5,
          8,
          11,
          14,
          14,
          6,
          14,
          6,
          9,
          12,
          9,
          12,
          5,
          15,
          8,
          8,
          5,
          12,
          9,
          12,
          5,
          14,
          6,
          8,
          13,
          6,
          5,
          15,
          13,
          11,
          11
        ]), f = C.create([0, 1518500249, 1859775393, 2400959708, 2840853838]), v = C.create([1352829926, 1548603684, 1836072691, 2053994217, 0]), m = c.RIPEMD160 = d.extend({
          _doReset: function() {
            this._hash = C.create([1732584193, 4023233417, 2562383102, 271733878, 3285377520]);
          },
          _doProcessBlock: function(E, y) {
            for (var b = 0; b < 16; b++) {
              var S = y + b, F = E[S];
              E[S] = (F << 8 | F >>> 24) & 16711935 | (F << 24 | F >>> 8) & 4278255360;
            }
            var D = this._hash.words, _ = f.words, w = v.words, P = t.words, O = a.words, W = h.words, T = n.words, G, L, U, M, z, H, R, $, N, j;
            H = G = D[0], R = L = D[1], $ = U = D[2], N = M = D[3], j = z = D[4];
            for (var q, b = 0; b < 80; b += 1)
              q = G + E[y + P[b]] | 0, b < 16 ? q += p(L, U, M) + _[0] : b < 32 ? q += g(L, U, M) + _[1] : b < 48 ? q += l(L, U, M) + _[2] : b < 64 ? q += u(L, U, M) + _[3] : q += B(L, U, M) + _[4], q = q | 0, q = A(q, W[b]), q = q + z | 0, G = z, z = M, M = A(U, 10), U = L, L = q, q = H + E[y + O[b]] | 0, b < 16 ? q += B(R, $, N) + w[0] : b < 32 ? q += u(R, $, N) + w[1] : b < 48 ? q += l(R, $, N) + w[2] : b < 64 ? q += g(R, $, N) + w[3] : q += p(R, $, N) + w[4], q = q | 0, q = A(q, T[b]), q = q + j | 0, H = j, j = N, N = A($, 10), $ = R, R = q;
            q = D[1] + U + N | 0, D[1] = D[2] + M + j | 0, D[2] = D[3] + z + H | 0, D[3] = D[4] + G + R | 0, D[4] = D[0] + L + $ | 0, D[0] = q;
          },
          _doFinalize: function() {
            var E = this._data, y = E.words, b = this._nDataBytes * 8, S = E.sigBytes * 8;
            y[S >>> 5] |= 128 << 24 - S % 32, y[(S + 64 >>> 9 << 4) + 14] = (b << 8 | b >>> 24) & 16711935 | (b << 24 | b >>> 8) & 4278255360, E.sigBytes = (y.length + 1) * 4, this._process();
            for (var F = this._hash, D = F.words, _ = 0; _ < 5; _++) {
              var w = D[_];
              D[_] = (w << 8 | w >>> 24) & 16711935 | (w << 24 | w >>> 8) & 4278255360;
            }
            return F;
          },
          clone: function() {
            var E = d.clone.call(this);
            return E._hash = this._hash.clone(), E;
          }
        });
        function p(E, y, b) {
          return E ^ y ^ b;
        }
        function g(E, y, b) {
          return E & y | ~E & b;
        }
        function l(E, y, b) {
          return (E | ~y) ^ b;
        }
        function u(E, y, b) {
          return E & b | y & ~b;
        }
        function B(E, y, b) {
          return E ^ (y | ~b);
        }
        function A(E, y) {
          return E << y | E >>> 32 - y;
        }
        s.RIPEMD160 = d._createHelper(m), s.HmacRIPEMD160 = d._createHmacHelper(m);
      })(), r.RIPEMD160;
    });
  })(U0)), U0.exports;
}
var $0 = { exports: {} }, _a = $0.exports, tr;
function De() {
  return tr || (tr = 1, (function(o, i) {
    (function(r, e) {
      o.exports = e(I());
    })(_a, function(r) {
      (function() {
        var e = r, s = e.lib, x = s.Base, C = e.enc, d = C.Utf8, c = e.algo;
        c.HMAC = x.extend({
          /**
           * Initializes a newly created HMAC.
           *
           * @param {Hasher} hasher The hash algorithm to use.
           * @param {WordArray|string} key The secret key.
           *
           * @example
           *
           *     var hmacHasher = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, key);
           */
          init: function(t, a) {
            t = this._hasher = new t.init(), typeof a == "string" && (a = d.parse(a));
            var h = t.blockSize, n = h * 4;
            a.sigBytes > n && (a = t.finalize(a)), a.clamp();
            for (var f = this._oKey = a.clone(), v = this._iKey = a.clone(), m = f.words, p = v.words, g = 0; g < h; g++)
              m[g] ^= 1549556828, p[g] ^= 909522486;
            f.sigBytes = v.sigBytes = n, this.reset();
          },
          /**
           * Resets this HMAC to its initial state.
           *
           * @example
           *
           *     hmacHasher.reset();
           */
          reset: function() {
            var t = this._hasher;
            t.reset(), t.update(this._iKey);
          },
          /**
           * Updates this HMAC with a message.
           *
           * @param {WordArray|string} messageUpdate The message to append.
           *
           * @return {HMAC} This HMAC instance.
           *
           * @example
           *
           *     hmacHasher.update('message');
           *     hmacHasher.update(wordArray);
           */
          update: function(t) {
            return this._hasher.update(t), this;
          },
          /**
           * Finalizes the HMAC computation.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} messageUpdate (Optional) A final message update.
           *
           * @return {WordArray} The HMAC.
           *
           * @example
           *
           *     var hmac = hmacHasher.finalize();
           *     var hmac = hmacHasher.finalize('message');
           *     var hmac = hmacHasher.finalize(wordArray);
           */
          finalize: function(t) {
            var a = this._hasher, h = a.finalize(t);
            a.reset();
            var n = a.finalize(this._oKey.clone().concat(h));
            return n;
          }
        });
      })();
    });
  })($0)), $0.exports;
}
var N0 = { exports: {} }, wa = N0.exports, ar;
function ka() {
  return ar || (ar = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), Fe(), De());
    })(wa, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.Base, C = s.WordArray, d = e.algo, c = d.SHA256, t = d.HMAC, a = d.PBKDF2 = x.extend({
          /**
           * Configuration options.
           *
           * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
           * @property {Hasher} hasher The hasher to use. Default: SHA256
           * @property {number} iterations The number of iterations to perform. Default: 250000
           */
          cfg: x.extend({
            keySize: 128 / 32,
            hasher: c,
            iterations: 25e4
          }),
          /**
           * Initializes a newly created key derivation function.
           *
           * @param {Object} cfg (Optional) The configuration options to use for the derivation.
           *
           * @example
           *
           *     var kdf = CryptoJS.algo.PBKDF2.create();
           *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8 });
           *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8, iterations: 1000 });
           */
          init: function(h) {
            this.cfg = this.cfg.extend(h);
          },
          /**
           * Computes the Password-Based Key Derivation Function 2.
           *
           * @param {WordArray|string} password The password.
           * @param {WordArray|string} salt A salt.
           *
           * @return {WordArray} The derived key.
           *
           * @example
           *
           *     var key = kdf.compute(password, salt);
           */
          compute: function(h, n) {
            for (var f = this.cfg, v = t.create(f.hasher, h), m = C.create(), p = C.create([1]), g = m.words, l = p.words, u = f.keySize, B = f.iterations; g.length < u; ) {
              var A = v.update(n).finalize(p);
              v.reset();
              for (var E = A.words, y = E.length, b = A, S = 1; S < B; S++) {
                b = v.finalize(b), v.reset();
                for (var F = b.words, D = 0; D < y; D++)
                  E[D] ^= F[D];
              }
              m.concat(A), l[0]++;
            }
            return m.sigBytes = u * 4, m;
          }
        });
        e.PBKDF2 = function(h, n, f) {
          return a.create(f).compute(h, n);
        };
      })(), r.PBKDF2;
    });
  })(N0)), N0.exports;
}
var V0 = { exports: {} }, Sa = V0.exports, nr;
function l0() {
  return nr || (nr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), Sr(), De());
    })(Sa, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.Base, C = s.WordArray, d = e.algo, c = d.MD5, t = d.EvpKDF = x.extend({
          /**
           * Configuration options.
           *
           * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
           * @property {Hasher} hasher The hash algorithm to use. Default: MD5
           * @property {number} iterations The number of iterations to perform. Default: 1
           */
          cfg: x.extend({
            keySize: 128 / 32,
            hasher: c,
            iterations: 1
          }),
          /**
           * Initializes a newly created key derivation function.
           *
           * @param {Object} cfg (Optional) The configuration options to use for the derivation.
           *
           * @example
           *
           *     var kdf = CryptoJS.algo.EvpKDF.create();
           *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8 });
           *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8, iterations: 1000 });
           */
          init: function(a) {
            this.cfg = this.cfg.extend(a);
          },
          /**
           * Derives a key from a password.
           *
           * @param {WordArray|string} password The password.
           * @param {WordArray|string} salt A salt.
           *
           * @return {WordArray} The derived key.
           *
           * @example
           *
           *     var key = kdf.compute(password, salt);
           */
          compute: function(a, h) {
            for (var n, f = this.cfg, v = f.hasher.create(), m = C.create(), p = m.words, g = f.keySize, l = f.iterations; p.length < g; ) {
              n && v.update(n), n = v.update(a).finalize(h), v.reset();
              for (var u = 1; u < l; u++)
                n = v.finalize(n), v.reset();
              m.concat(n);
            }
            return m.sigBytes = g * 4, m;
          }
        });
        e.EvpKDF = function(a, h, n) {
          return t.create(n).compute(a, h);
        };
      })(), r.EvpKDF;
    });
  })(V0)), V0.exports;
}
var j0 = { exports: {} }, Ma = j0.exports, or;
function X() {
  return or || (or = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), l0());
    })(Ma, function(r) {
      r.lib.Cipher || (function(e) {
        var s = r, x = s.lib, C = x.Base, d = x.WordArray, c = x.BufferedBlockAlgorithm, t = s.enc;
        t.Utf8;
        var a = t.Base64, h = s.algo, n = h.EvpKDF, f = x.Cipher = c.extend({
          /**
           * Configuration options.
           *
           * @property {WordArray} iv The IV to use for this operation.
           */
          cfg: C.extend(),
          /**
           * Creates this cipher in encryption mode.
           *
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {Cipher} A cipher instance.
           *
           * @static
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.createEncryptor(keyWordArray, { iv: ivWordArray });
           */
          createEncryptor: function(F, D) {
            return this.create(this._ENC_XFORM_MODE, F, D);
          },
          /**
           * Creates this cipher in decryption mode.
           *
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {Cipher} A cipher instance.
           *
           * @static
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.createDecryptor(keyWordArray, { iv: ivWordArray });
           */
          createDecryptor: function(F, D) {
            return this.create(this._DEC_XFORM_MODE, F, D);
          },
          /**
           * Initializes a newly created cipher.
           *
           * @param {number} xformMode Either the encryption or decryption transormation mode constant.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.create(CryptoJS.algo.AES._ENC_XFORM_MODE, keyWordArray, { iv: ivWordArray });
           */
          init: function(F, D, _) {
            this.cfg = this.cfg.extend(_), this._xformMode = F, this._key = D, this.reset();
          },
          /**
           * Resets this cipher to its initial state.
           *
           * @example
           *
           *     cipher.reset();
           */
          reset: function() {
            c.reset.call(this), this._doReset();
          },
          /**
           * Adds data to be encrypted or decrypted.
           *
           * @param {WordArray|string} dataUpdate The data to encrypt or decrypt.
           *
           * @return {WordArray} The data after processing.
           *
           * @example
           *
           *     var encrypted = cipher.process('data');
           *     var encrypted = cipher.process(wordArray);
           */
          process: function(F) {
            return this._append(F), this._process();
          },
          /**
           * Finalizes the encryption or decryption process.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} dataUpdate The final data to encrypt or decrypt.
           *
           * @return {WordArray} The data after final processing.
           *
           * @example
           *
           *     var encrypted = cipher.finalize();
           *     var encrypted = cipher.finalize('data');
           *     var encrypted = cipher.finalize(wordArray);
           */
          finalize: function(F) {
            F && this._append(F);
            var D = this._doFinalize();
            return D;
          },
          keySize: 128 / 32,
          ivSize: 128 / 32,
          _ENC_XFORM_MODE: 1,
          _DEC_XFORM_MODE: 2,
          /**
           * Creates shortcut functions to a cipher's object interface.
           *
           * @param {Cipher} cipher The cipher to create a helper for.
           *
           * @return {Object} An object with encrypt and decrypt shortcut functions.
           *
           * @static
           *
           * @example
           *
           *     var AES = CryptoJS.lib.Cipher._createHelper(CryptoJS.algo.AES);
           */
          _createHelper: /* @__PURE__ */ (function() {
            function F(D) {
              return typeof D == "string" ? S : E;
            }
            return function(D) {
              return {
                encrypt: function(_, w, P) {
                  return F(w).encrypt(D, _, w, P);
                },
                decrypt: function(_, w, P) {
                  return F(w).decrypt(D, _, w, P);
                }
              };
            };
          })()
        });
        x.StreamCipher = f.extend({
          _doFinalize: function() {
            var F = this._process(!0);
            return F;
          },
          blockSize: 1
        });
        var v = s.mode = {}, m = x.BlockCipherMode = C.extend({
          /**
           * Creates this mode for encryption.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @static
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.createEncryptor(cipher, iv.words);
           */
          createEncryptor: function(F, D) {
            return this.Encryptor.create(F, D);
          },
          /**
           * Creates this mode for decryption.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @static
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.createDecryptor(cipher, iv.words);
           */
          createDecryptor: function(F, D) {
            return this.Decryptor.create(F, D);
          },
          /**
           * Initializes a newly created mode.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.Encryptor.create(cipher, iv.words);
           */
          init: function(F, D) {
            this._cipher = F, this._iv = D;
          }
        }), p = v.CBC = (function() {
          var F = m.extend();
          F.Encryptor = F.extend({
            /**
             * Processes the data block at offset.
             *
             * @param {Array} words The data words to operate on.
             * @param {number} offset The offset where the block starts.
             *
             * @example
             *
             *     mode.processBlock(data.words, offset);
             */
            processBlock: function(_, w) {
              var P = this._cipher, O = P.blockSize;
              D.call(this, _, w, O), P.encryptBlock(_, w), this._prevBlock = _.slice(w, w + O);
            }
          }), F.Decryptor = F.extend({
            /**
             * Processes the data block at offset.
             *
             * @param {Array} words The data words to operate on.
             * @param {number} offset The offset where the block starts.
             *
             * @example
             *
             *     mode.processBlock(data.words, offset);
             */
            processBlock: function(_, w) {
              var P = this._cipher, O = P.blockSize, W = _.slice(w, w + O);
              P.decryptBlock(_, w), D.call(this, _, w, O), this._prevBlock = W;
            }
          });
          function D(_, w, P) {
            var O, W = this._iv;
            W ? (O = W, this._iv = e) : O = this._prevBlock;
            for (var T = 0; T < P; T++)
              _[w + T] ^= O[T];
          }
          return F;
        })(), g = s.pad = {}, l = g.Pkcs7 = {
          /**
           * Pads data using the algorithm defined in PKCS #5/7.
           *
           * @param {WordArray} data The data to pad.
           * @param {number} blockSize The multiple that the data should be padded to.
           *
           * @static
           *
           * @example
           *
           *     CryptoJS.pad.Pkcs7.pad(wordArray, 4);
           */
          pad: function(F, D) {
            for (var _ = D * 4, w = _ - F.sigBytes % _, P = w << 24 | w << 16 | w << 8 | w, O = [], W = 0; W < w; W += 4)
              O.push(P);
            var T = d.create(O, w);
            F.concat(T);
          },
          /**
           * Unpads data that had been padded using the algorithm defined in PKCS #5/7.
           *
           * @param {WordArray} data The data to unpad.
           *
           * @static
           *
           * @example
           *
           *     CryptoJS.pad.Pkcs7.unpad(wordArray);
           */
          unpad: function(F) {
            var D = F.words[F.sigBytes - 1 >>> 2] & 255;
            F.sigBytes -= D;
          }
        };
        x.BlockCipher = f.extend({
          /**
           * Configuration options.
           *
           * @property {Mode} mode The block mode to use. Default: CBC
           * @property {Padding} padding The padding strategy to use. Default: Pkcs7
           */
          cfg: f.cfg.extend({
            mode: p,
            padding: l
          }),
          reset: function() {
            var F;
            f.reset.call(this);
            var D = this.cfg, _ = D.iv, w = D.mode;
            this._xformMode == this._ENC_XFORM_MODE ? F = w.createEncryptor : (F = w.createDecryptor, this._minBufferSize = 1), this._mode && this._mode.__creator == F ? this._mode.init(this, _ && _.words) : (this._mode = F.call(w, this, _ && _.words), this._mode.__creator = F);
          },
          _doProcessBlock: function(F, D) {
            this._mode.processBlock(F, D);
          },
          _doFinalize: function() {
            var F, D = this.cfg.padding;
            return this._xformMode == this._ENC_XFORM_MODE ? (D.pad(this._data, this.blockSize), F = this._process(!0)) : (F = this._process(!0), D.unpad(F)), F;
          },
          blockSize: 128 / 32
        });
        var u = x.CipherParams = C.extend({
          /**
           * Initializes a newly created cipher params object.
           *
           * @param {Object} cipherParams An object with any of the possible cipher parameters.
           *
           * @example
           *
           *     var cipherParams = CryptoJS.lib.CipherParams.create({
           *         ciphertext: ciphertextWordArray,
           *         key: keyWordArray,
           *         iv: ivWordArray,
           *         salt: saltWordArray,
           *         algorithm: CryptoJS.algo.AES,
           *         mode: CryptoJS.mode.CBC,
           *         padding: CryptoJS.pad.PKCS7,
           *         blockSize: 4,
           *         formatter: CryptoJS.format.OpenSSL
           *     });
           */
          init: function(F) {
            this.mixIn(F);
          },
          /**
           * Converts this cipher params object to a string.
           *
           * @param {Format} formatter (Optional) The formatting strategy to use.
           *
           * @return {string} The stringified cipher params.
           *
           * @throws Error If neither the formatter nor the default formatter is set.
           *
           * @example
           *
           *     var string = cipherParams + '';
           *     var string = cipherParams.toString();
           *     var string = cipherParams.toString(CryptoJS.format.OpenSSL);
           */
          toString: function(F) {
            return (F || this.formatter).stringify(this);
          }
        }), B = s.format = {}, A = B.OpenSSL = {
          /**
           * Converts a cipher params object to an OpenSSL-compatible string.
           *
           * @param {CipherParams} cipherParams The cipher params object.
           *
           * @return {string} The OpenSSL-compatible string.
           *
           * @static
           *
           * @example
           *
           *     var openSSLString = CryptoJS.format.OpenSSL.stringify(cipherParams);
           */
          stringify: function(F) {
            var D, _ = F.ciphertext, w = F.salt;
            return w ? D = d.create([1398893684, 1701076831]).concat(w).concat(_) : D = _, D.toString(a);
          },
          /**
           * Converts an OpenSSL-compatible string to a cipher params object.
           *
           * @param {string} openSSLStr The OpenSSL-compatible string.
           *
           * @return {CipherParams} The cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var cipherParams = CryptoJS.format.OpenSSL.parse(openSSLString);
           */
          parse: function(F) {
            var D, _ = a.parse(F), w = _.words;
            return w[0] == 1398893684 && w[1] == 1701076831 && (D = d.create(w.slice(2, 4)), w.splice(0, 4), _.sigBytes -= 16), u.create({ ciphertext: _, salt: D });
          }
        }, E = x.SerializableCipher = C.extend({
          /**
           * Configuration options.
           *
           * @property {Formatter} format The formatting strategy to convert cipher param objects to and from a string. Default: OpenSSL
           */
          cfg: C.extend({
            format: A
          }),
          /**
           * Encrypts a message.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {WordArray|string} message The message to encrypt.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {CipherParams} A cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           */
          encrypt: function(F, D, _, w) {
            w = this.cfg.extend(w);
            var P = F.createEncryptor(_, w), O = P.finalize(D), W = P.cfg;
            return u.create({
              ciphertext: O,
              key: _,
              iv: W.iv,
              algorithm: F,
              mode: W.mode,
              padding: W.padding,
              blockSize: F.blockSize,
              formatter: w.format
            });
          },
          /**
           * Decrypts serialized ciphertext.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {WordArray} The plaintext.
           *
           * @static
           *
           * @example
           *
           *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           */
          decrypt: function(F, D, _, w) {
            w = this.cfg.extend(w), D = this._parse(D, w.format);
            var P = F.createDecryptor(_, w).finalize(D.ciphertext);
            return P;
          },
          /**
           * Converts serialized ciphertext to CipherParams,
           * else assumed CipherParams already and returns ciphertext unchanged.
           *
           * @param {CipherParams|string} ciphertext The ciphertext.
           * @param {Formatter} format The formatting strategy to use to parse serialized ciphertext.
           *
           * @return {CipherParams} The unserialized ciphertext.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);
           */
          _parse: function(F, D) {
            return typeof F == "string" ? D.parse(F, this) : F;
          }
        }), y = s.kdf = {}, b = y.OpenSSL = {
          /**
           * Derives a key and IV from a password.
           *
           * @param {string} password The password to derive from.
           * @param {number} keySize The size in words of the key to generate.
           * @param {number} ivSize The size in words of the IV to generate.
           * @param {WordArray|string} salt (Optional) A 64-bit salt to use. If omitted, a salt will be generated randomly.
           *
           * @return {CipherParams} A cipher params object with the key, IV, and salt.
           *
           * @static
           *
           * @example
           *
           *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32);
           *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32, 'saltsalt');
           */
          execute: function(F, D, _, w, P) {
            if (w || (w = d.random(64 / 8)), P)
              var O = n.create({ keySize: D + _, hasher: P }).compute(F, w);
            else
              var O = n.create({ keySize: D + _ }).compute(F, w);
            var W = d.create(O.words.slice(D), _ * 4);
            return O.sigBytes = D * 4, u.create({ key: O, iv: W, salt: w });
          }
        }, S = x.PasswordBasedCipher = E.extend({
          /**
           * Configuration options.
           *
           * @property {KDF} kdf The key derivation function to use to generate a key and IV from a password. Default: OpenSSL
           */
          cfg: E.cfg.extend({
            kdf: b
          }),
          /**
           * Encrypts a message using a password.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {WordArray|string} message The message to encrypt.
           * @param {string} password The password.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {CipherParams} A cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password');
           *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password', { format: CryptoJS.format.OpenSSL });
           */
          encrypt: function(F, D, _, w) {
            w = this.cfg.extend(w);
            var P = w.kdf.execute(_, F.keySize, F.ivSize, w.salt, w.hasher);
            w.iv = P.iv;
            var O = E.encrypt.call(this, F, D, P.key, w);
            return O.mixIn(P), O;
          },
          /**
           * Decrypts serialized ciphertext using a password.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
           * @param {string} password The password.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {WordArray} The plaintext.
           *
           * @static
           *
           * @example
           *
           *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, 'password', { format: CryptoJS.format.OpenSSL });
           *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, 'password', { format: CryptoJS.format.OpenSSL });
           */
          decrypt: function(F, D, _, w) {
            w = this.cfg.extend(w), D = this._parse(D, w.format);
            var P = w.kdf.execute(_, F.keySize, F.ivSize, D.salt, w.hasher);
            w.iv = P.iv;
            var O = E.decrypt.call(this, F, D, P.key, w);
            return O;
          }
        });
      })();
    });
  })(j0)), j0.exports;
}
var X0 = { exports: {} }, Ra = X0.exports, ir;
function za() {
  return ir || (ir = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Ra, function(r) {
      return r.mode.CFB = (function() {
        var e = r.lib.BlockCipherMode.extend();
        e.Encryptor = e.extend({
          processBlock: function(x, C) {
            var d = this._cipher, c = d.blockSize;
            s.call(this, x, C, c, d), this._prevBlock = x.slice(C, C + c);
          }
        }), e.Decryptor = e.extend({
          processBlock: function(x, C) {
            var d = this._cipher, c = d.blockSize, t = x.slice(C, C + c);
            s.call(this, x, C, c, d), this._prevBlock = t;
          }
        });
        function s(x, C, d, c) {
          var t, a = this._iv;
          a ? (t = a.slice(0), this._iv = void 0) : t = this._prevBlock, c.encryptBlock(t, 0);
          for (var h = 0; h < d; h++)
            x[C + h] ^= t[h];
        }
        return e;
      })(), r.mode.CFB;
    });
  })(X0)), X0.exports;
}
var K0 = { exports: {} }, Ha = K0.exports, sr;
function Pa() {
  return sr || (sr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Ha, function(r) {
      return r.mode.CTR = (function() {
        var e = r.lib.BlockCipherMode.extend(), s = e.Encryptor = e.extend({
          processBlock: function(x, C) {
            var d = this._cipher, c = d.blockSize, t = this._iv, a = this._counter;
            t && (a = this._counter = t.slice(0), this._iv = void 0);
            var h = a.slice(0);
            d.encryptBlock(h, 0), a[c - 1] = a[c - 1] + 1 | 0;
            for (var n = 0; n < c; n++)
              x[C + n] ^= h[n];
          }
        });
        return e.Decryptor = s, e;
      })(), r.mode.CTR;
    });
  })(K0)), K0.exports;
}
var Y0 = { exports: {} }, Oa = Y0.exports, xr;
function Wa() {
  return xr || (xr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Oa, function(r) {
      /** @preserve
       * Counter block mode compatible with  Dr Brian Gladman fileenc.c
       * derived from CryptoJS.mode.CTR
       * Jan Hruby jhruby.web@gmail.com
       */
      return r.mode.CTRGladman = (function() {
        var e = r.lib.BlockCipherMode.extend();
        function s(d) {
          if ((d >> 24 & 255) === 255) {
            var c = d >> 16 & 255, t = d >> 8 & 255, a = d & 255;
            c === 255 ? (c = 0, t === 255 ? (t = 0, a === 255 ? a = 0 : ++a) : ++t) : ++c, d = 0, d += c << 16, d += t << 8, d += a;
          } else
            d += 1 << 24;
          return d;
        }
        function x(d) {
          return (d[0] = s(d[0])) === 0 && (d[1] = s(d[1])), d;
        }
        var C = e.Encryptor = e.extend({
          processBlock: function(d, c) {
            var t = this._cipher, a = t.blockSize, h = this._iv, n = this._counter;
            h && (n = this._counter = h.slice(0), this._iv = void 0), x(n);
            var f = n.slice(0);
            t.encryptBlock(f, 0);
            for (var v = 0; v < a; v++)
              d[c + v] ^= f[v];
          }
        });
        return e.Decryptor = C, e;
      })(), r.mode.CTRGladman;
    });
  })(Y0)), Y0.exports;
}
var Z0 = { exports: {} }, Ta = Z0.exports, cr;
function qa() {
  return cr || (cr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Ta, function(r) {
      return r.mode.OFB = (function() {
        var e = r.lib.BlockCipherMode.extend(), s = e.Encryptor = e.extend({
          processBlock: function(x, C) {
            var d = this._cipher, c = d.blockSize, t = this._iv, a = this._keystream;
            t && (a = this._keystream = t.slice(0), this._iv = void 0), d.encryptBlock(a, 0);
            for (var h = 0; h < c; h++)
              x[C + h] ^= a[h];
          }
        });
        return e.Decryptor = s, e;
      })(), r.mode.OFB;
    });
  })(Z0)), Z0.exports;
}
var Q0 = { exports: {} }, La = Q0.exports, fr;
function Ia() {
  return fr || (fr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(La, function(r) {
      return r.mode.ECB = (function() {
        var e = r.lib.BlockCipherMode.extend();
        return e.Encryptor = e.extend({
          processBlock: function(s, x) {
            this._cipher.encryptBlock(s, x);
          }
        }), e.Decryptor = e.extend({
          processBlock: function(s, x) {
            this._cipher.decryptBlock(s, x);
          }
        }), e;
      })(), r.mode.ECB;
    });
  })(Q0)), Q0.exports;
}
var J0 = { exports: {} }, Ga = J0.exports, lr;
function Ua() {
  return lr || (lr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Ga, function(r) {
      return r.pad.AnsiX923 = {
        pad: function(e, s) {
          var x = e.sigBytes, C = s * 4, d = C - x % C, c = x + d - 1;
          e.clamp(), e.words[c >>> 2] |= d << 24 - c % 4 * 8, e.sigBytes += d;
        },
        unpad: function(e) {
          var s = e.words[e.sigBytes - 1 >>> 2] & 255;
          e.sigBytes -= s;
        }
      }, r.pad.Ansix923;
    });
  })(J0)), J0.exports;
}
var ee = { exports: {} }, $a = ee.exports, hr;
function Na() {
  return hr || (hr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })($a, function(r) {
      return r.pad.Iso10126 = {
        pad: function(e, s) {
          var x = s * 4, C = x - e.sigBytes % x;
          e.concat(r.lib.WordArray.random(C - 1)).concat(r.lib.WordArray.create([C << 24], 1));
        },
        unpad: function(e) {
          var s = e.words[e.sigBytes - 1 >>> 2] & 255;
          e.sigBytes -= s;
        }
      }, r.pad.Iso10126;
    });
  })(ee)), ee.exports;
}
var re = { exports: {} }, Va = re.exports, ur;
function ja() {
  return ur || (ur = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Va, function(r) {
      return r.pad.Iso97971 = {
        pad: function(e, s) {
          e.concat(r.lib.WordArray.create([2147483648], 1)), r.pad.ZeroPadding.pad(e, s);
        },
        unpad: function(e) {
          r.pad.ZeroPadding.unpad(e), e.sigBytes--;
        }
      }, r.pad.Iso97971;
    });
  })(re)), re.exports;
}
var te = { exports: {} }, Xa = te.exports, dr;
function Ka() {
  return dr || (dr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Xa, function(r) {
      return r.pad.ZeroPadding = {
        pad: function(e, s) {
          var x = s * 4;
          e.clamp(), e.sigBytes += x - (e.sigBytes % x || x);
        },
        unpad: function(e) {
          for (var s = e.words, x = e.sigBytes - 1, x = e.sigBytes - 1; x >= 0; x--)
            if (s[x >>> 2] >>> 24 - x % 4 * 8 & 255) {
              e.sigBytes = x + 1;
              break;
            }
        }
      }, r.pad.ZeroPadding;
    });
  })(te)), te.exports;
}
var ae = { exports: {} }, Ya = ae.exports, vr;
function Za() {
  return vr || (vr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Ya, function(r) {
      return r.pad.NoPadding = {
        pad: function() {
        },
        unpad: function() {
        }
      }, r.pad.NoPadding;
    });
  })(ae)), ae.exports;
}
var ne = { exports: {} }, Qa = ne.exports, pr;
function Ja() {
  return pr || (pr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), X());
    })(Qa, function(r) {
      return (function(e) {
        var s = r, x = s.lib, C = x.CipherParams, d = s.enc, c = d.Hex, t = s.format;
        t.Hex = {
          /**
           * Converts the ciphertext of a cipher params object to a hexadecimally encoded string.
           *
           * @param {CipherParams} cipherParams The cipher params object.
           *
           * @return {string} The hexadecimally encoded string.
           *
           * @static
           *
           * @example
           *
           *     var hexString = CryptoJS.format.Hex.stringify(cipherParams);
           */
          stringify: function(a) {
            return a.ciphertext.toString(c);
          },
          /**
           * Converts a hexadecimally encoded ciphertext string to a cipher params object.
           *
           * @param {string} input The hexadecimally encoded string.
           *
           * @return {CipherParams} The cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var cipherParams = CryptoJS.format.Hex.parse(hexString);
           */
          parse: function(a) {
            var h = c.parse(a);
            return C.create({ ciphertext: h });
          }
        };
      })(), r.format.Hex;
    });
  })(ne)), ne.exports;
}
var oe = { exports: {} }, en = oe.exports, Br;
function rn() {
  return Br || (Br = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), h0(), u0(), l0(), X());
    })(en, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.BlockCipher, C = e.algo, d = [], c = [], t = [], a = [], h = [], n = [], f = [], v = [], m = [], p = [];
        (function() {
          for (var u = [], B = 0; B < 256; B++)
            B < 128 ? u[B] = B << 1 : u[B] = B << 1 ^ 283;
          for (var A = 0, E = 0, B = 0; B < 256; B++) {
            var y = E ^ E << 1 ^ E << 2 ^ E << 3 ^ E << 4;
            y = y >>> 8 ^ y & 255 ^ 99, d[A] = y, c[y] = A;
            var b = u[A], S = u[b], F = u[S], D = u[y] * 257 ^ y * 16843008;
            t[A] = D << 24 | D >>> 8, a[A] = D << 16 | D >>> 16, h[A] = D << 8 | D >>> 24, n[A] = D;
            var D = F * 16843009 ^ S * 65537 ^ b * 257 ^ A * 16843008;
            f[y] = D << 24 | D >>> 8, v[y] = D << 16 | D >>> 16, m[y] = D << 8 | D >>> 24, p[y] = D, A ? (A = b ^ u[u[u[F ^ b]]], E ^= u[u[E]]) : A = E = 1;
          }
        })();
        var g = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], l = C.AES = x.extend({
          _doReset: function() {
            var u;
            if (!(this._nRounds && this._keyPriorReset === this._key)) {
              for (var B = this._keyPriorReset = this._key, A = B.words, E = B.sigBytes / 4, y = this._nRounds = E + 6, b = (y + 1) * 4, S = this._keySchedule = [], F = 0; F < b; F++)
                F < E ? S[F] = A[F] : (u = S[F - 1], F % E ? E > 6 && F % E == 4 && (u = d[u >>> 24] << 24 | d[u >>> 16 & 255] << 16 | d[u >>> 8 & 255] << 8 | d[u & 255]) : (u = u << 8 | u >>> 24, u = d[u >>> 24] << 24 | d[u >>> 16 & 255] << 16 | d[u >>> 8 & 255] << 8 | d[u & 255], u ^= g[F / E | 0] << 24), S[F] = S[F - E] ^ u);
              for (var D = this._invKeySchedule = [], _ = 0; _ < b; _++) {
                var F = b - _;
                if (_ % 4)
                  var u = S[F];
                else
                  var u = S[F - 4];
                _ < 4 || F <= 4 ? D[_] = u : D[_] = f[d[u >>> 24]] ^ v[d[u >>> 16 & 255]] ^ m[d[u >>> 8 & 255]] ^ p[d[u & 255]];
              }
            }
          },
          encryptBlock: function(u, B) {
            this._doCryptBlock(u, B, this._keySchedule, t, a, h, n, d);
          },
          decryptBlock: function(u, B) {
            var A = u[B + 1];
            u[B + 1] = u[B + 3], u[B + 3] = A, this._doCryptBlock(u, B, this._invKeySchedule, f, v, m, p, c);
            var A = u[B + 1];
            u[B + 1] = u[B + 3], u[B + 3] = A;
          },
          _doCryptBlock: function(u, B, A, E, y, b, S, F) {
            for (var D = this._nRounds, _ = u[B] ^ A[0], w = u[B + 1] ^ A[1], P = u[B + 2] ^ A[2], O = u[B + 3] ^ A[3], W = 4, T = 1; T < D; T++) {
              var G = E[_ >>> 24] ^ y[w >>> 16 & 255] ^ b[P >>> 8 & 255] ^ S[O & 255] ^ A[W++], L = E[w >>> 24] ^ y[P >>> 16 & 255] ^ b[O >>> 8 & 255] ^ S[_ & 255] ^ A[W++], U = E[P >>> 24] ^ y[O >>> 16 & 255] ^ b[_ >>> 8 & 255] ^ S[w & 255] ^ A[W++], M = E[O >>> 24] ^ y[_ >>> 16 & 255] ^ b[w >>> 8 & 255] ^ S[P & 255] ^ A[W++];
              _ = G, w = L, P = U, O = M;
            }
            var G = (F[_ >>> 24] << 24 | F[w >>> 16 & 255] << 16 | F[P >>> 8 & 255] << 8 | F[O & 255]) ^ A[W++], L = (F[w >>> 24] << 24 | F[P >>> 16 & 255] << 16 | F[O >>> 8 & 255] << 8 | F[_ & 255]) ^ A[W++], U = (F[P >>> 24] << 24 | F[O >>> 16 & 255] << 16 | F[_ >>> 8 & 255] << 8 | F[w & 255]) ^ A[W++], M = (F[O >>> 24] << 24 | F[_ >>> 16 & 255] << 16 | F[w >>> 8 & 255] << 8 | F[P & 255]) ^ A[W++];
            u[B] = G, u[B + 1] = L, u[B + 2] = U, u[B + 3] = M;
          },
          keySize: 256 / 32
        });
        e.AES = x._createHelper(l);
      })(), r.AES;
    });
  })(oe)), oe.exports;
}
var ie = { exports: {} }, tn = ie.exports, mr;
function an() {
  return mr || (mr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), h0(), u0(), l0(), X());
    })(tn, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.WordArray, C = s.BlockCipher, d = e.algo, c = [
          57,
          49,
          41,
          33,
          25,
          17,
          9,
          1,
          58,
          50,
          42,
          34,
          26,
          18,
          10,
          2,
          59,
          51,
          43,
          35,
          27,
          19,
          11,
          3,
          60,
          52,
          44,
          36,
          63,
          55,
          47,
          39,
          31,
          23,
          15,
          7,
          62,
          54,
          46,
          38,
          30,
          22,
          14,
          6,
          61,
          53,
          45,
          37,
          29,
          21,
          13,
          5,
          28,
          20,
          12,
          4
        ], t = [
          14,
          17,
          11,
          24,
          1,
          5,
          3,
          28,
          15,
          6,
          21,
          10,
          23,
          19,
          12,
          4,
          26,
          8,
          16,
          7,
          27,
          20,
          13,
          2,
          41,
          52,
          31,
          37,
          47,
          55,
          30,
          40,
          51,
          45,
          33,
          48,
          44,
          49,
          39,
          56,
          34,
          53,
          46,
          42,
          50,
          36,
          29,
          32
        ], a = [1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28], h = [
          {
            0: 8421888,
            268435456: 32768,
            536870912: 8421378,
            805306368: 2,
            1073741824: 512,
            1342177280: 8421890,
            1610612736: 8389122,
            1879048192: 8388608,
            2147483648: 514,
            2415919104: 8389120,
            2684354560: 33280,
            2952790016: 8421376,
            3221225472: 32770,
            3489660928: 8388610,
            3758096384: 0,
            4026531840: 33282,
            134217728: 0,
            402653184: 8421890,
            671088640: 33282,
            939524096: 32768,
            1207959552: 8421888,
            1476395008: 512,
            1744830464: 8421378,
            2013265920: 2,
            2281701376: 8389120,
            2550136832: 33280,
            2818572288: 8421376,
            3087007744: 8389122,
            3355443200: 8388610,
            3623878656: 32770,
            3892314112: 514,
            4160749568: 8388608,
            1: 32768,
            268435457: 2,
            536870913: 8421888,
            805306369: 8388608,
            1073741825: 8421378,
            1342177281: 33280,
            1610612737: 512,
            1879048193: 8389122,
            2147483649: 8421890,
            2415919105: 8421376,
            2684354561: 8388610,
            2952790017: 33282,
            3221225473: 514,
            3489660929: 8389120,
            3758096385: 32770,
            4026531841: 0,
            134217729: 8421890,
            402653185: 8421376,
            671088641: 8388608,
            939524097: 512,
            1207959553: 32768,
            1476395009: 8388610,
            1744830465: 2,
            2013265921: 33282,
            2281701377: 32770,
            2550136833: 8389122,
            2818572289: 514,
            3087007745: 8421888,
            3355443201: 8389120,
            3623878657: 0,
            3892314113: 33280,
            4160749569: 8421378
          },
          {
            0: 1074282512,
            16777216: 16384,
            33554432: 524288,
            50331648: 1074266128,
            67108864: 1073741840,
            83886080: 1074282496,
            100663296: 1073758208,
            117440512: 16,
            134217728: 540672,
            150994944: 1073758224,
            167772160: 1073741824,
            184549376: 540688,
            201326592: 524304,
            218103808: 0,
            234881024: 16400,
            251658240: 1074266112,
            8388608: 1073758208,
            25165824: 540688,
            41943040: 16,
            58720256: 1073758224,
            75497472: 1074282512,
            92274688: 1073741824,
            109051904: 524288,
            125829120: 1074266128,
            142606336: 524304,
            159383552: 0,
            176160768: 16384,
            192937984: 1074266112,
            209715200: 1073741840,
            226492416: 540672,
            243269632: 1074282496,
            260046848: 16400,
            268435456: 0,
            285212672: 1074266128,
            301989888: 1073758224,
            318767104: 1074282496,
            335544320: 1074266112,
            352321536: 16,
            369098752: 540688,
            385875968: 16384,
            402653184: 16400,
            419430400: 524288,
            436207616: 524304,
            452984832: 1073741840,
            469762048: 540672,
            486539264: 1073758208,
            503316480: 1073741824,
            520093696: 1074282512,
            276824064: 540688,
            293601280: 524288,
            310378496: 1074266112,
            327155712: 16384,
            343932928: 1073758208,
            360710144: 1074282512,
            377487360: 16,
            394264576: 1073741824,
            411041792: 1074282496,
            427819008: 1073741840,
            444596224: 1073758224,
            461373440: 524304,
            478150656: 0,
            494927872: 16400,
            511705088: 1074266128,
            528482304: 540672
          },
          {
            0: 260,
            1048576: 0,
            2097152: 67109120,
            3145728: 65796,
            4194304: 65540,
            5242880: 67108868,
            6291456: 67174660,
            7340032: 67174400,
            8388608: 67108864,
            9437184: 67174656,
            10485760: 65792,
            11534336: 67174404,
            12582912: 67109124,
            13631488: 65536,
            14680064: 4,
            15728640: 256,
            524288: 67174656,
            1572864: 67174404,
            2621440: 0,
            3670016: 67109120,
            4718592: 67108868,
            5767168: 65536,
            6815744: 65540,
            7864320: 260,
            8912896: 4,
            9961472: 256,
            11010048: 67174400,
            12058624: 65796,
            13107200: 65792,
            14155776: 67109124,
            15204352: 67174660,
            16252928: 67108864,
            16777216: 67174656,
            17825792: 65540,
            18874368: 65536,
            19922944: 67109120,
            20971520: 256,
            22020096: 67174660,
            23068672: 67108868,
            24117248: 0,
            25165824: 67109124,
            26214400: 67108864,
            27262976: 4,
            28311552: 65792,
            29360128: 67174400,
            30408704: 260,
            31457280: 65796,
            32505856: 67174404,
            17301504: 67108864,
            18350080: 260,
            19398656: 67174656,
            20447232: 0,
            21495808: 65540,
            22544384: 67109120,
            23592960: 256,
            24641536: 67174404,
            25690112: 65536,
            26738688: 67174660,
            27787264: 65796,
            28835840: 67108868,
            29884416: 67109124,
            30932992: 67174400,
            31981568: 4,
            33030144: 65792
          },
          {
            0: 2151682048,
            65536: 2147487808,
            131072: 4198464,
            196608: 2151677952,
            262144: 0,
            327680: 4198400,
            393216: 2147483712,
            458752: 4194368,
            524288: 2147483648,
            589824: 4194304,
            655360: 64,
            720896: 2147487744,
            786432: 2151678016,
            851968: 4160,
            917504: 4096,
            983040: 2151682112,
            32768: 2147487808,
            98304: 64,
            163840: 2151678016,
            229376: 2147487744,
            294912: 4198400,
            360448: 2151682112,
            425984: 0,
            491520: 2151677952,
            557056: 4096,
            622592: 2151682048,
            688128: 4194304,
            753664: 4160,
            819200: 2147483648,
            884736: 4194368,
            950272: 4198464,
            1015808: 2147483712,
            1048576: 4194368,
            1114112: 4198400,
            1179648: 2147483712,
            1245184: 0,
            1310720: 4160,
            1376256: 2151678016,
            1441792: 2151682048,
            1507328: 2147487808,
            1572864: 2151682112,
            1638400: 2147483648,
            1703936: 2151677952,
            1769472: 4198464,
            1835008: 2147487744,
            1900544: 4194304,
            1966080: 64,
            2031616: 4096,
            1081344: 2151677952,
            1146880: 2151682112,
            1212416: 0,
            1277952: 4198400,
            1343488: 4194368,
            1409024: 2147483648,
            1474560: 2147487808,
            1540096: 64,
            1605632: 2147483712,
            1671168: 4096,
            1736704: 2147487744,
            1802240: 2151678016,
            1867776: 4160,
            1933312: 2151682048,
            1998848: 4194304,
            2064384: 4198464
          },
          {
            0: 128,
            4096: 17039360,
            8192: 262144,
            12288: 536870912,
            16384: 537133184,
            20480: 16777344,
            24576: 553648256,
            28672: 262272,
            32768: 16777216,
            36864: 537133056,
            40960: 536871040,
            45056: 553910400,
            49152: 553910272,
            53248: 0,
            57344: 17039488,
            61440: 553648128,
            2048: 17039488,
            6144: 553648256,
            10240: 128,
            14336: 17039360,
            18432: 262144,
            22528: 537133184,
            26624: 553910272,
            30720: 536870912,
            34816: 537133056,
            38912: 0,
            43008: 553910400,
            47104: 16777344,
            51200: 536871040,
            55296: 553648128,
            59392: 16777216,
            63488: 262272,
            65536: 262144,
            69632: 128,
            73728: 536870912,
            77824: 553648256,
            81920: 16777344,
            86016: 553910272,
            90112: 537133184,
            94208: 16777216,
            98304: 553910400,
            102400: 553648128,
            106496: 17039360,
            110592: 537133056,
            114688: 262272,
            118784: 536871040,
            122880: 0,
            126976: 17039488,
            67584: 553648256,
            71680: 16777216,
            75776: 17039360,
            79872: 537133184,
            83968: 536870912,
            88064: 17039488,
            92160: 128,
            96256: 553910272,
            100352: 262272,
            104448: 553910400,
            108544: 0,
            112640: 553648128,
            116736: 16777344,
            120832: 262144,
            124928: 537133056,
            129024: 536871040
          },
          {
            0: 268435464,
            256: 8192,
            512: 270532608,
            768: 270540808,
            1024: 268443648,
            1280: 2097152,
            1536: 2097160,
            1792: 268435456,
            2048: 0,
            2304: 268443656,
            2560: 2105344,
            2816: 8,
            3072: 270532616,
            3328: 2105352,
            3584: 8200,
            3840: 270540800,
            128: 270532608,
            384: 270540808,
            640: 8,
            896: 2097152,
            1152: 2105352,
            1408: 268435464,
            1664: 268443648,
            1920: 8200,
            2176: 2097160,
            2432: 8192,
            2688: 268443656,
            2944: 270532616,
            3200: 0,
            3456: 270540800,
            3712: 2105344,
            3968: 268435456,
            4096: 268443648,
            4352: 270532616,
            4608: 270540808,
            4864: 8200,
            5120: 2097152,
            5376: 268435456,
            5632: 268435464,
            5888: 2105344,
            6144: 2105352,
            6400: 0,
            6656: 8,
            6912: 270532608,
            7168: 8192,
            7424: 268443656,
            7680: 270540800,
            7936: 2097160,
            4224: 8,
            4480: 2105344,
            4736: 2097152,
            4992: 268435464,
            5248: 268443648,
            5504: 8200,
            5760: 270540808,
            6016: 270532608,
            6272: 270540800,
            6528: 270532616,
            6784: 8192,
            7040: 2105352,
            7296: 2097160,
            7552: 0,
            7808: 268435456,
            8064: 268443656
          },
          {
            0: 1048576,
            16: 33555457,
            32: 1024,
            48: 1049601,
            64: 34604033,
            80: 0,
            96: 1,
            112: 34603009,
            128: 33555456,
            144: 1048577,
            160: 33554433,
            176: 34604032,
            192: 34603008,
            208: 1025,
            224: 1049600,
            240: 33554432,
            8: 34603009,
            24: 0,
            40: 33555457,
            56: 34604032,
            72: 1048576,
            88: 33554433,
            104: 33554432,
            120: 1025,
            136: 1049601,
            152: 33555456,
            168: 34603008,
            184: 1048577,
            200: 1024,
            216: 34604033,
            232: 1,
            248: 1049600,
            256: 33554432,
            272: 1048576,
            288: 33555457,
            304: 34603009,
            320: 1048577,
            336: 33555456,
            352: 34604032,
            368: 1049601,
            384: 1025,
            400: 34604033,
            416: 1049600,
            432: 1,
            448: 0,
            464: 34603008,
            480: 33554433,
            496: 1024,
            264: 1049600,
            280: 33555457,
            296: 34603009,
            312: 1,
            328: 33554432,
            344: 1048576,
            360: 1025,
            376: 34604032,
            392: 33554433,
            408: 34603008,
            424: 0,
            440: 34604033,
            456: 1049601,
            472: 1024,
            488: 33555456,
            504: 1048577
          },
          {
            0: 134219808,
            1: 131072,
            2: 134217728,
            3: 32,
            4: 131104,
            5: 134350880,
            6: 134350848,
            7: 2048,
            8: 134348800,
            9: 134219776,
            10: 133120,
            11: 134348832,
            12: 2080,
            13: 0,
            14: 134217760,
            15: 133152,
            2147483648: 2048,
            2147483649: 134350880,
            2147483650: 134219808,
            2147483651: 134217728,
            2147483652: 134348800,
            2147483653: 133120,
            2147483654: 133152,
            2147483655: 32,
            2147483656: 134217760,
            2147483657: 2080,
            2147483658: 131104,
            2147483659: 134350848,
            2147483660: 0,
            2147483661: 134348832,
            2147483662: 134219776,
            2147483663: 131072,
            16: 133152,
            17: 134350848,
            18: 32,
            19: 2048,
            20: 134219776,
            21: 134217760,
            22: 134348832,
            23: 131072,
            24: 0,
            25: 131104,
            26: 134348800,
            27: 134219808,
            28: 134350880,
            29: 133120,
            30: 2080,
            31: 134217728,
            2147483664: 131072,
            2147483665: 2048,
            2147483666: 134348832,
            2147483667: 133152,
            2147483668: 32,
            2147483669: 134348800,
            2147483670: 134217728,
            2147483671: 134219808,
            2147483672: 134350880,
            2147483673: 134217760,
            2147483674: 134219776,
            2147483675: 0,
            2147483676: 133120,
            2147483677: 2080,
            2147483678: 131104,
            2147483679: 134350848
          }
        ], n = [
          4160749569,
          528482304,
          33030144,
          2064384,
          129024,
          8064,
          504,
          2147483679
        ], f = d.DES = C.extend({
          _doReset: function() {
            for (var g = this._key, l = g.words, u = [], B = 0; B < 56; B++) {
              var A = c[B] - 1;
              u[B] = l[A >>> 5] >>> 31 - A % 32 & 1;
            }
            for (var E = this._subKeys = [], y = 0; y < 16; y++) {
              for (var b = E[y] = [], S = a[y], B = 0; B < 24; B++)
                b[B / 6 | 0] |= u[(t[B] - 1 + S) % 28] << 31 - B % 6, b[4 + (B / 6 | 0)] |= u[28 + (t[B + 24] - 1 + S) % 28] << 31 - B % 6;
              b[0] = b[0] << 1 | b[0] >>> 31;
              for (var B = 1; B < 7; B++)
                b[B] = b[B] >>> (B - 1) * 4 + 3;
              b[7] = b[7] << 5 | b[7] >>> 27;
            }
            for (var F = this._invSubKeys = [], B = 0; B < 16; B++)
              F[B] = E[15 - B];
          },
          encryptBlock: function(g, l) {
            this._doCryptBlock(g, l, this._subKeys);
          },
          decryptBlock: function(g, l) {
            this._doCryptBlock(g, l, this._invSubKeys);
          },
          _doCryptBlock: function(g, l, u) {
            this._lBlock = g[l], this._rBlock = g[l + 1], v.call(this, 4, 252645135), v.call(this, 16, 65535), m.call(this, 2, 858993459), m.call(this, 8, 16711935), v.call(this, 1, 1431655765);
            for (var B = 0; B < 16; B++) {
              for (var A = u[B], E = this._lBlock, y = this._rBlock, b = 0, S = 0; S < 8; S++)
                b |= h[S][((y ^ A[S]) & n[S]) >>> 0];
              this._lBlock = y, this._rBlock = E ^ b;
            }
            var F = this._lBlock;
            this._lBlock = this._rBlock, this._rBlock = F, v.call(this, 1, 1431655765), m.call(this, 8, 16711935), m.call(this, 2, 858993459), v.call(this, 16, 65535), v.call(this, 4, 252645135), g[l] = this._lBlock, g[l + 1] = this._rBlock;
          },
          keySize: 64 / 32,
          ivSize: 64 / 32,
          blockSize: 64 / 32
        });
        function v(g, l) {
          var u = (this._lBlock >>> g ^ this._rBlock) & l;
          this._rBlock ^= u, this._lBlock ^= u << g;
        }
        function m(g, l) {
          var u = (this._rBlock >>> g ^ this._lBlock) & l;
          this._lBlock ^= u, this._rBlock ^= u << g;
        }
        e.DES = C._createHelper(f);
        var p = d.TripleDES = C.extend({
          _doReset: function() {
            var g = this._key, l = g.words;
            if (l.length !== 2 && l.length !== 4 && l.length < 6)
              throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");
            var u = l.slice(0, 2), B = l.length < 4 ? l.slice(0, 2) : l.slice(2, 4), A = l.length < 6 ? l.slice(0, 2) : l.slice(4, 6);
            this._des1 = f.createEncryptor(x.create(u)), this._des2 = f.createEncryptor(x.create(B)), this._des3 = f.createEncryptor(x.create(A));
          },
          encryptBlock: function(g, l) {
            this._des1.encryptBlock(g, l), this._des2.decryptBlock(g, l), this._des3.encryptBlock(g, l);
          },
          decryptBlock: function(g, l) {
            this._des3.decryptBlock(g, l), this._des2.encryptBlock(g, l), this._des1.decryptBlock(g, l);
          },
          keySize: 192 / 32,
          ivSize: 64 / 32,
          blockSize: 64 / 32
        });
        e.TripleDES = C._createHelper(p);
      })(), r.TripleDES;
    });
  })(ie)), ie.exports;
}
var se = { exports: {} }, nn = se.exports, Cr;
function on() {
  return Cr || (Cr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), h0(), u0(), l0(), X());
    })(nn, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.StreamCipher, C = e.algo, d = C.RC4 = x.extend({
          _doReset: function() {
            for (var a = this._key, h = a.words, n = a.sigBytes, f = this._S = [], v = 0; v < 256; v++)
              f[v] = v;
            for (var v = 0, m = 0; v < 256; v++) {
              var p = v % n, g = h[p >>> 2] >>> 24 - p % 4 * 8 & 255;
              m = (m + f[v] + g) % 256;
              var l = f[v];
              f[v] = f[m], f[m] = l;
            }
            this._i = this._j = 0;
          },
          _doProcessBlock: function(a, h) {
            a[h] ^= c.call(this);
          },
          keySize: 256 / 32,
          ivSize: 0
        });
        function c() {
          for (var a = this._S, h = this._i, n = this._j, f = 0, v = 0; v < 4; v++) {
            h = (h + 1) % 256, n = (n + a[h]) % 256;
            var m = a[h];
            a[h] = a[n], a[n] = m, f |= a[(a[h] + a[n]) % 256] << 24 - v * 8;
          }
          return this._i = h, this._j = n, f;
        }
        e.RC4 = x._createHelper(d);
        var t = C.RC4Drop = d.extend({
          /**
           * Configuration options.
           *
           * @property {number} drop The number of keystream words to drop. Default 192
           */
          cfg: d.cfg.extend({
            drop: 192
          }),
          _doReset: function() {
            d._doReset.call(this);
            for (var a = this.cfg.drop; a > 0; a--)
              c.call(this);
          }
        });
        e.RC4Drop = x._createHelper(t);
      })(), r.RC4;
    });
  })(se)), se.exports;
}
var xe = { exports: {} }, sn = xe.exports, Ar;
function xn() {
  return Ar || (Ar = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), h0(), u0(), l0(), X());
    })(sn, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.StreamCipher, C = e.algo, d = [], c = [], t = [], a = C.Rabbit = x.extend({
          _doReset: function() {
            for (var n = this._key.words, f = this.cfg.iv, v = 0; v < 4; v++)
              n[v] = (n[v] << 8 | n[v] >>> 24) & 16711935 | (n[v] << 24 | n[v] >>> 8) & 4278255360;
            var m = this._X = [
              n[0],
              n[3] << 16 | n[2] >>> 16,
              n[1],
              n[0] << 16 | n[3] >>> 16,
              n[2],
              n[1] << 16 | n[0] >>> 16,
              n[3],
              n[2] << 16 | n[1] >>> 16
            ], p = this._C = [
              n[2] << 16 | n[2] >>> 16,
              n[0] & 4294901760 | n[1] & 65535,
              n[3] << 16 | n[3] >>> 16,
              n[1] & 4294901760 | n[2] & 65535,
              n[0] << 16 | n[0] >>> 16,
              n[2] & 4294901760 | n[3] & 65535,
              n[1] << 16 | n[1] >>> 16,
              n[3] & 4294901760 | n[0] & 65535
            ];
            this._b = 0;
            for (var v = 0; v < 4; v++)
              h.call(this);
            for (var v = 0; v < 8; v++)
              p[v] ^= m[v + 4 & 7];
            if (f) {
              var g = f.words, l = g[0], u = g[1], B = (l << 8 | l >>> 24) & 16711935 | (l << 24 | l >>> 8) & 4278255360, A = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360, E = B >>> 16 | A & 4294901760, y = A << 16 | B & 65535;
              p[0] ^= B, p[1] ^= E, p[2] ^= A, p[3] ^= y, p[4] ^= B, p[5] ^= E, p[6] ^= A, p[7] ^= y;
              for (var v = 0; v < 4; v++)
                h.call(this);
            }
          },
          _doProcessBlock: function(n, f) {
            var v = this._X;
            h.call(this), d[0] = v[0] ^ v[5] >>> 16 ^ v[3] << 16, d[1] = v[2] ^ v[7] >>> 16 ^ v[5] << 16, d[2] = v[4] ^ v[1] >>> 16 ^ v[7] << 16, d[3] = v[6] ^ v[3] >>> 16 ^ v[1] << 16;
            for (var m = 0; m < 4; m++)
              d[m] = (d[m] << 8 | d[m] >>> 24) & 16711935 | (d[m] << 24 | d[m] >>> 8) & 4278255360, n[f + m] ^= d[m];
          },
          blockSize: 128 / 32,
          ivSize: 64 / 32
        });
        function h() {
          for (var n = this._X, f = this._C, v = 0; v < 8; v++)
            c[v] = f[v];
          f[0] = f[0] + 1295307597 + this._b | 0, f[1] = f[1] + 3545052371 + (f[0] >>> 0 < c[0] >>> 0 ? 1 : 0) | 0, f[2] = f[2] + 886263092 + (f[1] >>> 0 < c[1] >>> 0 ? 1 : 0) | 0, f[3] = f[3] + 1295307597 + (f[2] >>> 0 < c[2] >>> 0 ? 1 : 0) | 0, f[4] = f[4] + 3545052371 + (f[3] >>> 0 < c[3] >>> 0 ? 1 : 0) | 0, f[5] = f[5] + 886263092 + (f[4] >>> 0 < c[4] >>> 0 ? 1 : 0) | 0, f[6] = f[6] + 1295307597 + (f[5] >>> 0 < c[5] >>> 0 ? 1 : 0) | 0, f[7] = f[7] + 3545052371 + (f[6] >>> 0 < c[6] >>> 0 ? 1 : 0) | 0, this._b = f[7] >>> 0 < c[7] >>> 0 ? 1 : 0;
          for (var v = 0; v < 8; v++) {
            var m = n[v] + f[v], p = m & 65535, g = m >>> 16, l = ((p * p >>> 17) + p * g >>> 15) + g * g, u = ((m & 4294901760) * m | 0) + ((m & 65535) * m | 0);
            t[v] = l ^ u;
          }
          n[0] = t[0] + (t[7] << 16 | t[7] >>> 16) + (t[6] << 16 | t[6] >>> 16) | 0, n[1] = t[1] + (t[0] << 8 | t[0] >>> 24) + t[7] | 0, n[2] = t[2] + (t[1] << 16 | t[1] >>> 16) + (t[0] << 16 | t[0] >>> 16) | 0, n[3] = t[3] + (t[2] << 8 | t[2] >>> 24) + t[1] | 0, n[4] = t[4] + (t[3] << 16 | t[3] >>> 16) + (t[2] << 16 | t[2] >>> 16) | 0, n[5] = t[5] + (t[4] << 8 | t[4] >>> 24) + t[3] | 0, n[6] = t[6] + (t[5] << 16 | t[5] >>> 16) + (t[4] << 16 | t[4] >>> 16) | 0, n[7] = t[7] + (t[6] << 8 | t[6] >>> 24) + t[5] | 0;
        }
        e.Rabbit = x._createHelper(a);
      })(), r.Rabbit;
    });
  })(xe)), xe.exports;
}
var ce = { exports: {} }, cn = ce.exports, Er;
function fn() {
  return Er || (Er = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), h0(), u0(), l0(), X());
    })(cn, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.StreamCipher, C = e.algo, d = [], c = [], t = [], a = C.RabbitLegacy = x.extend({
          _doReset: function() {
            var n = this._key.words, f = this.cfg.iv, v = this._X = [
              n[0],
              n[3] << 16 | n[2] >>> 16,
              n[1],
              n[0] << 16 | n[3] >>> 16,
              n[2],
              n[1] << 16 | n[0] >>> 16,
              n[3],
              n[2] << 16 | n[1] >>> 16
            ], m = this._C = [
              n[2] << 16 | n[2] >>> 16,
              n[0] & 4294901760 | n[1] & 65535,
              n[3] << 16 | n[3] >>> 16,
              n[1] & 4294901760 | n[2] & 65535,
              n[0] << 16 | n[0] >>> 16,
              n[2] & 4294901760 | n[3] & 65535,
              n[1] << 16 | n[1] >>> 16,
              n[3] & 4294901760 | n[0] & 65535
            ];
            this._b = 0;
            for (var p = 0; p < 4; p++)
              h.call(this);
            for (var p = 0; p < 8; p++)
              m[p] ^= v[p + 4 & 7];
            if (f) {
              var g = f.words, l = g[0], u = g[1], B = (l << 8 | l >>> 24) & 16711935 | (l << 24 | l >>> 8) & 4278255360, A = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360, E = B >>> 16 | A & 4294901760, y = A << 16 | B & 65535;
              m[0] ^= B, m[1] ^= E, m[2] ^= A, m[3] ^= y, m[4] ^= B, m[5] ^= E, m[6] ^= A, m[7] ^= y;
              for (var p = 0; p < 4; p++)
                h.call(this);
            }
          },
          _doProcessBlock: function(n, f) {
            var v = this._X;
            h.call(this), d[0] = v[0] ^ v[5] >>> 16 ^ v[3] << 16, d[1] = v[2] ^ v[7] >>> 16 ^ v[5] << 16, d[2] = v[4] ^ v[1] >>> 16 ^ v[7] << 16, d[3] = v[6] ^ v[3] >>> 16 ^ v[1] << 16;
            for (var m = 0; m < 4; m++)
              d[m] = (d[m] << 8 | d[m] >>> 24) & 16711935 | (d[m] << 24 | d[m] >>> 8) & 4278255360, n[f + m] ^= d[m];
          },
          blockSize: 128 / 32,
          ivSize: 64 / 32
        });
        function h() {
          for (var n = this._X, f = this._C, v = 0; v < 8; v++)
            c[v] = f[v];
          f[0] = f[0] + 1295307597 + this._b | 0, f[1] = f[1] + 3545052371 + (f[0] >>> 0 < c[0] >>> 0 ? 1 : 0) | 0, f[2] = f[2] + 886263092 + (f[1] >>> 0 < c[1] >>> 0 ? 1 : 0) | 0, f[3] = f[3] + 1295307597 + (f[2] >>> 0 < c[2] >>> 0 ? 1 : 0) | 0, f[4] = f[4] + 3545052371 + (f[3] >>> 0 < c[3] >>> 0 ? 1 : 0) | 0, f[5] = f[5] + 886263092 + (f[4] >>> 0 < c[4] >>> 0 ? 1 : 0) | 0, f[6] = f[6] + 1295307597 + (f[5] >>> 0 < c[5] >>> 0 ? 1 : 0) | 0, f[7] = f[7] + 3545052371 + (f[6] >>> 0 < c[6] >>> 0 ? 1 : 0) | 0, this._b = f[7] >>> 0 < c[7] >>> 0 ? 1 : 0;
          for (var v = 0; v < 8; v++) {
            var m = n[v] + f[v], p = m & 65535, g = m >>> 16, l = ((p * p >>> 17) + p * g >>> 15) + g * g, u = ((m & 4294901760) * m | 0) + ((m & 65535) * m | 0);
            t[v] = l ^ u;
          }
          n[0] = t[0] + (t[7] << 16 | t[7] >>> 16) + (t[6] << 16 | t[6] >>> 16) | 0, n[1] = t[1] + (t[0] << 8 | t[0] >>> 24) + t[7] | 0, n[2] = t[2] + (t[1] << 16 | t[1] >>> 16) + (t[0] << 16 | t[0] >>> 16) | 0, n[3] = t[3] + (t[2] << 8 | t[2] >>> 24) + t[1] | 0, n[4] = t[4] + (t[3] << 16 | t[3] >>> 16) + (t[2] << 16 | t[2] >>> 16) | 0, n[5] = t[5] + (t[4] << 8 | t[4] >>> 24) + t[3] | 0, n[6] = t[6] + (t[5] << 16 | t[5] >>> 16) + (t[4] << 16 | t[4] >>> 16) | 0, n[7] = t[7] + (t[6] << 8 | t[6] >>> 24) + t[5] | 0;
        }
        e.RabbitLegacy = x._createHelper(a);
      })(), r.RabbitLegacy;
    });
  })(ce)), ce.exports;
}
var fe = { exports: {} }, ln = fe.exports, gr;
function hn() {
  return gr || (gr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), h0(), u0(), l0(), X());
    })(ln, function(r) {
      return (function() {
        var e = r, s = e.lib, x = s.BlockCipher, C = e.algo;
        const d = 16, c = [
          608135816,
          2242054355,
          320440878,
          57701188,
          2752067618,
          698298832,
          137296536,
          3964562569,
          1160258022,
          953160567,
          3193202383,
          887688300,
          3232508343,
          3380367581,
          1065670069,
          3041331479,
          2450970073,
          2306472731
        ], t = [
          [
            3509652390,
            2564797868,
            805139163,
            3491422135,
            3101798381,
            1780907670,
            3128725573,
            4046225305,
            614570311,
            3012652279,
            134345442,
            2240740374,
            1667834072,
            1901547113,
            2757295779,
            4103290238,
            227898511,
            1921955416,
            1904987480,
            2182433518,
            2069144605,
            3260701109,
            2620446009,
            720527379,
            3318853667,
            677414384,
            3393288472,
            3101374703,
            2390351024,
            1614419982,
            1822297739,
            2954791486,
            3608508353,
            3174124327,
            2024746970,
            1432378464,
            3864339955,
            2857741204,
            1464375394,
            1676153920,
            1439316330,
            715854006,
            3033291828,
            289532110,
            2706671279,
            2087905683,
            3018724369,
            1668267050,
            732546397,
            1947742710,
            3462151702,
            2609353502,
            2950085171,
            1814351708,
            2050118529,
            680887927,
            999245976,
            1800124847,
            3300911131,
            1713906067,
            1641548236,
            4213287313,
            1216130144,
            1575780402,
            4018429277,
            3917837745,
            3693486850,
            3949271944,
            596196993,
            3549867205,
            258830323,
            2213823033,
            772490370,
            2760122372,
            1774776394,
            2652871518,
            566650946,
            4142492826,
            1728879713,
            2882767088,
            1783734482,
            3629395816,
            2517608232,
            2874225571,
            1861159788,
            326777828,
            3124490320,
            2130389656,
            2716951837,
            967770486,
            1724537150,
            2185432712,
            2364442137,
            1164943284,
            2105845187,
            998989502,
            3765401048,
            2244026483,
            1075463327,
            1455516326,
            1322494562,
            910128902,
            469688178,
            1117454909,
            936433444,
            3490320968,
            3675253459,
            1240580251,
            122909385,
            2157517691,
            634681816,
            4142456567,
            3825094682,
            3061402683,
            2540495037,
            79693498,
            3249098678,
            1084186820,
            1583128258,
            426386531,
            1761308591,
            1047286709,
            322548459,
            995290223,
            1845252383,
            2603652396,
            3431023940,
            2942221577,
            3202600964,
            3727903485,
            1712269319,
            422464435,
            3234572375,
            1170764815,
            3523960633,
            3117677531,
            1434042557,
            442511882,
            3600875718,
            1076654713,
            1738483198,
            4213154764,
            2393238008,
            3677496056,
            1014306527,
            4251020053,
            793779912,
            2902807211,
            842905082,
            4246964064,
            1395751752,
            1040244610,
            2656851899,
            3396308128,
            445077038,
            3742853595,
            3577915638,
            679411651,
            2892444358,
            2354009459,
            1767581616,
            3150600392,
            3791627101,
            3102740896,
            284835224,
            4246832056,
            1258075500,
            768725851,
            2589189241,
            3069724005,
            3532540348,
            1274779536,
            3789419226,
            2764799539,
            1660621633,
            3471099624,
            4011903706,
            913787905,
            3497959166,
            737222580,
            2514213453,
            2928710040,
            3937242737,
            1804850592,
            3499020752,
            2949064160,
            2386320175,
            2390070455,
            2415321851,
            4061277028,
            2290661394,
            2416832540,
            1336762016,
            1754252060,
            3520065937,
            3014181293,
            791618072,
            3188594551,
            3933548030,
            2332172193,
            3852520463,
            3043980520,
            413987798,
            3465142937,
            3030929376,
            4245938359,
            2093235073,
            3534596313,
            375366246,
            2157278981,
            2479649556,
            555357303,
            3870105701,
            2008414854,
            3344188149,
            4221384143,
            3956125452,
            2067696032,
            3594591187,
            2921233993,
            2428461,
            544322398,
            577241275,
            1471733935,
            610547355,
            4027169054,
            1432588573,
            1507829418,
            2025931657,
            3646575487,
            545086370,
            48609733,
            2200306550,
            1653985193,
            298326376,
            1316178497,
            3007786442,
            2064951626,
            458293330,
            2589141269,
            3591329599,
            3164325604,
            727753846,
            2179363840,
            146436021,
            1461446943,
            4069977195,
            705550613,
            3059967265,
            3887724982,
            4281599278,
            3313849956,
            1404054877,
            2845806497,
            146425753,
            1854211946
          ],
          [
            1266315497,
            3048417604,
            3681880366,
            3289982499,
            290971e4,
            1235738493,
            2632868024,
            2414719590,
            3970600049,
            1771706367,
            1449415276,
            3266420449,
            422970021,
            1963543593,
            2690192192,
            3826793022,
            1062508698,
            1531092325,
            1804592342,
            2583117782,
            2714934279,
            4024971509,
            1294809318,
            4028980673,
            1289560198,
            2221992742,
            1669523910,
            35572830,
            157838143,
            1052438473,
            1016535060,
            1802137761,
            1753167236,
            1386275462,
            3080475397,
            2857371447,
            1040679964,
            2145300060,
            2390574316,
            1461121720,
            2956646967,
            4031777805,
            4028374788,
            33600511,
            2920084762,
            1018524850,
            629373528,
            3691585981,
            3515945977,
            2091462646,
            2486323059,
            586499841,
            988145025,
            935516892,
            3367335476,
            2599673255,
            2839830854,
            265290510,
            3972581182,
            2759138881,
            3795373465,
            1005194799,
            847297441,
            406762289,
            1314163512,
            1332590856,
            1866599683,
            4127851711,
            750260880,
            613907577,
            1450815602,
            3165620655,
            3734664991,
            3650291728,
            3012275730,
            3704569646,
            1427272223,
            778793252,
            1343938022,
            2676280711,
            2052605720,
            1946737175,
            3164576444,
            3914038668,
            3967478842,
            3682934266,
            1661551462,
            3294938066,
            4011595847,
            840292616,
            3712170807,
            616741398,
            312560963,
            711312465,
            1351876610,
            322626781,
            1910503582,
            271666773,
            2175563734,
            1594956187,
            70604529,
            3617834859,
            1007753275,
            1495573769,
            4069517037,
            2549218298,
            2663038764,
            504708206,
            2263041392,
            3941167025,
            2249088522,
            1514023603,
            1998579484,
            1312622330,
            694541497,
            2582060303,
            2151582166,
            1382467621,
            776784248,
            2618340202,
            3323268794,
            2497899128,
            2784771155,
            503983604,
            4076293799,
            907881277,
            423175695,
            432175456,
            1378068232,
            4145222326,
            3954048622,
            3938656102,
            3820766613,
            2793130115,
            2977904593,
            26017576,
            3274890735,
            3194772133,
            1700274565,
            1756076034,
            4006520079,
            3677328699,
            720338349,
            1533947780,
            354530856,
            688349552,
            3973924725,
            1637815568,
            332179504,
            3949051286,
            53804574,
            2852348879,
            3044236432,
            1282449977,
            3583942155,
            3416972820,
            4006381244,
            1617046695,
            2628476075,
            3002303598,
            1686838959,
            431878346,
            2686675385,
            1700445008,
            1080580658,
            1009431731,
            832498133,
            3223435511,
            2605976345,
            2271191193,
            2516031870,
            1648197032,
            4164389018,
            2548247927,
            300782431,
            375919233,
            238389289,
            3353747414,
            2531188641,
            2019080857,
            1475708069,
            455242339,
            2609103871,
            448939670,
            3451063019,
            1395535956,
            2413381860,
            1841049896,
            1491858159,
            885456874,
            4264095073,
            4001119347,
            1565136089,
            3898914787,
            1108368660,
            540939232,
            1173283510,
            2745871338,
            3681308437,
            4207628240,
            3343053890,
            4016749493,
            1699691293,
            1103962373,
            3625875870,
            2256883143,
            3830138730,
            1031889488,
            3479347698,
            1535977030,
            4236805024,
            3251091107,
            2132092099,
            1774941330,
            1199868427,
            1452454533,
            157007616,
            2904115357,
            342012276,
            595725824,
            1480756522,
            206960106,
            497939518,
            591360097,
            863170706,
            2375253569,
            3596610801,
            1814182875,
            2094937945,
            3421402208,
            1082520231,
            3463918190,
            2785509508,
            435703966,
            3908032597,
            1641649973,
            2842273706,
            3305899714,
            1510255612,
            2148256476,
            2655287854,
            3276092548,
            4258621189,
            236887753,
            3681803219,
            274041037,
            1734335097,
            3815195456,
            3317970021,
            1899903192,
            1026095262,
            4050517792,
            356393447,
            2410691914,
            3873677099,
            3682840055
          ],
          [
            3913112168,
            2491498743,
            4132185628,
            2489919796,
            1091903735,
            1979897079,
            3170134830,
            3567386728,
            3557303409,
            857797738,
            1136121015,
            1342202287,
            507115054,
            2535736646,
            337727348,
            3213592640,
            1301675037,
            2528481711,
            1895095763,
            1721773893,
            3216771564,
            62756741,
            2142006736,
            835421444,
            2531993523,
            1442658625,
            3659876326,
            2882144922,
            676362277,
            1392781812,
            170690266,
            3921047035,
            1759253602,
            3611846912,
            1745797284,
            664899054,
            1329594018,
            3901205900,
            3045908486,
            2062866102,
            2865634940,
            3543621612,
            3464012697,
            1080764994,
            553557557,
            3656615353,
            3996768171,
            991055499,
            499776247,
            1265440854,
            648242737,
            3940784050,
            980351604,
            3713745714,
            1749149687,
            3396870395,
            4211799374,
            3640570775,
            1161844396,
            3125318951,
            1431517754,
            545492359,
            4268468663,
            3499529547,
            1437099964,
            2702547544,
            3433638243,
            2581715763,
            2787789398,
            1060185593,
            1593081372,
            2418618748,
            4260947970,
            69676912,
            2159744348,
            86519011,
            2512459080,
            3838209314,
            1220612927,
            3339683548,
            133810670,
            1090789135,
            1078426020,
            1569222167,
            845107691,
            3583754449,
            4072456591,
            1091646820,
            628848692,
            1613405280,
            3757631651,
            526609435,
            236106946,
            48312990,
            2942717905,
            3402727701,
            1797494240,
            859738849,
            992217954,
            4005476642,
            2243076622,
            3870952857,
            3732016268,
            765654824,
            3490871365,
            2511836413,
            1685915746,
            3888969200,
            1414112111,
            2273134842,
            3281911079,
            4080962846,
            172450625,
            2569994100,
            980381355,
            4109958455,
            2819808352,
            2716589560,
            2568741196,
            3681446669,
            3329971472,
            1835478071,
            660984891,
            3704678404,
            4045999559,
            3422617507,
            3040415634,
            1762651403,
            1719377915,
            3470491036,
            2693910283,
            3642056355,
            3138596744,
            1364962596,
            2073328063,
            1983633131,
            926494387,
            3423689081,
            2150032023,
            4096667949,
            1749200295,
            3328846651,
            309677260,
            2016342300,
            1779581495,
            3079819751,
            111262694,
            1274766160,
            443224088,
            298511866,
            1025883608,
            3806446537,
            1145181785,
            168956806,
            3641502830,
            3584813610,
            1689216846,
            3666258015,
            3200248200,
            1692713982,
            2646376535,
            4042768518,
            1618508792,
            1610833997,
            3523052358,
            4130873264,
            2001055236,
            3610705100,
            2202168115,
            4028541809,
            2961195399,
            1006657119,
            2006996926,
            3186142756,
            1430667929,
            3210227297,
            1314452623,
            4074634658,
            4101304120,
            2273951170,
            1399257539,
            3367210612,
            3027628629,
            1190975929,
            2062231137,
            2333990788,
            2221543033,
            2438960610,
            1181637006,
            548689776,
            2362791313,
            3372408396,
            3104550113,
            3145860560,
            296247880,
            1970579870,
            3078560182,
            3769228297,
            1714227617,
            3291629107,
            3898220290,
            166772364,
            1251581989,
            493813264,
            448347421,
            195405023,
            2709975567,
            677966185,
            3703036547,
            1463355134,
            2715995803,
            1338867538,
            1343315457,
            2802222074,
            2684532164,
            233230375,
            2599980071,
            2000651841,
            3277868038,
            1638401717,
            4028070440,
            3237316320,
            6314154,
            819756386,
            300326615,
            590932579,
            1405279636,
            3267499572,
            3150704214,
            2428286686,
            3959192993,
            3461946742,
            1862657033,
            1266418056,
            963775037,
            2089974820,
            2263052895,
            1917689273,
            448879540,
            3550394620,
            3981727096,
            150775221,
            3627908307,
            1303187396,
            508620638,
            2975983352,
            2726630617,
            1817252668,
            1876281319,
            1457606340,
            908771278,
            3720792119,
            3617206836,
            2455994898,
            1729034894,
            1080033504
          ],
          [
            976866871,
            3556439503,
            2881648439,
            1522871579,
            1555064734,
            1336096578,
            3548522304,
            2579274686,
            3574697629,
            3205460757,
            3593280638,
            3338716283,
            3079412587,
            564236357,
            2993598910,
            1781952180,
            1464380207,
            3163844217,
            3332601554,
            1699332808,
            1393555694,
            1183702653,
            3581086237,
            1288719814,
            691649499,
            2847557200,
            2895455976,
            3193889540,
            2717570544,
            1781354906,
            1676643554,
            2592534050,
            3230253752,
            1126444790,
            2770207658,
            2633158820,
            2210423226,
            2615765581,
            2414155088,
            3127139286,
            673620729,
            2805611233,
            1269405062,
            4015350505,
            3341807571,
            4149409754,
            1057255273,
            2012875353,
            2162469141,
            2276492801,
            2601117357,
            993977747,
            3918593370,
            2654263191,
            753973209,
            36408145,
            2530585658,
            25011837,
            3520020182,
            2088578344,
            530523599,
            2918365339,
            1524020338,
            1518925132,
            3760827505,
            3759777254,
            1202760957,
            3985898139,
            3906192525,
            674977740,
            4174734889,
            2031300136,
            2019492241,
            3983892565,
            4153806404,
            3822280332,
            352677332,
            2297720250,
            60907813,
            90501309,
            3286998549,
            1016092578,
            2535922412,
            2839152426,
            457141659,
            509813237,
            4120667899,
            652014361,
            1966332200,
            2975202805,
            55981186,
            2327461051,
            676427537,
            3255491064,
            2882294119,
            3433927263,
            1307055953,
            942726286,
            933058658,
            2468411793,
            3933900994,
            4215176142,
            1361170020,
            2001714738,
            2830558078,
            3274259782,
            1222529897,
            1679025792,
            2729314320,
            3714953764,
            1770335741,
            151462246,
            3013232138,
            1682292957,
            1483529935,
            471910574,
            1539241949,
            458788160,
            3436315007,
            1807016891,
            3718408830,
            978976581,
            1043663428,
            3165965781,
            1927990952,
            4200891579,
            2372276910,
            3208408903,
            3533431907,
            1412390302,
            2931980059,
            4132332400,
            1947078029,
            3881505623,
            4168226417,
            2941484381,
            1077988104,
            1320477388,
            886195818,
            18198404,
            3786409e3,
            2509781533,
            112762804,
            3463356488,
            1866414978,
            891333506,
            18488651,
            661792760,
            1628790961,
            3885187036,
            3141171499,
            876946877,
            2693282273,
            1372485963,
            791857591,
            2686433993,
            3759982718,
            3167212022,
            3472953795,
            2716379847,
            445679433,
            3561995674,
            3504004811,
            3574258232,
            54117162,
            3331405415,
            2381918588,
            3769707343,
            4154350007,
            1140177722,
            4074052095,
            668550556,
            3214352940,
            367459370,
            261225585,
            2610173221,
            4209349473,
            3468074219,
            3265815641,
            314222801,
            3066103646,
            3808782860,
            282218597,
            3406013506,
            3773591054,
            379116347,
            1285071038,
            846784868,
            2669647154,
            3771962079,
            3550491691,
            2305946142,
            453669953,
            1268987020,
            3317592352,
            3279303384,
            3744833421,
            2610507566,
            3859509063,
            266596637,
            3847019092,
            517658769,
            3462560207,
            3443424879,
            370717030,
            4247526661,
            2224018117,
            4143653529,
            4112773975,
            2788324899,
            2477274417,
            1456262402,
            2901442914,
            1517677493,
            1846949527,
            2295493580,
            3734397586,
            2176403920,
            1280348187,
            1908823572,
            3871786941,
            846861322,
            1172426758,
            3287448474,
            3383383037,
            1655181056,
            3139813346,
            901632758,
            1897031941,
            2986607138,
            3066810236,
            3447102507,
            1393639104,
            373351379,
            950779232,
            625454576,
            3124240540,
            4148612726,
            2007998917,
            544563296,
            2244738638,
            2330496472,
            2058025392,
            1291430526,
            424198748,
            50039436,
            29584100,
            3605783033,
            2429876329,
            2791104160,
            1057563949,
            3255363231,
            3075367218,
            3463963227,
            1469046755,
            985887462
          ]
        ];
        var a = {
          pbox: [],
          sbox: []
        };
        function h(p, g) {
          let l = g >> 24 & 255, u = g >> 16 & 255, B = g >> 8 & 255, A = g & 255, E = p.sbox[0][l] + p.sbox[1][u];
          return E = E ^ p.sbox[2][B], E = E + p.sbox[3][A], E;
        }
        function n(p, g, l) {
          let u = g, B = l, A;
          for (let E = 0; E < d; ++E)
            u = u ^ p.pbox[E], B = h(p, u) ^ B, A = u, u = B, B = A;
          return A = u, u = B, B = A, B = B ^ p.pbox[d], u = u ^ p.pbox[d + 1], { left: u, right: B };
        }
        function f(p, g, l) {
          let u = g, B = l, A;
          for (let E = d + 1; E > 1; --E)
            u = u ^ p.pbox[E], B = h(p, u) ^ B, A = u, u = B, B = A;
          return A = u, u = B, B = A, B = B ^ p.pbox[1], u = u ^ p.pbox[0], { left: u, right: B };
        }
        function v(p, g, l) {
          for (let y = 0; y < 4; y++) {
            p.sbox[y] = [];
            for (let b = 0; b < 256; b++)
              p.sbox[y][b] = t[y][b];
          }
          let u = 0;
          for (let y = 0; y < d + 2; y++)
            p.pbox[y] = c[y] ^ g[u], u++, u >= l && (u = 0);
          let B = 0, A = 0, E = 0;
          for (let y = 0; y < d + 2; y += 2)
            E = n(p, B, A), B = E.left, A = E.right, p.pbox[y] = B, p.pbox[y + 1] = A;
          for (let y = 0; y < 4; y++)
            for (let b = 0; b < 256; b += 2)
              E = n(p, B, A), B = E.left, A = E.right, p.sbox[y][b] = B, p.sbox[y][b + 1] = A;
          return !0;
        }
        var m = C.Blowfish = x.extend({
          _doReset: function() {
            if (this._keyPriorReset !== this._key) {
              var p = this._keyPriorReset = this._key, g = p.words, l = p.sigBytes / 4;
              v(a, g, l);
            }
          },
          encryptBlock: function(p, g) {
            var l = n(a, p[g], p[g + 1]);
            p[g] = l.left, p[g + 1] = l.right;
          },
          decryptBlock: function(p, g) {
            var l = f(a, p[g], p[g + 1]);
            p[g] = l.left, p[g + 1] = l.right;
          },
          blockSize: 64 / 32,
          keySize: 128 / 32,
          ivSize: 64 / 32
        });
        e.Blowfish = x._createHelper(m);
      })(), r.Blowfish;
    });
  })(fe)), fe.exports;
}
var un = k0.exports, Fr;
function dn() {
  return Fr || (Fr = 1, (function(o, i) {
    (function(r, e, s) {
      o.exports = e(I(), le(), ca(), la(), h0(), da(), u0(), Sr(), Fe(), Ca(), Mr(), ga(), Da(), ba(), De(), ka(), l0(), X(), za(), Pa(), Wa(), qa(), Ia(), Ua(), Na(), ja(), Ka(), Za(), Ja(), rn(), an(), on(), xn(), fn(), hn());
    })(un, function(r) {
      return r;
    });
  })(k0)), k0.exports;
}
var vn = dn();
const pn = /* @__PURE__ */ ea(vn), Bn = "KMED1W0N50YIWIYJCUNLYPMJ49JDLASE", mn = "UQ30SC5R5YTM1TEHHDB8QB20NUYOAQY6", Ee = {
  room: { fillcolor: "#8daed3", strokecolor: "#6d8fb5", height: 0.1 },
  wall: { height: 2, opacity: 0.6, fillcolor: "#3452B4", strokecolor: "#38AEBA" },
  floor: { fillcolor: "#F1F7F9", strokecolor: "#EEEEEE", height: 0.05 },
  plane: { fillcolor: "#4C4C54", strokecolor: "#3C3C3C", height: 0.1 },
  window: { fillcolor: "#AADDEE", strokecolor: "#5FA7C7", height: 1.5, opacity: 0.85 },
  door: { fillcolor: "#64C1EB", strokecolor: "#38AEBA", height: 0.1 },
  logo: { height: 1 },
  desk: { fillcolor: "#87CEFA", strokecolor: "#38AEBA", height: 0.5 },
  seat: { fillcolor: "#87CEFA", strokecolor: "#38AEBA", height: 0.3 },
  default: { fillcolor: "#0088FF", strokecolor: "#38AEBA", height: 1, eheight: 0, opacity: 1, size: 1.4, logo: "" },
  unknown: { fillcolor: "#F00", height: 2 }
}, Cn = { floor: 1, plane: 2, wall: 10, window: 11, door: 12, desk: 14, seat: 15, room: 18 }, An = 10;
function En(o) {
  if (typeof o != "string") {
    const r = new Uint8Array(o.slice ? o.slice(0, 2) : o);
    if (r[0] === 80 && r[1] === 75) return "buildingosmap";
    o = new TextDecoder().decode(o);
  }
  return o.trimStart().startsWith("{") ? "acmap-plain" : "acmap";
}
function gn(o, i, { key: r = Bn, iv: e = mn } = {}) {
  if (o.trimStart().startsWith("{")) return JSON.parse(o);
  const s = i.AES.decrypt(
    { ciphertext: i.enc.Base64.parse(o) },
    i.enc.Utf8.parse(r),
    { iv: i.enc.Utf8.parse(e), mode: i.mode.CBC, padding: i.pad.Pkcs7 }
  ).toString(i.enc.Utf8);
  if (!s) throw new Error(".acmap 解密失败（密钥不对或文件损坏）");
  return JSON.parse(s);
}
function Rr(o) {
  return {
    version: o.MAP_VERSION || o.version || "unknown",
    id: o.id ?? o.name,
    name: o.name,
    buildingName: o.building_name,
    offset: Array.isArray(o.iv) ? o.iv : [0, 0],
    // 楼栋平面偏移（旧引擎 building.position.x/z），不是加密 IV
    floors: o.floors || []
  };
}
function Fn(o, i, r) {
  const e = Object.assign({}, Ee[o] || Ee.default);
  r?.moduleStyle?.[o] && Object.assign(e, r.moduleStyle[o]);
  const s = r?.itemStyle?.find?.((x) => x.sType === i.type?.sType);
  if (s) {
    const { sType: x, ...C } = s;
    Object.assign(e, C);
  }
  return Object.assign(e, i.properties);
}
function Dn(o, { theme: i, unknownLayers: r = [] } = {}) {
  const e = Rr(o), s = new k.Group();
  s.name = `v1:${e.id}`, s.userData.semantic = { id: String(e.id), type: "building", name: e.name }, s.position.set(e.offset[0], 0, e.offset[1]);
  const x = { floors: 0, meshes: 0, items: 0, triangles: 0, skipped: {} }, C = {};
  let d = 0;
  return e.floors.forEach((c, t) => {
    const a = c.floorHeight || An, h = new k.Group();
    h.name = `floor:${t}`, h.position.y = d, d += a, h.userData.semantic = { id: `${e.id}-${c.name || t}`, type: "floor", name: c.name, index: t }, s.add(h), x.floors++;
    for (const [n, f] of Object.entries(c.floor || {})) {
      if (!f?.length) continue;
      if (n === "logo") {
        x.skipped.logo = (x.skipped.logo || 0) + f.length;
        continue;
      }
      const v = [], m = [], p = [];
      let g = 1, l = 0;
      if (f.forEach((E, y) => {
        if (!E.line || E.line.length < 3) return;
        const b = Fn(n, E, i), S = Number(b.height) || 0, F = Number(b.eheight) || 0;
        g = b.opacity === void 0 ? 1 : Number(b.opacity);
        const D = new k.Shape();
        D.moveTo(E.line[0][0], -E.line[0][1]);
        for (let T = 1; T < E.line.length; T++) D.lineTo(E.line[T][0], -E.line[T][1]);
        const _ = new k.ExtrudeGeometry(D, { depth: Math.max(S, 1e-3), bevelEnabled: !1 }), P = (_.toNonIndexed && _.index ? _.toNonIndexed() : _).attributes.position, O = new k.Color(b.fillcolor || "#888");
        for (let T = 0; T < P.count; T++)
          v.push(P.getX(T), P.getY(T), P.getZ(T) + F), m.push(O.r, O.g, O.b);
        const W = P.count / 3;
        p.push({ start: l, count: W, id: E.id ?? `${n}-${y}`, layer: n, name: E.name || E.properties?.name || "" }), l += W, x.items++, _.dispose();
      }), !v.length) continue;
      const u = new k.BufferGeometry();
      u.setAttribute("position", new k.Float32BufferAttribute(v, 3)), u.setAttribute("color", new k.Float32BufferAttribute(m, 3)), u.computeVertexNormals();
      const B = new k.MeshLambertMaterial({
        vertexColors: !0,
        transparent: g < 1,
        opacity: g,
        side: g < 1 ? k.DoubleSide : k.FrontSide,
        depthWrite: g >= 1
      }), A = new k.Mesh(u, B);
      A.rotation.x = -Math.PI / 2, A.renderOrder = Cn[n] ?? 5, A.name = `${h.userData.semantic.id}|v1.${n}`, A.userData.semantic = h.userData.semantic.id, A.visible = g > 0, A.userData.layer = n, C[A.uuid] = p, h.add(A), x.meshes++, x.triangles += l, Ee[n] || r.push(n);
    }
  }), { root: s, stats: x, pick: C, meta: e };
}
async function yn(o) {
  if (o instanceof Uint8Array) return o;
  if (o instanceof ArrayBuffer) return new Uint8Array(o);
  if (typeof Blob < "u" && o instanceof Blob) return new Uint8Array(await o.arrayBuffer());
  const i = await fetch(o);
  if (!i.ok) throw new Error("模型文件下载失败：" + i.status + " " + o);
  return new Uint8Array(await i.arrayBuffer());
}
async function bn(o, i, r = {}) {
  const e = await yn(o);
  return En(e) === "buildingosmap" ? _n(e, i, r) : wn(e, r);
}
let Be = null;
function zr() {
  return Be || (Be = typeof WebAssembly == "object" && typeof WebAssembly.compile == "function" ? WebAssembly.compile(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0])).then(() => !0, () => !1) : Promise.resolve(!1)), Be;
}
async function _n(o, i, { palette: r = {}, decoderPath: e = "/vendor/draco/" } = {}) {
  const s = Jt(o), x = JSON.parse(Ae(s["manifest.json"]));
  if (x.format !== "buildingosmap" || x.version !== 1) throw new Error("不支持的 .buildingosmap：" + x.format + " v" + x.version);
  const C = JSON.parse(Ae(s[x.entries.semantics])), d = s[x.entries.scene], c = new Kr();
  if (x.compression && x.compression.geometry === "draco") {
    const f = new Yr();
    f.setDecoderPath(e), await zr() || f.setDecoderConfig({ type: "js" }), c.setDRACOLoader(f), i.addDisposable && i.addDisposable(f);
  }
  const a = (await new Promise((f, v) => c.parse(d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength), "", f, v))).scene;
  a.name = x.id;
  const h = C.envMaps || {}, n = /* @__PURE__ */ new Map();
  return a.traverse((f) => {
    if (!f.isMesh) return;
    if (!f.userData.semantic) {
      const g = f.name.indexOf("|");
      g > 0 && (f.userData.semantic = f.name.slice(0, g));
    }
    f.castShadow = f.receiveShadow = !0;
    const v = f.material, m = v && v.name;
    if (!m) return;
    const p = i.presets.bySlot(m);
    if (p) {
      f.material = p;
      return;
    }
    n.has(m) || (r[m] !== void 0 && v.color && v.color.set(r[m]).convertSRGBToLinear(), h[m] !== void 0 && (v.envMap = i.presets.smartFacade().reflection, v.envMapIntensity = h[m], v.needsUpdate = !0), n.set(m, v));
  }), { root: a, model: { id: x.id, name: x.name, viewer: x.viewer, home: x.home, semantics: C }, stats: { format: "buildingosmap", bytes: o.byteLength } };
}
function wn(o, { key: i, iv: r } = {}) {
  const e = new TextDecoder().decode(o), s = gn(e, pn, { ...i ? { key: i } : {}, ...r ? { iv: r } : {} }), x = Rr(s), { root: C, stats: d, pick: c } = Dn(s, {}), t = new k.Box3().setFromObject(C), a = t.getCenter(new k.Vector3()), h = t.getSize(new k.Vector3()), n = Math.max(h.x, h.z) * 1.1 || 50, f = { position: [a.x, a.y + n, a.z + n * 0.6], target: [a.x, a.y, a.z] }, v = [{
    id: String(x.id),
    type: "building",
    name: x.name,
    pickable: !0,
    children: C.children.map((m) => ({ id: m.userData.semantic.id, type: "floor", name: m.userData.semantic.name, pickable: !0 }))
  }];
  return {
    root: C,
    model: {
      id: String(x.id),
      name: x.name,
      home: f,
      viewer: { fov: 45, near: 0.1, far: Math.max(2e3, n * 20), controls: { minDistance: 1, maxDistance: n * 6, maxPolarAngle: Math.PI / 2 } },
      semantics: { tree: v, cameras: [{ id: "home", ...f }, { id: "top", position: [a.x, a.y + n * 1.6, a.z + 0.01], target: [a.x, a.y, a.z] }], anchors: [], behaviors: [], pickRanges: c }
    },
    stats: { format: "acmap", version: x.version, ...d }
  };
}
const zn = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  loadMap: bn,
  wasmAllowed: zr
}, Symbol.toStringTag, { value: "Module" }));
export {
  wt as B,
  Ht as C,
  St as G,
  Bt as R,
  vt as T,
  Ie as V,
  gt as a,
  We as b,
  zt as c,
  zn as d,
  Ft as i,
  bn as l,
  At as m,
  pt as r,
  w0 as s,
  zr as w
};
