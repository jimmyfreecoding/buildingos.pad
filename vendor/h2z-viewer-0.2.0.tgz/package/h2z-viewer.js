import { LEGACY_COLOR as C, legacyLook as U } from "./h2z-viewer-compat.js";
import { V as I, C as G } from "./chunks/map-vxnzyh70.js";
import { B as q, G as W, T as H, a as N, c as z, i as F, b as _, l as K, r as Q, s as Y, w as J } from "./chunks/map-vxnzyh70.js";
import * as u from "three";
import * as k from "three/addons/utils/BufferGeometryUtils.js";
function O(S) {
  S.updateMatrixWorld(!0);
  const E = /* @__PURE__ */ new Map(), y = [];
  let f = 0;
  S.traverse((e) => {
    if (e !== S)
      if (e.isMesh && !e.isInstancedMesh && !e.isSkinnedMesh) {
        f++;
        const c = e.material, g = [e.userData.semantic || "site", c.uuid, e.castShadow, e.receiveShadow, e.renderOrder].join("|");
        E.has(g) || E.set(g, { semantic: e.userData.semantic || "site", material: c, first: e, list: [] }), E.get(g).list.push(e);
      } else (e.isPoints || e.isLine || e.isSprite || e.isInstancedMesh) && y.push(e);
  });
  const i = new u.Group();
  i.name = S.name;
  const w = [];
  for (const e of E.values()) {
    const c = e.list.map((m) => {
      const h = (m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone()).applyMatrix4(m.matrixWorld);
      for (const s of Object.keys(h.attributes)) ["position", "normal", "uv", "color"].includes(s) || h.deleteAttribute(s);
      return h.morphAttributes = {}, h.clearGroups(), h;
    }), g = ["position", "normal", "uv", "color"].filter((m) => c.every((h) => h.attributes[m]));
    c.forEach((m) => Object.keys(m.attributes).forEach((h) => {
      g.includes(h) || m.deleteAttribute(h);
    }));
    const v = c.length === 1 ? c[0] : k.mergeGeometries(c);
    if (!v) throw new Error("合并失败：" + e.semantic + "|" + e.material.name);
    c.length > 1 && c.forEach((m) => m.dispose());
    const b = Array.isArray(e.material) ? e.material[0] : e.material;
    Array.isArray(e.material) && w.push(e.semantic + "|" + (b && b.name || "unnamed") + "（多材质收成单材质，其余面沿用第一个材质）"), v.clearGroups();
    const r = new u.Mesh(v, b);
    r.name = e.semantic + "|" + (b && b.name || "unnamed"), r.userData.semantic = e.semantic, r.castShadow = e.first.castShadow, r.receiveShadow = e.first.receiveShadow, r.renderOrder = e.first.renderOrder, e.semantic === "site" && !e.first.userData.semantic && w.push(r.name), i.add(r);
  }
  let l = 0, M = 0;
  for (const e of y)
    e.matrixWorld.decompose(e.position, e.quaternion, e.scale), e.isInstancedMesh && (l++, M += e.count, (e.name || "").includes("|") || w.push(e.name || "(unnamed instanced)")), i.add(e);
  return { root: i, stats: { meshesIn: f, meshesOut: E.size, instanced: l, instances: M, unassigned: w } };
}
function T(S, E, { palette: y } = {}) {
  const f = S.build({ palette: y, presets: E.presets }), { root: i, stats: w } = O(f.root), l = /* @__PURE__ */ new Set();
  return f.root.traverse((M) => {
    M.geometry && l.add(M.geometry);
  }), l.forEach((M) => M.dispose()), { root: i, model: S.model, stats: w };
}
function D({ id: S, label: E, capabilities: y, emitSelect: f = !1, source: i }) {
  return {
    id: S,
    label: E,
    kind: "webgl",
    capabilities: [...y],
    // 只读信息：模型来源（迁移脚本、导出据此把模型文件带进项目目录）
    source: { kind: i.kind, ...i.url ? { url: i.url } : {} },
    create(w, l = {}) {
      const M = l.emit || (() => {
      }), e = new I(w, { emit: M, palette: l.theme && l.theme.scene, emitSelect: f, supports: y });
      let c = null, g = [];
      const v = () => {
        g.forEach(([r, m]) => e[r](...m)), g = [];
      };
      if (i.kind === "procedural") {
        const r = T(i, e, { palette: l.theme && l.theme.scene });
        e.setModel(r), c = Promise.resolve(e);
      } else if (i.kind === "file" || i.kind === "buildingosmap" || i.kind === "acmap")
        c = import("./chunks/map-vxnzyh70.js").then((r) => r.m).then((r) => r.loadMap(i.url, e, { palette: l.theme && l.theme.scene, key: i.key, decoderPath: i.decoderPath })).then((r) => (e.disposed || (e.setModel(r), v()), e)).catch((r) => {
          throw M("error", String(r && r.message || r)), r;
        });
      else
        throw new Error("未知的模型来源：" + i.kind);
      const b = { ready: c, viewer: e, highlight: (...r) => e.highlight(...r), setVisible: (...r) => e.setVisible(...r), pickAt: (...r) => e.pickAt(...r) };
      for (const r of G)
        b[r] = (...m) => {
          if (e.model) return e[r](...m);
          g.push([r, m]);
        };
      return b.dispose = () => e.dispose(), b;
    }
  };
}
function B(S = {}, { name: E = "model" } = {}) {
  const y = S.palette || {}, f = new u.Group();
  f.name = E;
  const i = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Set(), M = new u.BoxGeometry(1, 1, 1);
  l.add(M);
  const e = /* @__PURE__ */ new Map([["box", M]]);
  let c = "site";
  const g = new u.Matrix4(), v = new u.Quaternion(), b = new u.Euler(), r = new u.Vector3(), m = new u.Vector3(), h = {
    THREE: u,
    root: f,
    /** 主题调色板覆盖（硬约束 4：主题只覆盖它关心的槽） */
    color(s, t) {
      return y[s] === void 0 ? t : y[s];
    },
    /** 材质槽。同名槽只建一次；shadow:false 的槽不投射阴影 */
    material(s, t, n = {}) {
      if (i.has(s)) return i.get(s);
      const { shadow: a = !0, basic: p = !1, ...d } = n, o = p ? new u.MeshBasicMaterial({ color: h.color(s, t), ...d }) : new u.MeshStandardMaterial({ color: h.color(s, t), roughness: 0.8, ...d });
      return o.color.convertSRGBToLinear(), o.emissive && d.emissive !== void 0 && o.emissive.convertSRGBToLinear(), o.name = s, o.userData.shadow = a, i.set(s, o), o;
    },
    /** 在语义实体下建模：fn 里创建的几何都归属 id */
    semantic(s, t) {
      const n = c;
      c = s;
      try {
        return t();
      } finally {
        c = n;
      }
    },
    get current() {
      return c;
    },
    /** 注册可复用几何（圆柱、球等），之后用 k.place(material, key, ...) 摆放 */
    geometry(s, t) {
      return e.has(s) || (e.set(s, t), l.add(t)), e.get(s);
    },
    /** 摆放一个方块：中心 (x,y,z)，尺寸 (w,h,d)，绕 y 旋转 ry 弧度 */
    box(s, t, n, a, p, d, o, x = 0) {
      return h.place(s, "box", t, n, a, p, d, o, x);
    },
    /** 两点之间的杆件（方截面） */
    beam(s, t, n, a = 0.1) {
      const p = new u.Vector3(...t), d = new u.Vector3(...n), o = d.clone().sub(p), x = o.length();
      v.setFromUnitVectors(new u.Vector3(0, 1, 0), o.normalize()), g.compose(p.add(d).multiplyScalar(0.5), v, m.set(a, x, a)), h.placeMatrix(s, "box", g);
    },
    /** 摆放已注册几何：位置、缩放、绕 y 旋转 */
    place(s, t, n, a, p, d = 1, o = 1, x = 1, A = 0) {
      b.set(0, A, 0), v.setFromEuler(b), g.compose(r.set(n, a, p), v, m.set(d, o, x)), h.placeMatrix(s, t, g);
    },
    placeMatrix(s, t, n) {
      if (!e.has(t)) throw new Error("未注册的几何：" + t);
      const a = c + "|" + s.name + "|" + t;
      w.has(a) || w.set(a, { semantic: c, material: s, key: t, list: [] }), w.get(a).list.push(n.clone());
    },
    /** 单个网格（形状特殊、不重复的构件）；编译时按「语义 × 材质」合并 */
    mesh(s, t, n) {
      const a = new u.Mesh(t, s);
      return a.userData.semantic = c, n && (a.matrixAutoUpdate = !1, a.matrix.copy(n), a.matrix.decompose(a.position, a.quaternion, a.scale), a.matrixAutoUpdate = !0), a.castShadow = s.userData.shadow !== !1, a.receiveShadow = !0, l.add(t), f.add(a), a;
    },
    /**
     * 实例集：重复设备（摄像机、AP、机柜……）逐台可拾取 / 高亮 / 显隐 / 聚焦。
     * ids[i] 与 transforms[i] 一一对应；parts 是一台设备的各部件（每个部件一个材质、一份本地几何）。
     * 返回 semantics.instanceSets 里要写的条目 { parent, ids }。
     */
    instanceSet(s, { parent: t, ids: n, transforms: a, parts: p }) {
      if (n.length !== a.length) throw new Error("实例集 " + s + "：ids 与 transforms 数量不一致");
      for (const d of p) {
        const o = new u.InstancedMesh(d.geometry, d.material, n.length);
        a.forEach((x, A) => o.setMatrixAt(A, x)), o.name = "@" + s + "|" + d.material.name, o.userData.semantic = "@" + s, o.castShadow = d.material.userData.shadow !== !1, o.receiveShadow = !0, l.add(d.geometry), f.add(o);
      }
      return { parent: t, ids: [...n] };
    },
    /** 把若干 [geometry, matrix] 合成一份几何（用于设备部件） */
    merge(s) {
      const t = s.map(([a, p]) => {
        const d = a.index ? a.toNonIndexed() : a.clone();
        p && d.applyMatrix4(p);
        for (const o of Object.keys(d.attributes)) ["position", "normal"].includes(o) || d.deleteAttribute(o);
        return d;
      }), n = k.mergeGeometries(t);
      return t.forEach((a) => a.dispose()), n;
    },
    /** 可复现的伪随机数 */
    rand(s) {
      let t = (s >>> 0) + 1831565813;
      return t = Math.imul(t ^ t >>> 15, t | 1), t ^= t + Math.imul(t ^ t >>> 7, t | 61), ((t ^ t >>> 14) >>> 0) / 4294967296;
    },
    /** 完成：合批写入场景，返回 buildModel 的标准结果 */
    finish() {
      for (const t of w.values()) {
        const n = new u.InstancedMesh(e.get(t.key), t.material, t.list.length);
        t.list.forEach((a, p) => n.setMatrixAt(p, a)), n.name = t.semantic + "|" + t.material.name, n.userData.semantic = t.semantic, n.castShadow = t.material.userData.shadow !== !1, n.receiveShadow = !0, f.add(n);
      }
      w.clear();
      const s = {};
      for (const [t, n] of i) s[t] = n;
      return { root: f, slots: s, dispose() {
        l.forEach((t) => t.dispose()), i.forEach((t) => {
          t.map && t.map.dispose(), t.dispose();
        });
      } };
    }
  };
  return h;
}
const R = "0.2.0";
export {
  q as BEHAVIORS,
  G as CAPABILITIES,
  W as GENERATORS,
  C as LEGACY_COLOR,
  R as RUNTIME_VERSION,
  H as THEMES,
  I as Viewer,
  N as applyTheme,
  B as createKit,
  z as createPresets,
  D as createTwinProvider,
  F as indexTree,
  _ as isWithin,
  U as legacyLook,
  K as loadMap,
  T as loadProcedural,
  O as mergeBySemantic,
  Q as resolveTheme,
  Y as semanticOf,
  J as wasmAllowed
};
