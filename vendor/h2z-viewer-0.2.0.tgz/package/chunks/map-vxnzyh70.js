import * as k from "three";
import { legacyLook as Xr } from "../h2z-viewer-compat.js";
import { OrbitControls as jr } from "three/addons/controls/OrbitControls.js";
import { GLTFLoader as Kr } from "three/addons/loaders/GLTFLoader.js";
import { DRACOLoader as Yr } from "three/addons/loaders/DRACOLoader.js";
const Zr = "dark-pad", Qr = "深色墙板", Jr = 1, et = "墙板（wallPad）地图区：楼层压暗略带蓝灰、所有房间名分级显示、本房间橙色、会议室占用 / 空闲、灯开关。2026-11-02 定稿（Smart 总部 1F 验收）。", rt = { background: "#090909", exposure: 0.18, pixelRatio: [1.5, 2] }, tt = { tone: { dim: 0.55, tint: "#1c2536", mix: 0.25 }, slots: {} }, at = { font: '"PingFang SC","Microsoft YaHei",sans-serif', size: 13, fontScale: [1, 1.55], room: { bg: "rgba(12,17,26,.72)", fg: "#c9d3e0", border: "rgba(255,255,255,.08)", weight: 500 }, mine: { bg: "#ff8a3d", fg: "#ffffff", tag: "当前", scale: 1.25, fill: "#ff8a3d", fillOpacity: 0.3, edge: "#ff8a3d" }, meeting: { bg: "rgba(12,17,26,.86)", fg: "#ffffff", scale: 1.08 }, busy: { color: "#ff5a5a", text: "占用", badge: "#d93838" }, free: { color: "#3ddc84", text: "空闲", badge: "#1f9d5a" }, lightOn: "#ffd23f", lightOff: "#a7b0bd" }, nt = { mode: "plan", focusMinSpan: 26, focusRoomScale: 1.8, margin: 1.12 }, ot = {
  id: Zr,
  name: Qr,
  version: Jr,
  description: et,
  scene: rt,
  materials: tt,
  overlay: at,
  camera: nt
}, it = "light-ops", st = "浅色运维", xt = 1, ct = "BuildingOS 运维页现在的样子：模型原色、默认天空背景和曝光；叠加层用浅底深字、选中蓝色。", ft = {}, lt = { slots: {} }, ht = { font: '"PingFang SC","Microsoft YaHei",sans-serif', size: 12, fontScale: [1, 1.4], room: { bg: "rgba(255,255,255,.85)", fg: "#303133", border: "rgba(0,0,0,.08)", weight: 500 }, mine: { bg: "#409eff", fg: "#ffffff", tag: "当前", scale: 1.2, fill: "#409eff", fillOpacity: 0.35, edge: "#409eff" }, meeting: { bg: "rgba(255,255,255,.92)", fg: "#303133", scale: 1.05 }, busy: { color: "#f56c6c", text: "占用", badge: "#f56c6c" }, free: { color: "#67c23a", text: "空闲", badge: "#67c23a" }, lightOn: "#e6a23c", lightOff: "#909399" }, ut = { mode: "three", focusMinSpan: 26, focusRoomScale: 1.8, margin: 1.12 }, dt = {
  id: it,
  name: st,
  version: xt,
  description: ct,
  scene: ft,
  materials: lt,
  overlay: ht,
  camera: ut
}, vt = Object.freeze({ "dark-pad": ot, "light-ops": dt });
function pt(o) {
  return o ? typeof o == "string" ? vt[o] || null : typeof o == "object" ? o : null : null;
}
const Bt = (o) => o == null ? null : new k.Color(o);
function Ct(o, n) {
  const r = pt(n);
  o._themeOrig || (o._themeOrig = {
    palette: { ...o.palette },
    exposure: o.renderer.toneMappingExposure,
    pixelRatio: o.renderer.getPixelRatio(),
    colors: /* @__PURE__ */ new Map()
  }, o.scene.traverse((t) => {
    if (t.isMesh)
      for (const l of Array.isArray(t.material) ? t.material : [t.material])
        l && !o._themeOrig.colors.has(l) && o._themeOrig.colors.set(l, { color: l.color?.clone(), emissive: l.emissive?.clone(), opacity: l.opacity, transparent: l.transparent });
  }));
  const e = o._themeOrig;
  o._theme = r;
  const i = r?.scene?.background;
  o.palette = i ? { ...e.palette, skyDay: i, skyNight: i, studioSky: i } : { ...e.palette }, o.renderer.toneMappingExposure = r?.scene?.exposure ?? e.exposure;
  const c = r?.scene?.pixelRatio;
  Array.isArray(c) ? o.renderer.setPixelRatio(Math.min(c[1], Math.max(c[0], window.devicePixelRatio || 1))) : typeof c == "number" ? o.renderer.setPixelRatio(c) : o.renderer.setPixelRatio(e.pixelRatio), o._resize?.();
  const A = r?.materials?.tone, d = Bt(A?.tint), x = r?.materials?.slots || {}, a = new Set(Object.keys(o.model?.semantics?.materialStates || {}).map((t) => o.materials?.get(t)).filter(Boolean));
  return o._themeMaterials = () => {
    for (const [t, l] of e.colors) {
      a.has(t) || (l.color && t.color && t.color.copy(l.color), l.emissive && t.emissive && t.emissive.copy(l.emissive)), t.opacity = l.opacity, t.transparent = l.transparent, A && t.color && (A.dim !== void 0 && t.color.multiplyScalar(A.dim), d && t.color.lerp(d, A.mix ?? 0.25), t.emissive && A.dim !== void 0 && !a.has(t) && t.emissive.multiplyScalar(A.dim));
      const s = x[t.name];
      s && (s.color !== void 0 && t.color && t.color.set(s.color).convertSRGBToLinear(), s.opacity !== void 0 && (t.opacity = s.opacity, t.transparent = s.opacity < 1)), t.needsUpdate = !0;
    }
  }, o.environment?.(o.weather, o.hour), o.emit?.("theme", r ? r.id : null), r;
}
function w0(o) {
  if (o.userData && o.userData.semantic) return o.userData.semantic;
  const n = o.name || "", r = n.indexOf("|");
  return r > 0 ? n.slice(0, r) : null;
}
function mt(o = []) {
  const n = /* @__PURE__ */ new Map(), r = (e, i) => e.forEach((c) => {
    n.set(c.id, { ...c, parent: i }), c.children && r(c.children, c.id);
  });
  return r(o, null), n;
}
function We(o, n, r) {
  for (let e = n; e; e = o.get(e)?.parent) if (e === r) return !0;
  return !1;
}
const At = {
  id: "campus-life",
  version: 1,
  create(o, n, r = {}) {
    const e = { time: { value: 0 }, cloud: { value: 0.43 }, night: { value: 0 }, dusk: { value: 0 }, flatMix: { value: 0 }, flatColor: { value: new k.Color(16777215) } }, i = new k.Mesh(new k.SphereGeometry(1100, 32, 16), new k.ShaderMaterial({
      side: k.BackSide,
      depthWrite: !1,
      uniforms: e,
      vertexShader: "varying vec3 vWorld; void main(){vWorld=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}",
      fragmentShader: `varying vec3 vWorld; uniform float time; uniform float cloud; uniform float night; uniform float dusk; uniform float flatMix; uniform vec3 flatColor;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      float fbm(vec2 p){float v=0.;float a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+13.5;a*=.5;}return v;}
      void main(){vec3 d=normalize(vWorld);float h=max(d.y,0.);vec3 color=mix(vec3(.72,.81,.87),vec3(.16,.39,.66),pow(h,.45));
      color=mix(color,mix(vec3(.91,.59,.39),vec3(.29,.33,.54),pow(h,.4)),dusk*.82);
      vec2 uv=d.xz/(max(d.y,.06)+.24)*2.6+vec2(time*.004,0.);float n=fbm(uv);float c=smoothstep(.68-cloud*.42,.79-cloud*.33,n)*smoothstep(-.02,.16,d.y);
      color=mix(color,mix(vec3(.69,.76,.8),vec3(1.),smoothstep(.4,.8,n)),c*.93);
      color=mix(color,vec3(.016,.033,.085)+h*.02,night*.98);
      float star=step(.9978,hash(floor(d.xz/(d.y+.2)*850.)))*smoothstep(.1,.5,h);color+=star*night*.7;
      color=mix(color,flatColor,flatMix);
      gl_FragColor=vec4(color,1.);}`
    }));
    i.name = "campus-life-sky", i.frustumCulled = !1, i.renderOrder = -1e3, o.scene.add(i);
    const c = new k.Group();
    c.name = "campus-life-traffic", o.scene.add(c);
    const A = 32, d = new k.BoxGeometry(1, 1, 1), x = new k.MeshStandardMaterial({ color: 16777215, roughness: 0.48, metalness: 0.25 }), a = new k.MeshStandardMaterial({ color: 3162698, roughness: 0.38, metalness: 0.25 }), t = new k.MeshStandardMaterial({ color: 2369322, roughness: 0.9 }), l = new k.InstancedMesh(d, x, A), s = new k.InstancedMesh(d, a, A), h = new k.InstancedMesh(d, t, A * 4);
    for (const m of [l, s, h])
      m.frustumCulled = !1, m.castShadow = !0, c.add(m);
    const p = [13029070, 5073019, 7568252, 11907753, 8803919], C = Array.from({ length: A }, (m, E) => {
      const y = E < 20, b = E % 2 ? 1 : -1;
      return { axis: y ? "x" : "z", dir: b, speed: 7 + E * 7 % 9, position: -280 + E % (y ? 20 : 12) * (y ? 28 : 46), initial: -280 + E % (y ? 20 : 12) * (y ? 28 : 46), lane: y ? b > 0 ? 71 : 83 : b > 0 ? 109 : 119 };
    }), v = new k.Matrix4(), g = new k.Quaternion(), f = new k.Vector3(), u = new k.Vector3();
    function B() {
      C.forEach((m, E) => {
        const y = m.axis === "x" ? m.position : m.lane, b = m.axis === "z" ? m.position : m.lane, S = m.axis === "x" ? m.dir > 0 ? Math.PI / 2 : -Math.PI / 2 : m.dir > 0 ? 0 : Math.PI;
        g.setFromAxisAngle(new k.Vector3(0, 1, 0), S);
        const F = (D, _, w, P, O, W, T, G) => {
          f.set(y + w * Math.cos(S) + O * Math.sin(S), P, b - w * Math.sin(S) + O * Math.cos(S)), v.compose(f, g, u.set(W, T, G)), D.setMatrixAt(_, v);
        };
        F(l, E, 0, 0.65, 0, 1.9, 0.8, 4.4), F(s, E, 0, 1.25, -0.2, 1.65, 0.6, 2.4);
        for (let D = 0; D < 4; D++) F(h, E * 4 + D, D % 2 ? 0.95 : -0.95, 0.35, D < 2 ? -1.35 : 1.35, 0.25, 0.55, 0.65);
        l.setColorAt(E, new k.Color(p[E % p.length]));
      });
      for (const m of [l, s, h]) m.instanceMatrix.needsUpdate = !0;
    }
    return B(), i.position.copy(o.camera.position), r.sky === !1 && (i.visible = !1), {
      kind: "campus-life",
      cars: C,
      sky: i,
      traffic: c,
      environment({ weather: m, hour: E, night: y }) {
        e.night.value = y ? 1 : 0, e.dusk.value = !y && (E < 8 || E > 17) ? 1 : 0, e.cloud.value = m === "sunny" ? 0.4 : m === "cloudy" ? 0.95 : 1.4, i.visible = !o.studioOn && r.sky !== !1;
      },
      update(m) {
        if (i.position.copy(o.camera.position), e.time.value += m, c.visible = o.layerState?.[r.vehicleLayer || "vehicles"] !== !1, !!c.visible) {
          for (const E of C)
            E.position += E.dir * E.speed * m, E.position > 290 && (E.position = -290), E.position < -290 && (E.position = 290);
          B();
        }
      },
      dispose() {
        o.scene.remove(i, c), i.geometry.dispose(), i.material.dispose(), d.dispose(), x.dispose(), a.dispose(), t.dispose();
      }
    };
  }
}, Et = {
  id: "precipitation",
  version: 1,
  create(o, n, r = {}) {
    const e = r.count || 600, i = r.min || [-130, 0, -170], c = r.max || [130, 150, 130];
    let A = 1234567;
    const d = () => (A = A * 16807 % 2147483647) / 2147483647, x = new Float32Array(e * 3);
    for (let s = 0; s < e; s++) for (let h = 0; h < 3; h++) x[s * 3 + h] = i[h] + d() * (c[h] - i[h]);
    const a = new k.BufferGeometry();
    a.setAttribute("position", new k.BufferAttribute(x, 3));
    const t = new k.Points(a, new k.PointsMaterial({ color: r.color ?? 14479359, size: 0.55, transparent: !0, opacity: 0.7 }));
    t.visible = !1, o.scene.add(t);
    let l = "sunny";
    return {
      environment(s) {
        l = s.weather, t.visible = l === "rain" || l === "snow", t.material.size = l === "snow" ? 1.1 : 0.45;
      },
      update(s) {
        if (t.visible) {
          for (let h = 1; h < x.length; h += 3)
            x[h] -= s * (l === "snow" ? 5 : 65), x[h] < i[1] && (x[h] = c[1]);
          a.attributes.position.needsUpdate = !0;
        }
      },
      dispose() {
        o.scene.remove(t), a.dispose(), t.material.dispose();
      }
    };
  }
}, gt = {
  id: "traffic",
  version: 1,
  create(o, n, r = {}) {
    const e = Array.isArray(r.ids) ? r.ids : [], i = Array.isArray(r.v) ? r.v : [r.v || 8], c = (v) => {
      const g = Number(i[0]) || 8, f = Number(i[1] ?? g) || g, u = v * 37 % 100 / 100;
      return g + (f - g) * u;
    }, A = Array.isArray(r.wrap) && r.wrap.length === 2 ? r.wrap.map(Number) : [-400, 400], d = String(r.layer || "vehicles"), x = /* @__PURE__ */ new Map(), a = o.root;
    a && a.traverse((v) => {
      if (!v.isMesh) return;
      const g = v.userData && v.userData.semantic || (v.name || "").split("|")[0];
      g && (x.has(g) || x.set(g, []), x.get(g).push(v));
    });
    const t = [];
    let l = 0;
    const s = new k.Box3(), h = new k.Vector3(), p = new k.Vector3();
    for (const v of e) {
      const g = x.get(v);
      if (!g || !g.length) continue;
      s.makeEmpty();
      for (const m of g) s.expandByObject(m);
      s.getSize(h), s.getCenter(p);
      const f = h.x > h.z ? "x" : "z", u = l % 2 ? 1 : -1, B = new k.Group();
      B.name = v, g[0].parent && g[0].parent.add(B);
      for (const m of g) B.add(m);
      t.push({ node: B, axis: f, dir: u, speed: c(l), base: B.position.clone() }), l++;
    }
    let C = !1;
    return {
      kind: "traffic",
      cars: t,
      update(v) {
        if (!(!(!o.layerState || o.layerState[d] !== !1) || C))
          for (const f of t)
            f.node.position[f.axis] += f.dir * f.speed * v, f.node.position[f.axis] > A[1] && (f.node.position[f.axis] = A[0]), f.node.position[f.axis] < A[0] && (f.node.position[f.axis] = A[1]);
      },
      pause(v) {
        C = !!v;
      },
      reset() {
        for (const v of t) v.node.position.copy(v.base);
      },
      dispose() {
      }
    };
  }
}, Te = "varying vec3 vWorld; void main(){ vWorld = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }", qe = `varying vec3 vWorld;
uniform float time; uniform float cloud; uniform float night; uniform float dusk; uniform vec3 sunDir; uniform vec3 ground; uniform float groundMix; uniform float flatMix; uniform vec3 flatColor;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p){ float v = 0.; float a = .5; for (int i = 0; i < 5; i++){ v += a * noise(p); p = p * 2.03 + 13.5; a *= .5; } return v; }
void main(){
  vec3 d = normalize(vWorld); float h = max(d.y, 0.);
  vec3 color = mix(vec3(.74, .83, .89), vec3(.18, .41, .70), pow(h, .45));
  color = mix(color, mix(vec3(.93, .62, .40), vec3(.30, .34, .55), pow(h, .4)), dusk * .82);
  float sd = max(dot(d, normalize(sunDir)), 0.);
  color += vec3(1., .93, .78) * (pow(sd, 900.) * 6. + pow(sd, 12.) * .18) * (1. - night);
  vec2 uv = d.xz / (max(d.y, .06) + .24) * 2.6 + vec2(time * .004, 0.);
  float n = fbm(uv); float c = smoothstep(.68 - cloud * .42, .79 - cloud * .33, n) * smoothstep(-.02, .16, d.y);
  color = mix(color, mix(vec3(.70, .77, .81), vec3(1.), smoothstep(.4, .8, n)), c * .9);
  color = mix(color, vec3(.016, .033, .085) + h * .02, night * .98);
  float star = step(.9978, hash(floor(d.xz / (d.y + .2) * 850.))) * smoothstep(.1, .5, h); color += star * night * .7;
  // 地平线以下：地面色（玻璃里反出来的是地面，不是天空）
  // groundMix=1（只用于烘环境贴图）：地面色；=0（看得见的天空）：延续地平线雾色，免得小场地边缘外露出一条地面色带
  vec3 haze = mix(mix(vec3(.74, .83, .89), vec3(.93, .62, .40), dusk * .6), vec3(.03, .05, .1), night * .95);
  vec3 g = mix(haze, mix(ground, ground * .12, night), groundMix);
  color = mix(color, g, 1. - smoothstep(-.08, 0., d.y));   // smoothstep 的两个边界必须递增，反着写在部分驱动上是未定义（会出黑）
  color = mix(color, flatColor, flatMix);
  gl_FragColor = vec4(color, 1.);
}`, Ft = {
  id: "sky",
  version: 1,
  create(o, n, r = {}) {
    const e = Number(r.radius) || 1500, i = {
      time: { value: 0 },
      cloud: { value: r.cloud ?? 0.4 },
      night: { value: 0 },
      dusk: { value: 0 },
      sunDir: { value: new k.Vector3(-0.5, 0.7, 0.4) },
      ground: { value: new k.Color().setHex(parseInt(String(r.ground || "#5a6352").replace("#", ""), 16), k.LinearSRGBColorSpace) },
      // 着色器里的颜色按原值输出（天空色也是这么写的），不做线性化
      groundMix: { value: 0 },
      flatMix: { value: 0 },
      flatColor: { value: new k.Color(16777215) }
    }, c = { ...i, groundMix: { value: 1 } }, A = new k.ShaderMaterial({ side: k.BackSide, depthWrite: !1, uniforms: i, vertexShader: Te, fragmentShader: qe }), d = new k.Mesh(new k.SphereGeometry(e, 48, 24), A);
    d.name = "sky@1", d.frustumCulled = !1, d.renderOrder = -1e3, o.scene.add(d);
    const x = new k.Scene(), a = new k.ShaderMaterial({ side: k.BackSide, depthWrite: !1, uniforms: c, vertexShader: Te, fragmentShader: qe }), t = new k.Mesh(new k.SphereGeometry(100, 48, 24), a);
    x.add(t);
    const l = Number(r.envSize) || 256, s = new k.WebGLCubeRenderTarget(l, { type: k.HalfFloatType }), h = new k.CubeCamera(1, 1e3, s);
    x.add(h);
    const p = new k.PMREMGenerator(o.renderer);
    let C = null;
    const v = r.envDefault ?? 0.3, g = r.envSlots || {};
    function f() {
      o.sun && i.sunDir.value.copy(o.sun.position).normalize(), h.update(o.renderer, x);
      const u = p.fromCubemap(s.texture);
      C && C.dispose(), C = u, o.scene.environment = o.studioOn ? null : C.texture;
      for (const [B, m] of o.materials || [])
        !m || !("envMapIntensity" in m) || (m.envMapIntensity = g[B] ?? v, m.envMap && g[B] !== void 0 && (m.envMap = null), m.needsUpdate = !0);
    }
    return {
      kind: "sky",
      sky: d,
      environment({ weather: u, hour: B, night: m }) {
        i.night.value = m ? 1 : 0, i.dusk.value = !m && (B < 8 || B > 17) ? 1 : 0, i.cloud.value = u === "sunny" ? r.cloud ?? 0.4 : u === "cloudy" ? 0.95 : 1.4, d.visible = !o.studioOn, f();
      },
      update(u) {
        d.position.copy(o.camera.position), i.time.value += u;
      },
      dispose() {
        o.scene.remove(d), o.scene.environment === C?.texture && (o.scene.environment = null), d.geometry.dispose(), t.geometry.dispose(), A.dispose(), a.dispose(), s.dispose(), C && C.dispose(), p.dispose();
      }
    };
  }
}, Dt = { "precipitation@1": Et, "campus-life@1": At, "traffic@1": gt, "sky@1": Ft };
function Ie(o) {
  let n = (o >>> 0) + 1831565813;
  return n = Math.imul(n ^ n >>> 15, n | 1), n ^= n + Math.imul(n ^ n >>> 7, n | 61), ((n ^ n >>> 14) >>> 0) / 4294967296;
}
const yt = {
  build(o, n = {}, { palette: r = {} } = {}) {
    const e = n.semantic || "racks", i = n.floorY || 0, c = n.height || 9, A = n.beams || [1.8, 3.6, 5.4, 7.2], d = n.fill ?? 0.7, x = n.seed || 1, a = { upright: 3108784, beam: 15694380, cargo: 13215610, cargo2: 14467995, ...n.colors || {} }, t = (f, u, B = {}) => {
      const m = new k.MeshStandardMaterial({ color: r[f] === void 0 ? u : r[f], roughness: 0.75, ...B });
      return m.color.convertSRGBToLinear(), m.name = f, m;
    }, l = new k.BoxGeometry(1, 1, 1), s = { "rack.upright": [], "rack.beam": [], "rack.cargo": [], "rack.cargo2": [] }, h = (f, u, B, m, E, y) => new k.Matrix4().compose(new k.Vector3(f, u, B), new k.Quaternion(), new k.Vector3(m, E, y)), p = /* @__PURE__ */ new Set(), C = n.keepout || [], v = (n.bays || []).filter(([f, u, B, m]) => !C.some(([E, y, b]) => Math.abs(E - f) < B / 2 + b && Math.abs(y - u) < m / 2 + b));
    v.forEach(([f, u, B, m], E) => {
      for (const S of [-1, 1]) for (const F of [-1, 1]) {
        const D = f + S * (B / 2 - 0.04), _ = u + F * (m / 2), w = Math.round(D * 50) + "," + Math.round(_ * 50);
        p.has(w) || (p.add(w), s["rack.upright"].push(h(D, i + c / 2, _, 0.08, c, 0.08)));
      }
      for (const S of [...A, c - 0.1]) for (const F of [-1, 1]) s["rack.beam"].push(h(f + F * (B / 2 - 0.04), i + S, u, 0.06, 0.12, m - 0.08));
      const y = m > 3.3 ? 3 : m > 2 ? 2 : 1, b = m / y;
      [0, ...A].forEach((S, F) => {
        for (let D = 0; D < y; D++) {
          const _ = Ie(x * 7919 + E * 131 + F * 17 + D);
          if (_ > d) continue;
          const w = 0.85 + Ie(E * 31 + F * 7 + D * 3 + x) * 0.45;
          s[_ < d / 2 ? "rack.cargo" : "rack.cargo2"].push(h(f, i + S + 0.07 + w / 2, u - m / 2 + b * (D + 0.5), B * 0.86, w, Math.min(1.1, b * 0.86)));
        }
      });
    });
    const g = [];
    for (const [f, u] of Object.entries(s)) {
      if (!u.length) continue;
      const B = t(f, f === "rack.upright" ? a.upright : f === "rack.beam" ? a.beam : f === "rack.cargo" ? a.cargo : a.cargo2, f === "rack.upright" ? { metalness: 0.3 } : {}), m = new k.InstancedMesh(l, B, u.length);
      u.forEach((E, y) => m.setMatrixAt(y, E)), m.name = e + "|" + f, m.userData.semantic = e, m.userData.generated = "racks@1", m.castShadow = f === "rack.upright", m.receiveShadow = !0, o.add(m), g.push(m);
    }
    return { meshes: g, stats: { bays: v.length, removed: (n.bays || []).length - v.length, instances: Object.values(s).reduce((f, u) => f + u.length, 0) } };
  }
}, bt = { "racks@1": yt };
function _t(o) {
  const n = document.createElement("canvas");
  n.width = 512, n.height = 1024;
  const r = n.getContext("2d"), e = r.createLinearGradient(0, 0, 0, 1024);
  e.addColorStop(0, "#14282d"), e.addColorStop(0.3, "#243c40"), e.addColorStop(0.55, "#698185"), e.addColorStop(0.82, "#334c50"), e.addColorStop(1, "#172d31"), r.fillStyle = e, r.fillRect(0, 0, 512, 1024);
  for (let a = 0; a < 3; a++) {
    const t = a * 341;
    r.fillStyle = "rgba(10,23,27,.6)", r.fillRect(0, t + 6, 512, 43);
    for (let l = -64; l < 576; l += 64)
      r.strokeStyle = "rgba(16,31,34,.65)", r.lineWidth = 5, r.beginPath(), r.moveTo(l, t + 38), r.lineTo(l + 52, t + 105), r.lineTo(l + 52, t + 319), r.stroke(), r.strokeStyle = "rgba(166,189,187,.32)", r.lineWidth = 2, r.beginPath(), r.moveTo(l + 7, t + 40), r.lineTo(l + 59, t + 105), r.lineTo(l + 59, t + 319), r.stroke();
    r.fillStyle = "rgba(157,173,170,.4)", r.fillRect(0, t + 274, 512, 14), r.fillStyle = "rgba(13,29,32,.75)", r.fillRect(0, t + 291, 512, 11), r.strokeStyle = "rgba(30,48,51,.6)", r.lineWidth = 3;
    for (let l = 18; l < 512; l += 85)
      r.strokeRect(l, t + 145, 48, 99), r.strokeRect(l + 7, t + 152, 34, 84);
  }
  for (let a = 0; a < 4; a++) {
    const t = a * 128;
    r.fillStyle = a % 2 ? "rgba(142,175,180,.09)" : "rgba(8,32,38,.12)", r.fillRect(t, 0, 128, 1024), r.fillStyle = "rgba(7,23,29,.7)", r.fillRect(t, 0, 5, 1024), r.fillRect(t + 120, 0, 4, 1024), r.fillStyle = "rgba(176,205,205,.42)", r.fillRect(t + 7, 0, 2, 1024), r.fillRect(t + 116, 0, 2, 1024);
    for (let l = 0; l < 1024; l += 170.5)
      r.fillStyle = "rgba(12,31,36,.55)", r.fillRect(t, l, 128, 4), r.fillStyle = "rgba(163,191,194,.36)", r.fillRect(t, l + 5, 128, 2);
  }
  const i = r.createLinearGradient(0, 0, 512, 600);
  i.addColorStop(0, "rgba(192,222,233,.03)"), i.addColorStop(0.48, "rgba(169,201,211,.18)"), i.addColorStop(1, "rgba(130,169,183,0)"), r.fillStyle = i, r.fillRect(0, 0, 512, 1024);
  const c = new k.CanvasTexture(n);
  c.colorSpace = k.SRGBColorSpace, c.wrapS = k.RepeatWrapping, c.anisotropy = o ? Math.min(8, o.capabilities.getMaxAnisotropy()) : 8;
  const A = [];
  for (let a = 0; a < 6; a++) {
    const t = document.createElement("canvas");
    t.width = t.height = 256;
    const l = t.getContext("2d"), s = l.createLinearGradient(0, 0, 0, 256);
    s.addColorStop(0, "#688bad"), s.addColorStop(0.5, "#b5cbd4"), s.addColorStop(0.63, "#829491"), s.addColorStop(1, "#344941"), l.fillStyle = s, l.fillRect(0, 0, 256, 256);
    for (let h = 0; h < 12; h++) {
      const p = (h * 83 + a * 39) % 256, C = 20 + h * 37 % 105, v = l.createRadialGradient(p, C, 2, p, C, 36);
      v.addColorStop(0, "rgba(245,250,250,.4)"), v.addColorStop(1, "rgba(245,250,250,0)"), l.fillStyle = v, l.fillRect(0, 0, 256, 256);
    }
    A.push(t);
  }
  const d = new k.CubeTexture(A);
  d.colorSpace = k.SRGBColorSpace, d.needsUpdate = !0;
  const x = new k.MeshStandardMaterial({
    color: 12966873,
    map: c,
    roughness: 0.28,
    metalness: 0.22,
    envMap: d,
    envMapIntensity: 0.32,
    emissive: 6652535,
    emissiveMap: c,
    emissiveIntensity: 0
  });
  return x.color.convertSRGBToLinear(), x.name = "facade.glass", { facadeGlass: x, facadeTexture: c, reflection: d };
}
function wt() {
  const n = [], r = [(A, d) => [1, -d, -A], (A, d) => [-1, -d, A], (A, d) => [A, 1, d], (A, d) => [A, -1, -d], (A, d) => [A, -d, 1], (A, d) => [-A, -d, -1]], e = (A, d, x) => A.map((a, t) => a + (d[t] - a) * x);
  for (const A of r) {
    const d = document.createElement("canvas");
    d.width = d.height = 256;
    const x = d.getContext("2d"), a = x.createImageData(256, 256);
    for (let t = 0; t < 256; t++) for (let l = 0; l < 256; l++) {
      let [s, h, p] = A(2 * (l + 0.5) / 256 - 1, 2 * (t + 0.5) / 256 - 1);
      const C = Math.hypot(s, h, p);
      s /= C, h /= C, p /= C;
      const v = Math.atan2(p, s), g = Math.max(0, Math.min(1, h));
      let f = e([202, 215, 221], [96, 139, 181], Math.sqrt(g));
      const u = Math.max(0, Math.sin(v * 3 + h * 8) * Math.sin(v * 7 - h * 13)) * 0.25;
      h > 0 && (f = e(f, [242, 244, 243], u));
      const B = Math.max(0, s * -0.65 + p * 0.76) * Math.exp(-Math.pow((h - 0.23) * 3, 2)) * 0.1;
      f = e(f, [248, 221, 179], B);
      const m = Math.floor((v + Math.PI) * 3), E = (v + Math.PI) * 3 % 1, y = 0.08 + 0.43 * (0.5 + 0.5 * Math.sin(m * 13.7));
      if (h < y && E > 0.09 && E < 0.9) {
        const S = 0.5 + 0.5 * Math.sin(m * 4.3);
        f = e([57, 73, 82], [133, 151, 159], S), E % 0.28 < 0.015 && (f = e(f, [211, 224, 230], 0.18));
      }
      h < -0.65 && (f = e([30, 43, 45], [67, 82, 82], Math.max(0, 1 + h)));
      const b = (t * 256 + l) * 4;
      for (let S = 0; S < 3; S++) a.data[b + S] = f[S];
      a.data[b + 3] = 255;
    }
    x.putImageData(a, 0, 0), n.push(d);
  }
  const i = new k.CubeTexture(n);
  i.colorSpace = k.SRGBColorSpace, i.needsUpdate = !0;
  const c = new k.MeshStandardMaterial({ color: 8690083, metalness: 0.35, roughness: 0.32, envMap: i, envMapIntensity: 0.62 });
  return c.color.convertSRGBToLinear(), c.name = "wangchao.glass", { glass: c, reflection: i };
}
function kt(o) {
  const n = /* @__PURE__ */ new Map(), r = (i, c) => (n.has(i) || n.set(i, c()), n.get(i)), e = {
    smartFacade: () => r("smartFacade", () => _t(o)),
    towerGlass: () => r("towerGlass", () => wt()),
    /** 按槽名取预设材质；没有对应预设时返回 null（加载器保留文件里的材质） */
    bySlot(i) {
      return i === "facade.glass" ? e.smartFacade().facadeGlass : i === "wangchao.glass" ? e.towerGlass().glass : null;
    },
    dispose() {
      for (const i of n.values()) for (const c of Object.values(i)) c && c.dispose && c.dispose();
      n.clear();
    }
  };
  return e;
}
const St = Object.freeze([
  "focus",
  "reset",
  "top",
  "orbit",
  "pause",
  "view",
  "labels",
  "studio",
  "environment",
  "snapshots",
  "theme",
  "select",
  "explodeFloor",
  "closeFloor",
  "mode",
  "layer",
  "router",
  "roomHighlight",
  "planView",
  "highlight"
]), Mt = {
  fov: 43,
  near: 1,
  far: 1800,
  pixelRatioMax: 1.65,
  exposure: 0.85,
  controls: { minDistance: 40, maxDistance: 850, maxPolarAngle: Math.PI * 0.485, autoRotateSpeed: 0.45 },
  sun: { color: 16772824, position: [-100, 180, 100], shadowMapSize: 2048, shadowExtent: 210, shadowFar: 600, shadowBias: -3e-4 },
  hemisphere: { sky: 14151423, ground: 5924432 },
  sky: { day: 11060956, night: 595237, overcast: 9018281, studio: 16777215 },
  fog: { normal: 9e-4, fog: 7e-3 },
  lights: { sun: [2.4, 0.9, 0.15], ambient: [1.3, 0.5] }
  // [晴, 阴, 夜] / [日, 夜]，r115 艺术家单位
};
class Le {
  /**
   * @param {HTMLElement} container
   * @param {object} opts
   *   - emit(type, payload)       事件出口（labels / stats / snapshots / select）
   *   - palette                   主题场景调色板（skyDay / skyNight / studioSky / studioGround 等）
   *   - studio                    初始是否纯白背景
   *   - emitSelect                点击楼栋时是否发 select 事件（Smart 现状为 false，只聚焦）
   *   - supports                  当前模型声明支持的能力（can() 的依据）
   */
  constructor(n, r = {}) {
    this.container = n, this.opts = r, this.emit = r.emit || (() => {
    }), this.palette = r.palette || {}, this.supports = new Set(r.supports || []), this.renderer = new k.WebGLRenderer({ antialias: !0, preserveDrawingBuffer: !0 }), this.presets = kt(this.renderer), this.scene = new k.Scene(), r.legacyLook !== !1 && Xr(this.scene), this.behaviors = [], this._disposables = [], this.paused = !1, this.disposed = !1, this.fly = null, this.weather = "sunny", this.hour = 14, this.studioOn = !!r.studio, this._frames = 0, this._statsAt = performance.now(), this._labelsAt = 0, this._last = performance.now();
  }
  /** 装入模型：{ root, model: { viewer, home, semantics }, slots? } */
  setModel({ root: n, model: r }) {
    const e = { ...Mt, ...r.viewer || {} };
    this.cfg = e, this.model = r;
    const i = this.renderer;
    i.setPixelRatio(Math.min(devicePixelRatio, e.pixelRatioMax)), i.outputColorSpace = k.SRGBColorSpace, i.toneMapping = k.ACESFilmicToneMapping, i.toneMappingExposure = e.exposure, i.shadowMap.enabled = !0, i.shadowMap.type = k.PCFShadowMap, this.container.appendChild(i.domElement), this.camera = new k.PerspectiveCamera(e.fov, 1, e.near, e.far);
    const c = this.controls = new jr(this.camera, i.domElement);
    c.enableDamping = !0, Object.assign(c, e.controls);
    const A = e.sun;
    this.sun = new k.DirectionalLight(A.color, 2.4), this.sun.position.set(...A.position), this.sun.castShadow = !0, this.sun.shadow.mapSize.set(A.shadowMapSize, A.shadowMapSize), Object.assign(this.sun.shadow.camera, { left: -A.shadowExtent, right: A.shadowExtent, top: A.shadowExtent, bottom: -A.shadowExtent, near: 1, far: A.shadowFar }), this.sun.shadow.bias = A.shadowBias, this.ambient = new k.HemisphereLight(e.hemisphere.sky, e.hemisphere.ground, 1.3), this.scene.add(this.sun, this.ambient), this.root = n, this.scene.add(n), this.generated = [];
    for (const x of r.semantics?.generators || []) {
      const a = bt[x.plugin];
      a && this.generated.push(a.build(n, x.params, { palette: this.palette }));
    }
    this.index = mt(r.semantics?.tree), this.cameras = new Map((r.semantics?.cameras || []).map((x) => [x.id, x])), this.materials = /* @__PURE__ */ new Map(), n.traverse((x) => {
      x.isMesh && (Array.isArray(x.material) ? x.material : [x.material]).forEach((a) => {
        a && a.name && !this.materials.has(a.name) && this.materials.set(a.name, a);
      });
    }), this._materialBase = new Map([...this.materials].map(([x, a]) => [x, { color: a.color && a.color.clone(), emissiveIntensity: a.emissiveIntensity, roughness: a.roughness }])), this.sets = /* @__PURE__ */ new Map();
    for (const [x, a] of Object.entries(r.semantics?.instanceSets || {}))
      this.sets.set(x, { name: x, parent: a.parent, ids: a.ids, index: new Map(a.ids.map((t, l) => [t, l])), meshes: [], base: /* @__PURE__ */ new Map() });
    n.traverse((x) => {
      if (!x.isInstancedMesh) return;
      const a = w0(x), t = a && a[0] === "@" ? this.sets.get(a.slice(1)) : null;
      t && (x.userData.instanceSet = t.name, t.meshes.push(x), t.base.set(x, x.instanceMatrix.array.slice()));
    }), this.pickable = [], n.traverse((x) => {
      if (!x.isMesh) return;
      const a = x.userData.instanceSet && this.sets.get(x.userData.instanceSet), t = this.index.get(a ? a.parent : w0(x));
      t && t.pickable !== !1 && this.pickable.push(x);
    }), this.layerDefs = r.semantics?.layers || [], this.layerState = Object.fromEntries(this.layerDefs.map((x) => [x.id, x.default !== !1])), this.modes = r.semantics?.modes || [], this.modeId = this.modes[0]?.id || null;
    for (const x of r.semantics?.behaviors || []) {
      const a = Dt[x.plugin];
      a && this.behaviors.push(a.create(this, x, x.params));
    }
    this.overlay = new k.Group(), this.overlay.name = "highlight-overlay", this.scene.add(this.overlay), this._layerCover = /* @__PURE__ */ new Map();
    for (const x of this.layerDefs) for (const a of x.targets || []) for (const t of this._targets(a))
      t.instance === void 0 && (this._layerCover.has(t.mesh) || this._layerCover.set(t.mesh, /* @__PURE__ */ new Set()), this._layerCover.get(t.mesh).add(x.id));
    this._applyLayers(), this._onDown = (x) => {
      this._down = [x.clientX, x.clientY], this.fly = null;
    }, this._onUp = (x) => this._click(x), i.domElement.addEventListener("pointerdown", this._onDown), i.domElement.addEventListener("pointerup", this._onUp), this._resize = () => {
      const x = this.container.clientWidth, a = Math.max(1, this.container.clientHeight);
      i.setSize(x, a), this.camera.aspect = x / a, this.camera.updateProjectionMatrix();
    }, this._observer = new ResizeObserver(this._resize), this._observer.observe(this.container), this._resize();
    const d = r.home || this.cameras.get("home");
    return this.home = { position: new k.Vector3(...d.position), target: new k.Vector3(...d.target) }, this.camera.position.copy(this.home.position), c.target.copy(this.home.target), c.update(), this.environment(), this._animate = this._animate.bind(this), this._frame = requestAnimationFrame(this._animate), this._snapshotTimer = setTimeout(() => this.snapshots(), 500), this;
  }
  can(n) {
    return this.supports.has(n);
  }
  // ---------------- 环境 ----------------
  _pick(n, r) {
    return this.palette[n] === void 0 ? r : this.palette[n];
  }
  environment(n = "sunny", r = 14) {
    this.hour = r, this.weather = n;
    const e = r < 6 || r > 19, i = this.cfg.sky;
    this.scene.background = new k.Color(this.studioOn ? this._pick("studioSky", i.studio) : e ? this._pick("skyNight", i.night) : n === "sunny" ? this._pick("skyDay", i.day) : i.overcast), this.scene.fog = new k.FogExp2(this.scene.background, n === "fog" ? this.cfg.fog.fog : this.cfg.fog.normal);
    const c = this.cfg.lights;
    this.sun.intensity = e ? c.sun[2] : n === "sunny" ? c.sun[0] : c.sun[1], this.ambient.intensity = e ? c.ambient[1] : c.ambient[0], this.sun.position.set(Math.cos(r / 24 * Math.PI * 2) * 160, 80 + Math.sin(r / 24 * Math.PI) * 120, 100), this._applyMaterialStates({ night: e, weather: n, studio: this.studioOn }), this._themeMaterials && this._themeMaterials();
    for (const A of this.behaviors) A.environment && A.environment({ weather: n, hour: r, night: e });
    return !0;
  }
  _applyMaterialStates(n) {
    const r = this.model.semantics?.materialStates || {};
    for (const [e, i] of Object.entries(r)) {
      const c = this.materials.get(e);
      if (!c) continue;
      const A = this._materialBase.get(e), d = (x) => {
        for (const [a, t] of Object.entries(x || {}))
          a === "color" ? c.color.set(this._pick(t, 16777215)).convertSRGBToLinear() : c[a] = t;
      };
      i.studio && A.color && c.color.copy(A.color), d(i.default), n.night && d(i.night), n.weather === "rain" && d(i.rain), n.weather === "snow" && d(i.snow), n.weather === "fog" && d(i.fog), n.studio && d(i.studio);
    }
  }
  /** 主题（皮肤）：名字（内置，见 themes/）或主题对象；null = 恢复模型原样。返回生效的主题。见 docs/THEME.md */
  theme(n) {
    return n === void 0 ? this._theme || null : Ct(this, n);
  }
  studio(n) {
    return this.studioOn = !!n, this.environment(this.weather, this.hour), !0;
  }
  // ---------------- 相机 ----------------
  _flyTo(n) {
    this.controls.autoRotate = !1, this.fly = { position: new k.Vector3(...n.position), target: new k.Vector3(...n.target) };
  }
  focus(n) {
    const r = this._focusMode(n);
    r && r !== this.modeId && this.mode(r, { keepCamera: !0 });
    const e = this.cameras.get("focus:" + n) || this._autoFrame(n);
    return e ? (this._flyTo(e), this.index.get(n)?.type === "device" && this.highlight([n]), this.opts.emitSelect && this.emit("select", this._selectPayload(n)), !0) : !1;
  }
  /** 语义节点（或其祖先）上的 focusMode：聚焦前先切到该模式（例如库内设备先去顶） */
  _focusMode(n) {
    return this._inherit(n, "focusMode");
  }
  /** 沿语义树向上找第一个设置了 key 的节点 */
  _inherit(n, r) {
    for (let e = n; e; e = this.index.get(e)?.parent) {
      const i = this.index.get(e);
      if (i && i[r] !== void 0) return i[r];
    }
  }
  /** 没有命名机位时按包围盒取景：沿当前视线方向后退，保证俯角 */
  _autoFrame(n) {
    const r = this.boundsOf(n);
    if (!r) return null;
    let e = r.getCenter(new k.Vector3()), i = r.getSize(new k.Vector3()).length();
    const c = this._inherit(n, "focusDistance");
    if (c) {
      const t = this.boundsOf(n, { first: !0 });
      t && (e = t.getCenter(new k.Vector3()));
    }
    let A = this.camera.position.clone().sub(this.controls.target);
    const d = this._inherit(n, "focusFrom"), x = d && this._targets(n).find((t) => t.instance !== void 0);
    if (x) {
      const t = new k.Matrix4();
      x.mesh.getMatrixAt(x.instance, t), t.premultiply(x.mesh.matrixWorld), A = new k.Vector3().setFromMatrixColumn(t, d === "z" ? 2 : 0), A.y = 0;
    }
    A.lengthSq() < 1e-6 && A.set(1, 1, 1), A.normalize(), A.y < 0.45 && (A.y = 0.45, A.normalize());
    const a = Math.max(c || i * 1.6 + 2.2, (this.controls.minDistance || 0) * 1.05);
    return { position: e.clone().addScaledVector(A, a).toArray(), target: e.toArray() };
  }
  /** 语义 id（楼、分组、单台设备）的世界包围盒 */
  boundsOf(n, { first: r = !1 } = {}) {
    const e = new k.Box3(), i = new k.Box3(), c = new k.Matrix4();
    let A = !1;
    const d = this._targets(n).filter((x) => x.mesh.visible);
    for (const x of r ? d.slice(0, 1) : d) {
      const a = x.mesh.geometry;
      a.boundingBox || a.computeBoundingBox(), x.mesh.updateMatrixWorld(), x.instance !== void 0 ? (x.mesh.getMatrixAt(x.instance, c), i.copy(a.boundingBox).applyMatrix4(c).applyMatrix4(x.mesh.matrixWorld)) : x.mesh.isInstancedMesh ? (x.mesh.boundingBox || x.mesh.computeBoundingBox(), i.copy(x.mesh.boundingBox).applyMatrix4(x.mesh.matrixWorld)) : i.copy(a.boundingBox).applyMatrix4(x.mesh.matrixWorld), e.union(i), A = !0;
    }
    return A ? e : null;
  }
  /** 一个语义 id 覆盖的渲染对象：普通网格整件；实例集整件（分组）或单个实例（单台设备） */
  _targets(n) {
    const r = [];
    return this.root.traverse((e) => {
      if (!e.isMesh) return;
      const i = e.userData.instanceSet && this.sets.get(e.userData.instanceSet);
      if (i)
        if (We(this.index, i.parent, n)) r.push({ mesh: e });
        else {
          const c = i.index.get(n);
          c !== void 0 && r.push({ mesh: e, instance: c });
        }
      else We(this.index, w0(e), n) && r.push({ mesh: e });
    }), r;
  }
  _selectPayload(n) {
    const r = this.index.get(n);
    return r ? { id: n, type: r.type, name: r.name, ...r.props || {} } : { id: n };
  }
  reset() {
    return this.fly = { position: this.home.position.clone(), target: this.home.target.clone() }, this.controls.autoRotate = !1, !0;
  }
  top() {
    const n = this.cameras.get("top");
    return n ? (this.controls.autoRotate = !1, this.fly = { position: new k.Vector3(...n.position), target: this.home.target.clone() }, !0) : !1;
  }
  orbit(n) {
    return this.controls.autoRotate = n, this.fly = null, !0;
  }
  pause(n) {
    return this.paused = n, this._frames = 0, this._statsAt = performance.now(), !0;
  }
  /** 不带参数：读当前机位；带参数：平滑飞过去（演示模式每页的视角） */
  view(n) {
    if (!n) return { camera: this.camera.position.toArray(), target: this.controls.target.toArray() };
    const r = n.position, e = n.target;
    !Array.isArray(r) || r.length < 3 || (this.controls.autoRotate = !1, this.fly = { position: new k.Vector3(r[0], r[1], r[2]), target: Array.isArray(e) && e.length >= 3 ? new k.Vector3(e[0], e[1], e[2]) : this.controls.target.clone() });
  }
  snapshots() {
    const n = [...this.cameras.values()].filter((c) => c.id.startsWith("snapshot-"));
    if (!n.length) return !1;
    const r = this.camera.position.clone(), e = [], i = this.renderer;
    if (!i.domElement.width || !i.domElement.height)
      return (this._snapshotTries = (this._snapshotTries || 0) + 1) <= 20 && !this.disposed && (this._snapshotTimer = setTimeout(() => this.snapshots(), 500)), !1;
    for (const c of n) {
      this.camera.position.set(...c.position), this.camera.lookAt(...c.target), i.render(this.scene, this.camera);
      const A = document.createElement("canvas");
      A.width = 480, A.height = 270, A.getContext("2d").drawImage(i.domElement, 0, 0, 480, 270), e.push(A.toDataURL("image/jpeg", 0.82));
    }
    return this.camera.position.copy(r), this.camera.lookAt(this.controls.target), i.render(this.scene, this.camera), this.emit("snapshots", e), !0;
  }
  // ---------------- 拾取 / 高亮 / 显隐 ----------------
  pickAt(n, r) {
    const e = this.renderer.domElement.getBoundingClientRect(), i = new k.Raycaster();
    i.setFromCamera(new k.Vector2((n - e.left) / e.width * 2 - 1, -(r - e.top) / e.height * 2 + 1), this.camera);
    const c = i.intersectObjects(this.pickable.filter((x) => x.visible))[0];
    if (!c) return null;
    const A = c.object.userData.instanceSet && this.sets.get(c.object.userData.instanceSet);
    return { id: A && c.instanceId !== void 0 ? A.ids[c.instanceId] : w0(c.object), point: c.point.toArray(), object: c.object, instanceId: c.instanceId };
  }
  _click(n) {
    if (!this._down || Math.hypot(n.clientX - this._down[0], n.clientY - this._down[1]) > 5) return;
    const r = this.pickAt(n.clientX, n.clientY);
    r && this.focus(r.id);
  }
  /** 覆盖层高亮（不替换原材质）。ids 为空数组时清除 */
  highlight(n = [], r = {}) {
    if (this.overlay.children.slice().forEach((A) => this.overlay.remove(A)), !n.length) return !0;
    const e = new k.MeshBasicMaterial({ color: r.color || 16738816, transparent: !0, opacity: r.opacity ?? 0.35, polygonOffset: !0, polygonOffsetFactor: -1, depthWrite: !1 }), i = new k.Matrix4(), c = /* @__PURE__ */ new Set();
    for (const A of n) for (const d of this._targets(A)) {
      const x = d.mesh;
      if (!x.visible) continue;
      const a = x.uuid + ":" + (d.instance ?? "*");
      if (c.has(a)) continue;
      c.add(a), x.updateMatrixWorld();
      let t;
      d.instance !== void 0 ? (t = new k.Mesh(x.geometry, e), x.getMatrixAt(d.instance, i), t.matrix.multiplyMatrices(x.matrixWorld, i)) : x.isInstancedMesh ? (t = new k.InstancedMesh(x.geometry, e, x.count), t.instanceMatrix = x.instanceMatrix, t.matrix.copy(x.matrixWorld), t.frustumCulled = !1) : (t = new k.Mesh(x.geometry, e), t.matrix.copy(x.matrixWorld)), t.matrixAutoUpdate = !1, t.renderOrder = 10, this.overlay.add(t);
    }
    return this.overlay.children.length > 0;
  }
  setVisible(n, r) {
    let e = 0;
    const i = new k.Matrix4().makeScale(0, 0, 0);
    for (const c of this._targets(n)) {
      if (e++, c.instance === void 0) {
        c.mesh.visible = r;
        continue;
      }
      const A = this.sets.get(c.mesh.userData.instanceSet).base.get(c.mesh);
      r ? c.mesh.setMatrixAt(c.instance, new k.Matrix4().fromArray(A, c.instance * 16)) : c.mesh.setMatrixAt(c.instance, i), c.mesh.instanceMatrix.needsUpdate = !0, c.mesh.boundingSphere = null, c.mesh.boundingBox = null;
    }
    return e > 0;
  }
  /** 图层：不带参数读全部开关；带参数设置一个 */
  layer(n, r) {
    return n !== void 0 && typeof r == "boolean" && n in this.layerState && (this.layerState[n] = r, this._applyLayers(), this.emit("layers", { ...this.layerState })), { ...this.layerState };
  }
  _applyLayers() {
    for (const [n, r] of this._layerCover) n.visible = [...r].every((e) => this.layerState[e]);
  }
  /** 模式：不带参数读当前模式；带参数切换（图层组合 + 机位） */
  mode(n, { keepCamera: r = !1 } = {}) {
    if (n === void 0) return this.modeId;
    const e = this.modes.find((i) => i.id === n);
    if (!e) return this.modeId;
    this.modeId = n;
    for (const [i, c] of Object.entries(e.layers || {})) i in this.layerState && (this.layerState[i] = c);
    if (this._applyLayers(), this.emit("layers", { ...this.layerState }), !r && e.camera) {
      const i = e.camera === "home" ? { position: this.home.position.toArray(), target: this.home.target.toArray() } : this.cameras.get(e.camera);
      i && this._flyTo(i);
    }
    return this.emit("mode", n), n;
  }
  // ---------------- 循环 ----------------
  _animate(n) {
    if (this.disposed) return;
    this._frame = requestAnimationFrame(this._animate);
    const r = Math.min((n - this._last) / 1e3, 0.05);
    if (this._last = n, !this.paused) {
      this.fly && (this.camera.position.lerp(this.fly.position, 0.05), this.controls.target.lerp(this.fly.target, 0.05), this.camera.position.distanceTo(this.fly.position) < 0.1 && (this.fly = null));
      for (const e of this.behaviors) e.update && e.update(r);
      this.controls.update(), this.renderer.render(this.scene, this.camera), n - this._labelsAt > 60 && (this._labelsAt = n, this.emit("labels", this.labels())), this._frames++, n - this._statsAt > 1200 && (this.emit("stats", Math.round(this._frames * 1e3 / (n - this._statsAt))), this._frames = 0, this._statsAt = n);
    }
  }
  /** 锚点投影到屏幕：[{ id, x, y, visible }]，id 为锚点指向的语义 id（与现有 onLabels 一致） */
  labels() {
    const n = this.container.clientWidth, r = this.container.clientHeight;
    return (this.model.semantics?.anchors || []).map((e) => {
      const i = new k.Vector3(...e.position).project(this.camera), c = !e.layer || this.layerState[e.layer] !== !1, A = { id: e.target, x: (i.x * 0.5 + 0.5) * n, y: (-i.y * 0.5 + 0.5) * r, visible: c && i.z > -1 && i.z < 1 };
      for (const d of ["text", "kind", "icon", "color"]) e[d] !== void 0 && (A[d] = e[d]);
      return A;
    });
  }
  /** 挂一个跟 Viewer 一起释放的东西（例：loadMap 建的 Draco 解码器 —— 它背后有 Worker 和 WASM 实例） */
  addDisposable(n) {
    return n && typeof n.dispose == "function" && this._disposables.push(n), n;
  }
  dispose() {
    this.disposed = !0, cancelAnimationFrame(this._frame), clearTimeout(this._snapshotTimer);
    for (const e of this._disposables.splice(0))
      try {
        e.dispose();
      } catch {
      }
    this._observer && this._observer.disconnect(), this.controls && this.controls.dispose();
    const n = this.renderer.domElement;
    n.removeEventListener("pointerdown", this._onDown), n.removeEventListener("pointerup", this._onUp), this.behaviors.forEach((e) => e.dispose && e.dispose());
    const r = /* @__PURE__ */ new Set();
    this.scene.traverse((e) => {
      e.geometry && r.add(e.geometry), e.material && (Array.isArray(e.material) ? e.material : [e.material]).forEach((i) => {
        r.add(i);
        for (const c of Object.values(i)) c && c.isTexture && r.add(c);
      });
    }), r.forEach((e) => e.dispose && e.dispose()), this.presets.dispose(), this.renderer.dispose(), n.remove();
  }
}
for (const o of St) o in Le.prototype || (Le.prototype[o] = function() {
  return !1;
});
var J = Uint8Array, B0 = Uint16Array, Rt = Int32Array, Dr = new J([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), yr = new J([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), zt = new J([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), br = function(o, n) {
  for (var r = new B0(31), e = 0; e < 31; ++e)
    r[e] = n += 1 << o[e - 1];
  for (var i = new Rt(r[30]), e = 1; e < 30; ++e)
    for (var c = r[e]; c < r[e + 1]; ++c)
      i[c] = c - r[e] << 5 | e;
  return { b: r, r: i };
}, _r = br(Dr, 2), wr = _r.b, Ht = _r.r;
wr[28] = 258, Ht[258] = 28;
var Pt = br(yr, 0), Ot = Pt.b, Ce = new B0(32768);
for (var V = 0; V < 32768; ++V) {
  var f0 = (V & 43690) >> 1 | (V & 21845) << 1;
  f0 = (f0 & 52428) >> 2 | (f0 & 13107) << 2, f0 = (f0 & 61680) >> 4 | (f0 & 3855) << 4, Ce[V] = ((f0 & 65280) >> 8 | (f0 & 255) << 8) >> 1;
}
var F0 = (function(o, n, r) {
  for (var e = o.length, i = 0, c = new B0(n); i < e; ++i)
    o[i] && ++c[o[i] - 1];
  var A = new B0(n);
  for (i = 1; i < n; ++i)
    A[i] = A[i - 1] + c[i - 1] << 1;
  var d;
  if (r) {
    d = new B0(1 << n);
    var x = 15 - n;
    for (i = 0; i < e; ++i)
      if (o[i])
        for (var a = i << 4 | o[i], t = n - o[i], l = A[o[i] - 1]++ << t, s = l | (1 << t) - 1; l <= s; ++l)
          d[Ce[l] >> x] = a;
  } else
    for (d = new B0(e), i = 0; i < e; ++i)
      o[i] && (d[i] = Ce[A[o[i] - 1]++] >> 15 - o[i]);
  return d;
}), D0 = new J(288);
for (var V = 0; V < 144; ++V)
  D0[V] = 8;
for (var V = 144; V < 256; ++V)
  D0[V] = 9;
for (var V = 256; V < 280; ++V)
  D0[V] = 7;
for (var V = 280; V < 288; ++V)
  D0[V] = 8;
var kr = new J(32);
for (var V = 0; V < 32; ++V)
  kr[V] = 5;
var Wt = /* @__PURE__ */ F0(D0, 9, 1), Tt = /* @__PURE__ */ F0(kr, 5, 1), ue = function(o) {
  for (var n = o[0], r = 1; r < o.length; ++r)
    o[r] > n && (n = o[r]);
  return n;
}, a0 = function(o, n, r) {
  var e = n / 8 | 0;
  return (o[e] | o[e + 1] << 8) >> (n & 7) & r;
}, de = function(o, n) {
  var r = n / 8 | 0;
  return (o[r] | o[r + 1] << 8 | o[r + 2] << 16) >> (n & 7);
}, qt = function(o) {
  return (o + 7) / 8 | 0;
}, ge = function(o, n, r) {
  return (n == null || n < 0) && (n = 0), (r == null || r > o.length) && (r = o.length), new J(o.subarray(n, r));
}, It = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], Q = function(o, n, r) {
  var e = new Error(n || It[o]);
  if (e.code = o, Error.captureStackTrace && Error.captureStackTrace(e, Q), !r)
    throw e;
  return e;
}, Lt = function(o, n, r, e) {
  var i = o.length, c = e ? e.length : 0;
  if (!i || n.f && !n.l)
    return r || new J(0);
  var A = !r, d = A || n.i != 2, x = n.i;
  A && (r = new J(i * 3));
  var a = function(d0) {
    var s0 = r.length;
    if (d0 > s0) {
      var K = new J(Math.max(s0 * 2, d0));
      K.set(r), r = K;
    }
  }, t = n.f || 0, l = n.p || 0, s = n.b || 0, h = n.l, p = n.d, C = n.m, v = n.n, g = i * 8;
  do {
    if (!h) {
      t = a0(o, l, 1);
      var f = a0(o, l + 1, 3);
      if (l += 3, f)
        if (f == 1)
          h = Wt, p = Tt, C = 9, v = 5;
        else if (f == 2) {
          var E = a0(o, l, 31) + 257, y = a0(o, l + 10, 15) + 4, b = E + a0(o, l + 5, 31) + 1;
          l += 14;
          for (var S = new J(b), F = new J(19), D = 0; D < y; ++D)
            F[zt[D]] = a0(o, l + D * 3, 7);
          l += y * 3;
          for (var _ = ue(F), w = (1 << _) - 1, P = F0(F, _, 1), D = 0; D < b; ) {
            var O = P[a0(o, l, w)];
            l += O & 15;
            var u = O >> 4;
            if (u < 16)
              S[D++] = u;
            else {
              var W = 0, T = 0;
              for (u == 16 ? (T = 3 + a0(o, l, 3), l += 2, W = S[D - 1]) : u == 17 ? (T = 3 + a0(o, l, 7), l += 3) : u == 18 && (T = 11 + a0(o, l, 127), l += 7); T--; )
                S[D++] = W;
            }
          }
          var G = S.subarray(0, E), I = S.subarray(E);
          C = ue(G), v = ue(I), h = F0(G, C, 1), p = F0(I, v, 1);
        } else
          Q(1);
      else {
        var u = qt(l) + 4, B = o[u - 4] | o[u - 3] << 8, m = u + B;
        if (m > i) {
          x && Q(0);
          break;
        }
        d && a(s + B), r.set(o.subarray(u, m), s), n.b = s += B, n.p = l = m * 8, n.f = t;
        continue;
      }
      if (l > g) {
        x && Q(0);
        break;
      }
    }
    d && a(s + 131072);
    for (var U = (1 << C) - 1, M = (1 << v) - 1, z = l; ; z = l) {
      var W = h[de(o, l) & U], H = W >> 4;
      if (l += W & 15, l > g) {
        x && Q(0);
        break;
      }
      if (W || Q(2), H < 256)
        r[s++] = H;
      else if (H == 256) {
        z = l, h = null;
        break;
      } else {
        var R = H - 254;
        if (H > 264) {
          var D = H - 257, $ = Dr[D];
          R = a0(o, l, (1 << $) - 1) + wr[D], l += $;
        }
        var N = p[de(o, l) & M], X = N >> 4;
        N || Q(3), l += N & 15;
        var I = Ot[X];
        if (X > 3) {
          var $ = yr[X];
          I += de(o, l) & (1 << $) - 1, l += $;
        }
        if (l > g) {
          x && Q(0);
          break;
        }
        d && a(s + 131072);
        var q = s + R;
        if (s < I) {
          var o0 = c - I, i0 = Math.min(I, q);
          for (o0 + s < 0 && Q(3); s < i0; ++s)
            r[s] = e[o0 + s];
        }
        for (; s < q; ++s)
          r[s] = r[s - I];
      }
    }
    n.l = h, n.p = z, n.b = s, n.f = t, h && (t = 1, n.m = C, n.d = p, n.n = v);
  } while (!t);
  return s != r.length && A ? ge(r, 0, s) : r.subarray(0, s);
}, Gt = /* @__PURE__ */ new J(0), n0 = function(o, n) {
  return o[n] | o[n + 1] << 8;
}, r0 = function(o, n) {
  return (o[n] | o[n + 1] << 8 | o[n + 2] << 16 | o[n + 3] << 24) >>> 0;
}, ve = function(o, n) {
  return r0(o, n) + r0(o, n + 4) * 4294967296;
};
function Ut(o, n) {
  return Lt(o, { i: 2 }, n && n.out, n && n.dictionary);
}
var me = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), $t = 0;
try {
  me.decode(Gt, { stream: !0 }), $t = 1;
} catch {
}
var Nt = function(o) {
  for (var n = "", r = 0; ; ) {
    var e = o[r++], i = (e > 127) + (e > 223) + (e > 239);
    if (r + i > o.length)
      return { s: n, r: ge(o, r - 1) };
    i ? i == 3 ? (e = ((e & 15) << 18 | (o[r++] & 63) << 12 | (o[r++] & 63) << 6 | o[r++] & 63) - 65536, n += String.fromCharCode(55296 | e >> 10, 56320 | e & 1023)) : i & 1 ? n += String.fromCharCode((e & 31) << 6 | o[r++] & 63) : n += String.fromCharCode((e & 15) << 12 | (o[r++] & 63) << 6 | o[r++] & 63) : n += String.fromCharCode(e);
  }
};
function Ae(o, n) {
  if (n) {
    for (var r = "", e = 0; e < o.length; e += 16384)
      r += String.fromCharCode.apply(null, o.subarray(e, e + 16384));
    return r;
  } else {
    if (me)
      return me.decode(o);
    var i = Nt(o), c = i.s, r = i.r;
    return r.length && Q(8), c;
  }
}
var Vt = function(o, n) {
  return n + 30 + n0(o, n + 26) + n0(o, n + 28);
}, Xt = function(o, n, r) {
  var e = n0(o, n + 28), i = n0(o, n + 30), c = Ae(o.subarray(n + 46, n + 46 + e), !(n0(o, n + 8) & 2048)), A = n + 46 + e, d = jt(o, A, i, r, r0(o, n + 20), r0(o, n + 24), r0(o, n + 42)), x = d[0], a = d[1], t = d[2];
  return [n0(o, n + 10), x, a, c, A + i + n0(o, n + 32), t];
}, jt = function(o, n, r, e, i, c, A) {
  var d = i == 4294967295, x = c == 4294967295, a = A == 4294967295, t = n + r, l = d + x + a;
  if (e && l) {
    for (; n + 4 < t; n += 4 + n0(o, n + 2))
      if (n0(o, n) == 1)
        return [
          d ? ve(o, n + 4 + 8 * x) : i,
          x ? ve(o, n + 4) : c,
          a ? ve(o, n + 4 + 8 * (x + d)) : A,
          1
        ];
    e < 2 && Q(13);
  }
  return [i, c, A, 0];
};
function Kt(o, n) {
  for (var r = {}, e = o.length - 22; r0(o, e) != 101010256; --e)
    (!e || o.length - e > 65558) && Q(13);
  var i = n0(o, e + 8);
  if (!i)
    return {};
  var c = r0(o, e + 16), A = r0(o, e - 20) == 117853008;
  if (A) {
    var d = r0(o, e - 12);
    A = r0(o, d) == 101075792, A && (i = r0(o, d + 32), c = r0(o, d + 48));
  }
  for (var x = 0; x < i; ++x) {
    var a = Xt(o, c, A), t = a[0], l = a[1], s = a[2], h = a[3], p = a[4], C = a[5], v = Vt(o, C);
    c = p, t ? t == 8 ? r[h] = Ut(o.subarray(v, v + l), { out: new J(s) }) : Q(14, "unknown compression type " + t) : r[h] = ge(o, v, v + l);
  }
  return r;
}
var pe = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Yt(o) {
  return o && o.__esModule && Object.prototype.hasOwnProperty.call(o, "default") ? o.default : o;
}
function Zt(o) {
  if (Object.prototype.hasOwnProperty.call(o, "__esModule")) return o;
  var n = o.default;
  if (typeof n == "function") {
    var r = function e() {
      return this instanceof e ? Reflect.construct(n, arguments, this.constructor) : n.apply(this, arguments);
    };
    r.prototype = n.prototype;
  } else r = {};
  return Object.defineProperty(r, "__esModule", { value: !0 }), Object.keys(o).forEach(function(e) {
    var i = Object.getOwnPropertyDescriptor(o, e);
    Object.defineProperty(r, e, i.get ? i : {
      enumerable: !0,
      get: function() {
        return o[e];
      }
    });
  }), r;
}
var k0 = { exports: {} };
function Qt(o) {
  throw new Error('Could not dynamically require "' + o + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var S0 = { exports: {} };
const Jt = {}, ea = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Jt
}, Symbol.toStringTag, { value: "Module" })), ra = /* @__PURE__ */ Zt(ea);
var ta = S0.exports, Ge;
function L() {
  return Ge || (Ge = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e();
    })(ta, function() {
      var r = r || (function(e, i) {
        var c;
        if (typeof window < "u" && window.crypto && (c = window.crypto), typeof self < "u" && self.crypto && (c = self.crypto), typeof globalThis < "u" && globalThis.crypto && (c = globalThis.crypto), !c && typeof window < "u" && window.msCrypto && (c = window.msCrypto), !c && typeof pe < "u" && pe.crypto && (c = pe.crypto), !c && typeof Qt == "function")
          try {
            c = ra;
          } catch {
          }
        var A = function() {
          if (c) {
            if (typeof c.getRandomValues == "function")
              try {
                return c.getRandomValues(new Uint32Array(1))[0];
              } catch {
              }
            if (typeof c.randomBytes == "function")
              try {
                return c.randomBytes(4).readInt32LE();
              } catch {
              }
          }
          throw new Error("Native crypto module could not be used to get secure random number.");
        }, d = Object.create || /* @__PURE__ */ (function() {
          function f() {
          }
          return function(u) {
            var B;
            return f.prototype = u, B = new f(), f.prototype = null, B;
          };
        })(), x = {}, a = x.lib = {}, t = a.Base = /* @__PURE__ */ (function() {
          return {
            /**
             * Creates a new object that inherits from this object.
             *
             * @param {Object} overrides Properties to copy into the new object.
             *
             * @return {Object} The new object.
             *
             * @static
             *
             * @example
             *
             *     var MyType = CryptoJS.lib.Base.extend({
             *         field: 'value',
             *
             *         method: function () {
             *         }
             *     });
             */
            extend: function(f) {
              var u = d(this);
              return f && u.mixIn(f), (!u.hasOwnProperty("init") || this.init === u.init) && (u.init = function() {
                u.$super.init.apply(this, arguments);
              }), u.init.prototype = u, u.$super = this, u;
            },
            /**
             * Extends this object and runs the init method.
             * Arguments to create() will be passed to init().
             *
             * @return {Object} The new object.
             *
             * @static
             *
             * @example
             *
             *     var instance = MyType.create();
             */
            create: function() {
              var f = this.extend();
              return f.init.apply(f, arguments), f;
            },
            /**
             * Initializes a newly created object.
             * Override this method to add some logic when your objects are created.
             *
             * @example
             *
             *     var MyType = CryptoJS.lib.Base.extend({
             *         init: function () {
             *             // ...
             *         }
             *     });
             */
            init: function() {
            },
            /**
             * Copies properties into this object.
             *
             * @param {Object} properties The properties to mix in.
             *
             * @example
             *
             *     MyType.mixIn({
             *         field: 'value'
             *     });
             */
            mixIn: function(f) {
              for (var u in f)
                f.hasOwnProperty(u) && (this[u] = f[u]);
              f.hasOwnProperty("toString") && (this.toString = f.toString);
            },
            /**
             * Creates a copy of this object.
             *
             * @return {Object} The clone.
             *
             * @example
             *
             *     var clone = instance.clone();
             */
            clone: function() {
              return this.init.prototype.extend(this);
            }
          };
        })(), l = a.WordArray = t.extend({
          /**
           * Initializes a newly created word array.
           *
           * @param {Array} words (Optional) An array of 32-bit words.
           * @param {number} sigBytes (Optional) The number of significant bytes in the words.
           *
           * @example
           *
           *     var wordArray = CryptoJS.lib.WordArray.create();
           *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);
           *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);
           */
          init: function(f, u) {
            f = this.words = f || [], u != i ? this.sigBytes = u : this.sigBytes = f.length * 4;
          },
          /**
           * Converts this word array to a string.
           *
           * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex
           *
           * @return {string} The stringified word array.
           *
           * @example
           *
           *     var string = wordArray + '';
           *     var string = wordArray.toString();
           *     var string = wordArray.toString(CryptoJS.enc.Utf8);
           */
          toString: function(f) {
            return (f || h).stringify(this);
          },
          /**
           * Concatenates a word array to this word array.
           *
           * @param {WordArray} wordArray The word array to append.
           *
           * @return {WordArray} This word array.
           *
           * @example
           *
           *     wordArray1.concat(wordArray2);
           */
          concat: function(f) {
            var u = this.words, B = f.words, m = this.sigBytes, E = f.sigBytes;
            if (this.clamp(), m % 4)
              for (var y = 0; y < E; y++) {
                var b = B[y >>> 2] >>> 24 - y % 4 * 8 & 255;
                u[m + y >>> 2] |= b << 24 - (m + y) % 4 * 8;
              }
            else
              for (var S = 0; S < E; S += 4)
                u[m + S >>> 2] = B[S >>> 2];
            return this.sigBytes += E, this;
          },
          /**
           * Removes insignificant bits.
           *
           * @example
           *
           *     wordArray.clamp();
           */
          clamp: function() {
            var f = this.words, u = this.sigBytes;
            f[u >>> 2] &= 4294967295 << 32 - u % 4 * 8, f.length = e.ceil(u / 4);
          },
          /**
           * Creates a copy of this word array.
           *
           * @return {WordArray} The clone.
           *
           * @example
           *
           *     var clone = wordArray.clone();
           */
          clone: function() {
            var f = t.clone.call(this);
            return f.words = this.words.slice(0), f;
          },
          /**
           * Creates a word array filled with random bytes.
           *
           * @param {number} nBytes The number of random bytes to generate.
           *
           * @return {WordArray} The random word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.lib.WordArray.random(16);
           */
          random: function(f) {
            for (var u = [], B = 0; B < f; B += 4)
              u.push(A());
            return new l.init(u, f);
          }
        }), s = x.enc = {}, h = s.Hex = {
          /**
           * Converts a word array to a hex string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The hex string.
           *
           * @static
           *
           * @example
           *
           *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);
           */
          stringify: function(f) {
            for (var u = f.words, B = f.sigBytes, m = [], E = 0; E < B; E++) {
              var y = u[E >>> 2] >>> 24 - E % 4 * 8 & 255;
              m.push((y >>> 4).toString(16)), m.push((y & 15).toString(16));
            }
            return m.join("");
          },
          /**
           * Converts a hex string to a word array.
           *
           * @param {string} hexStr The hex string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Hex.parse(hexString);
           */
          parse: function(f) {
            for (var u = f.length, B = [], m = 0; m < u; m += 2)
              B[m >>> 3] |= parseInt(f.substr(m, 2), 16) << 24 - m % 8 * 4;
            return new l.init(B, u / 2);
          }
        }, p = s.Latin1 = {
          /**
           * Converts a word array to a Latin1 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The Latin1 string.
           *
           * @static
           *
           * @example
           *
           *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);
           */
          stringify: function(f) {
            for (var u = f.words, B = f.sigBytes, m = [], E = 0; E < B; E++) {
              var y = u[E >>> 2] >>> 24 - E % 4 * 8 & 255;
              m.push(String.fromCharCode(y));
            }
            return m.join("");
          },
          /**
           * Converts a Latin1 string to a word array.
           *
           * @param {string} latin1Str The Latin1 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);
           */
          parse: function(f) {
            for (var u = f.length, B = [], m = 0; m < u; m++)
              B[m >>> 2] |= (f.charCodeAt(m) & 255) << 24 - m % 4 * 8;
            return new l.init(B, u);
          }
        }, C = s.Utf8 = {
          /**
           * Converts a word array to a UTF-8 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-8 string.
           *
           * @static
           *
           * @example
           *
           *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);
           */
          stringify: function(f) {
            try {
              return decodeURIComponent(escape(p.stringify(f)));
            } catch {
              throw new Error("Malformed UTF-8 data");
            }
          },
          /**
           * Converts a UTF-8 string to a word array.
           *
           * @param {string} utf8Str The UTF-8 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);
           */
          parse: function(f) {
            return p.parse(unescape(encodeURIComponent(f)));
          }
        }, v = a.BufferedBlockAlgorithm = t.extend({
          /**
           * Resets this block algorithm's data buffer to its initial state.
           *
           * @example
           *
           *     bufferedBlockAlgorithm.reset();
           */
          reset: function() {
            this._data = new l.init(), this._nDataBytes = 0;
          },
          /**
           * Adds new data to this block algorithm's buffer.
           *
           * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.
           *
           * @example
           *
           *     bufferedBlockAlgorithm._append('data');
           *     bufferedBlockAlgorithm._append(wordArray);
           */
          _append: function(f) {
            typeof f == "string" && (f = C.parse(f)), this._data.concat(f), this._nDataBytes += f.sigBytes;
          },
          /**
           * Processes available data blocks.
           *
           * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.
           *
           * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.
           *
           * @return {WordArray} The processed data.
           *
           * @example
           *
           *     var processedData = bufferedBlockAlgorithm._process();
           *     var processedData = bufferedBlockAlgorithm._process(!!'flush');
           */
          _process: function(f) {
            var u, B = this._data, m = B.words, E = B.sigBytes, y = this.blockSize, b = y * 4, S = E / b;
            f ? S = e.ceil(S) : S = e.max((S | 0) - this._minBufferSize, 0);
            var F = S * y, D = e.min(F * 4, E);
            if (F) {
              for (var _ = 0; _ < F; _ += y)
                this._doProcessBlock(m, _);
              u = m.splice(0, F), B.sigBytes -= D;
            }
            return new l.init(u, D);
          },
          /**
           * Creates a copy of this object.
           *
           * @return {Object} The clone.
           *
           * @example
           *
           *     var clone = bufferedBlockAlgorithm.clone();
           */
          clone: function() {
            var f = t.clone.call(this);
            return f._data = this._data.clone(), f;
          },
          _minBufferSize: 0
        });
        a.Hasher = v.extend({
          /**
           * Configuration options.
           */
          cfg: t.extend(),
          /**
           * Initializes a newly created hasher.
           *
           * @param {Object} cfg (Optional) The configuration options to use for this hash computation.
           *
           * @example
           *
           *     var hasher = CryptoJS.algo.SHA256.create();
           */
          init: function(f) {
            this.cfg = this.cfg.extend(f), this.reset();
          },
          /**
           * Resets this hasher to its initial state.
           *
           * @example
           *
           *     hasher.reset();
           */
          reset: function() {
            v.reset.call(this), this._doReset();
          },
          /**
           * Updates this hasher with a message.
           *
           * @param {WordArray|string} messageUpdate The message to append.
           *
           * @return {Hasher} This hasher.
           *
           * @example
           *
           *     hasher.update('message');
           *     hasher.update(wordArray);
           */
          update: function(f) {
            return this._append(f), this._process(), this;
          },
          /**
           * Finalizes the hash computation.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} messageUpdate (Optional) A final message update.
           *
           * @return {WordArray} The hash.
           *
           * @example
           *
           *     var hash = hasher.finalize();
           *     var hash = hasher.finalize('message');
           *     var hash = hasher.finalize(wordArray);
           */
          finalize: function(f) {
            f && this._append(f);
            var u = this._doFinalize();
            return u;
          },
          blockSize: 16,
          /**
           * Creates a shortcut function to a hasher's object interface.
           *
           * @param {Hasher} hasher The hasher to create a helper for.
           *
           * @return {Function} The shortcut function.
           *
           * @static
           *
           * @example
           *
           *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);
           */
          _createHelper: function(f) {
            return function(u, B) {
              return new f.init(B).finalize(u);
            };
          },
          /**
           * Creates a shortcut function to the HMAC's object interface.
           *
           * @param {Hasher} hasher The hasher to use in this HMAC helper.
           *
           * @return {Function} The shortcut function.
           *
           * @static
           *
           * @example
           *
           *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);
           */
          _createHmacHelper: function(f) {
            return function(u, B) {
              return new g.HMAC.init(f, B).finalize(u);
            };
          }
        });
        var g = x.algo = {};
        return x;
      })(Math);
      return r;
    });
  })(S0)), S0.exports;
}
var M0 = { exports: {} }, aa = M0.exports, Ue;
function le() {
  return Ue || (Ue = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(aa, function(r) {
      return (function(e) {
        var i = r, c = i.lib, A = c.Base, d = c.WordArray, x = i.x64 = {};
        x.Word = A.extend({
          /**
           * Initializes a newly created 64-bit word.
           *
           * @param {number} high The high 32 bits.
           * @param {number} low The low 32 bits.
           *
           * @example
           *
           *     var x64Word = CryptoJS.x64.Word.create(0x00010203, 0x04050607);
           */
          init: function(a, t) {
            this.high = a, this.low = t;
          }
          /**
           * Bitwise NOTs this word.
           *
           * @return {X64Word} A new x64-Word object after negating.
           *
           * @example
           *
           *     var negated = x64Word.not();
           */
          // not: function () {
          // var high = ~this.high;
          // var low = ~this.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise ANDs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to AND with this word.
           *
           * @return {X64Word} A new x64-Word object after ANDing.
           *
           * @example
           *
           *     var anded = x64Word.and(anotherX64Word);
           */
          // and: function (word) {
          // var high = this.high & word.high;
          // var low = this.low & word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise ORs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to OR with this word.
           *
           * @return {X64Word} A new x64-Word object after ORing.
           *
           * @example
           *
           *     var ored = x64Word.or(anotherX64Word);
           */
          // or: function (word) {
          // var high = this.high | word.high;
          // var low = this.low | word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise XORs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to XOR with this word.
           *
           * @return {X64Word} A new x64-Word object after XORing.
           *
           * @example
           *
           *     var xored = x64Word.xor(anotherX64Word);
           */
          // xor: function (word) {
          // var high = this.high ^ word.high;
          // var low = this.low ^ word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Shifts this word n bits to the left.
           *
           * @param {number} n The number of bits to shift.
           *
           * @return {X64Word} A new x64-Word object after shifting.
           *
           * @example
           *
           *     var shifted = x64Word.shiftL(25);
           */
          // shiftL: function (n) {
          // if (n < 32) {
          // var high = (this.high << n) | (this.low >>> (32 - n));
          // var low = this.low << n;
          // } else {
          // var high = this.low << (n - 32);
          // var low = 0;
          // }
          // return X64Word.create(high, low);
          // },
          /**
           * Shifts this word n bits to the right.
           *
           * @param {number} n The number of bits to shift.
           *
           * @return {X64Word} A new x64-Word object after shifting.
           *
           * @example
           *
           *     var shifted = x64Word.shiftR(7);
           */
          // shiftR: function (n) {
          // if (n < 32) {
          // var low = (this.low >>> n) | (this.high << (32 - n));
          // var high = this.high >>> n;
          // } else {
          // var low = this.high >>> (n - 32);
          // var high = 0;
          // }
          // return X64Word.create(high, low);
          // },
          /**
           * Rotates this word n bits to the left.
           *
           * @param {number} n The number of bits to rotate.
           *
           * @return {X64Word} A new x64-Word object after rotating.
           *
           * @example
           *
           *     var rotated = x64Word.rotL(25);
           */
          // rotL: function (n) {
          // return this.shiftL(n).or(this.shiftR(64 - n));
          // },
          /**
           * Rotates this word n bits to the right.
           *
           * @param {number} n The number of bits to rotate.
           *
           * @return {X64Word} A new x64-Word object after rotating.
           *
           * @example
           *
           *     var rotated = x64Word.rotR(7);
           */
          // rotR: function (n) {
          // return this.shiftR(n).or(this.shiftL(64 - n));
          // },
          /**
           * Adds this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to add with this word.
           *
           * @return {X64Word} A new x64-Word object after adding.
           *
           * @example
           *
           *     var added = x64Word.add(anotherX64Word);
           */
          // add: function (word) {
          // var low = (this.low + word.low) | 0;
          // var carry = (low >>> 0) < (this.low >>> 0) ? 1 : 0;
          // var high = (this.high + word.high + carry) | 0;
          // return X64Word.create(high, low);
          // }
        }), x.WordArray = A.extend({
          /**
           * Initializes a newly created word array.
           *
           * @param {Array} words (Optional) An array of CryptoJS.x64.Word objects.
           * @param {number} sigBytes (Optional) The number of significant bytes in the words.
           *
           * @example
           *
           *     var wordArray = CryptoJS.x64.WordArray.create();
           *
           *     var wordArray = CryptoJS.x64.WordArray.create([
           *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
           *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
           *     ]);
           *
           *     var wordArray = CryptoJS.x64.WordArray.create([
           *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
           *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
           *     ], 10);
           */
          init: function(a, t) {
            a = this.words = a || [], t != e ? this.sigBytes = t : this.sigBytes = a.length * 8;
          },
          /**
           * Converts this 64-bit word array to a 32-bit word array.
           *
           * @return {CryptoJS.lib.WordArray} This word array's data as a 32-bit word array.
           *
           * @example
           *
           *     var x32WordArray = x64WordArray.toX32();
           */
          toX32: function() {
            for (var a = this.words, t = a.length, l = [], s = 0; s < t; s++) {
              var h = a[s];
              l.push(h.high), l.push(h.low);
            }
            return d.create(l, this.sigBytes);
          },
          /**
           * Creates a copy of this word array.
           *
           * @return {X64WordArray} The clone.
           *
           * @example
           *
           *     var clone = x64WordArray.clone();
           */
          clone: function() {
            for (var a = A.clone.call(this), t = a.words = this.words.slice(0), l = t.length, s = 0; s < l; s++)
              t[s] = t[s].clone();
            return a;
          }
        });
      })(), r;
    });
  })(M0)), M0.exports;
}
var R0 = { exports: {} }, na = R0.exports, $e;
function oa() {
  return $e || ($e = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(na, function(r) {
      return (function() {
        if (typeof ArrayBuffer == "function") {
          var e = r, i = e.lib, c = i.WordArray, A = c.init, d = c.init = function(x) {
            if (x instanceof ArrayBuffer && (x = new Uint8Array(x)), (x instanceof Int8Array || typeof Uint8ClampedArray < "u" && x instanceof Uint8ClampedArray || x instanceof Int16Array || x instanceof Uint16Array || x instanceof Int32Array || x instanceof Uint32Array || x instanceof Float32Array || x instanceof Float64Array) && (x = new Uint8Array(x.buffer, x.byteOffset, x.byteLength)), x instanceof Uint8Array) {
              for (var a = x.byteLength, t = [], l = 0; l < a; l++)
                t[l >>> 2] |= x[l] << 24 - l % 4 * 8;
              A.call(this, t, a);
            } else
              A.apply(this, arguments);
          };
          d.prototype = c;
        }
      })(), r.lib.WordArray;
    });
  })(R0)), R0.exports;
}
var z0 = { exports: {} }, ia = z0.exports, Ne;
function sa() {
  return Ne || (Ne = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(ia, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.WordArray, A = e.enc;
        A.Utf16 = A.Utf16BE = {
          /**
           * Converts a word array to a UTF-16 BE string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-16 BE string.
           *
           * @static
           *
           * @example
           *
           *     var utf16String = CryptoJS.enc.Utf16.stringify(wordArray);
           */
          stringify: function(x) {
            for (var a = x.words, t = x.sigBytes, l = [], s = 0; s < t; s += 2) {
              var h = a[s >>> 2] >>> 16 - s % 4 * 8 & 65535;
              l.push(String.fromCharCode(h));
            }
            return l.join("");
          },
          /**
           * Converts a UTF-16 BE string to a word array.
           *
           * @param {string} utf16Str The UTF-16 BE string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf16.parse(utf16String);
           */
          parse: function(x) {
            for (var a = x.length, t = [], l = 0; l < a; l++)
              t[l >>> 1] |= x.charCodeAt(l) << 16 - l % 2 * 16;
            return c.create(t, a * 2);
          }
        }, A.Utf16LE = {
          /**
           * Converts a word array to a UTF-16 LE string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-16 LE string.
           *
           * @static
           *
           * @example
           *
           *     var utf16Str = CryptoJS.enc.Utf16LE.stringify(wordArray);
           */
          stringify: function(x) {
            for (var a = x.words, t = x.sigBytes, l = [], s = 0; s < t; s += 2) {
              var h = d(a[s >>> 2] >>> 16 - s % 4 * 8 & 65535);
              l.push(String.fromCharCode(h));
            }
            return l.join("");
          },
          /**
           * Converts a UTF-16 LE string to a word array.
           *
           * @param {string} utf16Str The UTF-16 LE string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf16LE.parse(utf16Str);
           */
          parse: function(x) {
            for (var a = x.length, t = [], l = 0; l < a; l++)
              t[l >>> 1] |= d(x.charCodeAt(l) << 16 - l % 2 * 16);
            return c.create(t, a * 2);
          }
        };
        function d(x) {
          return x << 8 & 4278255360 | x >>> 8 & 16711935;
        }
      })(), r.enc.Utf16;
    });
  })(z0)), z0.exports;
}
var H0 = { exports: {} }, xa = H0.exports, Ve;
function h0() {
  return Ve || (Ve = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(xa, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.WordArray, A = e.enc;
        A.Base64 = {
          /**
           * Converts a word array to a Base64 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The Base64 string.
           *
           * @static
           *
           * @example
           *
           *     var base64String = CryptoJS.enc.Base64.stringify(wordArray);
           */
          stringify: function(x) {
            var a = x.words, t = x.sigBytes, l = this._map;
            x.clamp();
            for (var s = [], h = 0; h < t; h += 3)
              for (var p = a[h >>> 2] >>> 24 - h % 4 * 8 & 255, C = a[h + 1 >>> 2] >>> 24 - (h + 1) % 4 * 8 & 255, v = a[h + 2 >>> 2] >>> 24 - (h + 2) % 4 * 8 & 255, g = p << 16 | C << 8 | v, f = 0; f < 4 && h + f * 0.75 < t; f++)
                s.push(l.charAt(g >>> 6 * (3 - f) & 63));
            var u = l.charAt(64);
            if (u)
              for (; s.length % 4; )
                s.push(u);
            return s.join("");
          },
          /**
           * Converts a Base64 string to a word array.
           *
           * @param {string} base64Str The Base64 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Base64.parse(base64String);
           */
          parse: function(x) {
            var a = x.length, t = this._map, l = this._reverseMap;
            if (!l) {
              l = this._reverseMap = [];
              for (var s = 0; s < t.length; s++)
                l[t.charCodeAt(s)] = s;
            }
            var h = t.charAt(64);
            if (h) {
              var p = x.indexOf(h);
              p !== -1 && (a = p);
            }
            return d(x, a, l);
          },
          _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
        };
        function d(x, a, t) {
          for (var l = [], s = 0, h = 0; h < a; h++)
            if (h % 4) {
              var p = t[x.charCodeAt(h - 1)] << h % 4 * 2, C = t[x.charCodeAt(h)] >>> 6 - h % 4 * 2, v = p | C;
              l[s >>> 2] |= v << 24 - s % 4 * 8, s++;
            }
          return c.create(l, s);
        }
      })(), r.enc.Base64;
    });
  })(H0)), H0.exports;
}
var P0 = { exports: {} }, ca = P0.exports, Xe;
function fa() {
  return Xe || (Xe = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(ca, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.WordArray, A = e.enc;
        A.Base64url = {
          /**
           * Converts a word array to a Base64url string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @param {boolean} urlSafe Whether to use url safe
           *
           * @return {string} The Base64url string.
           *
           * @static
           *
           * @example
           *
           *     var base64String = CryptoJS.enc.Base64url.stringify(wordArray);
           */
          stringify: function(x, a) {
            a === void 0 && (a = !0);
            var t = x.words, l = x.sigBytes, s = a ? this._safe_map : this._map;
            x.clamp();
            for (var h = [], p = 0; p < l; p += 3)
              for (var C = t[p >>> 2] >>> 24 - p % 4 * 8 & 255, v = t[p + 1 >>> 2] >>> 24 - (p + 1) % 4 * 8 & 255, g = t[p + 2 >>> 2] >>> 24 - (p + 2) % 4 * 8 & 255, f = C << 16 | v << 8 | g, u = 0; u < 4 && p + u * 0.75 < l; u++)
                h.push(s.charAt(f >>> 6 * (3 - u) & 63));
            var B = s.charAt(64);
            if (B)
              for (; h.length % 4; )
                h.push(B);
            return h.join("");
          },
          /**
           * Converts a Base64url string to a word array.
           *
           * @param {string} base64Str The Base64url string.
           *
           * @param {boolean} urlSafe Whether to use url safe
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Base64url.parse(base64String);
           */
          parse: function(x, a) {
            a === void 0 && (a = !0);
            var t = x.length, l = a ? this._safe_map : this._map, s = this._reverseMap;
            if (!s) {
              s = this._reverseMap = [];
              for (var h = 0; h < l.length; h++)
                s[l.charCodeAt(h)] = h;
            }
            var p = l.charAt(64);
            if (p) {
              var C = x.indexOf(p);
              C !== -1 && (t = C);
            }
            return d(x, t, s);
          },
          _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          _safe_map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        };
        function d(x, a, t) {
          for (var l = [], s = 0, h = 0; h < a; h++)
            if (h % 4) {
              var p = t[x.charCodeAt(h - 1)] << h % 4 * 2, C = t[x.charCodeAt(h)] >>> 6 - h % 4 * 2, v = p | C;
              l[s >>> 2] |= v << 24 - s % 4 * 8, s++;
            }
          return c.create(l, s);
        }
      })(), r.enc.Base64url;
    });
  })(P0)), P0.exports;
}
var O0 = { exports: {} }, la = O0.exports, je;
function u0() {
  return je || (je = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(la, function(r) {
      return (function(e) {
        var i = r, c = i.lib, A = c.WordArray, d = c.Hasher, x = i.algo, a = [];
        (function() {
          for (var C = 0; C < 64; C++)
            a[C] = e.abs(e.sin(C + 1)) * 4294967296 | 0;
        })();
        var t = x.MD5 = d.extend({
          _doReset: function() {
            this._hash = new A.init([
              1732584193,
              4023233417,
              2562383102,
              271733878
            ]);
          },
          _doProcessBlock: function(C, v) {
            for (var g = 0; g < 16; g++) {
              var f = v + g, u = C[f];
              C[f] = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360;
            }
            var B = this._hash.words, m = C[v + 0], E = C[v + 1], y = C[v + 2], b = C[v + 3], S = C[v + 4], F = C[v + 5], D = C[v + 6], _ = C[v + 7], w = C[v + 8], P = C[v + 9], O = C[v + 10], W = C[v + 11], T = C[v + 12], G = C[v + 13], I = C[v + 14], U = C[v + 15], M = B[0], z = B[1], H = B[2], R = B[3];
            M = l(M, z, H, R, m, 7, a[0]), R = l(R, M, z, H, E, 12, a[1]), H = l(H, R, M, z, y, 17, a[2]), z = l(z, H, R, M, b, 22, a[3]), M = l(M, z, H, R, S, 7, a[4]), R = l(R, M, z, H, F, 12, a[5]), H = l(H, R, M, z, D, 17, a[6]), z = l(z, H, R, M, _, 22, a[7]), M = l(M, z, H, R, w, 7, a[8]), R = l(R, M, z, H, P, 12, a[9]), H = l(H, R, M, z, O, 17, a[10]), z = l(z, H, R, M, W, 22, a[11]), M = l(M, z, H, R, T, 7, a[12]), R = l(R, M, z, H, G, 12, a[13]), H = l(H, R, M, z, I, 17, a[14]), z = l(z, H, R, M, U, 22, a[15]), M = s(M, z, H, R, E, 5, a[16]), R = s(R, M, z, H, D, 9, a[17]), H = s(H, R, M, z, W, 14, a[18]), z = s(z, H, R, M, m, 20, a[19]), M = s(M, z, H, R, F, 5, a[20]), R = s(R, M, z, H, O, 9, a[21]), H = s(H, R, M, z, U, 14, a[22]), z = s(z, H, R, M, S, 20, a[23]), M = s(M, z, H, R, P, 5, a[24]), R = s(R, M, z, H, I, 9, a[25]), H = s(H, R, M, z, b, 14, a[26]), z = s(z, H, R, M, w, 20, a[27]), M = s(M, z, H, R, G, 5, a[28]), R = s(R, M, z, H, y, 9, a[29]), H = s(H, R, M, z, _, 14, a[30]), z = s(z, H, R, M, T, 20, a[31]), M = h(M, z, H, R, F, 4, a[32]), R = h(R, M, z, H, w, 11, a[33]), H = h(H, R, M, z, W, 16, a[34]), z = h(z, H, R, M, I, 23, a[35]), M = h(M, z, H, R, E, 4, a[36]), R = h(R, M, z, H, S, 11, a[37]), H = h(H, R, M, z, _, 16, a[38]), z = h(z, H, R, M, O, 23, a[39]), M = h(M, z, H, R, G, 4, a[40]), R = h(R, M, z, H, m, 11, a[41]), H = h(H, R, M, z, b, 16, a[42]), z = h(z, H, R, M, D, 23, a[43]), M = h(M, z, H, R, P, 4, a[44]), R = h(R, M, z, H, T, 11, a[45]), H = h(H, R, M, z, U, 16, a[46]), z = h(z, H, R, M, y, 23, a[47]), M = p(M, z, H, R, m, 6, a[48]), R = p(R, M, z, H, _, 10, a[49]), H = p(H, R, M, z, I, 15, a[50]), z = p(z, H, R, M, F, 21, a[51]), M = p(M, z, H, R, T, 6, a[52]), R = p(R, M, z, H, b, 10, a[53]), H = p(H, R, M, z, O, 15, a[54]), z = p(z, H, R, M, E, 21, a[55]), M = p(M, z, H, R, w, 6, a[56]), R = p(R, M, z, H, U, 10, a[57]), H = p(H, R, M, z, D, 15, a[58]), z = p(z, H, R, M, G, 21, a[59]), M = p(M, z, H, R, S, 6, a[60]), R = p(R, M, z, H, W, 10, a[61]), H = p(H, R, M, z, y, 15, a[62]), z = p(z, H, R, M, P, 21, a[63]), B[0] = B[0] + M | 0, B[1] = B[1] + z | 0, B[2] = B[2] + H | 0, B[3] = B[3] + R | 0;
          },
          _doFinalize: function() {
            var C = this._data, v = C.words, g = this._nDataBytes * 8, f = C.sigBytes * 8;
            v[f >>> 5] |= 128 << 24 - f % 32;
            var u = e.floor(g / 4294967296), B = g;
            v[(f + 64 >>> 9 << 4) + 15] = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360, v[(f + 64 >>> 9 << 4) + 14] = (B << 8 | B >>> 24) & 16711935 | (B << 24 | B >>> 8) & 4278255360, C.sigBytes = (v.length + 1) * 4, this._process();
            for (var m = this._hash, E = m.words, y = 0; y < 4; y++) {
              var b = E[y];
              E[y] = (b << 8 | b >>> 24) & 16711935 | (b << 24 | b >>> 8) & 4278255360;
            }
            return m;
          },
          clone: function() {
            var C = d.clone.call(this);
            return C._hash = this._hash.clone(), C;
          }
        });
        function l(C, v, g, f, u, B, m) {
          var E = C + (v & g | ~v & f) + u + m;
          return (E << B | E >>> 32 - B) + v;
        }
        function s(C, v, g, f, u, B, m) {
          var E = C + (v & f | g & ~f) + u + m;
          return (E << B | E >>> 32 - B) + v;
        }
        function h(C, v, g, f, u, B, m) {
          var E = C + (v ^ g ^ f) + u + m;
          return (E << B | E >>> 32 - B) + v;
        }
        function p(C, v, g, f, u, B, m) {
          var E = C + (g ^ (v | ~f)) + u + m;
          return (E << B | E >>> 32 - B) + v;
        }
        i.MD5 = d._createHelper(t), i.HmacMD5 = d._createHmacHelper(t);
      })(Math), r.MD5;
    });
  })(O0)), O0.exports;
}
var W0 = { exports: {} }, ha = W0.exports, Ke;
function Sr() {
  return Ke || (Ke = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(ha, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.WordArray, A = i.Hasher, d = e.algo, x = [], a = d.SHA1 = A.extend({
          _doReset: function() {
            this._hash = new c.init([
              1732584193,
              4023233417,
              2562383102,
              271733878,
              3285377520
            ]);
          },
          _doProcessBlock: function(t, l) {
            for (var s = this._hash.words, h = s[0], p = s[1], C = s[2], v = s[3], g = s[4], f = 0; f < 80; f++) {
              if (f < 16)
                x[f] = t[l + f] | 0;
              else {
                var u = x[f - 3] ^ x[f - 8] ^ x[f - 14] ^ x[f - 16];
                x[f] = u << 1 | u >>> 31;
              }
              var B = (h << 5 | h >>> 27) + g + x[f];
              f < 20 ? B += (p & C | ~p & v) + 1518500249 : f < 40 ? B += (p ^ C ^ v) + 1859775393 : f < 60 ? B += (p & C | p & v | C & v) - 1894007588 : B += (p ^ C ^ v) - 899497514, g = v, v = C, C = p << 30 | p >>> 2, p = h, h = B;
            }
            s[0] = s[0] + h | 0, s[1] = s[1] + p | 0, s[2] = s[2] + C | 0, s[3] = s[3] + v | 0, s[4] = s[4] + g | 0;
          },
          _doFinalize: function() {
            var t = this._data, l = t.words, s = this._nDataBytes * 8, h = t.sigBytes * 8;
            return l[h >>> 5] |= 128 << 24 - h % 32, l[(h + 64 >>> 9 << 4) + 14] = Math.floor(s / 4294967296), l[(h + 64 >>> 9 << 4) + 15] = s, t.sigBytes = l.length * 4, this._process(), this._hash;
          },
          clone: function() {
            var t = A.clone.call(this);
            return t._hash = this._hash.clone(), t;
          }
        });
        e.SHA1 = A._createHelper(a), e.HmacSHA1 = A._createHmacHelper(a);
      })(), r.SHA1;
    });
  })(W0)), W0.exports;
}
var T0 = { exports: {} }, ua = T0.exports, Ye;
function Fe() {
  return Ye || (Ye = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(ua, function(r) {
      return (function(e) {
        var i = r, c = i.lib, A = c.WordArray, d = c.Hasher, x = i.algo, a = [], t = [];
        (function() {
          function h(g) {
            for (var f = e.sqrt(g), u = 2; u <= f; u++)
              if (!(g % u))
                return !1;
            return !0;
          }
          function p(g) {
            return (g - (g | 0)) * 4294967296 | 0;
          }
          for (var C = 2, v = 0; v < 64; )
            h(C) && (v < 8 && (a[v] = p(e.pow(C, 1 / 2))), t[v] = p(e.pow(C, 1 / 3)), v++), C++;
        })();
        var l = [], s = x.SHA256 = d.extend({
          _doReset: function() {
            this._hash = new A.init(a.slice(0));
          },
          _doProcessBlock: function(h, p) {
            for (var C = this._hash.words, v = C[0], g = C[1], f = C[2], u = C[3], B = C[4], m = C[5], E = C[6], y = C[7], b = 0; b < 64; b++) {
              if (b < 16)
                l[b] = h[p + b] | 0;
              else {
                var S = l[b - 15], F = (S << 25 | S >>> 7) ^ (S << 14 | S >>> 18) ^ S >>> 3, D = l[b - 2], _ = (D << 15 | D >>> 17) ^ (D << 13 | D >>> 19) ^ D >>> 10;
                l[b] = F + l[b - 7] + _ + l[b - 16];
              }
              var w = B & m ^ ~B & E, P = v & g ^ v & f ^ g & f, O = (v << 30 | v >>> 2) ^ (v << 19 | v >>> 13) ^ (v << 10 | v >>> 22), W = (B << 26 | B >>> 6) ^ (B << 21 | B >>> 11) ^ (B << 7 | B >>> 25), T = y + W + w + t[b] + l[b], G = O + P;
              y = E, E = m, m = B, B = u + T | 0, u = f, f = g, g = v, v = T + G | 0;
            }
            C[0] = C[0] + v | 0, C[1] = C[1] + g | 0, C[2] = C[2] + f | 0, C[3] = C[3] + u | 0, C[4] = C[4] + B | 0, C[5] = C[5] + m | 0, C[6] = C[6] + E | 0, C[7] = C[7] + y | 0;
          },
          _doFinalize: function() {
            var h = this._data, p = h.words, C = this._nDataBytes * 8, v = h.sigBytes * 8;
            return p[v >>> 5] |= 128 << 24 - v % 32, p[(v + 64 >>> 9 << 4) + 14] = e.floor(C / 4294967296), p[(v + 64 >>> 9 << 4) + 15] = C, h.sigBytes = p.length * 4, this._process(), this._hash;
          },
          clone: function() {
            var h = d.clone.call(this);
            return h._hash = this._hash.clone(), h;
          }
        });
        i.SHA256 = d._createHelper(s), i.HmacSHA256 = d._createHmacHelper(s);
      })(Math), r.SHA256;
    });
  })(T0)), T0.exports;
}
var q0 = { exports: {} }, da = q0.exports, Ze;
function va() {
  return Ze || (Ze = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), Fe());
    })(da, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.WordArray, A = e.algo, d = A.SHA256, x = A.SHA224 = d.extend({
          _doReset: function() {
            this._hash = new c.init([
              3238371032,
              914150663,
              812702999,
              4144912697,
              4290775857,
              1750603025,
              1694076839,
              3204075428
            ]);
          },
          _doFinalize: function() {
            var a = d._doFinalize.call(this);
            return a.sigBytes -= 4, a;
          }
        });
        e.SHA224 = d._createHelper(x), e.HmacSHA224 = d._createHmacHelper(x);
      })(), r.SHA224;
    });
  })(q0)), q0.exports;
}
var I0 = { exports: {} }, pa = I0.exports, Qe;
function Mr() {
  return Qe || (Qe = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), le());
    })(pa, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.Hasher, A = e.x64, d = A.Word, x = A.WordArray, a = e.algo;
        function t() {
          return d.create.apply(d, arguments);
        }
        var l = [
          t(1116352408, 3609767458),
          t(1899447441, 602891725),
          t(3049323471, 3964484399),
          t(3921009573, 2173295548),
          t(961987163, 4081628472),
          t(1508970993, 3053834265),
          t(2453635748, 2937671579),
          t(2870763221, 3664609560),
          t(3624381080, 2734883394),
          t(310598401, 1164996542),
          t(607225278, 1323610764),
          t(1426881987, 3590304994),
          t(1925078388, 4068182383),
          t(2162078206, 991336113),
          t(2614888103, 633803317),
          t(3248222580, 3479774868),
          t(3835390401, 2666613458),
          t(4022224774, 944711139),
          t(264347078, 2341262773),
          t(604807628, 2007800933),
          t(770255983, 1495990901),
          t(1249150122, 1856431235),
          t(1555081692, 3175218132),
          t(1996064986, 2198950837),
          t(2554220882, 3999719339),
          t(2821834349, 766784016),
          t(2952996808, 2566594879),
          t(3210313671, 3203337956),
          t(3336571891, 1034457026),
          t(3584528711, 2466948901),
          t(113926993, 3758326383),
          t(338241895, 168717936),
          t(666307205, 1188179964),
          t(773529912, 1546045734),
          t(1294757372, 1522805485),
          t(1396182291, 2643833823),
          t(1695183700, 2343527390),
          t(1986661051, 1014477480),
          t(2177026350, 1206759142),
          t(2456956037, 344077627),
          t(2730485921, 1290863460),
          t(2820302411, 3158454273),
          t(3259730800, 3505952657),
          t(3345764771, 106217008),
          t(3516065817, 3606008344),
          t(3600352804, 1432725776),
          t(4094571909, 1467031594),
          t(275423344, 851169720),
          t(430227734, 3100823752),
          t(506948616, 1363258195),
          t(659060556, 3750685593),
          t(883997877, 3785050280),
          t(958139571, 3318307427),
          t(1322822218, 3812723403),
          t(1537002063, 2003034995),
          t(1747873779, 3602036899),
          t(1955562222, 1575990012),
          t(2024104815, 1125592928),
          t(2227730452, 2716904306),
          t(2361852424, 442776044),
          t(2428436474, 593698344),
          t(2756734187, 3733110249),
          t(3204031479, 2999351573),
          t(3329325298, 3815920427),
          t(3391569614, 3928383900),
          t(3515267271, 566280711),
          t(3940187606, 3454069534),
          t(4118630271, 4000239992),
          t(116418474, 1914138554),
          t(174292421, 2731055270),
          t(289380356, 3203993006),
          t(460393269, 320620315),
          t(685471733, 587496836),
          t(852142971, 1086792851),
          t(1017036298, 365543100),
          t(1126000580, 2618297676),
          t(1288033470, 3409855158),
          t(1501505948, 4234509866),
          t(1607167915, 987167468),
          t(1816402316, 1246189591)
        ], s = [];
        (function() {
          for (var p = 0; p < 80; p++)
            s[p] = t();
        })();
        var h = a.SHA512 = c.extend({
          _doReset: function() {
            this._hash = new x.init([
              new d.init(1779033703, 4089235720),
              new d.init(3144134277, 2227873595),
              new d.init(1013904242, 4271175723),
              new d.init(2773480762, 1595750129),
              new d.init(1359893119, 2917565137),
              new d.init(2600822924, 725511199),
              new d.init(528734635, 4215389547),
              new d.init(1541459225, 327033209)
            ]);
          },
          _doProcessBlock: function(p, C) {
            for (var v = this._hash.words, g = v[0], f = v[1], u = v[2], B = v[3], m = v[4], E = v[5], y = v[6], b = v[7], S = g.high, F = g.low, D = f.high, _ = f.low, w = u.high, P = u.low, O = B.high, W = B.low, T = m.high, G = m.low, I = E.high, U = E.low, M = y.high, z = y.low, H = b.high, R = b.low, $ = S, N = F, X = D, q = _, o0 = w, i0 = P, d0 = O, s0 = W, K = T, Y = G, y0 = I, C0 = U, b0 = M, m0 = z, he = H, A0 = R, t0 = 0; t0 < 80; t0++) {
              var e0, x0, _0 = s[t0];
              if (t0 < 16)
                x0 = _0.high = p[C + t0 * 2] | 0, e0 = _0.low = p[C + t0 * 2 + 1] | 0;
              else {
                var ye = s[t0 - 15], v0 = ye.high, E0 = ye.low, Hr = (v0 >>> 1 | E0 << 31) ^ (v0 >>> 8 | E0 << 24) ^ v0 >>> 7, be = (E0 >>> 1 | v0 << 31) ^ (E0 >>> 8 | v0 << 24) ^ (E0 >>> 7 | v0 << 25), _e = s[t0 - 2], p0 = _e.high, g0 = _e.low, Pr = (p0 >>> 19 | g0 << 13) ^ (p0 << 3 | g0 >>> 29) ^ p0 >>> 6, we = (g0 >>> 19 | p0 << 13) ^ (g0 << 3 | p0 >>> 29) ^ (g0 >>> 6 | p0 << 26), ke = s[t0 - 7], Or = ke.high, Wr = ke.low, Se = s[t0 - 16], Tr = Se.high, Me = Se.low;
                e0 = be + Wr, x0 = Hr + Or + (e0 >>> 0 < be >>> 0 ? 1 : 0), e0 = e0 + we, x0 = x0 + Pr + (e0 >>> 0 < we >>> 0 ? 1 : 0), e0 = e0 + Me, x0 = x0 + Tr + (e0 >>> 0 < Me >>> 0 ? 1 : 0), _0.high = x0, _0.low = e0;
              }
              var qr = K & y0 ^ ~K & b0, Re = Y & C0 ^ ~Y & m0, Ir = $ & X ^ $ & o0 ^ X & o0, Lr = N & q ^ N & i0 ^ q & i0, Gr = ($ >>> 28 | N << 4) ^ ($ << 30 | N >>> 2) ^ ($ << 25 | N >>> 7), ze = (N >>> 28 | $ << 4) ^ (N << 30 | $ >>> 2) ^ (N << 25 | $ >>> 7), Ur = (K >>> 14 | Y << 18) ^ (K >>> 18 | Y << 14) ^ (K << 23 | Y >>> 9), $r = (Y >>> 14 | K << 18) ^ (Y >>> 18 | K << 14) ^ (Y << 23 | K >>> 9), He = l[t0], Nr = He.high, Pe = He.low, Z = A0 + $r, c0 = he + Ur + (Z >>> 0 < A0 >>> 0 ? 1 : 0), Z = Z + Re, c0 = c0 + qr + (Z >>> 0 < Re >>> 0 ? 1 : 0), Z = Z + Pe, c0 = c0 + Nr + (Z >>> 0 < Pe >>> 0 ? 1 : 0), Z = Z + e0, c0 = c0 + x0 + (Z >>> 0 < e0 >>> 0 ? 1 : 0), Oe = ze + Lr, Vr = Gr + Ir + (Oe >>> 0 < ze >>> 0 ? 1 : 0);
              he = b0, A0 = m0, b0 = y0, m0 = C0, y0 = K, C0 = Y, Y = s0 + Z | 0, K = d0 + c0 + (Y >>> 0 < s0 >>> 0 ? 1 : 0) | 0, d0 = o0, s0 = i0, o0 = X, i0 = q, X = $, q = N, N = Z + Oe | 0, $ = c0 + Vr + (N >>> 0 < Z >>> 0 ? 1 : 0) | 0;
            }
            F = g.low = F + N, g.high = S + $ + (F >>> 0 < N >>> 0 ? 1 : 0), _ = f.low = _ + q, f.high = D + X + (_ >>> 0 < q >>> 0 ? 1 : 0), P = u.low = P + i0, u.high = w + o0 + (P >>> 0 < i0 >>> 0 ? 1 : 0), W = B.low = W + s0, B.high = O + d0 + (W >>> 0 < s0 >>> 0 ? 1 : 0), G = m.low = G + Y, m.high = T + K + (G >>> 0 < Y >>> 0 ? 1 : 0), U = E.low = U + C0, E.high = I + y0 + (U >>> 0 < C0 >>> 0 ? 1 : 0), z = y.low = z + m0, y.high = M + b0 + (z >>> 0 < m0 >>> 0 ? 1 : 0), R = b.low = R + A0, b.high = H + he + (R >>> 0 < A0 >>> 0 ? 1 : 0);
          },
          _doFinalize: function() {
            var p = this._data, C = p.words, v = this._nDataBytes * 8, g = p.sigBytes * 8;
            C[g >>> 5] |= 128 << 24 - g % 32, C[(g + 128 >>> 10 << 5) + 30] = Math.floor(v / 4294967296), C[(g + 128 >>> 10 << 5) + 31] = v, p.sigBytes = C.length * 4, this._process();
            var f = this._hash.toX32();
            return f;
          },
          clone: function() {
            var p = c.clone.call(this);
            return p._hash = this._hash.clone(), p;
          },
          blockSize: 1024 / 32
        });
        e.SHA512 = c._createHelper(h), e.HmacSHA512 = c._createHmacHelper(h);
      })(), r.SHA512;
    });
  })(I0)), I0.exports;
}
var L0 = { exports: {} }, Ba = L0.exports, Je;
function Ca() {
  return Je || (Je = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), le(), Mr());
    })(Ba, function(r) {
      return (function() {
        var e = r, i = e.x64, c = i.Word, A = i.WordArray, d = e.algo, x = d.SHA512, a = d.SHA384 = x.extend({
          _doReset: function() {
            this._hash = new A.init([
              new c.init(3418070365, 3238371032),
              new c.init(1654270250, 914150663),
              new c.init(2438529370, 812702999),
              new c.init(355462360, 4144912697),
              new c.init(1731405415, 4290775857),
              new c.init(2394180231, 1750603025),
              new c.init(3675008525, 1694076839),
              new c.init(1203062813, 3204075428)
            ]);
          },
          _doFinalize: function() {
            var t = x._doFinalize.call(this);
            return t.sigBytes -= 16, t;
          }
        });
        e.SHA384 = x._createHelper(a), e.HmacSHA384 = x._createHmacHelper(a);
      })(), r.SHA384;
    });
  })(L0)), L0.exports;
}
var G0 = { exports: {} }, ma = G0.exports, er;
function Aa() {
  return er || (er = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), le());
    })(ma, function(r) {
      return (function(e) {
        var i = r, c = i.lib, A = c.WordArray, d = c.Hasher, x = i.x64, a = x.Word, t = i.algo, l = [], s = [], h = [];
        (function() {
          for (var v = 1, g = 0, f = 0; f < 24; f++) {
            l[v + 5 * g] = (f + 1) * (f + 2) / 2 % 64;
            var u = g % 5, B = (2 * v + 3 * g) % 5;
            v = u, g = B;
          }
          for (var v = 0; v < 5; v++)
            for (var g = 0; g < 5; g++)
              s[v + 5 * g] = g + (2 * v + 3 * g) % 5 * 5;
          for (var m = 1, E = 0; E < 24; E++) {
            for (var y = 0, b = 0, S = 0; S < 7; S++) {
              if (m & 1) {
                var F = (1 << S) - 1;
                F < 32 ? b ^= 1 << F : y ^= 1 << F - 32;
              }
              m & 128 ? m = m << 1 ^ 113 : m <<= 1;
            }
            h[E] = a.create(y, b);
          }
        })();
        var p = [];
        (function() {
          for (var v = 0; v < 25; v++)
            p[v] = a.create();
        })();
        var C = t.SHA3 = d.extend({
          /**
           * Configuration options.
           *
           * @property {number} outputLength
           *   The desired number of bits in the output hash.
           *   Only values permitted are: 224, 256, 384, 512.
           *   Default: 512
           */
          cfg: d.cfg.extend({
            outputLength: 512
          }),
          _doReset: function() {
            for (var v = this._state = [], g = 0; g < 25; g++)
              v[g] = new a.init();
            this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32;
          },
          _doProcessBlock: function(v, g) {
            for (var f = this._state, u = this.blockSize / 2, B = 0; B < u; B++) {
              var m = v[g + 2 * B], E = v[g + 2 * B + 1];
              m = (m << 8 | m >>> 24) & 16711935 | (m << 24 | m >>> 8) & 4278255360, E = (E << 8 | E >>> 24) & 16711935 | (E << 24 | E >>> 8) & 4278255360;
              var y = f[B];
              y.high ^= E, y.low ^= m;
            }
            for (var b = 0; b < 24; b++) {
              for (var S = 0; S < 5; S++) {
                for (var F = 0, D = 0, _ = 0; _ < 5; _++) {
                  var y = f[S + 5 * _];
                  F ^= y.high, D ^= y.low;
                }
                var w = p[S];
                w.high = F, w.low = D;
              }
              for (var S = 0; S < 5; S++)
                for (var P = p[(S + 4) % 5], O = p[(S + 1) % 5], W = O.high, T = O.low, F = P.high ^ (W << 1 | T >>> 31), D = P.low ^ (T << 1 | W >>> 31), _ = 0; _ < 5; _++) {
                  var y = f[S + 5 * _];
                  y.high ^= F, y.low ^= D;
                }
              for (var G = 1; G < 25; G++) {
                var F, D, y = f[G], I = y.high, U = y.low, M = l[G];
                M < 32 ? (F = I << M | U >>> 32 - M, D = U << M | I >>> 32 - M) : (F = U << M - 32 | I >>> 64 - M, D = I << M - 32 | U >>> 64 - M);
                var z = p[s[G]];
                z.high = F, z.low = D;
              }
              var H = p[0], R = f[0];
              H.high = R.high, H.low = R.low;
              for (var S = 0; S < 5; S++)
                for (var _ = 0; _ < 5; _++) {
                  var G = S + 5 * _, y = f[G], $ = p[G], N = p[(S + 1) % 5 + 5 * _], X = p[(S + 2) % 5 + 5 * _];
                  y.high = $.high ^ ~N.high & X.high, y.low = $.low ^ ~N.low & X.low;
                }
              var y = f[0], q = h[b];
              y.high ^= q.high, y.low ^= q.low;
            }
          },
          _doFinalize: function() {
            var v = this._data, g = v.words;
            this._nDataBytes * 8;
            var f = v.sigBytes * 8, u = this.blockSize * 32;
            g[f >>> 5] |= 1 << 24 - f % 32, g[(e.ceil((f + 1) / u) * u >>> 5) - 1] |= 128, v.sigBytes = g.length * 4, this._process();
            for (var B = this._state, m = this.cfg.outputLength / 8, E = m / 8, y = [], b = 0; b < E; b++) {
              var S = B[b], F = S.high, D = S.low;
              F = (F << 8 | F >>> 24) & 16711935 | (F << 24 | F >>> 8) & 4278255360, D = (D << 8 | D >>> 24) & 16711935 | (D << 24 | D >>> 8) & 4278255360, y.push(D), y.push(F);
            }
            return new A.init(y, m);
          },
          clone: function() {
            for (var v = d.clone.call(this), g = v._state = this._state.slice(0), f = 0; f < 25; f++)
              g[f] = g[f].clone();
            return v;
          }
        });
        i.SHA3 = d._createHelper(C), i.HmacSHA3 = d._createHmacHelper(C);
      })(Math), r.SHA3;
    });
  })(G0)), G0.exports;
}
var U0 = { exports: {} }, Ea = U0.exports, rr;
function ga() {
  return rr || (rr = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(Ea, function(r) {
      /** @preserve
      			(c) 2012 by Cédric Mesnil. All rights reserved.
      
      			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
      
      			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
      			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
      
      			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
      			*/
      return (function(e) {
        var i = r, c = i.lib, A = c.WordArray, d = c.Hasher, x = i.algo, a = A.create([
          0,
          1,
          2,
          3,
          4,
          5,
          6,
          7,
          8,
          9,
          10,
          11,
          12,
          13,
          14,
          15,
          7,
          4,
          13,
          1,
          10,
          6,
          15,
          3,
          12,
          0,
          9,
          5,
          2,
          14,
          11,
          8,
          3,
          10,
          14,
          4,
          9,
          15,
          8,
          1,
          2,
          7,
          0,
          6,
          13,
          11,
          5,
          12,
          1,
          9,
          11,
          10,
          0,
          8,
          12,
          4,
          13,
          3,
          7,
          15,
          14,
          5,
          6,
          2,
          4,
          0,
          5,
          9,
          7,
          12,
          2,
          10,
          14,
          1,
          3,
          8,
          11,
          6,
          15,
          13
        ]), t = A.create([
          5,
          14,
          7,
          0,
          9,
          2,
          11,
          4,
          13,
          6,
          15,
          8,
          1,
          10,
          3,
          12,
          6,
          11,
          3,
          7,
          0,
          13,
          5,
          10,
          14,
          15,
          8,
          12,
          4,
          9,
          1,
          2,
          15,
          5,
          1,
          3,
          7,
          14,
          6,
          9,
          11,
          8,
          12,
          2,
          10,
          0,
          4,
          13,
          8,
          6,
          4,
          1,
          3,
          11,
          15,
          0,
          5,
          12,
          2,
          13,
          9,
          7,
          10,
          14,
          12,
          15,
          10,
          4,
          1,
          5,
          8,
          7,
          6,
          2,
          13,
          14,
          0,
          3,
          9,
          11
        ]), l = A.create([
          11,
          14,
          15,
          12,
          5,
          8,
          7,
          9,
          11,
          13,
          14,
          15,
          6,
          7,
          9,
          8,
          7,
          6,
          8,
          13,
          11,
          9,
          7,
          15,
          7,
          12,
          15,
          9,
          11,
          7,
          13,
          12,
          11,
          13,
          6,
          7,
          14,
          9,
          13,
          15,
          14,
          8,
          13,
          6,
          5,
          12,
          7,
          5,
          11,
          12,
          14,
          15,
          14,
          15,
          9,
          8,
          9,
          14,
          5,
          6,
          8,
          6,
          5,
          12,
          9,
          15,
          5,
          11,
          6,
          8,
          13,
          12,
          5,
          12,
          13,
          14,
          11,
          8,
          5,
          6
        ]), s = A.create([
          8,
          9,
          9,
          11,
          13,
          15,
          15,
          5,
          7,
          7,
          8,
          11,
          14,
          14,
          12,
          6,
          9,
          13,
          15,
          7,
          12,
          8,
          9,
          11,
          7,
          7,
          12,
          7,
          6,
          15,
          13,
          11,
          9,
          7,
          15,
          11,
          8,
          6,
          6,
          14,
          12,
          13,
          5,
          14,
          13,
          13,
          7,
          5,
          15,
          5,
          8,
          11,
          14,
          14,
          6,
          14,
          6,
          9,
          12,
          9,
          12,
          5,
          15,
          8,
          8,
          5,
          12,
          9,
          12,
          5,
          14,
          6,
          8,
          13,
          6,
          5,
          15,
          13,
          11,
          11
        ]), h = A.create([0, 1518500249, 1859775393, 2400959708, 2840853838]), p = A.create([1352829926, 1548603684, 1836072691, 2053994217, 0]), C = x.RIPEMD160 = d.extend({
          _doReset: function() {
            this._hash = A.create([1732584193, 4023233417, 2562383102, 271733878, 3285377520]);
          },
          _doProcessBlock: function(E, y) {
            for (var b = 0; b < 16; b++) {
              var S = y + b, F = E[S];
              E[S] = (F << 8 | F >>> 24) & 16711935 | (F << 24 | F >>> 8) & 4278255360;
            }
            var D = this._hash.words, _ = h.words, w = p.words, P = a.words, O = t.words, W = l.words, T = s.words, G, I, U, M, z, H, R, $, N, X;
            H = G = D[0], R = I = D[1], $ = U = D[2], N = M = D[3], X = z = D[4];
            for (var q, b = 0; b < 80; b += 1)
              q = G + E[y + P[b]] | 0, b < 16 ? q += v(I, U, M) + _[0] : b < 32 ? q += g(I, U, M) + _[1] : b < 48 ? q += f(I, U, M) + _[2] : b < 64 ? q += u(I, U, M) + _[3] : q += B(I, U, M) + _[4], q = q | 0, q = m(q, W[b]), q = q + z | 0, G = z, z = M, M = m(U, 10), U = I, I = q, q = H + E[y + O[b]] | 0, b < 16 ? q += B(R, $, N) + w[0] : b < 32 ? q += u(R, $, N) + w[1] : b < 48 ? q += f(R, $, N) + w[2] : b < 64 ? q += g(R, $, N) + w[3] : q += v(R, $, N) + w[4], q = q | 0, q = m(q, T[b]), q = q + X | 0, H = X, X = N, N = m($, 10), $ = R, R = q;
            q = D[1] + U + N | 0, D[1] = D[2] + M + X | 0, D[2] = D[3] + z + H | 0, D[3] = D[4] + G + R | 0, D[4] = D[0] + I + $ | 0, D[0] = q;
          },
          _doFinalize: function() {
            var E = this._data, y = E.words, b = this._nDataBytes * 8, S = E.sigBytes * 8;
            y[S >>> 5] |= 128 << 24 - S % 32, y[(S + 64 >>> 9 << 4) + 14] = (b << 8 | b >>> 24) & 16711935 | (b << 24 | b >>> 8) & 4278255360, E.sigBytes = (y.length + 1) * 4, this._process();
            for (var F = this._hash, D = F.words, _ = 0; _ < 5; _++) {
              var w = D[_];
              D[_] = (w << 8 | w >>> 24) & 16711935 | (w << 24 | w >>> 8) & 4278255360;
            }
            return F;
          },
          clone: function() {
            var E = d.clone.call(this);
            return E._hash = this._hash.clone(), E;
          }
        });
        function v(E, y, b) {
          return E ^ y ^ b;
        }
        function g(E, y, b) {
          return E & y | ~E & b;
        }
        function f(E, y, b) {
          return (E | ~y) ^ b;
        }
        function u(E, y, b) {
          return E & b | y & ~b;
        }
        function B(E, y, b) {
          return E ^ (y | ~b);
        }
        function m(E, y) {
          return E << y | E >>> 32 - y;
        }
        i.RIPEMD160 = d._createHelper(C), i.HmacRIPEMD160 = d._createHmacHelper(C);
      })(), r.RIPEMD160;
    });
  })(U0)), U0.exports;
}
var $0 = { exports: {} }, Fa = $0.exports, tr;
function De() {
  return tr || (tr = 1, (function(o, n) {
    (function(r, e) {
      o.exports = e(L());
    })(Fa, function(r) {
      (function() {
        var e = r, i = e.lib, c = i.Base, A = e.enc, d = A.Utf8, x = e.algo;
        x.HMAC = c.extend({
          /**
           * Initializes a newly created HMAC.
           *
           * @param {Hasher} hasher The hash algorithm to use.
           * @param {WordArray|string} key The secret key.
           *
           * @example
           *
           *     var hmacHasher = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, key);
           */
          init: function(a, t) {
            a = this._hasher = new a.init(), typeof t == "string" && (t = d.parse(t));
            var l = a.blockSize, s = l * 4;
            t.sigBytes > s && (t = a.finalize(t)), t.clamp();
            for (var h = this._oKey = t.clone(), p = this._iKey = t.clone(), C = h.words, v = p.words, g = 0; g < l; g++)
              C[g] ^= 1549556828, v[g] ^= 909522486;
            h.sigBytes = p.sigBytes = s, this.reset();
          },
          /**
           * Resets this HMAC to its initial state.
           *
           * @example
           *
           *     hmacHasher.reset();
           */
          reset: function() {
            var a = this._hasher;
            a.reset(), a.update(this._iKey);
          },
          /**
           * Updates this HMAC with a message.
           *
           * @param {WordArray|string} messageUpdate The message to append.
           *
           * @return {HMAC} This HMAC instance.
           *
           * @example
           *
           *     hmacHasher.update('message');
           *     hmacHasher.update(wordArray);
           */
          update: function(a) {
            return this._hasher.update(a), this;
          },
          /**
           * Finalizes the HMAC computation.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} messageUpdate (Optional) A final message update.
           *
           * @return {WordArray} The HMAC.
           *
           * @example
           *
           *     var hmac = hmacHasher.finalize();
           *     var hmac = hmacHasher.finalize('message');
           *     var hmac = hmacHasher.finalize(wordArray);
           */
          finalize: function(a) {
            var t = this._hasher, l = t.finalize(a);
            t.reset();
            var s = t.finalize(this._oKey.clone().concat(l));
            return s;
          }
        });
      })();
    });
  })($0)), $0.exports;
}
var N0 = { exports: {} }, Da = N0.exports, ar;
function ya() {
  return ar || (ar = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), Fe(), De());
    })(Da, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.Base, A = i.WordArray, d = e.algo, x = d.SHA256, a = d.HMAC, t = d.PBKDF2 = c.extend({
          /**
           * Configuration options.
           *
           * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
           * @property {Hasher} hasher The hasher to use. Default: SHA256
           * @property {number} iterations The number of iterations to perform. Default: 250000
           */
          cfg: c.extend({
            keySize: 128 / 32,
            hasher: x,
            iterations: 25e4
          }),
          /**
           * Initializes a newly created key derivation function.
           *
           * @param {Object} cfg (Optional) The configuration options to use for the derivation.
           *
           * @example
           *
           *     var kdf = CryptoJS.algo.PBKDF2.create();
           *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8 });
           *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8, iterations: 1000 });
           */
          init: function(l) {
            this.cfg = this.cfg.extend(l);
          },
          /**
           * Computes the Password-Based Key Derivation Function 2.
           *
           * @param {WordArray|string} password The password.
           * @param {WordArray|string} salt A salt.
           *
           * @return {WordArray} The derived key.
           *
           * @example
           *
           *     var key = kdf.compute(password, salt);
           */
          compute: function(l, s) {
            for (var h = this.cfg, p = a.create(h.hasher, l), C = A.create(), v = A.create([1]), g = C.words, f = v.words, u = h.keySize, B = h.iterations; g.length < u; ) {
              var m = p.update(s).finalize(v);
              p.reset();
              for (var E = m.words, y = E.length, b = m, S = 1; S < B; S++) {
                b = p.finalize(b), p.reset();
                for (var F = b.words, D = 0; D < y; D++)
                  E[D] ^= F[D];
              }
              C.concat(m), f[0]++;
            }
            return C.sigBytes = u * 4, C;
          }
        });
        e.PBKDF2 = function(l, s, h) {
          return t.create(h).compute(l, s);
        };
      })(), r.PBKDF2;
    });
  })(N0)), N0.exports;
}
var V0 = { exports: {} }, ba = V0.exports, nr;
function l0() {
  return nr || (nr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), Sr(), De());
    })(ba, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.Base, A = i.WordArray, d = e.algo, x = d.MD5, a = d.EvpKDF = c.extend({
          /**
           * Configuration options.
           *
           * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
           * @property {Hasher} hasher The hash algorithm to use. Default: MD5
           * @property {number} iterations The number of iterations to perform. Default: 1
           */
          cfg: c.extend({
            keySize: 128 / 32,
            hasher: x,
            iterations: 1
          }),
          /**
           * Initializes a newly created key derivation function.
           *
           * @param {Object} cfg (Optional) The configuration options to use for the derivation.
           *
           * @example
           *
           *     var kdf = CryptoJS.algo.EvpKDF.create();
           *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8 });
           *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8, iterations: 1000 });
           */
          init: function(t) {
            this.cfg = this.cfg.extend(t);
          },
          /**
           * Derives a key from a password.
           *
           * @param {WordArray|string} password The password.
           * @param {WordArray|string} salt A salt.
           *
           * @return {WordArray} The derived key.
           *
           * @example
           *
           *     var key = kdf.compute(password, salt);
           */
          compute: function(t, l) {
            for (var s, h = this.cfg, p = h.hasher.create(), C = A.create(), v = C.words, g = h.keySize, f = h.iterations; v.length < g; ) {
              s && p.update(s), s = p.update(t).finalize(l), p.reset();
              for (var u = 1; u < f; u++)
                s = p.finalize(s), p.reset();
              C.concat(s);
            }
            return C.sigBytes = g * 4, C;
          }
        });
        e.EvpKDF = function(t, l, s) {
          return a.create(s).compute(t, l);
        };
      })(), r.EvpKDF;
    });
  })(V0)), V0.exports;
}
var X0 = { exports: {} }, _a = X0.exports, or;
function j() {
  return or || (or = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), l0());
    })(_a, function(r) {
      r.lib.Cipher || (function(e) {
        var i = r, c = i.lib, A = c.Base, d = c.WordArray, x = c.BufferedBlockAlgorithm, a = i.enc;
        a.Utf8;
        var t = a.Base64, l = i.algo, s = l.EvpKDF, h = c.Cipher = x.extend({
          /**
           * Configuration options.
           *
           * @property {WordArray} iv The IV to use for this operation.
           */
          cfg: A.extend(),
          /**
           * Creates this cipher in encryption mode.
           *
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {Cipher} A cipher instance.
           *
           * @static
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.createEncryptor(keyWordArray, { iv: ivWordArray });
           */
          createEncryptor: function(F, D) {
            return this.create(this._ENC_XFORM_MODE, F, D);
          },
          /**
           * Creates this cipher in decryption mode.
           *
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {Cipher} A cipher instance.
           *
           * @static
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.createDecryptor(keyWordArray, { iv: ivWordArray });
           */
          createDecryptor: function(F, D) {
            return this.create(this._DEC_XFORM_MODE, F, D);
          },
          /**
           * Initializes a newly created cipher.
           *
           * @param {number} xformMode Either the encryption or decryption transormation mode constant.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.create(CryptoJS.algo.AES._ENC_XFORM_MODE, keyWordArray, { iv: ivWordArray });
           */
          init: function(F, D, _) {
            this.cfg = this.cfg.extend(_), this._xformMode = F, this._key = D, this.reset();
          },
          /**
           * Resets this cipher to its initial state.
           *
           * @example
           *
           *     cipher.reset();
           */
          reset: function() {
            x.reset.call(this), this._doReset();
          },
          /**
           * Adds data to be encrypted or decrypted.
           *
           * @param {WordArray|string} dataUpdate The data to encrypt or decrypt.
           *
           * @return {WordArray} The data after processing.
           *
           * @example
           *
           *     var encrypted = cipher.process('data');
           *     var encrypted = cipher.process(wordArray);
           */
          process: function(F) {
            return this._append(F), this._process();
          },
          /**
           * Finalizes the encryption or decryption process.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} dataUpdate The final data to encrypt or decrypt.
           *
           * @return {WordArray} The data after final processing.
           *
           * @example
           *
           *     var encrypted = cipher.finalize();
           *     var encrypted = cipher.finalize('data');
           *     var encrypted = cipher.finalize(wordArray);
           */
          finalize: function(F) {
            F && this._append(F);
            var D = this._doFinalize();
            return D;
          },
          keySize: 128 / 32,
          ivSize: 128 / 32,
          _ENC_XFORM_MODE: 1,
          _DEC_XFORM_MODE: 2,
          /**
           * Creates shortcut functions to a cipher's object interface.
           *
           * @param {Cipher} cipher The cipher to create a helper for.
           *
           * @return {Object} An object with encrypt and decrypt shortcut functions.
           *
           * @static
           *
           * @example
           *
           *     var AES = CryptoJS.lib.Cipher._createHelper(CryptoJS.algo.AES);
           */
          _createHelper: /* @__PURE__ */ (function() {
            function F(D) {
              return typeof D == "string" ? S : E;
            }
            return function(D) {
              return {
                encrypt: function(_, w, P) {
                  return F(w).encrypt(D, _, w, P);
                },
                decrypt: function(_, w, P) {
                  return F(w).decrypt(D, _, w, P);
                }
              };
            };
          })()
        });
        c.StreamCipher = h.extend({
          _doFinalize: function() {
            var F = this._process(!0);
            return F;
          },
          blockSize: 1
        });
        var p = i.mode = {}, C = c.BlockCipherMode = A.extend({
          /**
           * Creates this mode for encryption.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @static
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.createEncryptor(cipher, iv.words);
           */
          createEncryptor: function(F, D) {
            return this.Encryptor.create(F, D);
          },
          /**
           * Creates this mode for decryption.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @static
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.createDecryptor(cipher, iv.words);
           */
          createDecryptor: function(F, D) {
            return this.Decryptor.create(F, D);
          },
          /**
           * Initializes a newly created mode.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.Encryptor.create(cipher, iv.words);
           */
          init: function(F, D) {
            this._cipher = F, this._iv = D;
          }
        }), v = p.CBC = (function() {
          var F = C.extend();
          F.Encryptor = F.extend({
            /**
             * Processes the data block at offset.
             *
             * @param {Array} words The data words to operate on.
             * @param {number} offset The offset where the block starts.
             *
             * @example
             *
             *     mode.processBlock(data.words, offset);
             */
            processBlock: function(_, w) {
              var P = this._cipher, O = P.blockSize;
              D.call(this, _, w, O), P.encryptBlock(_, w), this._prevBlock = _.slice(w, w + O);
            }
          }), F.Decryptor = F.extend({
            /**
             * Processes the data block at offset.
             *
             * @param {Array} words The data words to operate on.
             * @param {number} offset The offset where the block starts.
             *
             * @example
             *
             *     mode.processBlock(data.words, offset);
             */
            processBlock: function(_, w) {
              var P = this._cipher, O = P.blockSize, W = _.slice(w, w + O);
              P.decryptBlock(_, w), D.call(this, _, w, O), this._prevBlock = W;
            }
          });
          function D(_, w, P) {
            var O, W = this._iv;
            W ? (O = W, this._iv = e) : O = this._prevBlock;
            for (var T = 0; T < P; T++)
              _[w + T] ^= O[T];
          }
          return F;
        })(), g = i.pad = {}, f = g.Pkcs7 = {
          /**
           * Pads data using the algorithm defined in PKCS #5/7.
           *
           * @param {WordArray} data The data to pad.
           * @param {number} blockSize The multiple that the data should be padded to.
           *
           * @static
           *
           * @example
           *
           *     CryptoJS.pad.Pkcs7.pad(wordArray, 4);
           */
          pad: function(F, D) {
            for (var _ = D * 4, w = _ - F.sigBytes % _, P = w << 24 | w << 16 | w << 8 | w, O = [], W = 0; W < w; W += 4)
              O.push(P);
            var T = d.create(O, w);
            F.concat(T);
          },
          /**
           * Unpads data that had been padded using the algorithm defined in PKCS #5/7.
           *
           * @param {WordArray} data The data to unpad.
           *
           * @static
           *
           * @example
           *
           *     CryptoJS.pad.Pkcs7.unpad(wordArray);
           */
          unpad: function(F) {
            var D = F.words[F.sigBytes - 1 >>> 2] & 255;
            F.sigBytes -= D;
          }
        };
        c.BlockCipher = h.extend({
          /**
           * Configuration options.
           *
           * @property {Mode} mode The block mode to use. Default: CBC
           * @property {Padding} padding The padding strategy to use. Default: Pkcs7
           */
          cfg: h.cfg.extend({
            mode: v,
            padding: f
          }),
          reset: function() {
            var F;
            h.reset.call(this);
            var D = this.cfg, _ = D.iv, w = D.mode;
            this._xformMode == this._ENC_XFORM_MODE ? F = w.createEncryptor : (F = w.createDecryptor, this._minBufferSize = 1), this._mode && this._mode.__creator == F ? this._mode.init(this, _ && _.words) : (this._mode = F.call(w, this, _ && _.words), this._mode.__creator = F);
          },
          _doProcessBlock: function(F, D) {
            this._mode.processBlock(F, D);
          },
          _doFinalize: function() {
            var F, D = this.cfg.padding;
            return this._xformMode == this._ENC_XFORM_MODE ? (D.pad(this._data, this.blockSize), F = this._process(!0)) : (F = this._process(!0), D.unpad(F)), F;
          },
          blockSize: 128 / 32
        });
        var u = c.CipherParams = A.extend({
          /**
           * Initializes a newly created cipher params object.
           *
           * @param {Object} cipherParams An object with any of the possible cipher parameters.
           *
           * @example
           *
           *     var cipherParams = CryptoJS.lib.CipherParams.create({
           *         ciphertext: ciphertextWordArray,
           *         key: keyWordArray,
           *         iv: ivWordArray,
           *         salt: saltWordArray,
           *         algorithm: CryptoJS.algo.AES,
           *         mode: CryptoJS.mode.CBC,
           *         padding: CryptoJS.pad.PKCS7,
           *         blockSize: 4,
           *         formatter: CryptoJS.format.OpenSSL
           *     });
           */
          init: function(F) {
            this.mixIn(F);
          },
          /**
           * Converts this cipher params object to a string.
           *
           * @param {Format} formatter (Optional) The formatting strategy to use.
           *
           * @return {string} The stringified cipher params.
           *
           * @throws Error If neither the formatter nor the default formatter is set.
           *
           * @example
           *
           *     var string = cipherParams + '';
           *     var string = cipherParams.toString();
           *     var string = cipherParams.toString(CryptoJS.format.OpenSSL);
           */
          toString: function(F) {
            return (F || this.formatter).stringify(this);
          }
        }), B = i.format = {}, m = B.OpenSSL = {
          /**
           * Converts a cipher params object to an OpenSSL-compatible string.
           *
           * @param {CipherParams} cipherParams The cipher params object.
           *
           * @return {string} The OpenSSL-compatible string.
           *
           * @static
           *
           * @example
           *
           *     var openSSLString = CryptoJS.format.OpenSSL.stringify(cipherParams);
           */
          stringify: function(F) {
            var D, _ = F.ciphertext, w = F.salt;
            return w ? D = d.create([1398893684, 1701076831]).concat(w).concat(_) : D = _, D.toString(t);
          },
          /**
           * Converts an OpenSSL-compatible string to a cipher params object.
           *
           * @param {string} openSSLStr The OpenSSL-compatible string.
           *
           * @return {CipherParams} The cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var cipherParams = CryptoJS.format.OpenSSL.parse(openSSLString);
           */
          parse: function(F) {
            var D, _ = t.parse(F), w = _.words;
            return w[0] == 1398893684 && w[1] == 1701076831 && (D = d.create(w.slice(2, 4)), w.splice(0, 4), _.sigBytes -= 16), u.create({ ciphertext: _, salt: D });
          }
        }, E = c.SerializableCipher = A.extend({
          /**
           * Configuration options.
           *
           * @property {Formatter} format The formatting strategy to convert cipher param objects to and from a string. Default: OpenSSL
           */
          cfg: A.extend({
            format: m
          }),
          /**
           * Encrypts a message.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {WordArray|string} message The message to encrypt.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {CipherParams} A cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           */
          encrypt: function(F, D, _, w) {
            w = this.cfg.extend(w);
            var P = F.createEncryptor(_, w), O = P.finalize(D), W = P.cfg;
            return u.create({
              ciphertext: O,
              key: _,
              iv: W.iv,
              algorithm: F,
              mode: W.mode,
              padding: W.padding,
              blockSize: F.blockSize,
              formatter: w.format
            });
          },
          /**
           * Decrypts serialized ciphertext.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {WordArray} The plaintext.
           *
           * @static
           *
           * @example
           *
           *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           */
          decrypt: function(F, D, _, w) {
            w = this.cfg.extend(w), D = this._parse(D, w.format);
            var P = F.createDecryptor(_, w).finalize(D.ciphertext);
            return P;
          },
          /**
           * Converts serialized ciphertext to CipherParams,
           * else assumed CipherParams already and returns ciphertext unchanged.
           *
           * @param {CipherParams|string} ciphertext The ciphertext.
           * @param {Formatter} format The formatting strategy to use to parse serialized ciphertext.
           *
           * @return {CipherParams} The unserialized ciphertext.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);
           */
          _parse: function(F, D) {
            return typeof F == "string" ? D.parse(F, this) : F;
          }
        }), y = i.kdf = {}, b = y.OpenSSL = {
          /**
           * Derives a key and IV from a password.
           *
           * @param {string} password The password to derive from.
           * @param {number} keySize The size in words of the key to generate.
           * @param {number} ivSize The size in words of the IV to generate.
           * @param {WordArray|string} salt (Optional) A 64-bit salt to use. If omitted, a salt will be generated randomly.
           *
           * @return {CipherParams} A cipher params object with the key, IV, and salt.
           *
           * @static
           *
           * @example
           *
           *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32);
           *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32, 'saltsalt');
           */
          execute: function(F, D, _, w, P) {
            if (w || (w = d.random(64 / 8)), P)
              var O = s.create({ keySize: D + _, hasher: P }).compute(F, w);
            else
              var O = s.create({ keySize: D + _ }).compute(F, w);
            var W = d.create(O.words.slice(D), _ * 4);
            return O.sigBytes = D * 4, u.create({ key: O, iv: W, salt: w });
          }
        }, S = c.PasswordBasedCipher = E.extend({
          /**
           * Configuration options.
           *
           * @property {KDF} kdf The key derivation function to use to generate a key and IV from a password. Default: OpenSSL
           */
          cfg: E.cfg.extend({
            kdf: b
          }),
          /**
           * Encrypts a message using a password.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {WordArray|string} message The message to encrypt.
           * @param {string} password The password.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {CipherParams} A cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password');
           *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password', { format: CryptoJS.format.OpenSSL });
           */
          encrypt: function(F, D, _, w) {
            w = this.cfg.extend(w);
            var P = w.kdf.execute(_, F.keySize, F.ivSize, w.salt, w.hasher);
            w.iv = P.iv;
            var O = E.encrypt.call(this, F, D, P.key, w);
            return O.mixIn(P), O;
          },
          /**
           * Decrypts serialized ciphertext using a password.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
           * @param {string} password The password.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {WordArray} The plaintext.
           *
           * @static
           *
           * @example
           *
           *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, 'password', { format: CryptoJS.format.OpenSSL });
           *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, 'password', { format: CryptoJS.format.OpenSSL });
           */
          decrypt: function(F, D, _, w) {
            w = this.cfg.extend(w), D = this._parse(D, w.format);
            var P = w.kdf.execute(_, F.keySize, F.ivSize, D.salt, w.hasher);
            w.iv = P.iv;
            var O = E.decrypt.call(this, F, D, P.key, w);
            return O;
          }
        });
      })();
    });
  })(X0)), X0.exports;
}
var j0 = { exports: {} }, wa = j0.exports, ir;
function ka() {
  return ir || (ir = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(wa, function(r) {
      return r.mode.CFB = (function() {
        var e = r.lib.BlockCipherMode.extend();
        e.Encryptor = e.extend({
          processBlock: function(c, A) {
            var d = this._cipher, x = d.blockSize;
            i.call(this, c, A, x, d), this._prevBlock = c.slice(A, A + x);
          }
        }), e.Decryptor = e.extend({
          processBlock: function(c, A) {
            var d = this._cipher, x = d.blockSize, a = c.slice(A, A + x);
            i.call(this, c, A, x, d), this._prevBlock = a;
          }
        });
        function i(c, A, d, x) {
          var a, t = this._iv;
          t ? (a = t.slice(0), this._iv = void 0) : a = this._prevBlock, x.encryptBlock(a, 0);
          for (var l = 0; l < d; l++)
            c[A + l] ^= a[l];
        }
        return e;
      })(), r.mode.CFB;
    });
  })(j0)), j0.exports;
}
var K0 = { exports: {} }, Sa = K0.exports, sr;
function Ma() {
  return sr || (sr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Sa, function(r) {
      return r.mode.CTR = (function() {
        var e = r.lib.BlockCipherMode.extend(), i = e.Encryptor = e.extend({
          processBlock: function(c, A) {
            var d = this._cipher, x = d.blockSize, a = this._iv, t = this._counter;
            a && (t = this._counter = a.slice(0), this._iv = void 0);
            var l = t.slice(0);
            d.encryptBlock(l, 0), t[x - 1] = t[x - 1] + 1 | 0;
            for (var s = 0; s < x; s++)
              c[A + s] ^= l[s];
          }
        });
        return e.Decryptor = i, e;
      })(), r.mode.CTR;
    });
  })(K0)), K0.exports;
}
var Y0 = { exports: {} }, Ra = Y0.exports, xr;
function za() {
  return xr || (xr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Ra, function(r) {
      /** @preserve
       * Counter block mode compatible with  Dr Brian Gladman fileenc.c
       * derived from CryptoJS.mode.CTR
       * Jan Hruby jhruby.web@gmail.com
       */
      return r.mode.CTRGladman = (function() {
        var e = r.lib.BlockCipherMode.extend();
        function i(d) {
          if ((d >> 24 & 255) === 255) {
            var x = d >> 16 & 255, a = d >> 8 & 255, t = d & 255;
            x === 255 ? (x = 0, a === 255 ? (a = 0, t === 255 ? t = 0 : ++t) : ++a) : ++x, d = 0, d += x << 16, d += a << 8, d += t;
          } else
            d += 1 << 24;
          return d;
        }
        function c(d) {
          return (d[0] = i(d[0])) === 0 && (d[1] = i(d[1])), d;
        }
        var A = e.Encryptor = e.extend({
          processBlock: function(d, x) {
            var a = this._cipher, t = a.blockSize, l = this._iv, s = this._counter;
            l && (s = this._counter = l.slice(0), this._iv = void 0), c(s);
            var h = s.slice(0);
            a.encryptBlock(h, 0);
            for (var p = 0; p < t; p++)
              d[x + p] ^= h[p];
          }
        });
        return e.Decryptor = A, e;
      })(), r.mode.CTRGladman;
    });
  })(Y0)), Y0.exports;
}
var Z0 = { exports: {} }, Ha = Z0.exports, cr;
function Pa() {
  return cr || (cr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Ha, function(r) {
      return r.mode.OFB = (function() {
        var e = r.lib.BlockCipherMode.extend(), i = e.Encryptor = e.extend({
          processBlock: function(c, A) {
            var d = this._cipher, x = d.blockSize, a = this._iv, t = this._keystream;
            a && (t = this._keystream = a.slice(0), this._iv = void 0), d.encryptBlock(t, 0);
            for (var l = 0; l < x; l++)
              c[A + l] ^= t[l];
          }
        });
        return e.Decryptor = i, e;
      })(), r.mode.OFB;
    });
  })(Z0)), Z0.exports;
}
var Q0 = { exports: {} }, Oa = Q0.exports, fr;
function Wa() {
  return fr || (fr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Oa, function(r) {
      return r.mode.ECB = (function() {
        var e = r.lib.BlockCipherMode.extend();
        return e.Encryptor = e.extend({
          processBlock: function(i, c) {
            this._cipher.encryptBlock(i, c);
          }
        }), e.Decryptor = e.extend({
          processBlock: function(i, c) {
            this._cipher.decryptBlock(i, c);
          }
        }), e;
      })(), r.mode.ECB;
    });
  })(Q0)), Q0.exports;
}
var J0 = { exports: {} }, Ta = J0.exports, lr;
function qa() {
  return lr || (lr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Ta, function(r) {
      return r.pad.AnsiX923 = {
        pad: function(e, i) {
          var c = e.sigBytes, A = i * 4, d = A - c % A, x = c + d - 1;
          e.clamp(), e.words[x >>> 2] |= d << 24 - x % 4 * 8, e.sigBytes += d;
        },
        unpad: function(e) {
          var i = e.words[e.sigBytes - 1 >>> 2] & 255;
          e.sigBytes -= i;
        }
      }, r.pad.Ansix923;
    });
  })(J0)), J0.exports;
}
var ee = { exports: {} }, Ia = ee.exports, hr;
function La() {
  return hr || (hr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Ia, function(r) {
      return r.pad.Iso10126 = {
        pad: function(e, i) {
          var c = i * 4, A = c - e.sigBytes % c;
          e.concat(r.lib.WordArray.random(A - 1)).concat(r.lib.WordArray.create([A << 24], 1));
        },
        unpad: function(e) {
          var i = e.words[e.sigBytes - 1 >>> 2] & 255;
          e.sigBytes -= i;
        }
      }, r.pad.Iso10126;
    });
  })(ee)), ee.exports;
}
var re = { exports: {} }, Ga = re.exports, ur;
function Ua() {
  return ur || (ur = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Ga, function(r) {
      return r.pad.Iso97971 = {
        pad: function(e, i) {
          e.concat(r.lib.WordArray.create([2147483648], 1)), r.pad.ZeroPadding.pad(e, i);
        },
        unpad: function(e) {
          r.pad.ZeroPadding.unpad(e), e.sigBytes--;
        }
      }, r.pad.Iso97971;
    });
  })(re)), re.exports;
}
var te = { exports: {} }, $a = te.exports, dr;
function Na() {
  return dr || (dr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })($a, function(r) {
      return r.pad.ZeroPadding = {
        pad: function(e, i) {
          var c = i * 4;
          e.clamp(), e.sigBytes += c - (e.sigBytes % c || c);
        },
        unpad: function(e) {
          for (var i = e.words, c = e.sigBytes - 1, c = e.sigBytes - 1; c >= 0; c--)
            if (i[c >>> 2] >>> 24 - c % 4 * 8 & 255) {
              e.sigBytes = c + 1;
              break;
            }
        }
      }, r.pad.ZeroPadding;
    });
  })(te)), te.exports;
}
var ae = { exports: {} }, Va = ae.exports, vr;
function Xa() {
  return vr || (vr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(Va, function(r) {
      return r.pad.NoPadding = {
        pad: function() {
        },
        unpad: function() {
        }
      }, r.pad.NoPadding;
    });
  })(ae)), ae.exports;
}
var ne = { exports: {} }, ja = ne.exports, pr;
function Ka() {
  return pr || (pr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), j());
    })(ja, function(r) {
      return (function(e) {
        var i = r, c = i.lib, A = c.CipherParams, d = i.enc, x = d.Hex, a = i.format;
        a.Hex = {
          /**
           * Converts the ciphertext of a cipher params object to a hexadecimally encoded string.
           *
           * @param {CipherParams} cipherParams The cipher params object.
           *
           * @return {string} The hexadecimally encoded string.
           *
           * @static
           *
           * @example
           *
           *     var hexString = CryptoJS.format.Hex.stringify(cipherParams);
           */
          stringify: function(t) {
            return t.ciphertext.toString(x);
          },
          /**
           * Converts a hexadecimally encoded ciphertext string to a cipher params object.
           *
           * @param {string} input The hexadecimally encoded string.
           *
           * @return {CipherParams} The cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var cipherParams = CryptoJS.format.Hex.parse(hexString);
           */
          parse: function(t) {
            var l = x.parse(t);
            return A.create({ ciphertext: l });
          }
        };
      })(), r.format.Hex;
    });
  })(ne)), ne.exports;
}
var oe = { exports: {} }, Ya = oe.exports, Br;
function Za() {
  return Br || (Br = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), h0(), u0(), l0(), j());
    })(Ya, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.BlockCipher, A = e.algo, d = [], x = [], a = [], t = [], l = [], s = [], h = [], p = [], C = [], v = [];
        (function() {
          for (var u = [], B = 0; B < 256; B++)
            B < 128 ? u[B] = B << 1 : u[B] = B << 1 ^ 283;
          for (var m = 0, E = 0, B = 0; B < 256; B++) {
            var y = E ^ E << 1 ^ E << 2 ^ E << 3 ^ E << 4;
            y = y >>> 8 ^ y & 255 ^ 99, d[m] = y, x[y] = m;
            var b = u[m], S = u[b], F = u[S], D = u[y] * 257 ^ y * 16843008;
            a[m] = D << 24 | D >>> 8, t[m] = D << 16 | D >>> 16, l[m] = D << 8 | D >>> 24, s[m] = D;
            var D = F * 16843009 ^ S * 65537 ^ b * 257 ^ m * 16843008;
            h[y] = D << 24 | D >>> 8, p[y] = D << 16 | D >>> 16, C[y] = D << 8 | D >>> 24, v[y] = D, m ? (m = b ^ u[u[u[F ^ b]]], E ^= u[u[E]]) : m = E = 1;
          }
        })();
        var g = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], f = A.AES = c.extend({
          _doReset: function() {
            var u;
            if (!(this._nRounds && this._keyPriorReset === this._key)) {
              for (var B = this._keyPriorReset = this._key, m = B.words, E = B.sigBytes / 4, y = this._nRounds = E + 6, b = (y + 1) * 4, S = this._keySchedule = [], F = 0; F < b; F++)
                F < E ? S[F] = m[F] : (u = S[F - 1], F % E ? E > 6 && F % E == 4 && (u = d[u >>> 24] << 24 | d[u >>> 16 & 255] << 16 | d[u >>> 8 & 255] << 8 | d[u & 255]) : (u = u << 8 | u >>> 24, u = d[u >>> 24] << 24 | d[u >>> 16 & 255] << 16 | d[u >>> 8 & 255] << 8 | d[u & 255], u ^= g[F / E | 0] << 24), S[F] = S[F - E] ^ u);
              for (var D = this._invKeySchedule = [], _ = 0; _ < b; _++) {
                var F = b - _;
                if (_ % 4)
                  var u = S[F];
                else
                  var u = S[F - 4];
                _ < 4 || F <= 4 ? D[_] = u : D[_] = h[d[u >>> 24]] ^ p[d[u >>> 16 & 255]] ^ C[d[u >>> 8 & 255]] ^ v[d[u & 255]];
              }
            }
          },
          encryptBlock: function(u, B) {
            this._doCryptBlock(u, B, this._keySchedule, a, t, l, s, d);
          },
          decryptBlock: function(u, B) {
            var m = u[B + 1];
            u[B + 1] = u[B + 3], u[B + 3] = m, this._doCryptBlock(u, B, this._invKeySchedule, h, p, C, v, x);
            var m = u[B + 1];
            u[B + 1] = u[B + 3], u[B + 3] = m;
          },
          _doCryptBlock: function(u, B, m, E, y, b, S, F) {
            for (var D = this._nRounds, _ = u[B] ^ m[0], w = u[B + 1] ^ m[1], P = u[B + 2] ^ m[2], O = u[B + 3] ^ m[3], W = 4, T = 1; T < D; T++) {
              var G = E[_ >>> 24] ^ y[w >>> 16 & 255] ^ b[P >>> 8 & 255] ^ S[O & 255] ^ m[W++], I = E[w >>> 24] ^ y[P >>> 16 & 255] ^ b[O >>> 8 & 255] ^ S[_ & 255] ^ m[W++], U = E[P >>> 24] ^ y[O >>> 16 & 255] ^ b[_ >>> 8 & 255] ^ S[w & 255] ^ m[W++], M = E[O >>> 24] ^ y[_ >>> 16 & 255] ^ b[w >>> 8 & 255] ^ S[P & 255] ^ m[W++];
              _ = G, w = I, P = U, O = M;
            }
            var G = (F[_ >>> 24] << 24 | F[w >>> 16 & 255] << 16 | F[P >>> 8 & 255] << 8 | F[O & 255]) ^ m[W++], I = (F[w >>> 24] << 24 | F[P >>> 16 & 255] << 16 | F[O >>> 8 & 255] << 8 | F[_ & 255]) ^ m[W++], U = (F[P >>> 24] << 24 | F[O >>> 16 & 255] << 16 | F[_ >>> 8 & 255] << 8 | F[w & 255]) ^ m[W++], M = (F[O >>> 24] << 24 | F[_ >>> 16 & 255] << 16 | F[w >>> 8 & 255] << 8 | F[P & 255]) ^ m[W++];
            u[B] = G, u[B + 1] = I, u[B + 2] = U, u[B + 3] = M;
          },
          keySize: 256 / 32
        });
        e.AES = c._createHelper(f);
      })(), r.AES;
    });
  })(oe)), oe.exports;
}
var ie = { exports: {} }, Qa = ie.exports, Cr;
function Ja() {
  return Cr || (Cr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), h0(), u0(), l0(), j());
    })(Qa, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.WordArray, A = i.BlockCipher, d = e.algo, x = [
          57,
          49,
          41,
          33,
          25,
          17,
          9,
          1,
          58,
          50,
          42,
          34,
          26,
          18,
          10,
          2,
          59,
          51,
          43,
          35,
          27,
          19,
          11,
          3,
          60,
          52,
          44,
          36,
          63,
          55,
          47,
          39,
          31,
          23,
          15,
          7,
          62,
          54,
          46,
          38,
          30,
          22,
          14,
          6,
          61,
          53,
          45,
          37,
          29,
          21,
          13,
          5,
          28,
          20,
          12,
          4
        ], a = [
          14,
          17,
          11,
          24,
          1,
          5,
          3,
          28,
          15,
          6,
          21,
          10,
          23,
          19,
          12,
          4,
          26,
          8,
          16,
          7,
          27,
          20,
          13,
          2,
          41,
          52,
          31,
          37,
          47,
          55,
          30,
          40,
          51,
          45,
          33,
          48,
          44,
          49,
          39,
          56,
          34,
          53,
          46,
          42,
          50,
          36,
          29,
          32
        ], t = [1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28], l = [
          {
            0: 8421888,
            268435456: 32768,
            536870912: 8421378,
            805306368: 2,
            1073741824: 512,
            1342177280: 8421890,
            1610612736: 8389122,
            1879048192: 8388608,
            2147483648: 514,
            2415919104: 8389120,
            2684354560: 33280,
            2952790016: 8421376,
            3221225472: 32770,
            3489660928: 8388610,
            3758096384: 0,
            4026531840: 33282,
            134217728: 0,
            402653184: 8421890,
            671088640: 33282,
            939524096: 32768,
            1207959552: 8421888,
            1476395008: 512,
            1744830464: 8421378,
            2013265920: 2,
            2281701376: 8389120,
            2550136832: 33280,
            2818572288: 8421376,
            3087007744: 8389122,
            3355443200: 8388610,
            3623878656: 32770,
            3892314112: 514,
            4160749568: 8388608,
            1: 32768,
            268435457: 2,
            536870913: 8421888,
            805306369: 8388608,
            1073741825: 8421378,
            1342177281: 33280,
            1610612737: 512,
            1879048193: 8389122,
            2147483649: 8421890,
            2415919105: 8421376,
            2684354561: 8388610,
            2952790017: 33282,
            3221225473: 514,
            3489660929: 8389120,
            3758096385: 32770,
            4026531841: 0,
            134217729: 8421890,
            402653185: 8421376,
            671088641: 8388608,
            939524097: 512,
            1207959553: 32768,
            1476395009: 8388610,
            1744830465: 2,
            2013265921: 33282,
            2281701377: 32770,
            2550136833: 8389122,
            2818572289: 514,
            3087007745: 8421888,
            3355443201: 8389120,
            3623878657: 0,
            3892314113: 33280,
            4160749569: 8421378
          },
          {
            0: 1074282512,
            16777216: 16384,
            33554432: 524288,
            50331648: 1074266128,
            67108864: 1073741840,
            83886080: 1074282496,
            100663296: 1073758208,
            117440512: 16,
            134217728: 540672,
            150994944: 1073758224,
            167772160: 1073741824,
            184549376: 540688,
            201326592: 524304,
            218103808: 0,
            234881024: 16400,
            251658240: 1074266112,
            8388608: 1073758208,
            25165824: 540688,
            41943040: 16,
            58720256: 1073758224,
            75497472: 1074282512,
            92274688: 1073741824,
            109051904: 524288,
            125829120: 1074266128,
            142606336: 524304,
            159383552: 0,
            176160768: 16384,
            192937984: 1074266112,
            209715200: 1073741840,
            226492416: 540672,
            243269632: 1074282496,
            260046848: 16400,
            268435456: 0,
            285212672: 1074266128,
            301989888: 1073758224,
            318767104: 1074282496,
            335544320: 1074266112,
            352321536: 16,
            369098752: 540688,
            385875968: 16384,
            402653184: 16400,
            419430400: 524288,
            436207616: 524304,
            452984832: 1073741840,
            469762048: 540672,
            486539264: 1073758208,
            503316480: 1073741824,
            520093696: 1074282512,
            276824064: 540688,
            293601280: 524288,
            310378496: 1074266112,
            327155712: 16384,
            343932928: 1073758208,
            360710144: 1074282512,
            377487360: 16,
            394264576: 1073741824,
            411041792: 1074282496,
            427819008: 1073741840,
            444596224: 1073758224,
            461373440: 524304,
            478150656: 0,
            494927872: 16400,
            511705088: 1074266128,
            528482304: 540672
          },
          {
            0: 260,
            1048576: 0,
            2097152: 67109120,
            3145728: 65796,
            4194304: 65540,
            5242880: 67108868,
            6291456: 67174660,
            7340032: 67174400,
            8388608: 67108864,
            9437184: 67174656,
            10485760: 65792,
            11534336: 67174404,
            12582912: 67109124,
            13631488: 65536,
            14680064: 4,
            15728640: 256,
            524288: 67174656,
            1572864: 67174404,
            2621440: 0,
            3670016: 67109120,
            4718592: 67108868,
            5767168: 65536,
            6815744: 65540,
            7864320: 260,
            8912896: 4,
            9961472: 256,
            11010048: 67174400,
            12058624: 65796,
            13107200: 65792,
            14155776: 67109124,
            15204352: 67174660,
            16252928: 67108864,
            16777216: 67174656,
            17825792: 65540,
            18874368: 65536,
            19922944: 67109120,
            20971520: 256,
            22020096: 67174660,
            23068672: 67108868,
            24117248: 0,
            25165824: 67109124,
            26214400: 67108864,
            27262976: 4,
            28311552: 65792,
            29360128: 67174400,
            30408704: 260,
            31457280: 65796,
            32505856: 67174404,
            17301504: 67108864,
            18350080: 260,
            19398656: 67174656,
            20447232: 0,
            21495808: 65540,
            22544384: 67109120,
            23592960: 256,
            24641536: 67174404,
            25690112: 65536,
            26738688: 67174660,
            27787264: 65796,
            28835840: 67108868,
            29884416: 67109124,
            30932992: 67174400,
            31981568: 4,
            33030144: 65792
          },
          {
            0: 2151682048,
            65536: 2147487808,
            131072: 4198464,
            196608: 2151677952,
            262144: 0,
            327680: 4198400,
            393216: 2147483712,
            458752: 4194368,
            524288: 2147483648,
            589824: 4194304,
            655360: 64,
            720896: 2147487744,
            786432: 2151678016,
            851968: 4160,
            917504: 4096,
            983040: 2151682112,
            32768: 2147487808,
            98304: 64,
            163840: 2151678016,
            229376: 2147487744,
            294912: 4198400,
            360448: 2151682112,
            425984: 0,
            491520: 2151677952,
            557056: 4096,
            622592: 2151682048,
            688128: 4194304,
            753664: 4160,
            819200: 2147483648,
            884736: 4194368,
            950272: 4198464,
            1015808: 2147483712,
            1048576: 4194368,
            1114112: 4198400,
            1179648: 2147483712,
            1245184: 0,
            1310720: 4160,
            1376256: 2151678016,
            1441792: 2151682048,
            1507328: 2147487808,
            1572864: 2151682112,
            1638400: 2147483648,
            1703936: 2151677952,
            1769472: 4198464,
            1835008: 2147487744,
            1900544: 4194304,
            1966080: 64,
            2031616: 4096,
            1081344: 2151677952,
            1146880: 2151682112,
            1212416: 0,
            1277952: 4198400,
            1343488: 4194368,
            1409024: 2147483648,
            1474560: 2147487808,
            1540096: 64,
            1605632: 2147483712,
            1671168: 4096,
            1736704: 2147487744,
            1802240: 2151678016,
            1867776: 4160,
            1933312: 2151682048,
            1998848: 4194304,
            2064384: 4198464
          },
          {
            0: 128,
            4096: 17039360,
            8192: 262144,
            12288: 536870912,
            16384: 537133184,
            20480: 16777344,
            24576: 553648256,
            28672: 262272,
            32768: 16777216,
            36864: 537133056,
            40960: 536871040,
            45056: 553910400,
            49152: 553910272,
            53248: 0,
            57344: 17039488,
            61440: 553648128,
            2048: 17039488,
            6144: 553648256,
            10240: 128,
            14336: 17039360,
            18432: 262144,
            22528: 537133184,
            26624: 553910272,
            30720: 536870912,
            34816: 537133056,
            38912: 0,
            43008: 553910400,
            47104: 16777344,
            51200: 536871040,
            55296: 553648128,
            59392: 16777216,
            63488: 262272,
            65536: 262144,
            69632: 128,
            73728: 536870912,
            77824: 553648256,
            81920: 16777344,
            86016: 553910272,
            90112: 537133184,
            94208: 16777216,
            98304: 553910400,
            102400: 553648128,
            106496: 17039360,
            110592: 537133056,
            114688: 262272,
            118784: 536871040,
            122880: 0,
            126976: 17039488,
            67584: 553648256,
            71680: 16777216,
            75776: 17039360,
            79872: 537133184,
            83968: 536870912,
            88064: 17039488,
            92160: 128,
            96256: 553910272,
            100352: 262272,
            104448: 553910400,
            108544: 0,
            112640: 553648128,
            116736: 16777344,
            120832: 262144,
            124928: 537133056,
            129024: 536871040
          },
          {
            0: 268435464,
            256: 8192,
            512: 270532608,
            768: 270540808,
            1024: 268443648,
            1280: 2097152,
            1536: 2097160,
            1792: 268435456,
            2048: 0,
            2304: 268443656,
            2560: 2105344,
            2816: 8,
            3072: 270532616,
            3328: 2105352,
            3584: 8200,
            3840: 270540800,
            128: 270532608,
            384: 270540808,
            640: 8,
            896: 2097152,
            1152: 2105352,
            1408: 268435464,
            1664: 268443648,
            1920: 8200,
            2176: 2097160,
            2432: 8192,
            2688: 268443656,
            2944: 270532616,
            3200: 0,
            3456: 270540800,
            3712: 2105344,
            3968: 268435456,
            4096: 268443648,
            4352: 270532616,
            4608: 270540808,
            4864: 8200,
            5120: 2097152,
            5376: 268435456,
            5632: 268435464,
            5888: 2105344,
            6144: 2105352,
            6400: 0,
            6656: 8,
            6912: 270532608,
            7168: 8192,
            7424: 268443656,
            7680: 270540800,
            7936: 2097160,
            4224: 8,
            4480: 2105344,
            4736: 2097152,
            4992: 268435464,
            5248: 268443648,
            5504: 8200,
            5760: 270540808,
            6016: 270532608,
            6272: 270540800,
            6528: 270532616,
            6784: 8192,
            7040: 2105352,
            7296: 2097160,
            7552: 0,
            7808: 268435456,
            8064: 268443656
          },
          {
            0: 1048576,
            16: 33555457,
            32: 1024,
            48: 1049601,
            64: 34604033,
            80: 0,
            96: 1,
            112: 34603009,
            128: 33555456,
            144: 1048577,
            160: 33554433,
            176: 34604032,
            192: 34603008,
            208: 1025,
            224: 1049600,
            240: 33554432,
            8: 34603009,
            24: 0,
            40: 33555457,
            56: 34604032,
            72: 1048576,
            88: 33554433,
            104: 33554432,
            120: 1025,
            136: 1049601,
            152: 33555456,
            168: 34603008,
            184: 1048577,
            200: 1024,
            216: 34604033,
            232: 1,
            248: 1049600,
            256: 33554432,
            272: 1048576,
            288: 33555457,
            304: 34603009,
            320: 1048577,
            336: 33555456,
            352: 34604032,
            368: 1049601,
            384: 1025,
            400: 34604033,
            416: 1049600,
            432: 1,
            448: 0,
            464: 34603008,
            480: 33554433,
            496: 1024,
            264: 1049600,
            280: 33555457,
            296: 34603009,
            312: 1,
            328: 33554432,
            344: 1048576,
            360: 1025,
            376: 34604032,
            392: 33554433,
            408: 34603008,
            424: 0,
            440: 34604033,
            456: 1049601,
            472: 1024,
            488: 33555456,
            504: 1048577
          },
          {
            0: 134219808,
            1: 131072,
            2: 134217728,
            3: 32,
            4: 131104,
            5: 134350880,
            6: 134350848,
            7: 2048,
            8: 134348800,
            9: 134219776,
            10: 133120,
            11: 134348832,
            12: 2080,
            13: 0,
            14: 134217760,
            15: 133152,
            2147483648: 2048,
            2147483649: 134350880,
            2147483650: 134219808,
            2147483651: 134217728,
            2147483652: 134348800,
            2147483653: 133120,
            2147483654: 133152,
            2147483655: 32,
            2147483656: 134217760,
            2147483657: 2080,
            2147483658: 131104,
            2147483659: 134350848,
            2147483660: 0,
            2147483661: 134348832,
            2147483662: 134219776,
            2147483663: 131072,
            16: 133152,
            17: 134350848,
            18: 32,
            19: 2048,
            20: 134219776,
            21: 134217760,
            22: 134348832,
            23: 131072,
            24: 0,
            25: 131104,
            26: 134348800,
            27: 134219808,
            28: 134350880,
            29: 133120,
            30: 2080,
            31: 134217728,
            2147483664: 131072,
            2147483665: 2048,
            2147483666: 134348832,
            2147483667: 133152,
            2147483668: 32,
            2147483669: 134348800,
            2147483670: 134217728,
            2147483671: 134219808,
            2147483672: 134350880,
            2147483673: 134217760,
            2147483674: 134219776,
            2147483675: 0,
            2147483676: 133120,
            2147483677: 2080,
            2147483678: 131104,
            2147483679: 134350848
          }
        ], s = [
          4160749569,
          528482304,
          33030144,
          2064384,
          129024,
          8064,
          504,
          2147483679
        ], h = d.DES = A.extend({
          _doReset: function() {
            for (var g = this._key, f = g.words, u = [], B = 0; B < 56; B++) {
              var m = x[B] - 1;
              u[B] = f[m >>> 5] >>> 31 - m % 32 & 1;
            }
            for (var E = this._subKeys = [], y = 0; y < 16; y++) {
              for (var b = E[y] = [], S = t[y], B = 0; B < 24; B++)
                b[B / 6 | 0] |= u[(a[B] - 1 + S) % 28] << 31 - B % 6, b[4 + (B / 6 | 0)] |= u[28 + (a[B + 24] - 1 + S) % 28] << 31 - B % 6;
              b[0] = b[0] << 1 | b[0] >>> 31;
              for (var B = 1; B < 7; B++)
                b[B] = b[B] >>> (B - 1) * 4 + 3;
              b[7] = b[7] << 5 | b[7] >>> 27;
            }
            for (var F = this._invSubKeys = [], B = 0; B < 16; B++)
              F[B] = E[15 - B];
          },
          encryptBlock: function(g, f) {
            this._doCryptBlock(g, f, this._subKeys);
          },
          decryptBlock: function(g, f) {
            this._doCryptBlock(g, f, this._invSubKeys);
          },
          _doCryptBlock: function(g, f, u) {
            this._lBlock = g[f], this._rBlock = g[f + 1], p.call(this, 4, 252645135), p.call(this, 16, 65535), C.call(this, 2, 858993459), C.call(this, 8, 16711935), p.call(this, 1, 1431655765);
            for (var B = 0; B < 16; B++) {
              for (var m = u[B], E = this._lBlock, y = this._rBlock, b = 0, S = 0; S < 8; S++)
                b |= l[S][((y ^ m[S]) & s[S]) >>> 0];
              this._lBlock = y, this._rBlock = E ^ b;
            }
            var F = this._lBlock;
            this._lBlock = this._rBlock, this._rBlock = F, p.call(this, 1, 1431655765), C.call(this, 8, 16711935), C.call(this, 2, 858993459), p.call(this, 16, 65535), p.call(this, 4, 252645135), g[f] = this._lBlock, g[f + 1] = this._rBlock;
          },
          keySize: 64 / 32,
          ivSize: 64 / 32,
          blockSize: 64 / 32
        });
        function p(g, f) {
          var u = (this._lBlock >>> g ^ this._rBlock) & f;
          this._rBlock ^= u, this._lBlock ^= u << g;
        }
        function C(g, f) {
          var u = (this._rBlock >>> g ^ this._lBlock) & f;
          this._lBlock ^= u, this._rBlock ^= u << g;
        }
        e.DES = A._createHelper(h);
        var v = d.TripleDES = A.extend({
          _doReset: function() {
            var g = this._key, f = g.words;
            if (f.length !== 2 && f.length !== 4 && f.length < 6)
              throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");
            var u = f.slice(0, 2), B = f.length < 4 ? f.slice(0, 2) : f.slice(2, 4), m = f.length < 6 ? f.slice(0, 2) : f.slice(4, 6);
            this._des1 = h.createEncryptor(c.create(u)), this._des2 = h.createEncryptor(c.create(B)), this._des3 = h.createEncryptor(c.create(m));
          },
          encryptBlock: function(g, f) {
            this._des1.encryptBlock(g, f), this._des2.decryptBlock(g, f), this._des3.encryptBlock(g, f);
          },
          decryptBlock: function(g, f) {
            this._des3.decryptBlock(g, f), this._des2.encryptBlock(g, f), this._des1.decryptBlock(g, f);
          },
          keySize: 192 / 32,
          ivSize: 64 / 32,
          blockSize: 64 / 32
        });
        e.TripleDES = A._createHelper(v);
      })(), r.TripleDES;
    });
  })(ie)), ie.exports;
}
var se = { exports: {} }, en = se.exports, mr;
function rn() {
  return mr || (mr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), h0(), u0(), l0(), j());
    })(en, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.StreamCipher, A = e.algo, d = A.RC4 = c.extend({
          _doReset: function() {
            for (var t = this._key, l = t.words, s = t.sigBytes, h = this._S = [], p = 0; p < 256; p++)
              h[p] = p;
            for (var p = 0, C = 0; p < 256; p++) {
              var v = p % s, g = l[v >>> 2] >>> 24 - v % 4 * 8 & 255;
              C = (C + h[p] + g) % 256;
              var f = h[p];
              h[p] = h[C], h[C] = f;
            }
            this._i = this._j = 0;
          },
          _doProcessBlock: function(t, l) {
            t[l] ^= x.call(this);
          },
          keySize: 256 / 32,
          ivSize: 0
        });
        function x() {
          for (var t = this._S, l = this._i, s = this._j, h = 0, p = 0; p < 4; p++) {
            l = (l + 1) % 256, s = (s + t[l]) % 256;
            var C = t[l];
            t[l] = t[s], t[s] = C, h |= t[(t[l] + t[s]) % 256] << 24 - p * 8;
          }
          return this._i = l, this._j = s, h;
        }
        e.RC4 = c._createHelper(d);
        var a = A.RC4Drop = d.extend({
          /**
           * Configuration options.
           *
           * @property {number} drop The number of keystream words to drop. Default 192
           */
          cfg: d.cfg.extend({
            drop: 192
          }),
          _doReset: function() {
            d._doReset.call(this);
            for (var t = this.cfg.drop; t > 0; t--)
              x.call(this);
          }
        });
        e.RC4Drop = c._createHelper(a);
      })(), r.RC4;
    });
  })(se)), se.exports;
}
var xe = { exports: {} }, tn = xe.exports, Ar;
function an() {
  return Ar || (Ar = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), h0(), u0(), l0(), j());
    })(tn, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.StreamCipher, A = e.algo, d = [], x = [], a = [], t = A.Rabbit = c.extend({
          _doReset: function() {
            for (var s = this._key.words, h = this.cfg.iv, p = 0; p < 4; p++)
              s[p] = (s[p] << 8 | s[p] >>> 24) & 16711935 | (s[p] << 24 | s[p] >>> 8) & 4278255360;
            var C = this._X = [
              s[0],
              s[3] << 16 | s[2] >>> 16,
              s[1],
              s[0] << 16 | s[3] >>> 16,
              s[2],
              s[1] << 16 | s[0] >>> 16,
              s[3],
              s[2] << 16 | s[1] >>> 16
            ], v = this._C = [
              s[2] << 16 | s[2] >>> 16,
              s[0] & 4294901760 | s[1] & 65535,
              s[3] << 16 | s[3] >>> 16,
              s[1] & 4294901760 | s[2] & 65535,
              s[0] << 16 | s[0] >>> 16,
              s[2] & 4294901760 | s[3] & 65535,
              s[1] << 16 | s[1] >>> 16,
              s[3] & 4294901760 | s[0] & 65535
            ];
            this._b = 0;
            for (var p = 0; p < 4; p++)
              l.call(this);
            for (var p = 0; p < 8; p++)
              v[p] ^= C[p + 4 & 7];
            if (h) {
              var g = h.words, f = g[0], u = g[1], B = (f << 8 | f >>> 24) & 16711935 | (f << 24 | f >>> 8) & 4278255360, m = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360, E = B >>> 16 | m & 4294901760, y = m << 16 | B & 65535;
              v[0] ^= B, v[1] ^= E, v[2] ^= m, v[3] ^= y, v[4] ^= B, v[5] ^= E, v[6] ^= m, v[7] ^= y;
              for (var p = 0; p < 4; p++)
                l.call(this);
            }
          },
          _doProcessBlock: function(s, h) {
            var p = this._X;
            l.call(this), d[0] = p[0] ^ p[5] >>> 16 ^ p[3] << 16, d[1] = p[2] ^ p[7] >>> 16 ^ p[5] << 16, d[2] = p[4] ^ p[1] >>> 16 ^ p[7] << 16, d[3] = p[6] ^ p[3] >>> 16 ^ p[1] << 16;
            for (var C = 0; C < 4; C++)
              d[C] = (d[C] << 8 | d[C] >>> 24) & 16711935 | (d[C] << 24 | d[C] >>> 8) & 4278255360, s[h + C] ^= d[C];
          },
          blockSize: 128 / 32,
          ivSize: 64 / 32
        });
        function l() {
          for (var s = this._X, h = this._C, p = 0; p < 8; p++)
            x[p] = h[p];
          h[0] = h[0] + 1295307597 + this._b | 0, h[1] = h[1] + 3545052371 + (h[0] >>> 0 < x[0] >>> 0 ? 1 : 0) | 0, h[2] = h[2] + 886263092 + (h[1] >>> 0 < x[1] >>> 0 ? 1 : 0) | 0, h[3] = h[3] + 1295307597 + (h[2] >>> 0 < x[2] >>> 0 ? 1 : 0) | 0, h[4] = h[4] + 3545052371 + (h[3] >>> 0 < x[3] >>> 0 ? 1 : 0) | 0, h[5] = h[5] + 886263092 + (h[4] >>> 0 < x[4] >>> 0 ? 1 : 0) | 0, h[6] = h[6] + 1295307597 + (h[5] >>> 0 < x[5] >>> 0 ? 1 : 0) | 0, h[7] = h[7] + 3545052371 + (h[6] >>> 0 < x[6] >>> 0 ? 1 : 0) | 0, this._b = h[7] >>> 0 < x[7] >>> 0 ? 1 : 0;
          for (var p = 0; p < 8; p++) {
            var C = s[p] + h[p], v = C & 65535, g = C >>> 16, f = ((v * v >>> 17) + v * g >>> 15) + g * g, u = ((C & 4294901760) * C | 0) + ((C & 65535) * C | 0);
            a[p] = f ^ u;
          }
          s[0] = a[0] + (a[7] << 16 | a[7] >>> 16) + (a[6] << 16 | a[6] >>> 16) | 0, s[1] = a[1] + (a[0] << 8 | a[0] >>> 24) + a[7] | 0, s[2] = a[2] + (a[1] << 16 | a[1] >>> 16) + (a[0] << 16 | a[0] >>> 16) | 0, s[3] = a[3] + (a[2] << 8 | a[2] >>> 24) + a[1] | 0, s[4] = a[4] + (a[3] << 16 | a[3] >>> 16) + (a[2] << 16 | a[2] >>> 16) | 0, s[5] = a[5] + (a[4] << 8 | a[4] >>> 24) + a[3] | 0, s[6] = a[6] + (a[5] << 16 | a[5] >>> 16) + (a[4] << 16 | a[4] >>> 16) | 0, s[7] = a[7] + (a[6] << 8 | a[6] >>> 24) + a[5] | 0;
        }
        e.Rabbit = c._createHelper(t);
      })(), r.Rabbit;
    });
  })(xe)), xe.exports;
}
var ce = { exports: {} }, nn = ce.exports, Er;
function on() {
  return Er || (Er = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), h0(), u0(), l0(), j());
    })(nn, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.StreamCipher, A = e.algo, d = [], x = [], a = [], t = A.RabbitLegacy = c.extend({
          _doReset: function() {
            var s = this._key.words, h = this.cfg.iv, p = this._X = [
              s[0],
              s[3] << 16 | s[2] >>> 16,
              s[1],
              s[0] << 16 | s[3] >>> 16,
              s[2],
              s[1] << 16 | s[0] >>> 16,
              s[3],
              s[2] << 16 | s[1] >>> 16
            ], C = this._C = [
              s[2] << 16 | s[2] >>> 16,
              s[0] & 4294901760 | s[1] & 65535,
              s[3] << 16 | s[3] >>> 16,
              s[1] & 4294901760 | s[2] & 65535,
              s[0] << 16 | s[0] >>> 16,
              s[2] & 4294901760 | s[3] & 65535,
              s[1] << 16 | s[1] >>> 16,
              s[3] & 4294901760 | s[0] & 65535
            ];
            this._b = 0;
            for (var v = 0; v < 4; v++)
              l.call(this);
            for (var v = 0; v < 8; v++)
              C[v] ^= p[v + 4 & 7];
            if (h) {
              var g = h.words, f = g[0], u = g[1], B = (f << 8 | f >>> 24) & 16711935 | (f << 24 | f >>> 8) & 4278255360, m = (u << 8 | u >>> 24) & 16711935 | (u << 24 | u >>> 8) & 4278255360, E = B >>> 16 | m & 4294901760, y = m << 16 | B & 65535;
              C[0] ^= B, C[1] ^= E, C[2] ^= m, C[3] ^= y, C[4] ^= B, C[5] ^= E, C[6] ^= m, C[7] ^= y;
              for (var v = 0; v < 4; v++)
                l.call(this);
            }
          },
          _doProcessBlock: function(s, h) {
            var p = this._X;
            l.call(this), d[0] = p[0] ^ p[5] >>> 16 ^ p[3] << 16, d[1] = p[2] ^ p[7] >>> 16 ^ p[5] << 16, d[2] = p[4] ^ p[1] >>> 16 ^ p[7] << 16, d[3] = p[6] ^ p[3] >>> 16 ^ p[1] << 16;
            for (var C = 0; C < 4; C++)
              d[C] = (d[C] << 8 | d[C] >>> 24) & 16711935 | (d[C] << 24 | d[C] >>> 8) & 4278255360, s[h + C] ^= d[C];
          },
          blockSize: 128 / 32,
          ivSize: 64 / 32
        });
        function l() {
          for (var s = this._X, h = this._C, p = 0; p < 8; p++)
            x[p] = h[p];
          h[0] = h[0] + 1295307597 + this._b | 0, h[1] = h[1] + 3545052371 + (h[0] >>> 0 < x[0] >>> 0 ? 1 : 0) | 0, h[2] = h[2] + 886263092 + (h[1] >>> 0 < x[1] >>> 0 ? 1 : 0) | 0, h[3] = h[3] + 1295307597 + (h[2] >>> 0 < x[2] >>> 0 ? 1 : 0) | 0, h[4] = h[4] + 3545052371 + (h[3] >>> 0 < x[3] >>> 0 ? 1 : 0) | 0, h[5] = h[5] + 886263092 + (h[4] >>> 0 < x[4] >>> 0 ? 1 : 0) | 0, h[6] = h[6] + 1295307597 + (h[5] >>> 0 < x[5] >>> 0 ? 1 : 0) | 0, h[7] = h[7] + 3545052371 + (h[6] >>> 0 < x[6] >>> 0 ? 1 : 0) | 0, this._b = h[7] >>> 0 < x[7] >>> 0 ? 1 : 0;
          for (var p = 0; p < 8; p++) {
            var C = s[p] + h[p], v = C & 65535, g = C >>> 16, f = ((v * v >>> 17) + v * g >>> 15) + g * g, u = ((C & 4294901760) * C | 0) + ((C & 65535) * C | 0);
            a[p] = f ^ u;
          }
          s[0] = a[0] + (a[7] << 16 | a[7] >>> 16) + (a[6] << 16 | a[6] >>> 16) | 0, s[1] = a[1] + (a[0] << 8 | a[0] >>> 24) + a[7] | 0, s[2] = a[2] + (a[1] << 16 | a[1] >>> 16) + (a[0] << 16 | a[0] >>> 16) | 0, s[3] = a[3] + (a[2] << 8 | a[2] >>> 24) + a[1] | 0, s[4] = a[4] + (a[3] << 16 | a[3] >>> 16) + (a[2] << 16 | a[2] >>> 16) | 0, s[5] = a[5] + (a[4] << 8 | a[4] >>> 24) + a[3] | 0, s[6] = a[6] + (a[5] << 16 | a[5] >>> 16) + (a[4] << 16 | a[4] >>> 16) | 0, s[7] = a[7] + (a[6] << 8 | a[6] >>> 24) + a[5] | 0;
        }
        e.RabbitLegacy = c._createHelper(t);
      })(), r.RabbitLegacy;
    });
  })(ce)), ce.exports;
}
var fe = { exports: {} }, sn = fe.exports, gr;
function xn() {
  return gr || (gr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), h0(), u0(), l0(), j());
    })(sn, function(r) {
      return (function() {
        var e = r, i = e.lib, c = i.BlockCipher, A = e.algo;
        const d = 16, x = [
          608135816,
          2242054355,
          320440878,
          57701188,
          2752067618,
          698298832,
          137296536,
          3964562569,
          1160258022,
          953160567,
          3193202383,
          887688300,
          3232508343,
          3380367581,
          1065670069,
          3041331479,
          2450970073,
          2306472731
        ], a = [
          [
            3509652390,
            2564797868,
            805139163,
            3491422135,
            3101798381,
            1780907670,
            3128725573,
            4046225305,
            614570311,
            3012652279,
            134345442,
            2240740374,
            1667834072,
            1901547113,
            2757295779,
            4103290238,
            227898511,
            1921955416,
            1904987480,
            2182433518,
            2069144605,
            3260701109,
            2620446009,
            720527379,
            3318853667,
            677414384,
            3393288472,
            3101374703,
            2390351024,
            1614419982,
            1822297739,
            2954791486,
            3608508353,
            3174124327,
            2024746970,
            1432378464,
            3864339955,
            2857741204,
            1464375394,
            1676153920,
            1439316330,
            715854006,
            3033291828,
            289532110,
            2706671279,
            2087905683,
            3018724369,
            1668267050,
            732546397,
            1947742710,
            3462151702,
            2609353502,
            2950085171,
            1814351708,
            2050118529,
            680887927,
            999245976,
            1800124847,
            3300911131,
            1713906067,
            1641548236,
            4213287313,
            1216130144,
            1575780402,
            4018429277,
            3917837745,
            3693486850,
            3949271944,
            596196993,
            3549867205,
            258830323,
            2213823033,
            772490370,
            2760122372,
            1774776394,
            2652871518,
            566650946,
            4142492826,
            1728879713,
            2882767088,
            1783734482,
            3629395816,
            2517608232,
            2874225571,
            1861159788,
            326777828,
            3124490320,
            2130389656,
            2716951837,
            967770486,
            1724537150,
            2185432712,
            2364442137,
            1164943284,
            2105845187,
            998989502,
            3765401048,
            2244026483,
            1075463327,
            1455516326,
            1322494562,
            910128902,
            469688178,
            1117454909,
            936433444,
            3490320968,
            3675253459,
            1240580251,
            122909385,
            2157517691,
            634681816,
            4142456567,
            3825094682,
            3061402683,
            2540495037,
            79693498,
            3249098678,
            1084186820,
            1583128258,
            426386531,
            1761308591,
            1047286709,
            322548459,
            995290223,
            1845252383,
            2603652396,
            3431023940,
            2942221577,
            3202600964,
            3727903485,
            1712269319,
            422464435,
            3234572375,
            1170764815,
            3523960633,
            3117677531,
            1434042557,
            442511882,
            3600875718,
            1076654713,
            1738483198,
            4213154764,
            2393238008,
            3677496056,
            1014306527,
            4251020053,
            793779912,
            2902807211,
            842905082,
            4246964064,
            1395751752,
            1040244610,
            2656851899,
            3396308128,
            445077038,
            3742853595,
            3577915638,
            679411651,
            2892444358,
            2354009459,
            1767581616,
            3150600392,
            3791627101,
            3102740896,
            284835224,
            4246832056,
            1258075500,
            768725851,
            2589189241,
            3069724005,
            3532540348,
            1274779536,
            3789419226,
            2764799539,
            1660621633,
            3471099624,
            4011903706,
            913787905,
            3497959166,
            737222580,
            2514213453,
            2928710040,
            3937242737,
            1804850592,
            3499020752,
            2949064160,
            2386320175,
            2390070455,
            2415321851,
            4061277028,
            2290661394,
            2416832540,
            1336762016,
            1754252060,
            3520065937,
            3014181293,
            791618072,
            3188594551,
            3933548030,
            2332172193,
            3852520463,
            3043980520,
            413987798,
            3465142937,
            3030929376,
            4245938359,
            2093235073,
            3534596313,
            375366246,
            2157278981,
            2479649556,
            555357303,
            3870105701,
            2008414854,
            3344188149,
            4221384143,
            3956125452,
            2067696032,
            3594591187,
            2921233993,
            2428461,
            544322398,
            577241275,
            1471733935,
            610547355,
            4027169054,
            1432588573,
            1507829418,
            2025931657,
            3646575487,
            545086370,
            48609733,
            2200306550,
            1653985193,
            298326376,
            1316178497,
            3007786442,
            2064951626,
            458293330,
            2589141269,
            3591329599,
            3164325604,
            727753846,
            2179363840,
            146436021,
            1461446943,
            4069977195,
            705550613,
            3059967265,
            3887724982,
            4281599278,
            3313849956,
            1404054877,
            2845806497,
            146425753,
            1854211946
          ],
          [
            1266315497,
            3048417604,
            3681880366,
            3289982499,
            290971e4,
            1235738493,
            2632868024,
            2414719590,
            3970600049,
            1771706367,
            1449415276,
            3266420449,
            422970021,
            1963543593,
            2690192192,
            3826793022,
            1062508698,
            1531092325,
            1804592342,
            2583117782,
            2714934279,
            4024971509,
            1294809318,
            4028980673,
            1289560198,
            2221992742,
            1669523910,
            35572830,
            157838143,
            1052438473,
            1016535060,
            1802137761,
            1753167236,
            1386275462,
            3080475397,
            2857371447,
            1040679964,
            2145300060,
            2390574316,
            1461121720,
            2956646967,
            4031777805,
            4028374788,
            33600511,
            2920084762,
            1018524850,
            629373528,
            3691585981,
            3515945977,
            2091462646,
            2486323059,
            586499841,
            988145025,
            935516892,
            3367335476,
            2599673255,
            2839830854,
            265290510,
            3972581182,
            2759138881,
            3795373465,
            1005194799,
            847297441,
            406762289,
            1314163512,
            1332590856,
            1866599683,
            4127851711,
            750260880,
            613907577,
            1450815602,
            3165620655,
            3734664991,
            3650291728,
            3012275730,
            3704569646,
            1427272223,
            778793252,
            1343938022,
            2676280711,
            2052605720,
            1946737175,
            3164576444,
            3914038668,
            3967478842,
            3682934266,
            1661551462,
            3294938066,
            4011595847,
            840292616,
            3712170807,
            616741398,
            312560963,
            711312465,
            1351876610,
            322626781,
            1910503582,
            271666773,
            2175563734,
            1594956187,
            70604529,
            3617834859,
            1007753275,
            1495573769,
            4069517037,
            2549218298,
            2663038764,
            504708206,
            2263041392,
            3941167025,
            2249088522,
            1514023603,
            1998579484,
            1312622330,
            694541497,
            2582060303,
            2151582166,
            1382467621,
            776784248,
            2618340202,
            3323268794,
            2497899128,
            2784771155,
            503983604,
            4076293799,
            907881277,
            423175695,
            432175456,
            1378068232,
            4145222326,
            3954048622,
            3938656102,
            3820766613,
            2793130115,
            2977904593,
            26017576,
            3274890735,
            3194772133,
            1700274565,
            1756076034,
            4006520079,
            3677328699,
            720338349,
            1533947780,
            354530856,
            688349552,
            3973924725,
            1637815568,
            332179504,
            3949051286,
            53804574,
            2852348879,
            3044236432,
            1282449977,
            3583942155,
            3416972820,
            4006381244,
            1617046695,
            2628476075,
            3002303598,
            1686838959,
            431878346,
            2686675385,
            1700445008,
            1080580658,
            1009431731,
            832498133,
            3223435511,
            2605976345,
            2271191193,
            2516031870,
            1648197032,
            4164389018,
            2548247927,
            300782431,
            375919233,
            238389289,
            3353747414,
            2531188641,
            2019080857,
            1475708069,
            455242339,
            2609103871,
            448939670,
            3451063019,
            1395535956,
            2413381860,
            1841049896,
            1491858159,
            885456874,
            4264095073,
            4001119347,
            1565136089,
            3898914787,
            1108368660,
            540939232,
            1173283510,
            2745871338,
            3681308437,
            4207628240,
            3343053890,
            4016749493,
            1699691293,
            1103962373,
            3625875870,
            2256883143,
            3830138730,
            1031889488,
            3479347698,
            1535977030,
            4236805024,
            3251091107,
            2132092099,
            1774941330,
            1199868427,
            1452454533,
            157007616,
            2904115357,
            342012276,
            595725824,
            1480756522,
            206960106,
            497939518,
            591360097,
            863170706,
            2375253569,
            3596610801,
            1814182875,
            2094937945,
            3421402208,
            1082520231,
            3463918190,
            2785509508,
            435703966,
            3908032597,
            1641649973,
            2842273706,
            3305899714,
            1510255612,
            2148256476,
            2655287854,
            3276092548,
            4258621189,
            236887753,
            3681803219,
            274041037,
            1734335097,
            3815195456,
            3317970021,
            1899903192,
            1026095262,
            4050517792,
            356393447,
            2410691914,
            3873677099,
            3682840055
          ],
          [
            3913112168,
            2491498743,
            4132185628,
            2489919796,
            1091903735,
            1979897079,
            3170134830,
            3567386728,
            3557303409,
            857797738,
            1136121015,
            1342202287,
            507115054,
            2535736646,
            337727348,
            3213592640,
            1301675037,
            2528481711,
            1895095763,
            1721773893,
            3216771564,
            62756741,
            2142006736,
            835421444,
            2531993523,
            1442658625,
            3659876326,
            2882144922,
            676362277,
            1392781812,
            170690266,
            3921047035,
            1759253602,
            3611846912,
            1745797284,
            664899054,
            1329594018,
            3901205900,
            3045908486,
            2062866102,
            2865634940,
            3543621612,
            3464012697,
            1080764994,
            553557557,
            3656615353,
            3996768171,
            991055499,
            499776247,
            1265440854,
            648242737,
            3940784050,
            980351604,
            3713745714,
            1749149687,
            3396870395,
            4211799374,
            3640570775,
            1161844396,
            3125318951,
            1431517754,
            545492359,
            4268468663,
            3499529547,
            1437099964,
            2702547544,
            3433638243,
            2581715763,
            2787789398,
            1060185593,
            1593081372,
            2418618748,
            4260947970,
            69676912,
            2159744348,
            86519011,
            2512459080,
            3838209314,
            1220612927,
            3339683548,
            133810670,
            1090789135,
            1078426020,
            1569222167,
            845107691,
            3583754449,
            4072456591,
            1091646820,
            628848692,
            1613405280,
            3757631651,
            526609435,
            236106946,
            48312990,
            2942717905,
            3402727701,
            1797494240,
            859738849,
            992217954,
            4005476642,
            2243076622,
            3870952857,
            3732016268,
            765654824,
            3490871365,
            2511836413,
            1685915746,
            3888969200,
            1414112111,
            2273134842,
            3281911079,
            4080962846,
            172450625,
            2569994100,
            980381355,
            4109958455,
            2819808352,
            2716589560,
            2568741196,
            3681446669,
            3329971472,
            1835478071,
            660984891,
            3704678404,
            4045999559,
            3422617507,
            3040415634,
            1762651403,
            1719377915,
            3470491036,
            2693910283,
            3642056355,
            3138596744,
            1364962596,
            2073328063,
            1983633131,
            926494387,
            3423689081,
            2150032023,
            4096667949,
            1749200295,
            3328846651,
            309677260,
            2016342300,
            1779581495,
            3079819751,
            111262694,
            1274766160,
            443224088,
            298511866,
            1025883608,
            3806446537,
            1145181785,
            168956806,
            3641502830,
            3584813610,
            1689216846,
            3666258015,
            3200248200,
            1692713982,
            2646376535,
            4042768518,
            1618508792,
            1610833997,
            3523052358,
            4130873264,
            2001055236,
            3610705100,
            2202168115,
            4028541809,
            2961195399,
            1006657119,
            2006996926,
            3186142756,
            1430667929,
            3210227297,
            1314452623,
            4074634658,
            4101304120,
            2273951170,
            1399257539,
            3367210612,
            3027628629,
            1190975929,
            2062231137,
            2333990788,
            2221543033,
            2438960610,
            1181637006,
            548689776,
            2362791313,
            3372408396,
            3104550113,
            3145860560,
            296247880,
            1970579870,
            3078560182,
            3769228297,
            1714227617,
            3291629107,
            3898220290,
            166772364,
            1251581989,
            493813264,
            448347421,
            195405023,
            2709975567,
            677966185,
            3703036547,
            1463355134,
            2715995803,
            1338867538,
            1343315457,
            2802222074,
            2684532164,
            233230375,
            2599980071,
            2000651841,
            3277868038,
            1638401717,
            4028070440,
            3237316320,
            6314154,
            819756386,
            300326615,
            590932579,
            1405279636,
            3267499572,
            3150704214,
            2428286686,
            3959192993,
            3461946742,
            1862657033,
            1266418056,
            963775037,
            2089974820,
            2263052895,
            1917689273,
            448879540,
            3550394620,
            3981727096,
            150775221,
            3627908307,
            1303187396,
            508620638,
            2975983352,
            2726630617,
            1817252668,
            1876281319,
            1457606340,
            908771278,
            3720792119,
            3617206836,
            2455994898,
            1729034894,
            1080033504
          ],
          [
            976866871,
            3556439503,
            2881648439,
            1522871579,
            1555064734,
            1336096578,
            3548522304,
            2579274686,
            3574697629,
            3205460757,
            3593280638,
            3338716283,
            3079412587,
            564236357,
            2993598910,
            1781952180,
            1464380207,
            3163844217,
            3332601554,
            1699332808,
            1393555694,
            1183702653,
            3581086237,
            1288719814,
            691649499,
            2847557200,
            2895455976,
            3193889540,
            2717570544,
            1781354906,
            1676643554,
            2592534050,
            3230253752,
            1126444790,
            2770207658,
            2633158820,
            2210423226,
            2615765581,
            2414155088,
            3127139286,
            673620729,
            2805611233,
            1269405062,
            4015350505,
            3341807571,
            4149409754,
            1057255273,
            2012875353,
            2162469141,
            2276492801,
            2601117357,
            993977747,
            3918593370,
            2654263191,
            753973209,
            36408145,
            2530585658,
            25011837,
            3520020182,
            2088578344,
            530523599,
            2918365339,
            1524020338,
            1518925132,
            3760827505,
            3759777254,
            1202760957,
            3985898139,
            3906192525,
            674977740,
            4174734889,
            2031300136,
            2019492241,
            3983892565,
            4153806404,
            3822280332,
            352677332,
            2297720250,
            60907813,
            90501309,
            3286998549,
            1016092578,
            2535922412,
            2839152426,
            457141659,
            509813237,
            4120667899,
            652014361,
            1966332200,
            2975202805,
            55981186,
            2327461051,
            676427537,
            3255491064,
            2882294119,
            3433927263,
            1307055953,
            942726286,
            933058658,
            2468411793,
            3933900994,
            4215176142,
            1361170020,
            2001714738,
            2830558078,
            3274259782,
            1222529897,
            1679025792,
            2729314320,
            3714953764,
            1770335741,
            151462246,
            3013232138,
            1682292957,
            1483529935,
            471910574,
            1539241949,
            458788160,
            3436315007,
            1807016891,
            3718408830,
            978976581,
            1043663428,
            3165965781,
            1927990952,
            4200891579,
            2372276910,
            3208408903,
            3533431907,
            1412390302,
            2931980059,
            4132332400,
            1947078029,
            3881505623,
            4168226417,
            2941484381,
            1077988104,
            1320477388,
            886195818,
            18198404,
            3786409e3,
            2509781533,
            112762804,
            3463356488,
            1866414978,
            891333506,
            18488651,
            661792760,
            1628790961,
            3885187036,
            3141171499,
            876946877,
            2693282273,
            1372485963,
            791857591,
            2686433993,
            3759982718,
            3167212022,
            3472953795,
            2716379847,
            445679433,
            3561995674,
            3504004811,
            3574258232,
            54117162,
            3331405415,
            2381918588,
            3769707343,
            4154350007,
            1140177722,
            4074052095,
            668550556,
            3214352940,
            367459370,
            261225585,
            2610173221,
            4209349473,
            3468074219,
            3265815641,
            314222801,
            3066103646,
            3808782860,
            282218597,
            3406013506,
            3773591054,
            379116347,
            1285071038,
            846784868,
            2669647154,
            3771962079,
            3550491691,
            2305946142,
            453669953,
            1268987020,
            3317592352,
            3279303384,
            3744833421,
            2610507566,
            3859509063,
            266596637,
            3847019092,
            517658769,
            3462560207,
            3443424879,
            370717030,
            4247526661,
            2224018117,
            4143653529,
            4112773975,
            2788324899,
            2477274417,
            1456262402,
            2901442914,
            1517677493,
            1846949527,
            2295493580,
            3734397586,
            2176403920,
            1280348187,
            1908823572,
            3871786941,
            846861322,
            1172426758,
            3287448474,
            3383383037,
            1655181056,
            3139813346,
            901632758,
            1897031941,
            2986607138,
            3066810236,
            3447102507,
            1393639104,
            373351379,
            950779232,
            625454576,
            3124240540,
            4148612726,
            2007998917,
            544563296,
            2244738638,
            2330496472,
            2058025392,
            1291430526,
            424198748,
            50039436,
            29584100,
            3605783033,
            2429876329,
            2791104160,
            1057563949,
            3255363231,
            3075367218,
            3463963227,
            1469046755,
            985887462
          ]
        ];
        var t = {
          pbox: [],
          sbox: []
        };
        function l(v, g) {
          let f = g >> 24 & 255, u = g >> 16 & 255, B = g >> 8 & 255, m = g & 255, E = v.sbox[0][f] + v.sbox[1][u];
          return E = E ^ v.sbox[2][B], E = E + v.sbox[3][m], E;
        }
        function s(v, g, f) {
          let u = g, B = f, m;
          for (let E = 0; E < d; ++E)
            u = u ^ v.pbox[E], B = l(v, u) ^ B, m = u, u = B, B = m;
          return m = u, u = B, B = m, B = B ^ v.pbox[d], u = u ^ v.pbox[d + 1], { left: u, right: B };
        }
        function h(v, g, f) {
          let u = g, B = f, m;
          for (let E = d + 1; E > 1; --E)
            u = u ^ v.pbox[E], B = l(v, u) ^ B, m = u, u = B, B = m;
          return m = u, u = B, B = m, B = B ^ v.pbox[1], u = u ^ v.pbox[0], { left: u, right: B };
        }
        function p(v, g, f) {
          for (let y = 0; y < 4; y++) {
            v.sbox[y] = [];
            for (let b = 0; b < 256; b++)
              v.sbox[y][b] = a[y][b];
          }
          let u = 0;
          for (let y = 0; y < d + 2; y++)
            v.pbox[y] = x[y] ^ g[u], u++, u >= f && (u = 0);
          let B = 0, m = 0, E = 0;
          for (let y = 0; y < d + 2; y += 2)
            E = s(v, B, m), B = E.left, m = E.right, v.pbox[y] = B, v.pbox[y + 1] = m;
          for (let y = 0; y < 4; y++)
            for (let b = 0; b < 256; b += 2)
              E = s(v, B, m), B = E.left, m = E.right, v.sbox[y][b] = B, v.sbox[y][b + 1] = m;
          return !0;
        }
        var C = A.Blowfish = c.extend({
          _doReset: function() {
            if (this._keyPriorReset !== this._key) {
              var v = this._keyPriorReset = this._key, g = v.words, f = v.sigBytes / 4;
              p(t, g, f);
            }
          },
          encryptBlock: function(v, g) {
            var f = s(t, v[g], v[g + 1]);
            v[g] = f.left, v[g + 1] = f.right;
          },
          decryptBlock: function(v, g) {
            var f = h(t, v[g], v[g + 1]);
            v[g] = f.left, v[g + 1] = f.right;
          },
          blockSize: 64 / 32,
          keySize: 128 / 32,
          ivSize: 64 / 32
        });
        e.Blowfish = c._createHelper(C);
      })(), r.Blowfish;
    });
  })(fe)), fe.exports;
}
var cn = k0.exports, Fr;
function fn() {
  return Fr || (Fr = 1, (function(o, n) {
    (function(r, e, i) {
      o.exports = e(L(), le(), oa(), sa(), h0(), fa(), u0(), Sr(), Fe(), va(), Mr(), Ca(), Aa(), ga(), De(), ya(), l0(), j(), ka(), Ma(), za(), Pa(), Wa(), qa(), La(), Ua(), Na(), Xa(), Ka(), Za(), Ja(), rn(), an(), on(), xn());
    })(cn, function(r) {
      return r;
    });
  })(k0)), k0.exports;
}
var ln = fn();
const hn = /* @__PURE__ */ Yt(ln), un = "KMED1W0N50YIWIYJCUNLYPMJ49JDLASE", dn = "UQ30SC5R5YTM1TEHHDB8QB20NUYOAQY6", Ee = {
  room: { fillcolor: "#8daed3", strokecolor: "#6d8fb5", height: 0.1 },
  wall: { height: 2, opacity: 0.6, fillcolor: "#3452B4", strokecolor: "#38AEBA" },
  floor: { fillcolor: "#F1F7F9", strokecolor: "#EEEEEE", height: 0.05 },
  plane: { fillcolor: "#4C4C54", strokecolor: "#3C3C3C", height: 0.1 },
  window: { fillcolor: "#AADDEE", strokecolor: "#5FA7C7", height: 1.5, opacity: 0.85 },
  door: { fillcolor: "#64C1EB", strokecolor: "#38AEBA", height: 0.1 },
  logo: { height: 1 },
  desk: { fillcolor: "#87CEFA", strokecolor: "#38AEBA", height: 0.5 },
  seat: { fillcolor: "#87CEFA", strokecolor: "#38AEBA", height: 0.3 },
  default: { fillcolor: "#0088FF", strokecolor: "#38AEBA", height: 1, eheight: 0, opacity: 1, size: 1.4, logo: "" },
  unknown: { fillcolor: "#F00", height: 2 }
}, vn = { floor: 1, plane: 2, wall: 10, window: 11, door: 12, desk: 14, seat: 15, room: 18 }, pn = 10;
function Bn(o) {
  if (typeof o != "string") {
    const r = new Uint8Array(o.slice ? o.slice(0, 2) : o);
    if (r[0] === 80 && r[1] === 75) return "buildingosmap";
    o = new TextDecoder().decode(o);
  }
  return o.trimStart().startsWith("{") ? "acmap-plain" : "acmap";
}
function Cn(o, n, { key: r = un, iv: e = dn } = {}) {
  if (o.trimStart().startsWith("{")) return JSON.parse(o);
  const i = n.AES.decrypt(
    { ciphertext: n.enc.Base64.parse(o) },
    n.enc.Utf8.parse(r),
    { iv: n.enc.Utf8.parse(e), mode: n.mode.CBC, padding: n.pad.Pkcs7 }
  ).toString(n.enc.Utf8);
  if (!i) throw new Error(".acmap 解密失败（密钥不对或文件损坏）");
  return JSON.parse(i);
}
function Rr(o) {
  return {
    version: o.MAP_VERSION || o.version || "unknown",
    id: o.id ?? o.name,
    name: o.name,
    buildingName: o.building_name,
    offset: Array.isArray(o.iv) ? o.iv : [0, 0],
    // 楼栋平面偏移（旧引擎 building.position.x/z），不是加密 IV
    floors: o.floors || []
  };
}
function mn(o, n, r) {
  const e = Object.assign({}, Ee[o] || Ee.default);
  r?.moduleStyle?.[o] && Object.assign(e, r.moduleStyle[o]);
  const i = r?.itemStyle?.find?.((c) => c.sType === n.type?.sType);
  if (i) {
    const { sType: c, ...A } = i;
    Object.assign(e, A);
  }
  return Object.assign(e, n.properties);
}
function An(o, { theme: n, unknownLayers: r = [] } = {}) {
  const e = Rr(o), i = new k.Group();
  i.name = `v1:${e.id}`, i.userData.semantic = { id: String(e.id), type: "building", name: e.name }, i.position.set(e.offset[0], 0, e.offset[1]);
  const c = { floors: 0, meshes: 0, items: 0, triangles: 0, skipped: {} }, A = {};
  let d = 0;
  return e.floors.forEach((x, a) => {
    const t = x.floorHeight || pn, l = new k.Group();
    l.name = `floor:${a}`, l.position.y = d, d += t, l.userData.semantic = { id: `${e.id}-${x.name || a}`, type: "floor", name: x.name, index: a }, i.add(l), c.floors++;
    for (const [s, h] of Object.entries(x.floor || {})) {
      if (!h?.length) continue;
      if (s === "logo") {
        c.skipped.logo = (c.skipped.logo || 0) + h.length;
        continue;
      }
      const p = [], C = [], v = [];
      let g = 1, f = 0;
      if (h.forEach((E, y) => {
        if (!E.line || E.line.length < 3) return;
        const b = mn(s, E, n), S = Number(b.height) || 0, F = Number(b.eheight) || 0;
        g = b.opacity === void 0 ? 1 : Number(b.opacity);
        const D = new k.Shape();
        D.moveTo(E.line[0][0], -E.line[0][1]);
        for (let T = 1; T < E.line.length; T++) D.lineTo(E.line[T][0], -E.line[T][1]);
        const _ = new k.ExtrudeGeometry(D, { depth: Math.max(S, 1e-3), bevelEnabled: !1 }), P = (_.toNonIndexed && _.index ? _.toNonIndexed() : _).attributes.position, O = new k.Color(b.fillcolor || "#888");
        for (let T = 0; T < P.count; T++)
          p.push(P.getX(T), P.getY(T), P.getZ(T) + F), C.push(O.r, O.g, O.b);
        const W = P.count / 3;
        v.push({ start: f, count: W, id: E.id ?? `${s}-${y}`, layer: s, name: E.name || E.properties?.name || "" }), f += W, c.items++, _.dispose();
      }), !p.length) continue;
      const u = new k.BufferGeometry();
      u.setAttribute("position", new k.Float32BufferAttribute(p, 3)), u.setAttribute("color", new k.Float32BufferAttribute(C, 3)), u.computeVertexNormals();
      const B = new k.MeshLambertMaterial({
        vertexColors: !0,
        transparent: g < 1,
        opacity: g,
        side: g < 1 ? k.DoubleSide : k.FrontSide,
        depthWrite: g >= 1
      }), m = new k.Mesh(u, B);
      m.rotation.x = -Math.PI / 2, m.renderOrder = vn[s] ?? 5, m.name = `${l.userData.semantic.id}|v1.${s}`, m.userData.semantic = l.userData.semantic.id, m.visible = g > 0, m.userData.layer = s, A[m.uuid] = v, l.add(m), c.meshes++, c.triangles += f, Ee[s] || r.push(s);
    }
  }), { root: i, stats: c, pick: A, meta: e };
}
async function En(o) {
  if (o instanceof Uint8Array) return o;
  if (o instanceof ArrayBuffer) return new Uint8Array(o);
  if (typeof Blob < "u" && o instanceof Blob) return new Uint8Array(await o.arrayBuffer());
  const n = await fetch(o);
  if (!n.ok) throw new Error("模型文件下载失败：" + n.status + " " + o);
  return new Uint8Array(await n.arrayBuffer());
}
async function gn(o, n, r = {}) {
  const e = await En(o);
  return Bn(e) === "buildingosmap" ? Fn(e, n, r) : Dn(e, r);
}
let Be = null;
function zr() {
  return Be || (Be = typeof WebAssembly == "object" && typeof WebAssembly.compile == "function" ? WebAssembly.compile(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0])).then(() => !0, () => !1) : Promise.resolve(!1)), Be;
}
async function Fn(o, n, { palette: r = {}, decoderPath: e = "/vendor/draco/" } = {}) {
  const i = Kt(o), c = JSON.parse(Ae(i["manifest.json"]));
  if (c.format !== "buildingosmap" || c.version !== 1) throw new Error("不支持的 .buildingosmap：" + c.format + " v" + c.version);
  const A = JSON.parse(Ae(i[c.entries.semantics])), d = i[c.entries.scene], x = new Kr();
  if (c.compression && c.compression.geometry === "draco") {
    const h = new Yr();
    h.setDecoderPath(e), await zr() || h.setDecoderConfig({ type: "js" }), x.setDRACOLoader(h), n.addDisposable && n.addDisposable(h);
  }
  const t = (await new Promise((h, p) => x.parse(d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength), "", h, p))).scene;
  t.name = c.id;
  const l = A.envMaps || {}, s = /* @__PURE__ */ new Map();
  return t.traverse((h) => {
    if (!h.isMesh) return;
    if (!h.userData.semantic) {
      const g = h.name.indexOf("|");
      g > 0 && (h.userData.semantic = h.name.slice(0, g));
    }
    h.castShadow = h.receiveShadow = !0;
    const p = h.material, C = p && p.name;
    if (!C) return;
    const v = n.presets.bySlot(C);
    if (v) {
      h.material = v;
      return;
    }
    s.has(C) || (r[C] !== void 0 && p.color && p.color.set(r[C]).convertSRGBToLinear(), l[C] !== void 0 && (p.envMap = n.presets.smartFacade().reflection, p.envMapIntensity = l[C], p.needsUpdate = !0), s.set(C, p));
  }), { root: t, model: { id: c.id, name: c.name, viewer: c.viewer, home: c.home, semantics: A }, stats: { format: "buildingosmap", bytes: o.byteLength } };
}
function Dn(o, { key: n, iv: r } = {}) {
  const e = new TextDecoder().decode(o), i = Cn(e, hn, { ...n ? { key: n } : {}, ...r ? { iv: r } : {} }), c = Rr(i), { root: A, stats: d, pick: x } = An(i, {}), a = new k.Box3().setFromObject(A), t = a.getCenter(new k.Vector3()), l = a.getSize(new k.Vector3()), s = Math.max(l.x, l.z) * 1.1 || 50, h = { position: [t.x, t.y + s, t.z + s * 0.6], target: [t.x, t.y, t.z] }, p = [{
    id: String(c.id),
    type: "building",
    name: c.name,
    pickable: !0,
    children: A.children.map((C) => ({ id: C.userData.semantic.id, type: "floor", name: C.userData.semantic.name, pickable: !0 }))
  }];
  return {
    root: A,
    model: {
      id: String(c.id),
      name: c.name,
      home: h,
      viewer: { fov: 45, near: 0.1, far: Math.max(2e3, s * 20), controls: { minDistance: 1, maxDistance: s * 6, maxPolarAngle: Math.PI / 2 } },
      semantics: { tree: p, cameras: [{ id: "home", ...h }, { id: "top", position: [t.x, t.y + s * 1.6, t.z + 0.01], target: [t.x, t.y, t.z] }], anchors: [], behaviors: [], pickRanges: x }
    },
    stats: { format: "acmap", version: c.version, ...d }
  };
}
const kn = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  loadMap: gn,
  wasmAllowed: zr
}, Symbol.toStringTag, { value: "Module" }));
export {
  Dt as B,
  St as C,
  bt as G,
  vt as T,
  Le as V,
  Ct as a,
  We as b,
  kt as c,
  mt as i,
  gn as l,
  kn as m,
  pt as r,
  w0 as s,
  zr as w
};
