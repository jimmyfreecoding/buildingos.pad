# @h2z/viewer（发布构建）

本目录由 **h2z.3d** 的 `npm run build:viewer` 生成，**不要手改**。

- 入口：`h2z-viewer.js`（`import { Viewer, loadMap } from "@h2z/viewer"`）
- 自定义元素：`h2z-viewer-element.js`（`import "@h2z/viewer/element"`）
- Draco 解码器：`vendor/draco/`，消费方拷到自己的静态目录
- `three@0.186.1` 是 peerDependency，由消费方安装

用法见 h2z.3d 的 `docs/EMBED.md`。改三维解释器要改 h2z.3d 的源码并重新构建发布。
