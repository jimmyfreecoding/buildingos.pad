import * as u from "three";
const f = !0;
u.ColorManagement.enabled = !f;
const s = Math.PI;
function l(e) {
  if (!e || e.userData.__legacyLook) return e;
  e.userData.__legacyLook = !0;
  const r = [], i = e.onBeforeRender, a = e.onAfterRender;
  return e.onBeforeRender = function(...n) {
    return r.length = 0, e.traverseVisible((t) => {
      t.isLight && ((t.isPointLight || t.isSpotLight) && t.userData.__legacyDecay === void 0 && (t.userData.__legacyDecay = !0, t.decay = t.distance > 0 ? 1 : 0), r.push([t, t.intensity]), t.intensity *= s);
    }), i.apply(this, n);
  }, e.onAfterRender = function(...n) {
    for (const [t, o] of r) t.intensity = o;
    return r.length = 0, a.apply(this, n);
  }, e;
}
export {
  f as LEGACY_COLOR,
  l as legacyLook
};
