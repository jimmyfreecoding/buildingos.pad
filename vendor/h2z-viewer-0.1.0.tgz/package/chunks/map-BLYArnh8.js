import * as S from "three";
import { legacyLook as Xr } from "../h2z-viewer-compat.js";
import { OrbitControls as Kr } from "three/addons/controls/OrbitControls.js";
import { GLTFLoader as jr } from "three/addons/loaders/GLTFLoader.js";
import { DRACOLoader as Yr } from "three/addons/loaders/DRACOLoader.js";
function w0(s) {
  if (s.userData && s.userData.semantic) return s.userData.semantic;
  const n = s.name || "", r = n.indexOf("|");
  return r > 0 ? n.slice(0, r) : null;
}
function Zr(s = []) {
  const n = /* @__PURE__ */ new Map(), r = (e, o) => e.forEach((c) => {
    n.set(c.id, { ...c, parent: o }), c.children && r(c.children, c.id);
  });
  return r(s, null), n;
}
function qe(s, n, r) {
  for (let e = n; e; e = s.get(e)?.parent) if (e === r) return !0;
  return !1;
}
const Qr = {
  id: "campus-life",
  version: 1,
  create(s, n, r = {}) {
    const e = { time: { value: 0 }, cloud: { value: 0.43 }, night: { value: 0 }, dusk: { value: 0 }, flatMix: { value: 0 }, flatColor: { value: new S.Color(16777215) } }, o = new S.Mesh(new S.SphereGeometry(1100, 32, 16), new S.ShaderMaterial({
      side: S.BackSide,
      depthWrite: !1,
      uniforms: e,
      vertexShader: "varying vec3 vWorld; void main(){vWorld=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}",
      fragmentShader: `varying vec3 vWorld; uniform float time; uniform float cloud; uniform float night; uniform float dusk; uniform float flatMix; uniform vec3 flatColor;
      float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
      float fbm(vec2 p){float v=0.;float a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+13.5;a*=.5;}return v;}
      void main(){vec3 d=normalize(vWorld);float h=max(d.y,0.);vec3 color=mix(vec3(.72,.81,.87),vec3(.16,.39,.66),pow(h,.45));
      color=mix(color,mix(vec3(.91,.59,.39),vec3(.29,.33,.54),pow(h,.4)),dusk*.82);
      vec2 uv=d.xz/(max(d.y,.06)+.24)*2.6+vec2(time*.004,0.);float n=fbm(uv);float c=smoothstep(.68-cloud*.42,.79-cloud*.33,n)*smoothstep(-.02,.16,d.y);
      color=mix(color,mix(vec3(.69,.76,.8),vec3(1.),smoothstep(.4,.8,n)),c*.93);
      color=mix(color,vec3(.016,.033,.085)+h*.02,night*.98);
      float star=step(.9978,hash(floor(d.xz/(d.y+.2)*850.)))*smoothstep(.1,.5,h);color+=star*night*.7;
      color=mix(color,flatColor,flatMix);
      gl_FragColor=vec4(color,1.);}`
    }));
    o.name = "campus-life-sky", o.frustumCulled = !1, o.renderOrder = -1e3, s.scene.add(o);
    const c = new S.Group();
    c.name = "campus-life-traffic", s.scene.add(c);
    const E = 32, d = new S.BoxGeometry(1, 1, 1), x = new S.MeshStandardMaterial({ color: 16777215, roughness: 0.48, metalness: 0.25 }), t = new S.MeshStandardMaterial({ color: 3162698, roughness: 0.38, metalness: 0.25 }), a = new S.MeshStandardMaterial({ color: 2369322, roughness: 0.9 }), u = new S.InstancedMesh(d, x, E), i = new S.InstancedMesh(d, t, E), l = new S.InstancedMesh(d, a, E * 4);
    for (const A of [u, i, l])
      A.frustumCulled = !1, A.castShadow = !0, c.add(A);
    const p = [13029070, 5073019, 7568252, 11907753, 8803919], C = Array.from({ length: E }, (A, m) => {
      const y = m < 20, b = m % 2 ? 1 : -1;
      return { axis: y ? "x" : "z", dir: b, speed: 7 + m * 7 % 9, position: -280 + m % (y ? 20 : 12) * (y ? 28 : 46), initial: -280 + m % (y ? 20 : 12) * (y ? 28 : 46), lane: y ? b > 0 ? 71 : 83 : b > 0 ? 109 : 119 };
    }), v = new S.Matrix4(), F = new S.Quaternion(), f = new S.Vector3(), h = new S.Vector3();
    function B() {
      C.forEach((A, m) => {
        const y = A.axis === "x" ? A.position : A.lane, b = A.axis === "z" ? A.position : A.lane, k = A.axis === "x" ? A.dir > 0 ? Math.PI / 2 : -Math.PI / 2 : A.dir > 0 ? 0 : Math.PI;
        F.setFromAxisAngle(new S.Vector3(0, 1, 0), k);
        const g = (D, _, w, P, W, q, O, G) => {
          f.set(y + w * Math.cos(k) + W * Math.sin(k), P, b - w * Math.sin(k) + W * Math.cos(k)), v.compose(f, F, h.set(q, O, G)), D.setMatrixAt(_, v);
        };
        g(u, m, 0, 0.65, 0, 1.9, 0.8, 4.4), g(i, m, 0, 1.25, -0.2, 1.65, 0.6, 2.4);
        for (let D = 0; D < 4; D++) g(l, m * 4 + D, D % 2 ? 0.95 : -0.95, 0.35, D < 2 ? -1.35 : 1.35, 0.25, 0.55, 0.65);
        u.setColorAt(m, new S.Color(p[m % p.length]));
      });
      for (const A of [u, i, l]) A.instanceMatrix.needsUpdate = !0;
    }
    return B(), o.position.copy(s.camera.position), r.sky === !1 && (o.visible = !1), {
      kind: "campus-life",
      cars: C,
      sky: o,
      traffic: c,
      environment({ weather: A, hour: m, night: y }) {
        e.night.value = y ? 1 : 0, e.dusk.value = !y && (m < 8 || m > 17) ? 1 : 0, e.cloud.value = A === "sunny" ? 0.4 : A === "cloudy" ? 0.95 : 1.4, o.visible = !s.studioOn && r.sky !== !1;
      },
      update(A) {
        if (o.position.copy(s.camera.position), e.time.value += A, c.visible = s.layerState?.[r.vehicleLayer || "vehicles"] !== !1, !!c.visible) {
          for (const m of C)
            m.position += m.dir * m.speed * A, m.position > 290 && (m.position = -290), m.position < -290 && (m.position = 290);
          B();
        }
      },
      dispose() {
        s.scene.remove(o, c), o.geometry.dispose(), o.material.dispose(), d.dispose(), x.dispose(), t.dispose(), a.dispose();
      }
    };
  }
}, Jr = {
  id: "precipitation",
  version: 1,
  create(s, n, r = {}) {
    const e = r.count || 600, o = r.min || [-130, 0, -170], c = r.max || [130, 150, 130];
    let E = 1234567;
    const d = () => (E = E * 16807 % 2147483647) / 2147483647, x = new Float32Array(e * 3);
    for (let i = 0; i < e; i++) for (let l = 0; l < 3; l++) x[i * 3 + l] = o[l] + d() * (c[l] - o[l]);
    const t = new S.BufferGeometry();
    t.setAttribute("position", new S.BufferAttribute(x, 3));
    const a = new S.Points(t, new S.PointsMaterial({ color: r.color ?? 14479359, size: 0.55, transparent: !0, opacity: 0.7 }));
    a.visible = !1, s.scene.add(a);
    let u = "sunny";
    return {
      environment(i) {
        u = i.weather, a.visible = u === "rain" || u === "snow", a.material.size = u === "snow" ? 1.1 : 0.45;
      },
      update(i) {
        if (a.visible) {
          for (let l = 1; l < x.length; l += 3)
            x[l] -= i * (u === "snow" ? 5 : 65), x[l] < o[1] && (x[l] = c[1]);
          t.attributes.position.needsUpdate = !0;
        }
      },
      dispose() {
        s.scene.remove(a), t.dispose(), a.material.dispose();
      }
    };
  }
}, et = {
  id: "traffic",
  version: 1,
  create(s, n, r = {}) {
    const e = Array.isArray(r.ids) ? r.ids : [], o = Array.isArray(r.v) ? r.v : [r.v || 8], c = (v) => {
      const F = Number(o[0]) || 8, f = Number(o[1] ?? F) || F, h = v * 37 % 100 / 100;
      return F + (f - F) * h;
    }, E = Array.isArray(r.wrap) && r.wrap.length === 2 ? r.wrap.map(Number) : [-400, 400], d = String(r.layer || "vehicles"), x = /* @__PURE__ */ new Map(), t = s.root;
    t && t.traverse((v) => {
      if (!v.isMesh) return;
      const F = v.userData && v.userData.semantic || (v.name || "").split("|")[0];
      F && (x.has(F) || x.set(F, []), x.get(F).push(v));
    });
    const a = [];
    let u = 0;
    const i = new S.Box3(), l = new S.Vector3(), p = new S.Vector3();
    for (const v of e) {
      const F = x.get(v);
      if (!F || !F.length) continue;
      i.makeEmpty();
      for (const A of F) i.expandByObject(A);
      i.getSize(l), i.getCenter(p);
      const f = l.x > l.z ? "x" : "z", h = u % 2 ? 1 : -1, B = new S.Group();
      B.name = v, F[0].parent && F[0].parent.add(B);
      for (const A of F) B.add(A);
      a.push({ node: B, axis: f, dir: h, speed: c(u), base: B.position.clone() }), u++;
    }
    let C = !1;
    return {
      kind: "traffic",
      cars: a,
      update(v) {
        if (!(!(!s.layerState || s.layerState[d] !== !1) || C))
          for (const f of a)
            f.node.position[f.axis] += f.dir * f.speed * v, f.node.position[f.axis] > E[1] && (f.node.position[f.axis] = E[0]), f.node.position[f.axis] < E[0] && (f.node.position[f.axis] = E[1]);
      },
      pause(v) {
        C = !!v;
      },
      reset() {
        for (const v of a) v.node.position.copy(v.base);
      },
      dispose() {
      }
    };
  }
}, Oe = "varying vec3 vWorld; void main(){ vWorld = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }", Te = `varying vec3 vWorld;
uniform float time; uniform float cloud; uniform float night; uniform float dusk; uniform vec3 sunDir; uniform vec3 ground; uniform float groundMix; uniform float flatMix; uniform vec3 flatColor;
float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p){ float v = 0.; float a = .5; for (int i = 0; i < 5; i++){ v += a * noise(p); p = p * 2.03 + 13.5; a *= .5; } return v; }
void main(){
  vec3 d = normalize(vWorld); float h = max(d.y, 0.);
  vec3 color = mix(vec3(.74, .83, .89), vec3(.18, .41, .70), pow(h, .45));
  color = mix(color, mix(vec3(.93, .62, .40), vec3(.30, .34, .55), pow(h, .4)), dusk * .82);
  float sd = max(dot(d, normalize(sunDir)), 0.);
  color += vec3(1., .93, .78) * (pow(sd, 900.) * 6. + pow(sd, 12.) * .18) * (1. - night);
  vec2 uv = d.xz / (max(d.y, .06) + .24) * 2.6 + vec2(time * .004, 0.);
  float n = fbm(uv); float c = smoothstep(.68 - cloud * .42, .79 - cloud * .33, n) * smoothstep(-.02, .16, d.y);
  color = mix(color, mix(vec3(.70, .77, .81), vec3(1.), smoothstep(.4, .8, n)), c * .9);
  color = mix(color, vec3(.016, .033, .085) + h * .02, night * .98);
  float star = step(.9978, hash(floor(d.xz / (d.y + .2) * 850.))) * smoothstep(.1, .5, h); color += star * night * .7;
  // 地平线以下：地面色（玻璃里反出来的是地面，不是天空）
  // groundMix=1（只用于烘环境贴图）：地面色；=0（看得见的天空）：延续地平线雾色，免得小场地边缘外露出一条地面色带
  vec3 haze = mix(mix(vec3(.74, .83, .89), vec3(.93, .62, .40), dusk * .6), vec3(.03, .05, .1), night * .95);
  vec3 g = mix(haze, mix(ground, ground * .12, night), groundMix);
  color = mix(color, g, 1. - smoothstep(-.08, 0., d.y));   // smoothstep 的两个边界必须递增，反着写在部分驱动上是未定义（会出黑）
  color = mix(color, flatColor, flatMix);
  gl_FragColor = vec4(color, 1.);
}`, rt = {
  id: "sky",
  version: 1,
  create(s, n, r = {}) {
    const e = Number(r.radius) || 1500, o = {
      time: { value: 0 },
      cloud: { value: r.cloud ?? 0.4 },
      night: { value: 0 },
      dusk: { value: 0 },
      sunDir: { value: new S.Vector3(-0.5, 0.7, 0.4) },
      ground: { value: new S.Color().setHex(parseInt(String(r.ground || "#5a6352").replace("#", ""), 16), S.LinearSRGBColorSpace) },
      // 着色器里的颜色按原值输出（天空色也是这么写的），不做线性化
      groundMix: { value: 0 },
      flatMix: { value: 0 },
      flatColor: { value: new S.Color(16777215) }
    }, c = { ...o, groundMix: { value: 1 } }, E = new S.ShaderMaterial({ side: S.BackSide, depthWrite: !1, uniforms: o, vertexShader: Oe, fragmentShader: Te }), d = new S.Mesh(new S.SphereGeometry(e, 48, 24), E);
    d.name = "sky@1", d.frustumCulled = !1, d.renderOrder = -1e3, s.scene.add(d);
    const x = new S.Scene(), t = new S.ShaderMaterial({ side: S.BackSide, depthWrite: !1, uniforms: c, vertexShader: Oe, fragmentShader: Te }), a = new S.Mesh(new S.SphereGeometry(100, 48, 24), t);
    x.add(a);
    const u = Number(r.envSize) || 256, i = new S.WebGLCubeRenderTarget(u, { type: S.HalfFloatType }), l = new S.CubeCamera(1, 1e3, i);
    x.add(l);
    const p = new S.PMREMGenerator(s.renderer);
    let C = null;
    const v = r.envDefault ?? 0.3, F = r.envSlots || {};
    function f() {
      s.sun && o.sunDir.value.copy(s.sun.position).normalize(), l.update(s.renderer, x);
      const h = p.fromCubemap(i.texture);
      C && C.dispose(), C = h, s.scene.environment = s.studioOn ? null : C.texture;
      for (const [B, A] of s.materials || [])
        !A || !("envMapIntensity" in A) || (A.envMapIntensity = F[B] ?? v, A.envMap && F[B] !== void 0 && (A.envMap = null), A.needsUpdate = !0);
    }
    return {
      kind: "sky",
      sky: d,
      environment({ weather: h, hour: B, night: A }) {
        o.night.value = A ? 1 : 0, o.dusk.value = !A && (B < 8 || B > 17) ? 1 : 0, o.cloud.value = h === "sunny" ? r.cloud ?? 0.4 : h === "cloudy" ? 0.95 : 1.4, d.visible = !s.studioOn, f();
      },
      update(h) {
        d.position.copy(s.camera.position), o.time.value += h;
      },
      dispose() {
        s.scene.remove(d), s.scene.environment === C?.texture && (s.scene.environment = null), d.geometry.dispose(), a.geometry.dispose(), E.dispose(), t.dispose(), i.dispose(), C && C.dispose(), p.dispose();
      }
    };
  }
}, tt = { "precipitation@1": Jr, "campus-life@1": Qr, "traffic@1": et, "sky@1": rt };
function Ie(s) {
  let n = (s >>> 0) + 1831565813;
  return n = Math.imul(n ^ n >>> 15, n | 1), n ^= n + Math.imul(n ^ n >>> 7, n | 61), ((n ^ n >>> 14) >>> 0) / 4294967296;
}
const at = {
  build(s, n = {}, { palette: r = {} } = {}) {
    const e = n.semantic || "racks", o = n.floorY || 0, c = n.height || 9, E = n.beams || [1.8, 3.6, 5.4, 7.2], d = n.fill ?? 0.7, x = n.seed || 1, t = { upright: 3108784, beam: 15694380, cargo: 13215610, cargo2: 14467995, ...n.colors || {} }, a = (f, h, B = {}) => {
      const A = new S.MeshStandardMaterial({ color: r[f] === void 0 ? h : r[f], roughness: 0.75, ...B });
      return A.color.convertSRGBToLinear(), A.name = f, A;
    }, u = new S.BoxGeometry(1, 1, 1), i = { "rack.upright": [], "rack.beam": [], "rack.cargo": [], "rack.cargo2": [] }, l = (f, h, B, A, m, y) => new S.Matrix4().compose(new S.Vector3(f, h, B), new S.Quaternion(), new S.Vector3(A, m, y)), p = /* @__PURE__ */ new Set(), C = n.keepout || [], v = (n.bays || []).filter(([f, h, B, A]) => !C.some(([m, y, b]) => Math.abs(m - f) < B / 2 + b && Math.abs(y - h) < A / 2 + b));
    v.forEach(([f, h, B, A], m) => {
      for (const k of [-1, 1]) for (const g of [-1, 1]) {
        const D = f + k * (B / 2 - 0.04), _ = h + g * (A / 2), w = Math.round(D * 50) + "," + Math.round(_ * 50);
        p.has(w) || (p.add(w), i["rack.upright"].push(l(D, o + c / 2, _, 0.08, c, 0.08)));
      }
      for (const k of [...E, c - 0.1]) for (const g of [-1, 1]) i["rack.beam"].push(l(f + g * (B / 2 - 0.04), o + k, h, 0.06, 0.12, A - 0.08));
      const y = A > 3.3 ? 3 : A > 2 ? 2 : 1, b = A / y;
      [0, ...E].forEach((k, g) => {
        for (let D = 0; D < y; D++) {
          const _ = Ie(x * 7919 + m * 131 + g * 17 + D);
          if (_ > d) continue;
          const w = 0.85 + Ie(m * 31 + g * 7 + D * 3 + x) * 0.45;
          i[_ < d / 2 ? "rack.cargo" : "rack.cargo2"].push(l(f, o + k + 0.07 + w / 2, h - A / 2 + b * (D + 0.5), B * 0.86, w, Math.min(1.1, b * 0.86)));
        }
      });
    });
    const F = [];
    for (const [f, h] of Object.entries(i)) {
      if (!h.length) continue;
      const B = a(f, f === "rack.upright" ? t.upright : f === "rack.beam" ? t.beam : f === "rack.cargo" ? t.cargo : t.cargo2, f === "rack.upright" ? { metalness: 0.3 } : {}), A = new S.InstancedMesh(u, B, h.length);
      h.forEach((m, y) => A.setMatrixAt(y, m)), A.name = e + "|" + f, A.userData.semantic = e, A.userData.generated = "racks@1", A.castShadow = f === "rack.upright", A.receiveShadow = !0, s.add(A), F.push(A);
    }
    return { meshes: F, stats: { bays: v.length, removed: (n.bays || []).length - v.length, instances: Object.values(i).reduce((f, h) => f + h.length, 0) } };
  }
}, nt = { "racks@1": at };
function ot(s) {
  const n = document.createElement("canvas");
  n.width = 512, n.height = 1024;
  const r = n.getContext("2d"), e = r.createLinearGradient(0, 0, 0, 1024);
  e.addColorStop(0, "#14282d"), e.addColorStop(0.3, "#243c40"), e.addColorStop(0.55, "#698185"), e.addColorStop(0.82, "#334c50"), e.addColorStop(1, "#172d31"), r.fillStyle = e, r.fillRect(0, 0, 512, 1024);
  for (let t = 0; t < 3; t++) {
    const a = t * 341;
    r.fillStyle = "rgba(10,23,27,.6)", r.fillRect(0, a + 6, 512, 43);
    for (let u = -64; u < 576; u += 64)
      r.strokeStyle = "rgba(16,31,34,.65)", r.lineWidth = 5, r.beginPath(), r.moveTo(u, a + 38), r.lineTo(u + 52, a + 105), r.lineTo(u + 52, a + 319), r.stroke(), r.strokeStyle = "rgba(166,189,187,.32)", r.lineWidth = 2, r.beginPath(), r.moveTo(u + 7, a + 40), r.lineTo(u + 59, a + 105), r.lineTo(u + 59, a + 319), r.stroke();
    r.fillStyle = "rgba(157,173,170,.4)", r.fillRect(0, a + 274, 512, 14), r.fillStyle = "rgba(13,29,32,.75)", r.fillRect(0, a + 291, 512, 11), r.strokeStyle = "rgba(30,48,51,.6)", r.lineWidth = 3;
    for (let u = 18; u < 512; u += 85)
      r.strokeRect(u, a + 145, 48, 99), r.strokeRect(u + 7, a + 152, 34, 84);
  }
  for (let t = 0; t < 4; t++) {
    const a = t * 128;
    r.fillStyle = t % 2 ? "rgba(142,175,180,.09)" : "rgba(8,32,38,.12)", r.fillRect(a, 0, 128, 1024), r.fillStyle = "rgba(7,23,29,.7)", r.fillRect(a, 0, 5, 1024), r.fillRect(a + 120, 0, 4, 1024), r.fillStyle = "rgba(176,205,205,.42)", r.fillRect(a + 7, 0, 2, 1024), r.fillRect(a + 116, 0, 2, 1024);
    for (let u = 0; u < 1024; u += 170.5)
      r.fillStyle = "rgba(12,31,36,.55)", r.fillRect(a, u, 128, 4), r.fillStyle = "rgba(163,191,194,.36)", r.fillRect(a, u + 5, 128, 2);
  }
  const o = r.createLinearGradient(0, 0, 512, 600);
  o.addColorStop(0, "rgba(192,222,233,.03)"), o.addColorStop(0.48, "rgba(169,201,211,.18)"), o.addColorStop(1, "rgba(130,169,183,0)"), r.fillStyle = o, r.fillRect(0, 0, 512, 1024);
  const c = new S.CanvasTexture(n);
  c.colorSpace = S.SRGBColorSpace, c.wrapS = S.RepeatWrapping, c.anisotropy = s ? Math.min(8, s.capabilities.getMaxAnisotropy()) : 8;
  const E = [];
  for (let t = 0; t < 6; t++) {
    const a = document.createElement("canvas");
    a.width = a.height = 256;
    const u = a.getContext("2d"), i = u.createLinearGradient(0, 0, 0, 256);
    i.addColorStop(0, "#688bad"), i.addColorStop(0.5, "#b5cbd4"), i.addColorStop(0.63, "#829491"), i.addColorStop(1, "#344941"), u.fillStyle = i, u.fillRect(0, 0, 256, 256);
    for (let l = 0; l < 12; l++) {
      const p = (l * 83 + t * 39) % 256, C = 20 + l * 37 % 105, v = u.createRadialGradient(p, C, 2, p, C, 36);
      v.addColorStop(0, "rgba(245,250,250,.4)"), v.addColorStop(1, "rgba(245,250,250,0)"), u.fillStyle = v, u.fillRect(0, 0, 256, 256);
    }
    E.push(a);
  }
  const d = new S.CubeTexture(E);
  d.colorSpace = S.SRGBColorSpace, d.needsUpdate = !0;
  const x = new S.MeshStandardMaterial({
    color: 12966873,
    map: c,
    roughness: 0.28,
    metalness: 0.22,
    envMap: d,
    envMapIntensity: 0.32,
    emissive: 6652535,
    emissiveMap: c,
    emissiveIntensity: 0
  });
  return x.color.convertSRGBToLinear(), x.name = "facade.glass", { facadeGlass: x, facadeTexture: c, reflection: d };
}
function it() {
  const n = [], r = [(E, d) => [1, -d, -E], (E, d) => [-1, -d, E], (E, d) => [E, 1, d], (E, d) => [E, -1, -d], (E, d) => [E, -d, 1], (E, d) => [-E, -d, -1]], e = (E, d, x) => E.map((t, a) => t + (d[a] - t) * x);
  for (const E of r) {
    const d = document.createElement("canvas");
    d.width = d.height = 256;
    const x = d.getContext("2d"), t = x.createImageData(256, 256);
    for (let a = 0; a < 256; a++) for (let u = 0; u < 256; u++) {
      let [i, l, p] = E(2 * (u + 0.5) / 256 - 1, 2 * (a + 0.5) / 256 - 1);
      const C = Math.hypot(i, l, p);
      i /= C, l /= C, p /= C;
      const v = Math.atan2(p, i), F = Math.max(0, Math.min(1, l));
      let f = e([202, 215, 221], [96, 139, 181], Math.sqrt(F));
      const h = Math.max(0, Math.sin(v * 3 + l * 8) * Math.sin(v * 7 - l * 13)) * 0.25;
      l > 0 && (f = e(f, [242, 244, 243], h));
      const B = Math.max(0, i * -0.65 + p * 0.76) * Math.exp(-Math.pow((l - 0.23) * 3, 2)) * 0.1;
      f = e(f, [248, 221, 179], B);
      const A = Math.floor((v + Math.PI) * 3), m = (v + Math.PI) * 3 % 1, y = 0.08 + 0.43 * (0.5 + 0.5 * Math.sin(A * 13.7));
      if (l < y && m > 0.09 && m < 0.9) {
        const k = 0.5 + 0.5 * Math.sin(A * 4.3);
        f = e([57, 73, 82], [133, 151, 159], k), m % 0.28 < 0.015 && (f = e(f, [211, 224, 230], 0.18));
      }
      l < -0.65 && (f = e([30, 43, 45], [67, 82, 82], Math.max(0, 1 + l)));
      const b = (a * 256 + u) * 4;
      for (let k = 0; k < 3; k++) t.data[b + k] = f[k];
      t.data[b + 3] = 255;
    }
    x.putImageData(t, 0, 0), n.push(d);
  }
  const o = new S.CubeTexture(n);
  o.colorSpace = S.SRGBColorSpace, o.needsUpdate = !0;
  const c = new S.MeshStandardMaterial({ color: 8690083, metalness: 0.35, roughness: 0.32, envMap: o, envMapIntensity: 0.62 });
  return c.color.convertSRGBToLinear(), c.name = "wangchao.glass", { glass: c, reflection: o };
}
function st(s) {
  const n = /* @__PURE__ */ new Map(), r = (o, c) => (n.has(o) || n.set(o, c()), n.get(o)), e = {
    smartFacade: () => r("smartFacade", () => ot(s)),
    towerGlass: () => r("towerGlass", () => it()),
    /** 按槽名取预设材质；没有对应预设时返回 null（加载器保留文件里的材质） */
    bySlot(o) {
      return o === "facade.glass" ? e.smartFacade().facadeGlass : o === "wangchao.glass" ? e.towerGlass().glass : null;
    },
    dispose() {
      for (const o of n.values()) for (const c of Object.values(o)) c && c.dispose && c.dispose();
      n.clear();
    }
  };
  return e;
}
const xt = Object.freeze([
  "focus",
  "reset",
  "top",
  "orbit",
  "pause",
  "view",
  "labels",
  "studio",
  "environment",
  "snapshots",
  "select",
  "explodeFloor",
  "closeFloor",
  "mode",
  "layer",
  "router",
  "roomHighlight",
  "planView",
  "highlight"
]), ct = {
  fov: 43,
  near: 1,
  far: 1800,
  pixelRatioMax: 1.65,
  exposure: 0.85,
  controls: { minDistance: 40, maxDistance: 850, maxPolarAngle: Math.PI * 0.485, autoRotateSpeed: 0.45 },
  sun: { color: 16772824, position: [-100, 180, 100], shadowMapSize: 2048, shadowExtent: 210, shadowFar: 600, shadowBias: -3e-4 },
  hemisphere: { sky: 14151423, ground: 5924432 },
  sky: { day: 11060956, night: 595237, overcast: 9018281, studio: 16777215 },
  fog: { normal: 9e-4, fog: 7e-3 },
  lights: { sun: [2.4, 0.9, 0.15], ambient: [1.3, 0.5] }
  // [晴, 阴, 夜] / [日, 夜]，r115 艺术家单位
};
class Le {
  /**
   * @param {HTMLElement} container
   * @param {object} opts
   *   - emit(type, payload)       事件出口（labels / stats / snapshots / select）
   *   - palette                   主题场景调色板（skyDay / skyNight / studioSky / studioGround 等）
   *   - studio                    初始是否纯白背景
   *   - emitSelect                点击楼栋时是否发 select 事件（Smart 现状为 false，只聚焦）
   *   - supports                  当前模型声明支持的能力（can() 的依据）
   */
  constructor(n, r = {}) {
    this.container = n, this.opts = r, this.emit = r.emit || (() => {
    }), this.palette = r.palette || {}, this.supports = new Set(r.supports || []), this.renderer = new S.WebGLRenderer({ antialias: !0, preserveDrawingBuffer: !0 }), this.presets = st(this.renderer), this.scene = new S.Scene(), r.legacyLook !== !1 && Xr(this.scene), this.behaviors = [], this._disposables = [], this.paused = !1, this.disposed = !1, this.fly = null, this.weather = "sunny", this.hour = 14, this.studioOn = !!r.studio, this._frames = 0, this._statsAt = performance.now(), this._labelsAt = 0, this._last = performance.now();
  }
  /** 装入模型：{ root, model: { viewer, home, semantics }, slots? } */
  setModel({ root: n, model: r }) {
    const e = { ...ct, ...r.viewer || {} };
    this.cfg = e, this.model = r;
    const o = this.renderer;
    o.setPixelRatio(Math.min(devicePixelRatio, e.pixelRatioMax)), o.outputColorSpace = S.SRGBColorSpace, o.toneMapping = S.ACESFilmicToneMapping, o.toneMappingExposure = e.exposure, o.shadowMap.enabled = !0, o.shadowMap.type = S.PCFShadowMap, this.container.appendChild(o.domElement), this.camera = new S.PerspectiveCamera(e.fov, 1, e.near, e.far);
    const c = this.controls = new Kr(this.camera, o.domElement);
    c.enableDamping = !0, Object.assign(c, e.controls);
    const E = e.sun;
    this.sun = new S.DirectionalLight(E.color, 2.4), this.sun.position.set(...E.position), this.sun.castShadow = !0, this.sun.shadow.mapSize.set(E.shadowMapSize, E.shadowMapSize), Object.assign(this.sun.shadow.camera, { left: -E.shadowExtent, right: E.shadowExtent, top: E.shadowExtent, bottom: -E.shadowExtent, near: 1, far: E.shadowFar }), this.sun.shadow.bias = E.shadowBias, this.ambient = new S.HemisphereLight(e.hemisphere.sky, e.hemisphere.ground, 1.3), this.scene.add(this.sun, this.ambient), this.root = n, this.scene.add(n), this.generated = [];
    for (const x of r.semantics?.generators || []) {
      const t = nt[x.plugin];
      t && this.generated.push(t.build(n, x.params, { palette: this.palette }));
    }
    this.index = Zr(r.semantics?.tree), this.cameras = new Map((r.semantics?.cameras || []).map((x) => [x.id, x])), this.materials = /* @__PURE__ */ new Map(), n.traverse((x) => {
      x.isMesh && (Array.isArray(x.material) ? x.material : [x.material]).forEach((t) => {
        t && t.name && !this.materials.has(t.name) && this.materials.set(t.name, t);
      });
    }), this._materialBase = new Map([...this.materials].map(([x, t]) => [x, { color: t.color && t.color.clone(), emissiveIntensity: t.emissiveIntensity, roughness: t.roughness }])), this.sets = /* @__PURE__ */ new Map();
    for (const [x, t] of Object.entries(r.semantics?.instanceSets || {}))
      this.sets.set(x, { name: x, parent: t.parent, ids: t.ids, index: new Map(t.ids.map((a, u) => [a, u])), meshes: [], base: /* @__PURE__ */ new Map() });
    n.traverse((x) => {
      if (!x.isInstancedMesh) return;
      const t = w0(x), a = t && t[0] === "@" ? this.sets.get(t.slice(1)) : null;
      a && (x.userData.instanceSet = a.name, a.meshes.push(x), a.base.set(x, x.instanceMatrix.array.slice()));
    }), this.pickable = [], n.traverse((x) => {
      if (!x.isMesh) return;
      const t = x.userData.instanceSet && this.sets.get(x.userData.instanceSet), a = this.index.get(t ? t.parent : w0(x));
      a && a.pickable !== !1 && this.pickable.push(x);
    }), this.layerDefs = r.semantics?.layers || [], this.layerState = Object.fromEntries(this.layerDefs.map((x) => [x.id, x.default !== !1])), this.modes = r.semantics?.modes || [], this.modeId = this.modes[0]?.id || null;
    for (const x of r.semantics?.behaviors || []) {
      const t = tt[x.plugin];
      t && this.behaviors.push(t.create(this, x, x.params));
    }
    this.overlay = new S.Group(), this.overlay.name = "highlight-overlay", this.scene.add(this.overlay), this._layerCover = /* @__PURE__ */ new Map();
    for (const x of this.layerDefs) for (const t of x.targets || []) for (const a of this._targets(t))
      a.instance === void 0 && (this._layerCover.has(a.mesh) || this._layerCover.set(a.mesh, /* @__PURE__ */ new Set()), this._layerCover.get(a.mesh).add(x.id));
    this._applyLayers(), this._onDown = (x) => {
      this._down = [x.clientX, x.clientY], this.fly = null;
    }, this._onUp = (x) => this._click(x), o.domElement.addEventListener("pointerdown", this._onDown), o.domElement.addEventListener("pointerup", this._onUp), this._resize = () => {
      const x = this.container.clientWidth, t = Math.max(1, this.container.clientHeight);
      o.setSize(x, t), this.camera.aspect = x / t, this.camera.updateProjectionMatrix();
    }, this._observer = new ResizeObserver(this._resize), this._observer.observe(this.container), this._resize();
    const d = r.home || this.cameras.get("home");
    return this.home = { position: new S.Vector3(...d.position), target: new S.Vector3(...d.target) }, this.camera.position.copy(this.home.position), c.target.copy(this.home.target), c.update(), this.environment(), this._animate = this._animate.bind(this), this._frame = requestAnimationFrame(this._animate), this._snapshotTimer = setTimeout(() => this.snapshots(), 500), this;
  }
  can(n) {
    return this.supports.has(n);
  }
  // ---------------- 环境 ----------------
  _pick(n, r) {
    return this.palette[n] === void 0 ? r : this.palette[n];
  }
  environment(n = "sunny", r = 14) {
    this.hour = r, this.weather = n;
    const e = r < 6 || r > 19, o = this.cfg.sky;
    this.scene.background = new S.Color(this.studioOn ? this._pick("studioSky", o.studio) : e ? this._pick("skyNight", o.night) : n === "sunny" ? this._pick("skyDay", o.day) : o.overcast), this.scene.fog = new S.FogExp2(this.scene.background, n === "fog" ? this.cfg.fog.fog : this.cfg.fog.normal);
    const c = this.cfg.lights;
    this.sun.intensity = e ? c.sun[2] : n === "sunny" ? c.sun[0] : c.sun[1], this.ambient.intensity = e ? c.ambient[1] : c.ambient[0], this.sun.position.set(Math.cos(r / 24 * Math.PI * 2) * 160, 80 + Math.sin(r / 24 * Math.PI) * 120, 100), this._applyMaterialStates({ night: e, weather: n, studio: this.studioOn });
    for (const E of this.behaviors) E.environment && E.environment({ weather: n, hour: r, night: e });
    return !0;
  }
  _applyMaterialStates(n) {
    const r = this.model.semantics?.materialStates || {};
    for (const [e, o] of Object.entries(r)) {
      const c = this.materials.get(e);
      if (!c) continue;
      const E = this._materialBase.get(e), d = (x) => {
        for (const [t, a] of Object.entries(x || {}))
          t === "color" ? c.color.set(this._pick(a, 16777215)).convertSRGBToLinear() : c[t] = a;
      };
      o.studio && E.color && c.color.copy(E.color), d(o.default), n.night && d(o.night), n.weather === "rain" && d(o.rain), n.weather === "snow" && d(o.snow), n.weather === "fog" && d(o.fog), n.studio && d(o.studio);
    }
  }
  studio(n) {
    return this.studioOn = !!n, this.environment(this.weather, this.hour), !0;
  }
  // ---------------- 相机 ----------------
  _flyTo(n) {
    this.controls.autoRotate = !1, this.fly = { position: new S.Vector3(...n.position), target: new S.Vector3(...n.target) };
  }
  focus(n) {
    const r = this._focusMode(n);
    r && r !== this.modeId && this.mode(r, { keepCamera: !0 });
    const e = this.cameras.get("focus:" + n) || this._autoFrame(n);
    return e ? (this._flyTo(e), this.index.get(n)?.type === "device" && this.highlight([n]), this.opts.emitSelect && this.emit("select", this._selectPayload(n)), !0) : !1;
  }
  /** 语义节点（或其祖先）上的 focusMode：聚焦前先切到该模式（例如库内设备先去顶） */
  _focusMode(n) {
    return this._inherit(n, "focusMode");
  }
  /** 沿语义树向上找第一个设置了 key 的节点 */
  _inherit(n, r) {
    for (let e = n; e; e = this.index.get(e)?.parent) {
      const o = this.index.get(e);
      if (o && o[r] !== void 0) return o[r];
    }
  }
  /** 没有命名机位时按包围盒取景：沿当前视线方向后退，保证俯角 */
  _autoFrame(n) {
    const r = this.boundsOf(n);
    if (!r) return null;
    let e = r.getCenter(new S.Vector3()), o = r.getSize(new S.Vector3()).length();
    const c = this._inherit(n, "focusDistance");
    if (c) {
      const a = this.boundsOf(n, { first: !0 });
      a && (e = a.getCenter(new S.Vector3()));
    }
    let E = this.camera.position.clone().sub(this.controls.target);
    const d = this._inherit(n, "focusFrom"), x = d && this._targets(n).find((a) => a.instance !== void 0);
    if (x) {
      const a = new S.Matrix4();
      x.mesh.getMatrixAt(x.instance, a), a.premultiply(x.mesh.matrixWorld), E = new S.Vector3().setFromMatrixColumn(a, d === "z" ? 2 : 0), E.y = 0;
    }
    E.lengthSq() < 1e-6 && E.set(1, 1, 1), E.normalize(), E.y < 0.45 && (E.y = 0.45, E.normalize());
    const t = Math.max(c || o * 1.6 + 2.2, (this.controls.minDistance || 0) * 1.05);
    return { position: e.clone().addScaledVector(E, t).toArray(), target: e.toArray() };
  }
  /** 语义 id（楼、分组、单台设备）的世界包围盒 */
  boundsOf(n, { first: r = !1 } = {}) {
    const e = new S.Box3(), o = new S.Box3(), c = new S.Matrix4();
    let E = !1;
    const d = this._targets(n).filter((x) => x.mesh.visible);
    for (const x of r ? d.slice(0, 1) : d) {
      const t = x.mesh.geometry;
      t.boundingBox || t.computeBoundingBox(), x.mesh.updateMatrixWorld(), x.instance !== void 0 ? (x.mesh.getMatrixAt(x.instance, c), o.copy(t.boundingBox).applyMatrix4(c).applyMatrix4(x.mesh.matrixWorld)) : x.mesh.isInstancedMesh ? (x.mesh.boundingBox || x.mesh.computeBoundingBox(), o.copy(x.mesh.boundingBox).applyMatrix4(x.mesh.matrixWorld)) : o.copy(t.boundingBox).applyMatrix4(x.mesh.matrixWorld), e.union(o), E = !0;
    }
    return E ? e : null;
  }
  /** 一个语义 id 覆盖的渲染对象：普通网格整件；实例集整件（分组）或单个实例（单台设备） */
  _targets(n) {
    const r = [];
    return this.root.traverse((e) => {
      if (!e.isMesh) return;
      const o = e.userData.instanceSet && this.sets.get(e.userData.instanceSet);
      if (o)
        if (qe(this.index, o.parent, n)) r.push({ mesh: e });
        else {
          const c = o.index.get(n);
          c !== void 0 && r.push({ mesh: e, instance: c });
        }
      else qe(this.index, w0(e), n) && r.push({ mesh: e });
    }), r;
  }
  _selectPayload(n) {
    const r = this.index.get(n);
    return r ? { id: n, type: r.type, name: r.name, ...r.props || {} } : { id: n };
  }
  reset() {
    return this.fly = { position: this.home.position.clone(), target: this.home.target.clone() }, this.controls.autoRotate = !1, !0;
  }
  top() {
    const n = this.cameras.get("top");
    return n ? (this.controls.autoRotate = !1, this.fly = { position: new S.Vector3(...n.position), target: this.home.target.clone() }, !0) : !1;
  }
  orbit(n) {
    return this.controls.autoRotate = n, this.fly = null, !0;
  }
  pause(n) {
    return this.paused = n, this._frames = 0, this._statsAt = performance.now(), !0;
  }
  /** 不带参数：读当前机位；带参数：平滑飞过去（演示模式每页的视角） */
  view(n) {
    if (!n) return { camera: this.camera.position.toArray(), target: this.controls.target.toArray() };
    const r = n.position, e = n.target;
    !Array.isArray(r) || r.length < 3 || (this.controls.autoRotate = !1, this.fly = { position: new S.Vector3(r[0], r[1], r[2]), target: Array.isArray(e) && e.length >= 3 ? new S.Vector3(e[0], e[1], e[2]) : this.controls.target.clone() });
  }
  snapshots() {
    const n = [...this.cameras.values()].filter((c) => c.id.startsWith("snapshot-"));
    if (!n.length) return !1;
    const r = this.camera.position.clone(), e = [], o = this.renderer;
    if (!o.domElement.width || !o.domElement.height)
      return (this._snapshotTries = (this._snapshotTries || 0) + 1) <= 20 && !this.disposed && (this._snapshotTimer = setTimeout(() => this.snapshots(), 500)), !1;
    for (const c of n) {
      this.camera.position.set(...c.position), this.camera.lookAt(...c.target), o.render(this.scene, this.camera);
      const E = document.createElement("canvas");
      E.width = 480, E.height = 270, E.getContext("2d").drawImage(o.domElement, 0, 0, 480, 270), e.push(E.toDataURL("image/jpeg", 0.82));
    }
    return this.camera.position.copy(r), this.camera.lookAt(this.controls.target), o.render(this.scene, this.camera), this.emit("snapshots", e), !0;
  }
  // ---------------- 拾取 / 高亮 / 显隐 ----------------
  pickAt(n, r) {
    const e = this.renderer.domElement.getBoundingClientRect(), o = new S.Raycaster();
    o.setFromCamera(new S.Vector2((n - e.left) / e.width * 2 - 1, -(r - e.top) / e.height * 2 + 1), this.camera);
    const c = o.intersectObjects(this.pickable.filter((x) => x.visible))[0];
    if (!c) return null;
    const E = c.object.userData.instanceSet && this.sets.get(c.object.userData.instanceSet);
    return { id: E && c.instanceId !== void 0 ? E.ids[c.instanceId] : w0(c.object), point: c.point.toArray(), object: c.object, instanceId: c.instanceId };
  }
  _click(n) {
    if (!this._down || Math.hypot(n.clientX - this._down[0], n.clientY - this._down[1]) > 5) return;
    const r = this.pickAt(n.clientX, n.clientY);
    r && this.focus(r.id);
  }
  /** 覆盖层高亮（不替换原材质）。ids 为空数组时清除 */
  highlight(n = [], r = {}) {
    if (this.overlay.children.slice().forEach((E) => this.overlay.remove(E)), !n.length) return !0;
    const e = new S.MeshBasicMaterial({ color: r.color || 16738816, transparent: !0, opacity: r.opacity ?? 0.35, polygonOffset: !0, polygonOffsetFactor: -1, depthWrite: !1 }), o = new S.Matrix4(), c = /* @__PURE__ */ new Set();
    for (const E of n) for (const d of this._targets(E)) {
      const x = d.mesh;
      if (!x.visible) continue;
      const t = x.uuid + ":" + (d.instance ?? "*");
      if (c.has(t)) continue;
      c.add(t), x.updateMatrixWorld();
      let a;
      d.instance !== void 0 ? (a = new S.Mesh(x.geometry, e), x.getMatrixAt(d.instance, o), a.matrix.multiplyMatrices(x.matrixWorld, o)) : x.isInstancedMesh ? (a = new S.InstancedMesh(x.geometry, e, x.count), a.instanceMatrix = x.instanceMatrix, a.matrix.copy(x.matrixWorld), a.frustumCulled = !1) : (a = new S.Mesh(x.geometry, e), a.matrix.copy(x.matrixWorld)), a.matrixAutoUpdate = !1, a.renderOrder = 10, this.overlay.add(a);
    }
    return this.overlay.children.length > 0;
  }
  setVisible(n, r) {
    let e = 0;
    const o = new S.Matrix4().makeScale(0, 0, 0);
    for (const c of this._targets(n)) {
      if (e++, c.instance === void 0) {
        c.mesh.visible = r;
        continue;
      }
      const E = this.sets.get(c.mesh.userData.instanceSet).base.get(c.mesh);
      r ? c.mesh.setMatrixAt(c.instance, new S.Matrix4().fromArray(E, c.instance * 16)) : c.mesh.setMatrixAt(c.instance, o), c.mesh.instanceMatrix.needsUpdate = !0, c.mesh.boundingSphere = null, c.mesh.boundingBox = null;
    }
    return e > 0;
  }
  /** 图层：不带参数读全部开关；带参数设置一个 */
  layer(n, r) {
    return n !== void 0 && typeof r == "boolean" && n in this.layerState && (this.layerState[n] = r, this._applyLayers(), this.emit("layers", { ...this.layerState })), { ...this.layerState };
  }
  _applyLayers() {
    for (const [n, r] of this._layerCover) n.visible = [...r].every((e) => this.layerState[e]);
  }
  /** 模式：不带参数读当前模式；带参数切换（图层组合 + 机位） */
  mode(n, { keepCamera: r = !1 } = {}) {
    if (n === void 0) return this.modeId;
    const e = this.modes.find((o) => o.id === n);
    if (!e) return this.modeId;
    this.modeId = n;
    for (const [o, c] of Object.entries(e.layers || {})) o in this.layerState && (this.layerState[o] = c);
    if (this._applyLayers(), this.emit("layers", { ...this.layerState }), !r && e.camera) {
      const o = e.camera === "home" ? { position: this.home.position.toArray(), target: this.home.target.toArray() } : this.cameras.get(e.camera);
      o && this._flyTo(o);
    }
    return this.emit("mode", n), n;
  }
  // ---------------- 循环 ----------------
  _animate(n) {
    if (this.disposed) return;
    this._frame = requestAnimationFrame(this._animate);
    const r = Math.min((n - this._last) / 1e3, 0.05);
    if (this._last = n, !this.paused) {
      this.fly && (this.camera.position.lerp(this.fly.position, 0.05), this.controls.target.lerp(this.fly.target, 0.05), this.camera.position.distanceTo(this.fly.position) < 0.1 && (this.fly = null));
      for (const e of this.behaviors) e.update && e.update(r);
      this.controls.update(), this.renderer.render(this.scene, this.camera), n - this._labelsAt > 60 && (this._labelsAt = n, this.emit("labels", this.labels())), this._frames++, n - this._statsAt > 1200 && (this.emit("stats", Math.round(this._frames * 1e3 / (n - this._statsAt))), this._frames = 0, this._statsAt = n);
    }
  }
  /** 锚点投影到屏幕：[{ id, x, y, visible }]，id 为锚点指向的语义 id（与现有 onLabels 一致） */
  labels() {
    const n = this.container.clientWidth, r = this.container.clientHeight;
    return (this.model.semantics?.anchors || []).map((e) => {
      const o = new S.Vector3(...e.position).project(this.camera), c = !e.layer || this.layerState[e.layer] !== !1, E = { id: e.target, x: (o.x * 0.5 + 0.5) * n, y: (-o.y * 0.5 + 0.5) * r, visible: c && o.z > -1 && o.z < 1 };
      for (const d of ["text", "kind", "icon", "color"]) e[d] !== void 0 && (E[d] = e[d]);
      return E;
    });
  }
  /** 挂一个跟 Viewer 一起释放的东西（例：loadMap 建的 Draco 解码器 —— 它背后有 Worker 和 WASM 实例） */
  addDisposable(n) {
    return n && typeof n.dispose == "function" && this._disposables.push(n), n;
  }
  dispose() {
    this.disposed = !0, cancelAnimationFrame(this._frame), clearTimeout(this._snapshotTimer);
    for (const e of this._disposables.splice(0))
      try {
        e.dispose();
      } catch {
      }
    this._observer && this._observer.disconnect(), this.controls && this.controls.dispose();
    const n = this.renderer.domElement;
    n.removeEventListener("pointerdown", this._onDown), n.removeEventListener("pointerup", this._onUp), this.behaviors.forEach((e) => e.dispose && e.dispose());
    const r = /* @__PURE__ */ new Set();
    this.scene.traverse((e) => {
      e.geometry && r.add(e.geometry), e.material && (Array.isArray(e.material) ? e.material : [e.material]).forEach((o) => {
        r.add(o);
        for (const c of Object.values(o)) c && c.isTexture && r.add(c);
      });
    }), r.forEach((e) => e.dispose && e.dispose()), this.presets.dispose(), this.renderer.dispose(), n.remove();
  }
}
for (const s of xt) s in Le.prototype || (Le.prototype[s] = function() {
  return !1;
});
var J = Uint8Array, B0 = Uint16Array, ft = Int32Array, Dr = new J([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), yr = new J([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), lt = new J([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), br = function(s, n) {
  for (var r = new B0(31), e = 0; e < 31; ++e)
    r[e] = n += 1 << s[e - 1];
  for (var o = new ft(r[30]), e = 1; e < 30; ++e)
    for (var c = r[e]; c < r[e + 1]; ++c)
      o[c] = c - r[e] << 5 | e;
  return { b: r, r: o };
}, _r = br(Dr, 2), wr = _r.b, ht = _r.r;
wr[28] = 258, ht[258] = 28;
var ut = br(yr, 0), dt = ut.b, Ce = new B0(32768);
for (var V = 0; V < 32768; ++V) {
  var f0 = (V & 43690) >> 1 | (V & 21845) << 1;
  f0 = (f0 & 52428) >> 2 | (f0 & 13107) << 2, f0 = (f0 & 61680) >> 4 | (f0 & 3855) << 4, Ce[V] = ((f0 & 65280) >> 8 | (f0 & 255) << 8) >> 1;
}
var g0 = (function(s, n, r) {
  for (var e = s.length, o = 0, c = new B0(n); o < e; ++o)
    s[o] && ++c[s[o] - 1];
  var E = new B0(n);
  for (o = 1; o < n; ++o)
    E[o] = E[o - 1] + c[o - 1] << 1;
  var d;
  if (r) {
    d = new B0(1 << n);
    var x = 15 - n;
    for (o = 0; o < e; ++o)
      if (s[o])
        for (var t = o << 4 | s[o], a = n - s[o], u = E[s[o] - 1]++ << a, i = u | (1 << a) - 1; u <= i; ++u)
          d[Ce[u] >> x] = t;
  } else
    for (d = new B0(e), o = 0; o < e; ++o)
      s[o] && (d[o] = Ce[E[s[o] - 1]++] >> 15 - s[o]);
  return d;
}), D0 = new J(288);
for (var V = 0; V < 144; ++V)
  D0[V] = 8;
for (var V = 144; V < 256; ++V)
  D0[V] = 9;
for (var V = 256; V < 280; ++V)
  D0[V] = 7;
for (var V = 280; V < 288; ++V)
  D0[V] = 8;
var kr = new J(32);
for (var V = 0; V < 32; ++V)
  kr[V] = 5;
var vt = /* @__PURE__ */ g0(D0, 9, 1), pt = /* @__PURE__ */ g0(kr, 5, 1), ue = function(s) {
  for (var n = s[0], r = 1; r < s.length; ++r)
    s[r] > n && (n = s[r]);
  return n;
}, a0 = function(s, n, r) {
  var e = n / 8 | 0;
  return (s[e] | s[e + 1] << 8) >> (n & 7) & r;
}, de = function(s, n) {
  var r = n / 8 | 0;
  return (s[r] | s[r + 1] << 8 | s[r + 2] << 16) >> (n & 7);
}, Bt = function(s) {
  return (s + 7) / 8 | 0;
}, Fe = function(s, n, r) {
  return (n == null || n < 0) && (n = 0), (r == null || r > s.length) && (r = s.length), new J(s.subarray(n, r));
}, Ct = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], Q = function(s, n, r) {
  var e = new Error(n || Ct[s]);
  if (e.code = s, Error.captureStackTrace && Error.captureStackTrace(e, Q), !r)
    throw e;
  return e;
}, At = function(s, n, r, e) {
  var o = s.length, c = e ? e.length : 0;
  if (!o || n.f && !n.l)
    return r || new J(0);
  var E = !r, d = E || n.i != 2, x = n.i;
  E && (r = new J(o * 3));
  var t = function(d0) {
    var s0 = r.length;
    if (d0 > s0) {
      var j = new J(Math.max(s0 * 2, d0));
      j.set(r), r = j;
    }
  }, a = n.f || 0, u = n.p || 0, i = n.b || 0, l = n.l, p = n.d, C = n.m, v = n.n, F = o * 8;
  do {
    if (!l) {
      a = a0(s, u, 1);
      var f = a0(s, u + 1, 3);
      if (u += 3, f)
        if (f == 1)
          l = vt, p = pt, C = 9, v = 5;
        else if (f == 2) {
          var m = a0(s, u, 31) + 257, y = a0(s, u + 10, 15) + 4, b = m + a0(s, u + 5, 31) + 1;
          u += 14;
          for (var k = new J(b), g = new J(19), D = 0; D < y; ++D)
            g[lt[D]] = a0(s, u + D * 3, 7);
          u += y * 3;
          for (var _ = ue(g), w = (1 << _) - 1, P = g0(g, _, 1), D = 0; D < b; ) {
            var W = P[a0(s, u, w)];
            u += W & 15;
            var h = W >> 4;
            if (h < 16)
              k[D++] = h;
            else {
              var q = 0, O = 0;
              for (h == 16 ? (O = 3 + a0(s, u, 3), u += 2, q = k[D - 1]) : h == 17 ? (O = 3 + a0(s, u, 7), u += 3) : h == 18 && (O = 11 + a0(s, u, 127), u += 7); O--; )
                k[D++] = q;
            }
          }
          var G = k.subarray(0, m), I = k.subarray(m);
          C = ue(G), v = ue(I), l = g0(G, C, 1), p = g0(I, v, 1);
        } else
          Q(1);
      else {
        var h = Bt(u) + 4, B = s[h - 4] | s[h - 3] << 8, A = h + B;
        if (A > o) {
          x && Q(0);
          break;
        }
        d && t(i + B), r.set(s.subarray(h, A), i), n.b = i += B, n.p = u = A * 8, n.f = a;
        continue;
      }
      if (u > F) {
        x && Q(0);
        break;
      }
    }
    d && t(i + 131072);
    for (var U = (1 << C) - 1, M = (1 << v) - 1, z = u; ; z = u) {
      var q = l[de(s, u) & U], H = q >> 4;
      if (u += q & 15, u > F) {
        x && Q(0);
        break;
      }
      if (q || Q(2), H < 256)
        r[i++] = H;
      else if (H == 256) {
        z = u, l = null;
        break;
      } else {
        var R = H - 254;
        if (H > 264) {
          var D = H - 257, $ = Dr[D];
          R = a0(s, u, (1 << $) - 1) + wr[D], u += $;
        }
        var N = p[de(s, u) & M], X = N >> 4;
        N || Q(3), u += N & 15;
        var I = dt[X];
        if (X > 3) {
          var $ = yr[X];
          I += de(s, u) & (1 << $) - 1, u += $;
        }
        if (u > F) {
          x && Q(0);
          break;
        }
        d && t(i + 131072);
        var T = i + R;
        if (i < I) {
          var o0 = c - I, i0 = Math.min(I, T);
          for (o0 + i < 0 && Q(3); i < i0; ++i)
            r[i] = e[o0 + i];
        }
        for (; i < T; ++i)
          r[i] = r[i - I];
      }
    }
    n.l = l, n.p = z, n.b = i, n.f = a, l && (a = 1, n.m = C, n.d = p, n.n = v);
  } while (!a);
  return i != r.length && E ? Fe(r, 0, i) : r.subarray(0, i);
}, Et = /* @__PURE__ */ new J(0), n0 = function(s, n) {
  return s[n] | s[n + 1] << 8;
}, r0 = function(s, n) {
  return (s[n] | s[n + 1] << 8 | s[n + 2] << 16 | s[n + 3] << 24) >>> 0;
}, ve = function(s, n) {
  return r0(s, n) + r0(s, n + 4) * 4294967296;
};
function mt(s, n) {
  return At(s, { i: 2 }, n && n.out, n && n.dictionary);
}
var Ae = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), Ft = 0;
try {
  Ae.decode(Et, { stream: !0 }), Ft = 1;
} catch {
}
var gt = function(s) {
  for (var n = "", r = 0; ; ) {
    var e = s[r++], o = (e > 127) + (e > 223) + (e > 239);
    if (r + o > s.length)
      return { s: n, r: Fe(s, r - 1) };
    o ? o == 3 ? (e = ((e & 15) << 18 | (s[r++] & 63) << 12 | (s[r++] & 63) << 6 | s[r++] & 63) - 65536, n += String.fromCharCode(55296 | e >> 10, 56320 | e & 1023)) : o & 1 ? n += String.fromCharCode((e & 31) << 6 | s[r++] & 63) : n += String.fromCharCode((e & 15) << 12 | (s[r++] & 63) << 6 | s[r++] & 63) : n += String.fromCharCode(e);
  }
};
function Ee(s, n) {
  if (n) {
    for (var r = "", e = 0; e < s.length; e += 16384)
      r += String.fromCharCode.apply(null, s.subarray(e, e + 16384));
    return r;
  } else {
    if (Ae)
      return Ae.decode(s);
    var o = gt(s), c = o.s, r = o.r;
    return r.length && Q(8), c;
  }
}
var Dt = function(s, n) {
  return n + 30 + n0(s, n + 26) + n0(s, n + 28);
}, yt = function(s, n, r) {
  var e = n0(s, n + 28), o = n0(s, n + 30), c = Ee(s.subarray(n + 46, n + 46 + e), !(n0(s, n + 8) & 2048)), E = n + 46 + e, d = bt(s, E, o, r, r0(s, n + 20), r0(s, n + 24), r0(s, n + 42)), x = d[0], t = d[1], a = d[2];
  return [n0(s, n + 10), x, t, c, E + o + n0(s, n + 32), a];
}, bt = function(s, n, r, e, o, c, E) {
  var d = o == 4294967295, x = c == 4294967295, t = E == 4294967295, a = n + r, u = d + x + t;
  if (e && u) {
    for (; n + 4 < a; n += 4 + n0(s, n + 2))
      if (n0(s, n) == 1)
        return [
          d ? ve(s, n + 4 + 8 * x) : o,
          x ? ve(s, n + 4) : c,
          t ? ve(s, n + 4 + 8 * (x + d)) : E,
          1
        ];
    e < 2 && Q(13);
  }
  return [o, c, E, 0];
};
function _t(s, n) {
  for (var r = {}, e = s.length - 22; r0(s, e) != 101010256; --e)
    (!e || s.length - e > 65558) && Q(13);
  var o = n0(s, e + 8);
  if (!o)
    return {};
  var c = r0(s, e + 16), E = r0(s, e - 20) == 117853008;
  if (E) {
    var d = r0(s, e - 12);
    E = r0(s, d) == 101075792, E && (o = r0(s, d + 32), c = r0(s, d + 48));
  }
  for (var x = 0; x < o; ++x) {
    var t = yt(s, c, E), a = t[0], u = t[1], i = t[2], l = t[3], p = t[4], C = t[5], v = Dt(s, C);
    c = p, a ? a == 8 ? r[l] = mt(s.subarray(v, v + u), { out: new J(i) }) : Q(14, "unknown compression type " + a) : r[l] = Fe(s, v, v + u);
  }
  return r;
}
var pe = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function wt(s) {
  return s && s.__esModule && Object.prototype.hasOwnProperty.call(s, "default") ? s.default : s;
}
function kt(s) {
  if (Object.prototype.hasOwnProperty.call(s, "__esModule")) return s;
  var n = s.default;
  if (typeof n == "function") {
    var r = function e() {
      return this instanceof e ? Reflect.construct(n, arguments, this.constructor) : n.apply(this, arguments);
    };
    r.prototype = n.prototype;
  } else r = {};
  return Object.defineProperty(r, "__esModule", { value: !0 }), Object.keys(s).forEach(function(e) {
    var o = Object.getOwnPropertyDescriptor(s, e);
    Object.defineProperty(r, e, o.get ? o : {
      enumerable: !0,
      get: function() {
        return s[e];
      }
    });
  }), r;
}
var k0 = { exports: {} };
function St(s) {
  throw new Error('Could not dynamically require "' + s + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var S0 = { exports: {} };
const Mt = {}, Rt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Mt
}, Symbol.toStringTag, { value: "Module" })), zt = /* @__PURE__ */ kt(Rt);
var Ht = S0.exports, Ge;
function L() {
  return Ge || (Ge = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e();
    })(Ht, function() {
      var r = r || (function(e, o) {
        var c;
        if (typeof window < "u" && window.crypto && (c = window.crypto), typeof self < "u" && self.crypto && (c = self.crypto), typeof globalThis < "u" && globalThis.crypto && (c = globalThis.crypto), !c && typeof window < "u" && window.msCrypto && (c = window.msCrypto), !c && typeof pe < "u" && pe.crypto && (c = pe.crypto), !c && typeof St == "function")
          try {
            c = zt;
          } catch {
          }
        var E = function() {
          if (c) {
            if (typeof c.getRandomValues == "function")
              try {
                return c.getRandomValues(new Uint32Array(1))[0];
              } catch {
              }
            if (typeof c.randomBytes == "function")
              try {
                return c.randomBytes(4).readInt32LE();
              } catch {
              }
          }
          throw new Error("Native crypto module could not be used to get secure random number.");
        }, d = Object.create || /* @__PURE__ */ (function() {
          function f() {
          }
          return function(h) {
            var B;
            return f.prototype = h, B = new f(), f.prototype = null, B;
          };
        })(), x = {}, t = x.lib = {}, a = t.Base = /* @__PURE__ */ (function() {
          return {
            /**
             * Creates a new object that inherits from this object.
             *
             * @param {Object} overrides Properties to copy into the new object.
             *
             * @return {Object} The new object.
             *
             * @static
             *
             * @example
             *
             *     var MyType = CryptoJS.lib.Base.extend({
             *         field: 'value',
             *
             *         method: function () {
             *         }
             *     });
             */
            extend: function(f) {
              var h = d(this);
              return f && h.mixIn(f), (!h.hasOwnProperty("init") || this.init === h.init) && (h.init = function() {
                h.$super.init.apply(this, arguments);
              }), h.init.prototype = h, h.$super = this, h;
            },
            /**
             * Extends this object and runs the init method.
             * Arguments to create() will be passed to init().
             *
             * @return {Object} The new object.
             *
             * @static
             *
             * @example
             *
             *     var instance = MyType.create();
             */
            create: function() {
              var f = this.extend();
              return f.init.apply(f, arguments), f;
            },
            /**
             * Initializes a newly created object.
             * Override this method to add some logic when your objects are created.
             *
             * @example
             *
             *     var MyType = CryptoJS.lib.Base.extend({
             *         init: function () {
             *             // ...
             *         }
             *     });
             */
            init: function() {
            },
            /**
             * Copies properties into this object.
             *
             * @param {Object} properties The properties to mix in.
             *
             * @example
             *
             *     MyType.mixIn({
             *         field: 'value'
             *     });
             */
            mixIn: function(f) {
              for (var h in f)
                f.hasOwnProperty(h) && (this[h] = f[h]);
              f.hasOwnProperty("toString") && (this.toString = f.toString);
            },
            /**
             * Creates a copy of this object.
             *
             * @return {Object} The clone.
             *
             * @example
             *
             *     var clone = instance.clone();
             */
            clone: function() {
              return this.init.prototype.extend(this);
            }
          };
        })(), u = t.WordArray = a.extend({
          /**
           * Initializes a newly created word array.
           *
           * @param {Array} words (Optional) An array of 32-bit words.
           * @param {number} sigBytes (Optional) The number of significant bytes in the words.
           *
           * @example
           *
           *     var wordArray = CryptoJS.lib.WordArray.create();
           *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607]);
           *     var wordArray = CryptoJS.lib.WordArray.create([0x00010203, 0x04050607], 6);
           */
          init: function(f, h) {
            f = this.words = f || [], h != o ? this.sigBytes = h : this.sigBytes = f.length * 4;
          },
          /**
           * Converts this word array to a string.
           *
           * @param {Encoder} encoder (Optional) The encoding strategy to use. Default: CryptoJS.enc.Hex
           *
           * @return {string} The stringified word array.
           *
           * @example
           *
           *     var string = wordArray + '';
           *     var string = wordArray.toString();
           *     var string = wordArray.toString(CryptoJS.enc.Utf8);
           */
          toString: function(f) {
            return (f || l).stringify(this);
          },
          /**
           * Concatenates a word array to this word array.
           *
           * @param {WordArray} wordArray The word array to append.
           *
           * @return {WordArray} This word array.
           *
           * @example
           *
           *     wordArray1.concat(wordArray2);
           */
          concat: function(f) {
            var h = this.words, B = f.words, A = this.sigBytes, m = f.sigBytes;
            if (this.clamp(), A % 4)
              for (var y = 0; y < m; y++) {
                var b = B[y >>> 2] >>> 24 - y % 4 * 8 & 255;
                h[A + y >>> 2] |= b << 24 - (A + y) % 4 * 8;
              }
            else
              for (var k = 0; k < m; k += 4)
                h[A + k >>> 2] = B[k >>> 2];
            return this.sigBytes += m, this;
          },
          /**
           * Removes insignificant bits.
           *
           * @example
           *
           *     wordArray.clamp();
           */
          clamp: function() {
            var f = this.words, h = this.sigBytes;
            f[h >>> 2] &= 4294967295 << 32 - h % 4 * 8, f.length = e.ceil(h / 4);
          },
          /**
           * Creates a copy of this word array.
           *
           * @return {WordArray} The clone.
           *
           * @example
           *
           *     var clone = wordArray.clone();
           */
          clone: function() {
            var f = a.clone.call(this);
            return f.words = this.words.slice(0), f;
          },
          /**
           * Creates a word array filled with random bytes.
           *
           * @param {number} nBytes The number of random bytes to generate.
           *
           * @return {WordArray} The random word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.lib.WordArray.random(16);
           */
          random: function(f) {
            for (var h = [], B = 0; B < f; B += 4)
              h.push(E());
            return new u.init(h, f);
          }
        }), i = x.enc = {}, l = i.Hex = {
          /**
           * Converts a word array to a hex string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The hex string.
           *
           * @static
           *
           * @example
           *
           *     var hexString = CryptoJS.enc.Hex.stringify(wordArray);
           */
          stringify: function(f) {
            for (var h = f.words, B = f.sigBytes, A = [], m = 0; m < B; m++) {
              var y = h[m >>> 2] >>> 24 - m % 4 * 8 & 255;
              A.push((y >>> 4).toString(16)), A.push((y & 15).toString(16));
            }
            return A.join("");
          },
          /**
           * Converts a hex string to a word array.
           *
           * @param {string} hexStr The hex string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Hex.parse(hexString);
           */
          parse: function(f) {
            for (var h = f.length, B = [], A = 0; A < h; A += 2)
              B[A >>> 3] |= parseInt(f.substr(A, 2), 16) << 24 - A % 8 * 4;
            return new u.init(B, h / 2);
          }
        }, p = i.Latin1 = {
          /**
           * Converts a word array to a Latin1 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The Latin1 string.
           *
           * @static
           *
           * @example
           *
           *     var latin1String = CryptoJS.enc.Latin1.stringify(wordArray);
           */
          stringify: function(f) {
            for (var h = f.words, B = f.sigBytes, A = [], m = 0; m < B; m++) {
              var y = h[m >>> 2] >>> 24 - m % 4 * 8 & 255;
              A.push(String.fromCharCode(y));
            }
            return A.join("");
          },
          /**
           * Converts a Latin1 string to a word array.
           *
           * @param {string} latin1Str The Latin1 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Latin1.parse(latin1String);
           */
          parse: function(f) {
            for (var h = f.length, B = [], A = 0; A < h; A++)
              B[A >>> 2] |= (f.charCodeAt(A) & 255) << 24 - A % 4 * 8;
            return new u.init(B, h);
          }
        }, C = i.Utf8 = {
          /**
           * Converts a word array to a UTF-8 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-8 string.
           *
           * @static
           *
           * @example
           *
           *     var utf8String = CryptoJS.enc.Utf8.stringify(wordArray);
           */
          stringify: function(f) {
            try {
              return decodeURIComponent(escape(p.stringify(f)));
            } catch {
              throw new Error("Malformed UTF-8 data");
            }
          },
          /**
           * Converts a UTF-8 string to a word array.
           *
           * @param {string} utf8Str The UTF-8 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf8.parse(utf8String);
           */
          parse: function(f) {
            return p.parse(unescape(encodeURIComponent(f)));
          }
        }, v = t.BufferedBlockAlgorithm = a.extend({
          /**
           * Resets this block algorithm's data buffer to its initial state.
           *
           * @example
           *
           *     bufferedBlockAlgorithm.reset();
           */
          reset: function() {
            this._data = new u.init(), this._nDataBytes = 0;
          },
          /**
           * Adds new data to this block algorithm's buffer.
           *
           * @param {WordArray|string} data The data to append. Strings are converted to a WordArray using UTF-8.
           *
           * @example
           *
           *     bufferedBlockAlgorithm._append('data');
           *     bufferedBlockAlgorithm._append(wordArray);
           */
          _append: function(f) {
            typeof f == "string" && (f = C.parse(f)), this._data.concat(f), this._nDataBytes += f.sigBytes;
          },
          /**
           * Processes available data blocks.
           *
           * This method invokes _doProcessBlock(offset), which must be implemented by a concrete subtype.
           *
           * @param {boolean} doFlush Whether all blocks and partial blocks should be processed.
           *
           * @return {WordArray} The processed data.
           *
           * @example
           *
           *     var processedData = bufferedBlockAlgorithm._process();
           *     var processedData = bufferedBlockAlgorithm._process(!!'flush');
           */
          _process: function(f) {
            var h, B = this._data, A = B.words, m = B.sigBytes, y = this.blockSize, b = y * 4, k = m / b;
            f ? k = e.ceil(k) : k = e.max((k | 0) - this._minBufferSize, 0);
            var g = k * y, D = e.min(g * 4, m);
            if (g) {
              for (var _ = 0; _ < g; _ += y)
                this._doProcessBlock(A, _);
              h = A.splice(0, g), B.sigBytes -= D;
            }
            return new u.init(h, D);
          },
          /**
           * Creates a copy of this object.
           *
           * @return {Object} The clone.
           *
           * @example
           *
           *     var clone = bufferedBlockAlgorithm.clone();
           */
          clone: function() {
            var f = a.clone.call(this);
            return f._data = this._data.clone(), f;
          },
          _minBufferSize: 0
        });
        t.Hasher = v.extend({
          /**
           * Configuration options.
           */
          cfg: a.extend(),
          /**
           * Initializes a newly created hasher.
           *
           * @param {Object} cfg (Optional) The configuration options to use for this hash computation.
           *
           * @example
           *
           *     var hasher = CryptoJS.algo.SHA256.create();
           */
          init: function(f) {
            this.cfg = this.cfg.extend(f), this.reset();
          },
          /**
           * Resets this hasher to its initial state.
           *
           * @example
           *
           *     hasher.reset();
           */
          reset: function() {
            v.reset.call(this), this._doReset();
          },
          /**
           * Updates this hasher with a message.
           *
           * @param {WordArray|string} messageUpdate The message to append.
           *
           * @return {Hasher} This hasher.
           *
           * @example
           *
           *     hasher.update('message');
           *     hasher.update(wordArray);
           */
          update: function(f) {
            return this._append(f), this._process(), this;
          },
          /**
           * Finalizes the hash computation.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} messageUpdate (Optional) A final message update.
           *
           * @return {WordArray} The hash.
           *
           * @example
           *
           *     var hash = hasher.finalize();
           *     var hash = hasher.finalize('message');
           *     var hash = hasher.finalize(wordArray);
           */
          finalize: function(f) {
            f && this._append(f);
            var h = this._doFinalize();
            return h;
          },
          blockSize: 16,
          /**
           * Creates a shortcut function to a hasher's object interface.
           *
           * @param {Hasher} hasher The hasher to create a helper for.
           *
           * @return {Function} The shortcut function.
           *
           * @static
           *
           * @example
           *
           *     var SHA256 = CryptoJS.lib.Hasher._createHelper(CryptoJS.algo.SHA256);
           */
          _createHelper: function(f) {
            return function(h, B) {
              return new f.init(B).finalize(h);
            };
          },
          /**
           * Creates a shortcut function to the HMAC's object interface.
           *
           * @param {Hasher} hasher The hasher to use in this HMAC helper.
           *
           * @return {Function} The shortcut function.
           *
           * @static
           *
           * @example
           *
           *     var HmacSHA256 = CryptoJS.lib.Hasher._createHmacHelper(CryptoJS.algo.SHA256);
           */
          _createHmacHelper: function(f) {
            return function(h, B) {
              return new F.HMAC.init(f, B).finalize(h);
            };
          }
        });
        var F = x.algo = {};
        return x;
      })(Math);
      return r;
    });
  })(S0)), S0.exports;
}
var M0 = { exports: {} }, Pt = M0.exports, Ue;
function le() {
  return Ue || (Ue = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Pt, function(r) {
      return (function(e) {
        var o = r, c = o.lib, E = c.Base, d = c.WordArray, x = o.x64 = {};
        x.Word = E.extend({
          /**
           * Initializes a newly created 64-bit word.
           *
           * @param {number} high The high 32 bits.
           * @param {number} low The low 32 bits.
           *
           * @example
           *
           *     var x64Word = CryptoJS.x64.Word.create(0x00010203, 0x04050607);
           */
          init: function(t, a) {
            this.high = t, this.low = a;
          }
          /**
           * Bitwise NOTs this word.
           *
           * @return {X64Word} A new x64-Word object after negating.
           *
           * @example
           *
           *     var negated = x64Word.not();
           */
          // not: function () {
          // var high = ~this.high;
          // var low = ~this.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise ANDs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to AND with this word.
           *
           * @return {X64Word} A new x64-Word object after ANDing.
           *
           * @example
           *
           *     var anded = x64Word.and(anotherX64Word);
           */
          // and: function (word) {
          // var high = this.high & word.high;
          // var low = this.low & word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise ORs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to OR with this word.
           *
           * @return {X64Word} A new x64-Word object after ORing.
           *
           * @example
           *
           *     var ored = x64Word.or(anotherX64Word);
           */
          // or: function (word) {
          // var high = this.high | word.high;
          // var low = this.low | word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Bitwise XORs this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to XOR with this word.
           *
           * @return {X64Word} A new x64-Word object after XORing.
           *
           * @example
           *
           *     var xored = x64Word.xor(anotherX64Word);
           */
          // xor: function (word) {
          // var high = this.high ^ word.high;
          // var low = this.low ^ word.low;
          // return X64Word.create(high, low);
          // },
          /**
           * Shifts this word n bits to the left.
           *
           * @param {number} n The number of bits to shift.
           *
           * @return {X64Word} A new x64-Word object after shifting.
           *
           * @example
           *
           *     var shifted = x64Word.shiftL(25);
           */
          // shiftL: function (n) {
          // if (n < 32) {
          // var high = (this.high << n) | (this.low >>> (32 - n));
          // var low = this.low << n;
          // } else {
          // var high = this.low << (n - 32);
          // var low = 0;
          // }
          // return X64Word.create(high, low);
          // },
          /**
           * Shifts this word n bits to the right.
           *
           * @param {number} n The number of bits to shift.
           *
           * @return {X64Word} A new x64-Word object after shifting.
           *
           * @example
           *
           *     var shifted = x64Word.shiftR(7);
           */
          // shiftR: function (n) {
          // if (n < 32) {
          // var low = (this.low >>> n) | (this.high << (32 - n));
          // var high = this.high >>> n;
          // } else {
          // var low = this.high >>> (n - 32);
          // var high = 0;
          // }
          // return X64Word.create(high, low);
          // },
          /**
           * Rotates this word n bits to the left.
           *
           * @param {number} n The number of bits to rotate.
           *
           * @return {X64Word} A new x64-Word object after rotating.
           *
           * @example
           *
           *     var rotated = x64Word.rotL(25);
           */
          // rotL: function (n) {
          // return this.shiftL(n).or(this.shiftR(64 - n));
          // },
          /**
           * Rotates this word n bits to the right.
           *
           * @param {number} n The number of bits to rotate.
           *
           * @return {X64Word} A new x64-Word object after rotating.
           *
           * @example
           *
           *     var rotated = x64Word.rotR(7);
           */
          // rotR: function (n) {
          // return this.shiftR(n).or(this.shiftL(64 - n));
          // },
          /**
           * Adds this word with the passed word.
           *
           * @param {X64Word} word The x64-Word to add with this word.
           *
           * @return {X64Word} A new x64-Word object after adding.
           *
           * @example
           *
           *     var added = x64Word.add(anotherX64Word);
           */
          // add: function (word) {
          // var low = (this.low + word.low) | 0;
          // var carry = (low >>> 0) < (this.low >>> 0) ? 1 : 0;
          // var high = (this.high + word.high + carry) | 0;
          // return X64Word.create(high, low);
          // }
        }), x.WordArray = E.extend({
          /**
           * Initializes a newly created word array.
           *
           * @param {Array} words (Optional) An array of CryptoJS.x64.Word objects.
           * @param {number} sigBytes (Optional) The number of significant bytes in the words.
           *
           * @example
           *
           *     var wordArray = CryptoJS.x64.WordArray.create();
           *
           *     var wordArray = CryptoJS.x64.WordArray.create([
           *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
           *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
           *     ]);
           *
           *     var wordArray = CryptoJS.x64.WordArray.create([
           *         CryptoJS.x64.Word.create(0x00010203, 0x04050607),
           *         CryptoJS.x64.Word.create(0x18191a1b, 0x1c1d1e1f)
           *     ], 10);
           */
          init: function(t, a) {
            t = this.words = t || [], a != e ? this.sigBytes = a : this.sigBytes = t.length * 8;
          },
          /**
           * Converts this 64-bit word array to a 32-bit word array.
           *
           * @return {CryptoJS.lib.WordArray} This word array's data as a 32-bit word array.
           *
           * @example
           *
           *     var x32WordArray = x64WordArray.toX32();
           */
          toX32: function() {
            for (var t = this.words, a = t.length, u = [], i = 0; i < a; i++) {
              var l = t[i];
              u.push(l.high), u.push(l.low);
            }
            return d.create(u, this.sigBytes);
          },
          /**
           * Creates a copy of this word array.
           *
           * @return {X64WordArray} The clone.
           *
           * @example
           *
           *     var clone = x64WordArray.clone();
           */
          clone: function() {
            for (var t = E.clone.call(this), a = t.words = this.words.slice(0), u = a.length, i = 0; i < u; i++)
              a[i] = a[i].clone();
            return t;
          }
        });
      })(), r;
    });
  })(M0)), M0.exports;
}
var R0 = { exports: {} }, Wt = R0.exports, $e;
function qt() {
  return $e || ($e = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Wt, function(r) {
      return (function() {
        if (typeof ArrayBuffer == "function") {
          var e = r, o = e.lib, c = o.WordArray, E = c.init, d = c.init = function(x) {
            if (x instanceof ArrayBuffer && (x = new Uint8Array(x)), (x instanceof Int8Array || typeof Uint8ClampedArray < "u" && x instanceof Uint8ClampedArray || x instanceof Int16Array || x instanceof Uint16Array || x instanceof Int32Array || x instanceof Uint32Array || x instanceof Float32Array || x instanceof Float64Array) && (x = new Uint8Array(x.buffer, x.byteOffset, x.byteLength)), x instanceof Uint8Array) {
              for (var t = x.byteLength, a = [], u = 0; u < t; u++)
                a[u >>> 2] |= x[u] << 24 - u % 4 * 8;
              E.call(this, a, t);
            } else
              E.apply(this, arguments);
          };
          d.prototype = c;
        }
      })(), r.lib.WordArray;
    });
  })(R0)), R0.exports;
}
var z0 = { exports: {} }, Ot = z0.exports, Ne;
function Tt() {
  return Ne || (Ne = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Ot, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.WordArray, E = e.enc;
        E.Utf16 = E.Utf16BE = {
          /**
           * Converts a word array to a UTF-16 BE string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-16 BE string.
           *
           * @static
           *
           * @example
           *
           *     var utf16String = CryptoJS.enc.Utf16.stringify(wordArray);
           */
          stringify: function(x) {
            for (var t = x.words, a = x.sigBytes, u = [], i = 0; i < a; i += 2) {
              var l = t[i >>> 2] >>> 16 - i % 4 * 8 & 65535;
              u.push(String.fromCharCode(l));
            }
            return u.join("");
          },
          /**
           * Converts a UTF-16 BE string to a word array.
           *
           * @param {string} utf16Str The UTF-16 BE string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf16.parse(utf16String);
           */
          parse: function(x) {
            for (var t = x.length, a = [], u = 0; u < t; u++)
              a[u >>> 1] |= x.charCodeAt(u) << 16 - u % 2 * 16;
            return c.create(a, t * 2);
          }
        }, E.Utf16LE = {
          /**
           * Converts a word array to a UTF-16 LE string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The UTF-16 LE string.
           *
           * @static
           *
           * @example
           *
           *     var utf16Str = CryptoJS.enc.Utf16LE.stringify(wordArray);
           */
          stringify: function(x) {
            for (var t = x.words, a = x.sigBytes, u = [], i = 0; i < a; i += 2) {
              var l = d(t[i >>> 2] >>> 16 - i % 4 * 8 & 65535);
              u.push(String.fromCharCode(l));
            }
            return u.join("");
          },
          /**
           * Converts a UTF-16 LE string to a word array.
           *
           * @param {string} utf16Str The UTF-16 LE string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Utf16LE.parse(utf16Str);
           */
          parse: function(x) {
            for (var t = x.length, a = [], u = 0; u < t; u++)
              a[u >>> 1] |= d(x.charCodeAt(u) << 16 - u % 2 * 16);
            return c.create(a, t * 2);
          }
        };
        function d(x) {
          return x << 8 & 4278255360 | x >>> 8 & 16711935;
        }
      })(), r.enc.Utf16;
    });
  })(z0)), z0.exports;
}
var H0 = { exports: {} }, It = H0.exports, Ve;
function h0() {
  return Ve || (Ve = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(It, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.WordArray, E = e.enc;
        E.Base64 = {
          /**
           * Converts a word array to a Base64 string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @return {string} The Base64 string.
           *
           * @static
           *
           * @example
           *
           *     var base64String = CryptoJS.enc.Base64.stringify(wordArray);
           */
          stringify: function(x) {
            var t = x.words, a = x.sigBytes, u = this._map;
            x.clamp();
            for (var i = [], l = 0; l < a; l += 3)
              for (var p = t[l >>> 2] >>> 24 - l % 4 * 8 & 255, C = t[l + 1 >>> 2] >>> 24 - (l + 1) % 4 * 8 & 255, v = t[l + 2 >>> 2] >>> 24 - (l + 2) % 4 * 8 & 255, F = p << 16 | C << 8 | v, f = 0; f < 4 && l + f * 0.75 < a; f++)
                i.push(u.charAt(F >>> 6 * (3 - f) & 63));
            var h = u.charAt(64);
            if (h)
              for (; i.length % 4; )
                i.push(h);
            return i.join("");
          },
          /**
           * Converts a Base64 string to a word array.
           *
           * @param {string} base64Str The Base64 string.
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Base64.parse(base64String);
           */
          parse: function(x) {
            var t = x.length, a = this._map, u = this._reverseMap;
            if (!u) {
              u = this._reverseMap = [];
              for (var i = 0; i < a.length; i++)
                u[a.charCodeAt(i)] = i;
            }
            var l = a.charAt(64);
            if (l) {
              var p = x.indexOf(l);
              p !== -1 && (t = p);
            }
            return d(x, t, u);
          },
          _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
        };
        function d(x, t, a) {
          for (var u = [], i = 0, l = 0; l < t; l++)
            if (l % 4) {
              var p = a[x.charCodeAt(l - 1)] << l % 4 * 2, C = a[x.charCodeAt(l)] >>> 6 - l % 4 * 2, v = p | C;
              u[i >>> 2] |= v << 24 - i % 4 * 8, i++;
            }
          return c.create(u, i);
        }
      })(), r.enc.Base64;
    });
  })(H0)), H0.exports;
}
var P0 = { exports: {} }, Lt = P0.exports, Xe;
function Gt() {
  return Xe || (Xe = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Lt, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.WordArray, E = e.enc;
        E.Base64url = {
          /**
           * Converts a word array to a Base64url string.
           *
           * @param {WordArray} wordArray The word array.
           *
           * @param {boolean} urlSafe Whether to use url safe
           *
           * @return {string} The Base64url string.
           *
           * @static
           *
           * @example
           *
           *     var base64String = CryptoJS.enc.Base64url.stringify(wordArray);
           */
          stringify: function(x, t) {
            t === void 0 && (t = !0);
            var a = x.words, u = x.sigBytes, i = t ? this._safe_map : this._map;
            x.clamp();
            for (var l = [], p = 0; p < u; p += 3)
              for (var C = a[p >>> 2] >>> 24 - p % 4 * 8 & 255, v = a[p + 1 >>> 2] >>> 24 - (p + 1) % 4 * 8 & 255, F = a[p + 2 >>> 2] >>> 24 - (p + 2) % 4 * 8 & 255, f = C << 16 | v << 8 | F, h = 0; h < 4 && p + h * 0.75 < u; h++)
                l.push(i.charAt(f >>> 6 * (3 - h) & 63));
            var B = i.charAt(64);
            if (B)
              for (; l.length % 4; )
                l.push(B);
            return l.join("");
          },
          /**
           * Converts a Base64url string to a word array.
           *
           * @param {string} base64Str The Base64url string.
           *
           * @param {boolean} urlSafe Whether to use url safe
           *
           * @return {WordArray} The word array.
           *
           * @static
           *
           * @example
           *
           *     var wordArray = CryptoJS.enc.Base64url.parse(base64String);
           */
          parse: function(x, t) {
            t === void 0 && (t = !0);
            var a = x.length, u = t ? this._safe_map : this._map, i = this._reverseMap;
            if (!i) {
              i = this._reverseMap = [];
              for (var l = 0; l < u.length; l++)
                i[u.charCodeAt(l)] = l;
            }
            var p = u.charAt(64);
            if (p) {
              var C = x.indexOf(p);
              C !== -1 && (a = C);
            }
            return d(x, a, i);
          },
          _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
          _safe_map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
        };
        function d(x, t, a) {
          for (var u = [], i = 0, l = 0; l < t; l++)
            if (l % 4) {
              var p = a[x.charCodeAt(l - 1)] << l % 4 * 2, C = a[x.charCodeAt(l)] >>> 6 - l % 4 * 2, v = p | C;
              u[i >>> 2] |= v << 24 - i % 4 * 8, i++;
            }
          return c.create(u, i);
        }
      })(), r.enc.Base64url;
    });
  })(P0)), P0.exports;
}
var W0 = { exports: {} }, Ut = W0.exports, Ke;
function u0() {
  return Ke || (Ke = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Ut, function(r) {
      return (function(e) {
        var o = r, c = o.lib, E = c.WordArray, d = c.Hasher, x = o.algo, t = [];
        (function() {
          for (var C = 0; C < 64; C++)
            t[C] = e.abs(e.sin(C + 1)) * 4294967296 | 0;
        })();
        var a = x.MD5 = d.extend({
          _doReset: function() {
            this._hash = new E.init([
              1732584193,
              4023233417,
              2562383102,
              271733878
            ]);
          },
          _doProcessBlock: function(C, v) {
            for (var F = 0; F < 16; F++) {
              var f = v + F, h = C[f];
              C[f] = (h << 8 | h >>> 24) & 16711935 | (h << 24 | h >>> 8) & 4278255360;
            }
            var B = this._hash.words, A = C[v + 0], m = C[v + 1], y = C[v + 2], b = C[v + 3], k = C[v + 4], g = C[v + 5], D = C[v + 6], _ = C[v + 7], w = C[v + 8], P = C[v + 9], W = C[v + 10], q = C[v + 11], O = C[v + 12], G = C[v + 13], I = C[v + 14], U = C[v + 15], M = B[0], z = B[1], H = B[2], R = B[3];
            M = u(M, z, H, R, A, 7, t[0]), R = u(R, M, z, H, m, 12, t[1]), H = u(H, R, M, z, y, 17, t[2]), z = u(z, H, R, M, b, 22, t[3]), M = u(M, z, H, R, k, 7, t[4]), R = u(R, M, z, H, g, 12, t[5]), H = u(H, R, M, z, D, 17, t[6]), z = u(z, H, R, M, _, 22, t[7]), M = u(M, z, H, R, w, 7, t[8]), R = u(R, M, z, H, P, 12, t[9]), H = u(H, R, M, z, W, 17, t[10]), z = u(z, H, R, M, q, 22, t[11]), M = u(M, z, H, R, O, 7, t[12]), R = u(R, M, z, H, G, 12, t[13]), H = u(H, R, M, z, I, 17, t[14]), z = u(z, H, R, M, U, 22, t[15]), M = i(M, z, H, R, m, 5, t[16]), R = i(R, M, z, H, D, 9, t[17]), H = i(H, R, M, z, q, 14, t[18]), z = i(z, H, R, M, A, 20, t[19]), M = i(M, z, H, R, g, 5, t[20]), R = i(R, M, z, H, W, 9, t[21]), H = i(H, R, M, z, U, 14, t[22]), z = i(z, H, R, M, k, 20, t[23]), M = i(M, z, H, R, P, 5, t[24]), R = i(R, M, z, H, I, 9, t[25]), H = i(H, R, M, z, b, 14, t[26]), z = i(z, H, R, M, w, 20, t[27]), M = i(M, z, H, R, G, 5, t[28]), R = i(R, M, z, H, y, 9, t[29]), H = i(H, R, M, z, _, 14, t[30]), z = i(z, H, R, M, O, 20, t[31]), M = l(M, z, H, R, g, 4, t[32]), R = l(R, M, z, H, w, 11, t[33]), H = l(H, R, M, z, q, 16, t[34]), z = l(z, H, R, M, I, 23, t[35]), M = l(M, z, H, R, m, 4, t[36]), R = l(R, M, z, H, k, 11, t[37]), H = l(H, R, M, z, _, 16, t[38]), z = l(z, H, R, M, W, 23, t[39]), M = l(M, z, H, R, G, 4, t[40]), R = l(R, M, z, H, A, 11, t[41]), H = l(H, R, M, z, b, 16, t[42]), z = l(z, H, R, M, D, 23, t[43]), M = l(M, z, H, R, P, 4, t[44]), R = l(R, M, z, H, O, 11, t[45]), H = l(H, R, M, z, U, 16, t[46]), z = l(z, H, R, M, y, 23, t[47]), M = p(M, z, H, R, A, 6, t[48]), R = p(R, M, z, H, _, 10, t[49]), H = p(H, R, M, z, I, 15, t[50]), z = p(z, H, R, M, g, 21, t[51]), M = p(M, z, H, R, O, 6, t[52]), R = p(R, M, z, H, b, 10, t[53]), H = p(H, R, M, z, W, 15, t[54]), z = p(z, H, R, M, m, 21, t[55]), M = p(M, z, H, R, w, 6, t[56]), R = p(R, M, z, H, U, 10, t[57]), H = p(H, R, M, z, D, 15, t[58]), z = p(z, H, R, M, G, 21, t[59]), M = p(M, z, H, R, k, 6, t[60]), R = p(R, M, z, H, q, 10, t[61]), H = p(H, R, M, z, y, 15, t[62]), z = p(z, H, R, M, P, 21, t[63]), B[0] = B[0] + M | 0, B[1] = B[1] + z | 0, B[2] = B[2] + H | 0, B[3] = B[3] + R | 0;
          },
          _doFinalize: function() {
            var C = this._data, v = C.words, F = this._nDataBytes * 8, f = C.sigBytes * 8;
            v[f >>> 5] |= 128 << 24 - f % 32;
            var h = e.floor(F / 4294967296), B = F;
            v[(f + 64 >>> 9 << 4) + 15] = (h << 8 | h >>> 24) & 16711935 | (h << 24 | h >>> 8) & 4278255360, v[(f + 64 >>> 9 << 4) + 14] = (B << 8 | B >>> 24) & 16711935 | (B << 24 | B >>> 8) & 4278255360, C.sigBytes = (v.length + 1) * 4, this._process();
            for (var A = this._hash, m = A.words, y = 0; y < 4; y++) {
              var b = m[y];
              m[y] = (b << 8 | b >>> 24) & 16711935 | (b << 24 | b >>> 8) & 4278255360;
            }
            return A;
          },
          clone: function() {
            var C = d.clone.call(this);
            return C._hash = this._hash.clone(), C;
          }
        });
        function u(C, v, F, f, h, B, A) {
          var m = C + (v & F | ~v & f) + h + A;
          return (m << B | m >>> 32 - B) + v;
        }
        function i(C, v, F, f, h, B, A) {
          var m = C + (v & f | F & ~f) + h + A;
          return (m << B | m >>> 32 - B) + v;
        }
        function l(C, v, F, f, h, B, A) {
          var m = C + (v ^ F ^ f) + h + A;
          return (m << B | m >>> 32 - B) + v;
        }
        function p(C, v, F, f, h, B, A) {
          var m = C + (F ^ (v | ~f)) + h + A;
          return (m << B | m >>> 32 - B) + v;
        }
        o.MD5 = d._createHelper(a), o.HmacMD5 = d._createHmacHelper(a);
      })(Math), r.MD5;
    });
  })(W0)), W0.exports;
}
var q0 = { exports: {} }, $t = q0.exports, je;
function Sr() {
  return je || (je = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })($t, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.WordArray, E = o.Hasher, d = e.algo, x = [], t = d.SHA1 = E.extend({
          _doReset: function() {
            this._hash = new c.init([
              1732584193,
              4023233417,
              2562383102,
              271733878,
              3285377520
            ]);
          },
          _doProcessBlock: function(a, u) {
            for (var i = this._hash.words, l = i[0], p = i[1], C = i[2], v = i[3], F = i[4], f = 0; f < 80; f++) {
              if (f < 16)
                x[f] = a[u + f] | 0;
              else {
                var h = x[f - 3] ^ x[f - 8] ^ x[f - 14] ^ x[f - 16];
                x[f] = h << 1 | h >>> 31;
              }
              var B = (l << 5 | l >>> 27) + F + x[f];
              f < 20 ? B += (p & C | ~p & v) + 1518500249 : f < 40 ? B += (p ^ C ^ v) + 1859775393 : f < 60 ? B += (p & C | p & v | C & v) - 1894007588 : B += (p ^ C ^ v) - 899497514, F = v, v = C, C = p << 30 | p >>> 2, p = l, l = B;
            }
            i[0] = i[0] + l | 0, i[1] = i[1] + p | 0, i[2] = i[2] + C | 0, i[3] = i[3] + v | 0, i[4] = i[4] + F | 0;
          },
          _doFinalize: function() {
            var a = this._data, u = a.words, i = this._nDataBytes * 8, l = a.sigBytes * 8;
            return u[l >>> 5] |= 128 << 24 - l % 32, u[(l + 64 >>> 9 << 4) + 14] = Math.floor(i / 4294967296), u[(l + 64 >>> 9 << 4) + 15] = i, a.sigBytes = u.length * 4, this._process(), this._hash;
          },
          clone: function() {
            var a = E.clone.call(this);
            return a._hash = this._hash.clone(), a;
          }
        });
        e.SHA1 = E._createHelper(t), e.HmacSHA1 = E._createHmacHelper(t);
      })(), r.SHA1;
    });
  })(q0)), q0.exports;
}
var O0 = { exports: {} }, Nt = O0.exports, Ye;
function ge() {
  return Ye || (Ye = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Nt, function(r) {
      return (function(e) {
        var o = r, c = o.lib, E = c.WordArray, d = c.Hasher, x = o.algo, t = [], a = [];
        (function() {
          function l(F) {
            for (var f = e.sqrt(F), h = 2; h <= f; h++)
              if (!(F % h))
                return !1;
            return !0;
          }
          function p(F) {
            return (F - (F | 0)) * 4294967296 | 0;
          }
          for (var C = 2, v = 0; v < 64; )
            l(C) && (v < 8 && (t[v] = p(e.pow(C, 1 / 2))), a[v] = p(e.pow(C, 1 / 3)), v++), C++;
        })();
        var u = [], i = x.SHA256 = d.extend({
          _doReset: function() {
            this._hash = new E.init(t.slice(0));
          },
          _doProcessBlock: function(l, p) {
            for (var C = this._hash.words, v = C[0], F = C[1], f = C[2], h = C[3], B = C[4], A = C[5], m = C[6], y = C[7], b = 0; b < 64; b++) {
              if (b < 16)
                u[b] = l[p + b] | 0;
              else {
                var k = u[b - 15], g = (k << 25 | k >>> 7) ^ (k << 14 | k >>> 18) ^ k >>> 3, D = u[b - 2], _ = (D << 15 | D >>> 17) ^ (D << 13 | D >>> 19) ^ D >>> 10;
                u[b] = g + u[b - 7] + _ + u[b - 16];
              }
              var w = B & A ^ ~B & m, P = v & F ^ v & f ^ F & f, W = (v << 30 | v >>> 2) ^ (v << 19 | v >>> 13) ^ (v << 10 | v >>> 22), q = (B << 26 | B >>> 6) ^ (B << 21 | B >>> 11) ^ (B << 7 | B >>> 25), O = y + q + w + a[b] + u[b], G = W + P;
              y = m, m = A, A = B, B = h + O | 0, h = f, f = F, F = v, v = O + G | 0;
            }
            C[0] = C[0] + v | 0, C[1] = C[1] + F | 0, C[2] = C[2] + f | 0, C[3] = C[3] + h | 0, C[4] = C[4] + B | 0, C[5] = C[5] + A | 0, C[6] = C[6] + m | 0, C[7] = C[7] + y | 0;
          },
          _doFinalize: function() {
            var l = this._data, p = l.words, C = this._nDataBytes * 8, v = l.sigBytes * 8;
            return p[v >>> 5] |= 128 << 24 - v % 32, p[(v + 64 >>> 9 << 4) + 14] = e.floor(C / 4294967296), p[(v + 64 >>> 9 << 4) + 15] = C, l.sigBytes = p.length * 4, this._process(), this._hash;
          },
          clone: function() {
            var l = d.clone.call(this);
            return l._hash = this._hash.clone(), l;
          }
        });
        o.SHA256 = d._createHelper(i), o.HmacSHA256 = d._createHmacHelper(i);
      })(Math), r.SHA256;
    });
  })(O0)), O0.exports;
}
var T0 = { exports: {} }, Vt = T0.exports, Ze;
function Xt() {
  return Ze || (Ze = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), ge());
    })(Vt, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.WordArray, E = e.algo, d = E.SHA256, x = E.SHA224 = d.extend({
          _doReset: function() {
            this._hash = new c.init([
              3238371032,
              914150663,
              812702999,
              4144912697,
              4290775857,
              1750603025,
              1694076839,
              3204075428
            ]);
          },
          _doFinalize: function() {
            var t = d._doFinalize.call(this);
            return t.sigBytes -= 4, t;
          }
        });
        e.SHA224 = d._createHelper(x), e.HmacSHA224 = d._createHmacHelper(x);
      })(), r.SHA224;
    });
  })(T0)), T0.exports;
}
var I0 = { exports: {} }, Kt = I0.exports, Qe;
function Mr() {
  return Qe || (Qe = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), le());
    })(Kt, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.Hasher, E = e.x64, d = E.Word, x = E.WordArray, t = e.algo;
        function a() {
          return d.create.apply(d, arguments);
        }
        var u = [
          a(1116352408, 3609767458),
          a(1899447441, 602891725),
          a(3049323471, 3964484399),
          a(3921009573, 2173295548),
          a(961987163, 4081628472),
          a(1508970993, 3053834265),
          a(2453635748, 2937671579),
          a(2870763221, 3664609560),
          a(3624381080, 2734883394),
          a(310598401, 1164996542),
          a(607225278, 1323610764),
          a(1426881987, 3590304994),
          a(1925078388, 4068182383),
          a(2162078206, 991336113),
          a(2614888103, 633803317),
          a(3248222580, 3479774868),
          a(3835390401, 2666613458),
          a(4022224774, 944711139),
          a(264347078, 2341262773),
          a(604807628, 2007800933),
          a(770255983, 1495990901),
          a(1249150122, 1856431235),
          a(1555081692, 3175218132),
          a(1996064986, 2198950837),
          a(2554220882, 3999719339),
          a(2821834349, 766784016),
          a(2952996808, 2566594879),
          a(3210313671, 3203337956),
          a(3336571891, 1034457026),
          a(3584528711, 2466948901),
          a(113926993, 3758326383),
          a(338241895, 168717936),
          a(666307205, 1188179964),
          a(773529912, 1546045734),
          a(1294757372, 1522805485),
          a(1396182291, 2643833823),
          a(1695183700, 2343527390),
          a(1986661051, 1014477480),
          a(2177026350, 1206759142),
          a(2456956037, 344077627),
          a(2730485921, 1290863460),
          a(2820302411, 3158454273),
          a(3259730800, 3505952657),
          a(3345764771, 106217008),
          a(3516065817, 3606008344),
          a(3600352804, 1432725776),
          a(4094571909, 1467031594),
          a(275423344, 851169720),
          a(430227734, 3100823752),
          a(506948616, 1363258195),
          a(659060556, 3750685593),
          a(883997877, 3785050280),
          a(958139571, 3318307427),
          a(1322822218, 3812723403),
          a(1537002063, 2003034995),
          a(1747873779, 3602036899),
          a(1955562222, 1575990012),
          a(2024104815, 1125592928),
          a(2227730452, 2716904306),
          a(2361852424, 442776044),
          a(2428436474, 593698344),
          a(2756734187, 3733110249),
          a(3204031479, 2999351573),
          a(3329325298, 3815920427),
          a(3391569614, 3928383900),
          a(3515267271, 566280711),
          a(3940187606, 3454069534),
          a(4118630271, 4000239992),
          a(116418474, 1914138554),
          a(174292421, 2731055270),
          a(289380356, 3203993006),
          a(460393269, 320620315),
          a(685471733, 587496836),
          a(852142971, 1086792851),
          a(1017036298, 365543100),
          a(1126000580, 2618297676),
          a(1288033470, 3409855158),
          a(1501505948, 4234509866),
          a(1607167915, 987167468),
          a(1816402316, 1246189591)
        ], i = [];
        (function() {
          for (var p = 0; p < 80; p++)
            i[p] = a();
        })();
        var l = t.SHA512 = c.extend({
          _doReset: function() {
            this._hash = new x.init([
              new d.init(1779033703, 4089235720),
              new d.init(3144134277, 2227873595),
              new d.init(1013904242, 4271175723),
              new d.init(2773480762, 1595750129),
              new d.init(1359893119, 2917565137),
              new d.init(2600822924, 725511199),
              new d.init(528734635, 4215389547),
              new d.init(1541459225, 327033209)
            ]);
          },
          _doProcessBlock: function(p, C) {
            for (var v = this._hash.words, F = v[0], f = v[1], h = v[2], B = v[3], A = v[4], m = v[5], y = v[6], b = v[7], k = F.high, g = F.low, D = f.high, _ = f.low, w = h.high, P = h.low, W = B.high, q = B.low, O = A.high, G = A.low, I = m.high, U = m.low, M = y.high, z = y.low, H = b.high, R = b.low, $ = k, N = g, X = D, T = _, o0 = w, i0 = P, d0 = W, s0 = q, j = O, Y = G, y0 = I, C0 = U, b0 = M, A0 = z, he = H, E0 = R, t0 = 0; t0 < 80; t0++) {
              var e0, x0, _0 = i[t0];
              if (t0 < 16)
                x0 = _0.high = p[C + t0 * 2] | 0, e0 = _0.low = p[C + t0 * 2 + 1] | 0;
              else {
                var ye = i[t0 - 15], v0 = ye.high, m0 = ye.low, Hr = (v0 >>> 1 | m0 << 31) ^ (v0 >>> 8 | m0 << 24) ^ v0 >>> 7, be = (m0 >>> 1 | v0 << 31) ^ (m0 >>> 8 | v0 << 24) ^ (m0 >>> 7 | v0 << 25), _e = i[t0 - 2], p0 = _e.high, F0 = _e.low, Pr = (p0 >>> 19 | F0 << 13) ^ (p0 << 3 | F0 >>> 29) ^ p0 >>> 6, we = (F0 >>> 19 | p0 << 13) ^ (F0 << 3 | p0 >>> 29) ^ (F0 >>> 6 | p0 << 26), ke = i[t0 - 7], Wr = ke.high, qr = ke.low, Se = i[t0 - 16], Or = Se.high, Me = Se.low;
                e0 = be + qr, x0 = Hr + Wr + (e0 >>> 0 < be >>> 0 ? 1 : 0), e0 = e0 + we, x0 = x0 + Pr + (e0 >>> 0 < we >>> 0 ? 1 : 0), e0 = e0 + Me, x0 = x0 + Or + (e0 >>> 0 < Me >>> 0 ? 1 : 0), _0.high = x0, _0.low = e0;
              }
              var Tr = j & y0 ^ ~j & b0, Re = Y & C0 ^ ~Y & A0, Ir = $ & X ^ $ & o0 ^ X & o0, Lr = N & T ^ N & i0 ^ T & i0, Gr = ($ >>> 28 | N << 4) ^ ($ << 30 | N >>> 2) ^ ($ << 25 | N >>> 7), ze = (N >>> 28 | $ << 4) ^ (N << 30 | $ >>> 2) ^ (N << 25 | $ >>> 7), Ur = (j >>> 14 | Y << 18) ^ (j >>> 18 | Y << 14) ^ (j << 23 | Y >>> 9), $r = (Y >>> 14 | j << 18) ^ (Y >>> 18 | j << 14) ^ (Y << 23 | j >>> 9), He = u[t0], Nr = He.high, Pe = He.low, Z = E0 + $r, c0 = he + Ur + (Z >>> 0 < E0 >>> 0 ? 1 : 0), Z = Z + Re, c0 = c0 + Tr + (Z >>> 0 < Re >>> 0 ? 1 : 0), Z = Z + Pe, c0 = c0 + Nr + (Z >>> 0 < Pe >>> 0 ? 1 : 0), Z = Z + e0, c0 = c0 + x0 + (Z >>> 0 < e0 >>> 0 ? 1 : 0), We = ze + Lr, Vr = Gr + Ir + (We >>> 0 < ze >>> 0 ? 1 : 0);
              he = b0, E0 = A0, b0 = y0, A0 = C0, y0 = j, C0 = Y, Y = s0 + Z | 0, j = d0 + c0 + (Y >>> 0 < s0 >>> 0 ? 1 : 0) | 0, d0 = o0, s0 = i0, o0 = X, i0 = T, X = $, T = N, N = Z + We | 0, $ = c0 + Vr + (N >>> 0 < Z >>> 0 ? 1 : 0) | 0;
            }
            g = F.low = g + N, F.high = k + $ + (g >>> 0 < N >>> 0 ? 1 : 0), _ = f.low = _ + T, f.high = D + X + (_ >>> 0 < T >>> 0 ? 1 : 0), P = h.low = P + i0, h.high = w + o0 + (P >>> 0 < i0 >>> 0 ? 1 : 0), q = B.low = q + s0, B.high = W + d0 + (q >>> 0 < s0 >>> 0 ? 1 : 0), G = A.low = G + Y, A.high = O + j + (G >>> 0 < Y >>> 0 ? 1 : 0), U = m.low = U + C0, m.high = I + y0 + (U >>> 0 < C0 >>> 0 ? 1 : 0), z = y.low = z + A0, y.high = M + b0 + (z >>> 0 < A0 >>> 0 ? 1 : 0), R = b.low = R + E0, b.high = H + he + (R >>> 0 < E0 >>> 0 ? 1 : 0);
          },
          _doFinalize: function() {
            var p = this._data, C = p.words, v = this._nDataBytes * 8, F = p.sigBytes * 8;
            C[F >>> 5] |= 128 << 24 - F % 32, C[(F + 128 >>> 10 << 5) + 30] = Math.floor(v / 4294967296), C[(F + 128 >>> 10 << 5) + 31] = v, p.sigBytes = C.length * 4, this._process();
            var f = this._hash.toX32();
            return f;
          },
          clone: function() {
            var p = c.clone.call(this);
            return p._hash = this._hash.clone(), p;
          },
          blockSize: 1024 / 32
        });
        e.SHA512 = c._createHelper(l), e.HmacSHA512 = c._createHmacHelper(l);
      })(), r.SHA512;
    });
  })(I0)), I0.exports;
}
var L0 = { exports: {} }, jt = L0.exports, Je;
function Yt() {
  return Je || (Je = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), le(), Mr());
    })(jt, function(r) {
      return (function() {
        var e = r, o = e.x64, c = o.Word, E = o.WordArray, d = e.algo, x = d.SHA512, t = d.SHA384 = x.extend({
          _doReset: function() {
            this._hash = new E.init([
              new c.init(3418070365, 3238371032),
              new c.init(1654270250, 914150663),
              new c.init(2438529370, 812702999),
              new c.init(355462360, 4144912697),
              new c.init(1731405415, 4290775857),
              new c.init(2394180231, 1750603025),
              new c.init(3675008525, 1694076839),
              new c.init(1203062813, 3204075428)
            ]);
          },
          _doFinalize: function() {
            var a = x._doFinalize.call(this);
            return a.sigBytes -= 16, a;
          }
        });
        e.SHA384 = x._createHelper(t), e.HmacSHA384 = x._createHmacHelper(t);
      })(), r.SHA384;
    });
  })(L0)), L0.exports;
}
var G0 = { exports: {} }, Zt = G0.exports, er;
function Qt() {
  return er || (er = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), le());
    })(Zt, function(r) {
      return (function(e) {
        var o = r, c = o.lib, E = c.WordArray, d = c.Hasher, x = o.x64, t = x.Word, a = o.algo, u = [], i = [], l = [];
        (function() {
          for (var v = 1, F = 0, f = 0; f < 24; f++) {
            u[v + 5 * F] = (f + 1) * (f + 2) / 2 % 64;
            var h = F % 5, B = (2 * v + 3 * F) % 5;
            v = h, F = B;
          }
          for (var v = 0; v < 5; v++)
            for (var F = 0; F < 5; F++)
              i[v + 5 * F] = F + (2 * v + 3 * F) % 5 * 5;
          for (var A = 1, m = 0; m < 24; m++) {
            for (var y = 0, b = 0, k = 0; k < 7; k++) {
              if (A & 1) {
                var g = (1 << k) - 1;
                g < 32 ? b ^= 1 << g : y ^= 1 << g - 32;
              }
              A & 128 ? A = A << 1 ^ 113 : A <<= 1;
            }
            l[m] = t.create(y, b);
          }
        })();
        var p = [];
        (function() {
          for (var v = 0; v < 25; v++)
            p[v] = t.create();
        })();
        var C = a.SHA3 = d.extend({
          /**
           * Configuration options.
           *
           * @property {number} outputLength
           *   The desired number of bits in the output hash.
           *   Only values permitted are: 224, 256, 384, 512.
           *   Default: 512
           */
          cfg: d.cfg.extend({
            outputLength: 512
          }),
          _doReset: function() {
            for (var v = this._state = [], F = 0; F < 25; F++)
              v[F] = new t.init();
            this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32;
          },
          _doProcessBlock: function(v, F) {
            for (var f = this._state, h = this.blockSize / 2, B = 0; B < h; B++) {
              var A = v[F + 2 * B], m = v[F + 2 * B + 1];
              A = (A << 8 | A >>> 24) & 16711935 | (A << 24 | A >>> 8) & 4278255360, m = (m << 8 | m >>> 24) & 16711935 | (m << 24 | m >>> 8) & 4278255360;
              var y = f[B];
              y.high ^= m, y.low ^= A;
            }
            for (var b = 0; b < 24; b++) {
              for (var k = 0; k < 5; k++) {
                for (var g = 0, D = 0, _ = 0; _ < 5; _++) {
                  var y = f[k + 5 * _];
                  g ^= y.high, D ^= y.low;
                }
                var w = p[k];
                w.high = g, w.low = D;
              }
              for (var k = 0; k < 5; k++)
                for (var P = p[(k + 4) % 5], W = p[(k + 1) % 5], q = W.high, O = W.low, g = P.high ^ (q << 1 | O >>> 31), D = P.low ^ (O << 1 | q >>> 31), _ = 0; _ < 5; _++) {
                  var y = f[k + 5 * _];
                  y.high ^= g, y.low ^= D;
                }
              for (var G = 1; G < 25; G++) {
                var g, D, y = f[G], I = y.high, U = y.low, M = u[G];
                M < 32 ? (g = I << M | U >>> 32 - M, D = U << M | I >>> 32 - M) : (g = U << M - 32 | I >>> 64 - M, D = I << M - 32 | U >>> 64 - M);
                var z = p[i[G]];
                z.high = g, z.low = D;
              }
              var H = p[0], R = f[0];
              H.high = R.high, H.low = R.low;
              for (var k = 0; k < 5; k++)
                for (var _ = 0; _ < 5; _++) {
                  var G = k + 5 * _, y = f[G], $ = p[G], N = p[(k + 1) % 5 + 5 * _], X = p[(k + 2) % 5 + 5 * _];
                  y.high = $.high ^ ~N.high & X.high, y.low = $.low ^ ~N.low & X.low;
                }
              var y = f[0], T = l[b];
              y.high ^= T.high, y.low ^= T.low;
            }
          },
          _doFinalize: function() {
            var v = this._data, F = v.words;
            this._nDataBytes * 8;
            var f = v.sigBytes * 8, h = this.blockSize * 32;
            F[f >>> 5] |= 1 << 24 - f % 32, F[(e.ceil((f + 1) / h) * h >>> 5) - 1] |= 128, v.sigBytes = F.length * 4, this._process();
            for (var B = this._state, A = this.cfg.outputLength / 8, m = A / 8, y = [], b = 0; b < m; b++) {
              var k = B[b], g = k.high, D = k.low;
              g = (g << 8 | g >>> 24) & 16711935 | (g << 24 | g >>> 8) & 4278255360, D = (D << 8 | D >>> 24) & 16711935 | (D << 24 | D >>> 8) & 4278255360, y.push(D), y.push(g);
            }
            return new E.init(y, A);
          },
          clone: function() {
            for (var v = d.clone.call(this), F = v._state = this._state.slice(0), f = 0; f < 25; f++)
              F[f] = F[f].clone();
            return v;
          }
        });
        o.SHA3 = d._createHelper(C), o.HmacSHA3 = d._createHmacHelper(C);
      })(Math), r.SHA3;
    });
  })(G0)), G0.exports;
}
var U0 = { exports: {} }, Jt = U0.exports, rr;
function ea() {
  return rr || (rr = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(Jt, function(r) {
      /** @preserve
      			(c) 2012 by Cédric Mesnil. All rights reserved.
      
      			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
      
      			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
      			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
      
      			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
      			*/
      return (function(e) {
        var o = r, c = o.lib, E = c.WordArray, d = c.Hasher, x = o.algo, t = E.create([
          0,
          1,
          2,
          3,
          4,
          5,
          6,
          7,
          8,
          9,
          10,
          11,
          12,
          13,
          14,
          15,
          7,
          4,
          13,
          1,
          10,
          6,
          15,
          3,
          12,
          0,
          9,
          5,
          2,
          14,
          11,
          8,
          3,
          10,
          14,
          4,
          9,
          15,
          8,
          1,
          2,
          7,
          0,
          6,
          13,
          11,
          5,
          12,
          1,
          9,
          11,
          10,
          0,
          8,
          12,
          4,
          13,
          3,
          7,
          15,
          14,
          5,
          6,
          2,
          4,
          0,
          5,
          9,
          7,
          12,
          2,
          10,
          14,
          1,
          3,
          8,
          11,
          6,
          15,
          13
        ]), a = E.create([
          5,
          14,
          7,
          0,
          9,
          2,
          11,
          4,
          13,
          6,
          15,
          8,
          1,
          10,
          3,
          12,
          6,
          11,
          3,
          7,
          0,
          13,
          5,
          10,
          14,
          15,
          8,
          12,
          4,
          9,
          1,
          2,
          15,
          5,
          1,
          3,
          7,
          14,
          6,
          9,
          11,
          8,
          12,
          2,
          10,
          0,
          4,
          13,
          8,
          6,
          4,
          1,
          3,
          11,
          15,
          0,
          5,
          12,
          2,
          13,
          9,
          7,
          10,
          14,
          12,
          15,
          10,
          4,
          1,
          5,
          8,
          7,
          6,
          2,
          13,
          14,
          0,
          3,
          9,
          11
        ]), u = E.create([
          11,
          14,
          15,
          12,
          5,
          8,
          7,
          9,
          11,
          13,
          14,
          15,
          6,
          7,
          9,
          8,
          7,
          6,
          8,
          13,
          11,
          9,
          7,
          15,
          7,
          12,
          15,
          9,
          11,
          7,
          13,
          12,
          11,
          13,
          6,
          7,
          14,
          9,
          13,
          15,
          14,
          8,
          13,
          6,
          5,
          12,
          7,
          5,
          11,
          12,
          14,
          15,
          14,
          15,
          9,
          8,
          9,
          14,
          5,
          6,
          8,
          6,
          5,
          12,
          9,
          15,
          5,
          11,
          6,
          8,
          13,
          12,
          5,
          12,
          13,
          14,
          11,
          8,
          5,
          6
        ]), i = E.create([
          8,
          9,
          9,
          11,
          13,
          15,
          15,
          5,
          7,
          7,
          8,
          11,
          14,
          14,
          12,
          6,
          9,
          13,
          15,
          7,
          12,
          8,
          9,
          11,
          7,
          7,
          12,
          7,
          6,
          15,
          13,
          11,
          9,
          7,
          15,
          11,
          8,
          6,
          6,
          14,
          12,
          13,
          5,
          14,
          13,
          13,
          7,
          5,
          15,
          5,
          8,
          11,
          14,
          14,
          6,
          14,
          6,
          9,
          12,
          9,
          12,
          5,
          15,
          8,
          8,
          5,
          12,
          9,
          12,
          5,
          14,
          6,
          8,
          13,
          6,
          5,
          15,
          13,
          11,
          11
        ]), l = E.create([0, 1518500249, 1859775393, 2400959708, 2840853838]), p = E.create([1352829926, 1548603684, 1836072691, 2053994217, 0]), C = x.RIPEMD160 = d.extend({
          _doReset: function() {
            this._hash = E.create([1732584193, 4023233417, 2562383102, 271733878, 3285377520]);
          },
          _doProcessBlock: function(m, y) {
            for (var b = 0; b < 16; b++) {
              var k = y + b, g = m[k];
              m[k] = (g << 8 | g >>> 24) & 16711935 | (g << 24 | g >>> 8) & 4278255360;
            }
            var D = this._hash.words, _ = l.words, w = p.words, P = t.words, W = a.words, q = u.words, O = i.words, G, I, U, M, z, H, R, $, N, X;
            H = G = D[0], R = I = D[1], $ = U = D[2], N = M = D[3], X = z = D[4];
            for (var T, b = 0; b < 80; b += 1)
              T = G + m[y + P[b]] | 0, b < 16 ? T += v(I, U, M) + _[0] : b < 32 ? T += F(I, U, M) + _[1] : b < 48 ? T += f(I, U, M) + _[2] : b < 64 ? T += h(I, U, M) + _[3] : T += B(I, U, M) + _[4], T = T | 0, T = A(T, q[b]), T = T + z | 0, G = z, z = M, M = A(U, 10), U = I, I = T, T = H + m[y + W[b]] | 0, b < 16 ? T += B(R, $, N) + w[0] : b < 32 ? T += h(R, $, N) + w[1] : b < 48 ? T += f(R, $, N) + w[2] : b < 64 ? T += F(R, $, N) + w[3] : T += v(R, $, N) + w[4], T = T | 0, T = A(T, O[b]), T = T + X | 0, H = X, X = N, N = A($, 10), $ = R, R = T;
            T = D[1] + U + N | 0, D[1] = D[2] + M + X | 0, D[2] = D[3] + z + H | 0, D[3] = D[4] + G + R | 0, D[4] = D[0] + I + $ | 0, D[0] = T;
          },
          _doFinalize: function() {
            var m = this._data, y = m.words, b = this._nDataBytes * 8, k = m.sigBytes * 8;
            y[k >>> 5] |= 128 << 24 - k % 32, y[(k + 64 >>> 9 << 4) + 14] = (b << 8 | b >>> 24) & 16711935 | (b << 24 | b >>> 8) & 4278255360, m.sigBytes = (y.length + 1) * 4, this._process();
            for (var g = this._hash, D = g.words, _ = 0; _ < 5; _++) {
              var w = D[_];
              D[_] = (w << 8 | w >>> 24) & 16711935 | (w << 24 | w >>> 8) & 4278255360;
            }
            return g;
          },
          clone: function() {
            var m = d.clone.call(this);
            return m._hash = this._hash.clone(), m;
          }
        });
        function v(m, y, b) {
          return m ^ y ^ b;
        }
        function F(m, y, b) {
          return m & y | ~m & b;
        }
        function f(m, y, b) {
          return (m | ~y) ^ b;
        }
        function h(m, y, b) {
          return m & b | y & ~b;
        }
        function B(m, y, b) {
          return m ^ (y | ~b);
        }
        function A(m, y) {
          return m << y | m >>> 32 - y;
        }
        o.RIPEMD160 = d._createHelper(C), o.HmacRIPEMD160 = d._createHmacHelper(C);
      })(), r.RIPEMD160;
    });
  })(U0)), U0.exports;
}
var $0 = { exports: {} }, ra = $0.exports, tr;
function De() {
  return tr || (tr = 1, (function(s, n) {
    (function(r, e) {
      s.exports = e(L());
    })(ra, function(r) {
      (function() {
        var e = r, o = e.lib, c = o.Base, E = e.enc, d = E.Utf8, x = e.algo;
        x.HMAC = c.extend({
          /**
           * Initializes a newly created HMAC.
           *
           * @param {Hasher} hasher The hash algorithm to use.
           * @param {WordArray|string} key The secret key.
           *
           * @example
           *
           *     var hmacHasher = CryptoJS.algo.HMAC.create(CryptoJS.algo.SHA256, key);
           */
          init: function(t, a) {
            t = this._hasher = new t.init(), typeof a == "string" && (a = d.parse(a));
            var u = t.blockSize, i = u * 4;
            a.sigBytes > i && (a = t.finalize(a)), a.clamp();
            for (var l = this._oKey = a.clone(), p = this._iKey = a.clone(), C = l.words, v = p.words, F = 0; F < u; F++)
              C[F] ^= 1549556828, v[F] ^= 909522486;
            l.sigBytes = p.sigBytes = i, this.reset();
          },
          /**
           * Resets this HMAC to its initial state.
           *
           * @example
           *
           *     hmacHasher.reset();
           */
          reset: function() {
            var t = this._hasher;
            t.reset(), t.update(this._iKey);
          },
          /**
           * Updates this HMAC with a message.
           *
           * @param {WordArray|string} messageUpdate The message to append.
           *
           * @return {HMAC} This HMAC instance.
           *
           * @example
           *
           *     hmacHasher.update('message');
           *     hmacHasher.update(wordArray);
           */
          update: function(t) {
            return this._hasher.update(t), this;
          },
          /**
           * Finalizes the HMAC computation.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} messageUpdate (Optional) A final message update.
           *
           * @return {WordArray} The HMAC.
           *
           * @example
           *
           *     var hmac = hmacHasher.finalize();
           *     var hmac = hmacHasher.finalize('message');
           *     var hmac = hmacHasher.finalize(wordArray);
           */
          finalize: function(t) {
            var a = this._hasher, u = a.finalize(t);
            a.reset();
            var i = a.finalize(this._oKey.clone().concat(u));
            return i;
          }
        });
      })();
    });
  })($0)), $0.exports;
}
var N0 = { exports: {} }, ta = N0.exports, ar;
function aa() {
  return ar || (ar = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), ge(), De());
    })(ta, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.Base, E = o.WordArray, d = e.algo, x = d.SHA256, t = d.HMAC, a = d.PBKDF2 = c.extend({
          /**
           * Configuration options.
           *
           * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
           * @property {Hasher} hasher The hasher to use. Default: SHA256
           * @property {number} iterations The number of iterations to perform. Default: 250000
           */
          cfg: c.extend({
            keySize: 128 / 32,
            hasher: x,
            iterations: 25e4
          }),
          /**
           * Initializes a newly created key derivation function.
           *
           * @param {Object} cfg (Optional) The configuration options to use for the derivation.
           *
           * @example
           *
           *     var kdf = CryptoJS.algo.PBKDF2.create();
           *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8 });
           *     var kdf = CryptoJS.algo.PBKDF2.create({ keySize: 8, iterations: 1000 });
           */
          init: function(u) {
            this.cfg = this.cfg.extend(u);
          },
          /**
           * Computes the Password-Based Key Derivation Function 2.
           *
           * @param {WordArray|string} password The password.
           * @param {WordArray|string} salt A salt.
           *
           * @return {WordArray} The derived key.
           *
           * @example
           *
           *     var key = kdf.compute(password, salt);
           */
          compute: function(u, i) {
            for (var l = this.cfg, p = t.create(l.hasher, u), C = E.create(), v = E.create([1]), F = C.words, f = v.words, h = l.keySize, B = l.iterations; F.length < h; ) {
              var A = p.update(i).finalize(v);
              p.reset();
              for (var m = A.words, y = m.length, b = A, k = 1; k < B; k++) {
                b = p.finalize(b), p.reset();
                for (var g = b.words, D = 0; D < y; D++)
                  m[D] ^= g[D];
              }
              C.concat(A), f[0]++;
            }
            return C.sigBytes = h * 4, C;
          }
        });
        e.PBKDF2 = function(u, i, l) {
          return a.create(l).compute(u, i);
        };
      })(), r.PBKDF2;
    });
  })(N0)), N0.exports;
}
var V0 = { exports: {} }, na = V0.exports, nr;
function l0() {
  return nr || (nr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), Sr(), De());
    })(na, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.Base, E = o.WordArray, d = e.algo, x = d.MD5, t = d.EvpKDF = c.extend({
          /**
           * Configuration options.
           *
           * @property {number} keySize The key size in words to generate. Default: 4 (128 bits)
           * @property {Hasher} hasher The hash algorithm to use. Default: MD5
           * @property {number} iterations The number of iterations to perform. Default: 1
           */
          cfg: c.extend({
            keySize: 128 / 32,
            hasher: x,
            iterations: 1
          }),
          /**
           * Initializes a newly created key derivation function.
           *
           * @param {Object} cfg (Optional) The configuration options to use for the derivation.
           *
           * @example
           *
           *     var kdf = CryptoJS.algo.EvpKDF.create();
           *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8 });
           *     var kdf = CryptoJS.algo.EvpKDF.create({ keySize: 8, iterations: 1000 });
           */
          init: function(a) {
            this.cfg = this.cfg.extend(a);
          },
          /**
           * Derives a key from a password.
           *
           * @param {WordArray|string} password The password.
           * @param {WordArray|string} salt A salt.
           *
           * @return {WordArray} The derived key.
           *
           * @example
           *
           *     var key = kdf.compute(password, salt);
           */
          compute: function(a, u) {
            for (var i, l = this.cfg, p = l.hasher.create(), C = E.create(), v = C.words, F = l.keySize, f = l.iterations; v.length < F; ) {
              i && p.update(i), i = p.update(a).finalize(u), p.reset();
              for (var h = 1; h < f; h++)
                i = p.finalize(i), p.reset();
              C.concat(i);
            }
            return C.sigBytes = F * 4, C;
          }
        });
        e.EvpKDF = function(a, u, i) {
          return t.create(i).compute(a, u);
        };
      })(), r.EvpKDF;
    });
  })(V0)), V0.exports;
}
var X0 = { exports: {} }, oa = X0.exports, or;
function K() {
  return or || (or = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), l0());
    })(oa, function(r) {
      r.lib.Cipher || (function(e) {
        var o = r, c = o.lib, E = c.Base, d = c.WordArray, x = c.BufferedBlockAlgorithm, t = o.enc;
        t.Utf8;
        var a = t.Base64, u = o.algo, i = u.EvpKDF, l = c.Cipher = x.extend({
          /**
           * Configuration options.
           *
           * @property {WordArray} iv The IV to use for this operation.
           */
          cfg: E.extend(),
          /**
           * Creates this cipher in encryption mode.
           *
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {Cipher} A cipher instance.
           *
           * @static
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.createEncryptor(keyWordArray, { iv: ivWordArray });
           */
          createEncryptor: function(g, D) {
            return this.create(this._ENC_XFORM_MODE, g, D);
          },
          /**
           * Creates this cipher in decryption mode.
           *
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {Cipher} A cipher instance.
           *
           * @static
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.createDecryptor(keyWordArray, { iv: ivWordArray });
           */
          createDecryptor: function(g, D) {
            return this.create(this._DEC_XFORM_MODE, g, D);
          },
          /**
           * Initializes a newly created cipher.
           *
           * @param {number} xformMode Either the encryption or decryption transormation mode constant.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @example
           *
           *     var cipher = CryptoJS.algo.AES.create(CryptoJS.algo.AES._ENC_XFORM_MODE, keyWordArray, { iv: ivWordArray });
           */
          init: function(g, D, _) {
            this.cfg = this.cfg.extend(_), this._xformMode = g, this._key = D, this.reset();
          },
          /**
           * Resets this cipher to its initial state.
           *
           * @example
           *
           *     cipher.reset();
           */
          reset: function() {
            x.reset.call(this), this._doReset();
          },
          /**
           * Adds data to be encrypted or decrypted.
           *
           * @param {WordArray|string} dataUpdate The data to encrypt or decrypt.
           *
           * @return {WordArray} The data after processing.
           *
           * @example
           *
           *     var encrypted = cipher.process('data');
           *     var encrypted = cipher.process(wordArray);
           */
          process: function(g) {
            return this._append(g), this._process();
          },
          /**
           * Finalizes the encryption or decryption process.
           * Note that the finalize operation is effectively a destructive, read-once operation.
           *
           * @param {WordArray|string} dataUpdate The final data to encrypt or decrypt.
           *
           * @return {WordArray} The data after final processing.
           *
           * @example
           *
           *     var encrypted = cipher.finalize();
           *     var encrypted = cipher.finalize('data');
           *     var encrypted = cipher.finalize(wordArray);
           */
          finalize: function(g) {
            g && this._append(g);
            var D = this._doFinalize();
            return D;
          },
          keySize: 128 / 32,
          ivSize: 128 / 32,
          _ENC_XFORM_MODE: 1,
          _DEC_XFORM_MODE: 2,
          /**
           * Creates shortcut functions to a cipher's object interface.
           *
           * @param {Cipher} cipher The cipher to create a helper for.
           *
           * @return {Object} An object with encrypt and decrypt shortcut functions.
           *
           * @static
           *
           * @example
           *
           *     var AES = CryptoJS.lib.Cipher._createHelper(CryptoJS.algo.AES);
           */
          _createHelper: /* @__PURE__ */ (function() {
            function g(D) {
              return typeof D == "string" ? k : m;
            }
            return function(D) {
              return {
                encrypt: function(_, w, P) {
                  return g(w).encrypt(D, _, w, P);
                },
                decrypt: function(_, w, P) {
                  return g(w).decrypt(D, _, w, P);
                }
              };
            };
          })()
        });
        c.StreamCipher = l.extend({
          _doFinalize: function() {
            var g = this._process(!0);
            return g;
          },
          blockSize: 1
        });
        var p = o.mode = {}, C = c.BlockCipherMode = E.extend({
          /**
           * Creates this mode for encryption.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @static
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.createEncryptor(cipher, iv.words);
           */
          createEncryptor: function(g, D) {
            return this.Encryptor.create(g, D);
          },
          /**
           * Creates this mode for decryption.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @static
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.createDecryptor(cipher, iv.words);
           */
          createDecryptor: function(g, D) {
            return this.Decryptor.create(g, D);
          },
          /**
           * Initializes a newly created mode.
           *
           * @param {Cipher} cipher A block cipher instance.
           * @param {Array} iv The IV words.
           *
           * @example
           *
           *     var mode = CryptoJS.mode.CBC.Encryptor.create(cipher, iv.words);
           */
          init: function(g, D) {
            this._cipher = g, this._iv = D;
          }
        }), v = p.CBC = (function() {
          var g = C.extend();
          g.Encryptor = g.extend({
            /**
             * Processes the data block at offset.
             *
             * @param {Array} words The data words to operate on.
             * @param {number} offset The offset where the block starts.
             *
             * @example
             *
             *     mode.processBlock(data.words, offset);
             */
            processBlock: function(_, w) {
              var P = this._cipher, W = P.blockSize;
              D.call(this, _, w, W), P.encryptBlock(_, w), this._prevBlock = _.slice(w, w + W);
            }
          }), g.Decryptor = g.extend({
            /**
             * Processes the data block at offset.
             *
             * @param {Array} words The data words to operate on.
             * @param {number} offset The offset where the block starts.
             *
             * @example
             *
             *     mode.processBlock(data.words, offset);
             */
            processBlock: function(_, w) {
              var P = this._cipher, W = P.blockSize, q = _.slice(w, w + W);
              P.decryptBlock(_, w), D.call(this, _, w, W), this._prevBlock = q;
            }
          });
          function D(_, w, P) {
            var W, q = this._iv;
            q ? (W = q, this._iv = e) : W = this._prevBlock;
            for (var O = 0; O < P; O++)
              _[w + O] ^= W[O];
          }
          return g;
        })(), F = o.pad = {}, f = F.Pkcs7 = {
          /**
           * Pads data using the algorithm defined in PKCS #5/7.
           *
           * @param {WordArray} data The data to pad.
           * @param {number} blockSize The multiple that the data should be padded to.
           *
           * @static
           *
           * @example
           *
           *     CryptoJS.pad.Pkcs7.pad(wordArray, 4);
           */
          pad: function(g, D) {
            for (var _ = D * 4, w = _ - g.sigBytes % _, P = w << 24 | w << 16 | w << 8 | w, W = [], q = 0; q < w; q += 4)
              W.push(P);
            var O = d.create(W, w);
            g.concat(O);
          },
          /**
           * Unpads data that had been padded using the algorithm defined in PKCS #5/7.
           *
           * @param {WordArray} data The data to unpad.
           *
           * @static
           *
           * @example
           *
           *     CryptoJS.pad.Pkcs7.unpad(wordArray);
           */
          unpad: function(g) {
            var D = g.words[g.sigBytes - 1 >>> 2] & 255;
            g.sigBytes -= D;
          }
        };
        c.BlockCipher = l.extend({
          /**
           * Configuration options.
           *
           * @property {Mode} mode The block mode to use. Default: CBC
           * @property {Padding} padding The padding strategy to use. Default: Pkcs7
           */
          cfg: l.cfg.extend({
            mode: v,
            padding: f
          }),
          reset: function() {
            var g;
            l.reset.call(this);
            var D = this.cfg, _ = D.iv, w = D.mode;
            this._xformMode == this._ENC_XFORM_MODE ? g = w.createEncryptor : (g = w.createDecryptor, this._minBufferSize = 1), this._mode && this._mode.__creator == g ? this._mode.init(this, _ && _.words) : (this._mode = g.call(w, this, _ && _.words), this._mode.__creator = g);
          },
          _doProcessBlock: function(g, D) {
            this._mode.processBlock(g, D);
          },
          _doFinalize: function() {
            var g, D = this.cfg.padding;
            return this._xformMode == this._ENC_XFORM_MODE ? (D.pad(this._data, this.blockSize), g = this._process(!0)) : (g = this._process(!0), D.unpad(g)), g;
          },
          blockSize: 128 / 32
        });
        var h = c.CipherParams = E.extend({
          /**
           * Initializes a newly created cipher params object.
           *
           * @param {Object} cipherParams An object with any of the possible cipher parameters.
           *
           * @example
           *
           *     var cipherParams = CryptoJS.lib.CipherParams.create({
           *         ciphertext: ciphertextWordArray,
           *         key: keyWordArray,
           *         iv: ivWordArray,
           *         salt: saltWordArray,
           *         algorithm: CryptoJS.algo.AES,
           *         mode: CryptoJS.mode.CBC,
           *         padding: CryptoJS.pad.PKCS7,
           *         blockSize: 4,
           *         formatter: CryptoJS.format.OpenSSL
           *     });
           */
          init: function(g) {
            this.mixIn(g);
          },
          /**
           * Converts this cipher params object to a string.
           *
           * @param {Format} formatter (Optional) The formatting strategy to use.
           *
           * @return {string} The stringified cipher params.
           *
           * @throws Error If neither the formatter nor the default formatter is set.
           *
           * @example
           *
           *     var string = cipherParams + '';
           *     var string = cipherParams.toString();
           *     var string = cipherParams.toString(CryptoJS.format.OpenSSL);
           */
          toString: function(g) {
            return (g || this.formatter).stringify(this);
          }
        }), B = o.format = {}, A = B.OpenSSL = {
          /**
           * Converts a cipher params object to an OpenSSL-compatible string.
           *
           * @param {CipherParams} cipherParams The cipher params object.
           *
           * @return {string} The OpenSSL-compatible string.
           *
           * @static
           *
           * @example
           *
           *     var openSSLString = CryptoJS.format.OpenSSL.stringify(cipherParams);
           */
          stringify: function(g) {
            var D, _ = g.ciphertext, w = g.salt;
            return w ? D = d.create([1398893684, 1701076831]).concat(w).concat(_) : D = _, D.toString(a);
          },
          /**
           * Converts an OpenSSL-compatible string to a cipher params object.
           *
           * @param {string} openSSLStr The OpenSSL-compatible string.
           *
           * @return {CipherParams} The cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var cipherParams = CryptoJS.format.OpenSSL.parse(openSSLString);
           */
          parse: function(g) {
            var D, _ = a.parse(g), w = _.words;
            return w[0] == 1398893684 && w[1] == 1701076831 && (D = d.create(w.slice(2, 4)), w.splice(0, 4), _.sigBytes -= 16), h.create({ ciphertext: _, salt: D });
          }
        }, m = c.SerializableCipher = E.extend({
          /**
           * Configuration options.
           *
           * @property {Formatter} format The formatting strategy to convert cipher param objects to and from a string. Default: OpenSSL
           */
          cfg: E.extend({
            format: A
          }),
          /**
           * Encrypts a message.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {WordArray|string} message The message to encrypt.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {CipherParams} A cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key);
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv });
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher.encrypt(CryptoJS.algo.AES, message, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           */
          encrypt: function(g, D, _, w) {
            w = this.cfg.extend(w);
            var P = g.createEncryptor(_, w), W = P.finalize(D), q = P.cfg;
            return h.create({
              ciphertext: W,
              key: _,
              iv: q.iv,
              algorithm: g,
              mode: q.mode,
              padding: q.padding,
              blockSize: g.blockSize,
              formatter: w.format
            });
          },
          /**
           * Decrypts serialized ciphertext.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
           * @param {WordArray} key The key.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {WordArray} The plaintext.
           *
           * @static
           *
           * @example
           *
           *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           *     var plaintext = CryptoJS.lib.SerializableCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, key, { iv: iv, format: CryptoJS.format.OpenSSL });
           */
          decrypt: function(g, D, _, w) {
            w = this.cfg.extend(w), D = this._parse(D, w.format);
            var P = g.createDecryptor(_, w).finalize(D.ciphertext);
            return P;
          },
          /**
           * Converts serialized ciphertext to CipherParams,
           * else assumed CipherParams already and returns ciphertext unchanged.
           *
           * @param {CipherParams|string} ciphertext The ciphertext.
           * @param {Formatter} format The formatting strategy to use to parse serialized ciphertext.
           *
           * @return {CipherParams} The unserialized ciphertext.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.SerializableCipher._parse(ciphertextStringOrParams, format);
           */
          _parse: function(g, D) {
            return typeof g == "string" ? D.parse(g, this) : g;
          }
        }), y = o.kdf = {}, b = y.OpenSSL = {
          /**
           * Derives a key and IV from a password.
           *
           * @param {string} password The password to derive from.
           * @param {number} keySize The size in words of the key to generate.
           * @param {number} ivSize The size in words of the IV to generate.
           * @param {WordArray|string} salt (Optional) A 64-bit salt to use. If omitted, a salt will be generated randomly.
           *
           * @return {CipherParams} A cipher params object with the key, IV, and salt.
           *
           * @static
           *
           * @example
           *
           *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32);
           *     var derivedParams = CryptoJS.kdf.OpenSSL.execute('Password', 256/32, 128/32, 'saltsalt');
           */
          execute: function(g, D, _, w, P) {
            if (w || (w = d.random(64 / 8)), P)
              var W = i.create({ keySize: D + _, hasher: P }).compute(g, w);
            else
              var W = i.create({ keySize: D + _ }).compute(g, w);
            var q = d.create(W.words.slice(D), _ * 4);
            return W.sigBytes = D * 4, h.create({ key: W, iv: q, salt: w });
          }
        }, k = c.PasswordBasedCipher = m.extend({
          /**
           * Configuration options.
           *
           * @property {KDF} kdf The key derivation function to use to generate a key and IV from a password. Default: OpenSSL
           */
          cfg: m.cfg.extend({
            kdf: b
          }),
          /**
           * Encrypts a message using a password.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {WordArray|string} message The message to encrypt.
           * @param {string} password The password.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {CipherParams} A cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password');
           *     var ciphertextParams = CryptoJS.lib.PasswordBasedCipher.encrypt(CryptoJS.algo.AES, message, 'password', { format: CryptoJS.format.OpenSSL });
           */
          encrypt: function(g, D, _, w) {
            w = this.cfg.extend(w);
            var P = w.kdf.execute(_, g.keySize, g.ivSize, w.salt, w.hasher);
            w.iv = P.iv;
            var W = m.encrypt.call(this, g, D, P.key, w);
            return W.mixIn(P), W;
          },
          /**
           * Decrypts serialized ciphertext using a password.
           *
           * @param {Cipher} cipher The cipher algorithm to use.
           * @param {CipherParams|string} ciphertext The ciphertext to decrypt.
           * @param {string} password The password.
           * @param {Object} cfg (Optional) The configuration options to use for this operation.
           *
           * @return {WordArray} The plaintext.
           *
           * @static
           *
           * @example
           *
           *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, formattedCiphertext, 'password', { format: CryptoJS.format.OpenSSL });
           *     var plaintext = CryptoJS.lib.PasswordBasedCipher.decrypt(CryptoJS.algo.AES, ciphertextParams, 'password', { format: CryptoJS.format.OpenSSL });
           */
          decrypt: function(g, D, _, w) {
            w = this.cfg.extend(w), D = this._parse(D, w.format);
            var P = w.kdf.execute(_, g.keySize, g.ivSize, D.salt, w.hasher);
            w.iv = P.iv;
            var W = m.decrypt.call(this, g, D, P.key, w);
            return W;
          }
        });
      })();
    });
  })(X0)), X0.exports;
}
var K0 = { exports: {} }, ia = K0.exports, ir;
function sa() {
  return ir || (ir = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(ia, function(r) {
      return r.mode.CFB = (function() {
        var e = r.lib.BlockCipherMode.extend();
        e.Encryptor = e.extend({
          processBlock: function(c, E) {
            var d = this._cipher, x = d.blockSize;
            o.call(this, c, E, x, d), this._prevBlock = c.slice(E, E + x);
          }
        }), e.Decryptor = e.extend({
          processBlock: function(c, E) {
            var d = this._cipher, x = d.blockSize, t = c.slice(E, E + x);
            o.call(this, c, E, x, d), this._prevBlock = t;
          }
        });
        function o(c, E, d, x) {
          var t, a = this._iv;
          a ? (t = a.slice(0), this._iv = void 0) : t = this._prevBlock, x.encryptBlock(t, 0);
          for (var u = 0; u < d; u++)
            c[E + u] ^= t[u];
        }
        return e;
      })(), r.mode.CFB;
    });
  })(K0)), K0.exports;
}
var j0 = { exports: {} }, xa = j0.exports, sr;
function ca() {
  return sr || (sr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(xa, function(r) {
      return r.mode.CTR = (function() {
        var e = r.lib.BlockCipherMode.extend(), o = e.Encryptor = e.extend({
          processBlock: function(c, E) {
            var d = this._cipher, x = d.blockSize, t = this._iv, a = this._counter;
            t && (a = this._counter = t.slice(0), this._iv = void 0);
            var u = a.slice(0);
            d.encryptBlock(u, 0), a[x - 1] = a[x - 1] + 1 | 0;
            for (var i = 0; i < x; i++)
              c[E + i] ^= u[i];
          }
        });
        return e.Decryptor = o, e;
      })(), r.mode.CTR;
    });
  })(j0)), j0.exports;
}
var Y0 = { exports: {} }, fa = Y0.exports, xr;
function la() {
  return xr || (xr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(fa, function(r) {
      /** @preserve
       * Counter block mode compatible with  Dr Brian Gladman fileenc.c
       * derived from CryptoJS.mode.CTR
       * Jan Hruby jhruby.web@gmail.com
       */
      return r.mode.CTRGladman = (function() {
        var e = r.lib.BlockCipherMode.extend();
        function o(d) {
          if ((d >> 24 & 255) === 255) {
            var x = d >> 16 & 255, t = d >> 8 & 255, a = d & 255;
            x === 255 ? (x = 0, t === 255 ? (t = 0, a === 255 ? a = 0 : ++a) : ++t) : ++x, d = 0, d += x << 16, d += t << 8, d += a;
          } else
            d += 1 << 24;
          return d;
        }
        function c(d) {
          return (d[0] = o(d[0])) === 0 && (d[1] = o(d[1])), d;
        }
        var E = e.Encryptor = e.extend({
          processBlock: function(d, x) {
            var t = this._cipher, a = t.blockSize, u = this._iv, i = this._counter;
            u && (i = this._counter = u.slice(0), this._iv = void 0), c(i);
            var l = i.slice(0);
            t.encryptBlock(l, 0);
            for (var p = 0; p < a; p++)
              d[x + p] ^= l[p];
          }
        });
        return e.Decryptor = E, e;
      })(), r.mode.CTRGladman;
    });
  })(Y0)), Y0.exports;
}
var Z0 = { exports: {} }, ha = Z0.exports, cr;
function ua() {
  return cr || (cr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(ha, function(r) {
      return r.mode.OFB = (function() {
        var e = r.lib.BlockCipherMode.extend(), o = e.Encryptor = e.extend({
          processBlock: function(c, E) {
            var d = this._cipher, x = d.blockSize, t = this._iv, a = this._keystream;
            t && (a = this._keystream = t.slice(0), this._iv = void 0), d.encryptBlock(a, 0);
            for (var u = 0; u < x; u++)
              c[E + u] ^= a[u];
          }
        });
        return e.Decryptor = o, e;
      })(), r.mode.OFB;
    });
  })(Z0)), Z0.exports;
}
var Q0 = { exports: {} }, da = Q0.exports, fr;
function va() {
  return fr || (fr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(da, function(r) {
      return r.mode.ECB = (function() {
        var e = r.lib.BlockCipherMode.extend();
        return e.Encryptor = e.extend({
          processBlock: function(o, c) {
            this._cipher.encryptBlock(o, c);
          }
        }), e.Decryptor = e.extend({
          processBlock: function(o, c) {
            this._cipher.decryptBlock(o, c);
          }
        }), e;
      })(), r.mode.ECB;
    });
  })(Q0)), Q0.exports;
}
var J0 = { exports: {} }, pa = J0.exports, lr;
function Ba() {
  return lr || (lr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(pa, function(r) {
      return r.pad.AnsiX923 = {
        pad: function(e, o) {
          var c = e.sigBytes, E = o * 4, d = E - c % E, x = c + d - 1;
          e.clamp(), e.words[x >>> 2] |= d << 24 - x % 4 * 8, e.sigBytes += d;
        },
        unpad: function(e) {
          var o = e.words[e.sigBytes - 1 >>> 2] & 255;
          e.sigBytes -= o;
        }
      }, r.pad.Ansix923;
    });
  })(J0)), J0.exports;
}
var ee = { exports: {} }, Ca = ee.exports, hr;
function Aa() {
  return hr || (hr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(Ca, function(r) {
      return r.pad.Iso10126 = {
        pad: function(e, o) {
          var c = o * 4, E = c - e.sigBytes % c;
          e.concat(r.lib.WordArray.random(E - 1)).concat(r.lib.WordArray.create([E << 24], 1));
        },
        unpad: function(e) {
          var o = e.words[e.sigBytes - 1 >>> 2] & 255;
          e.sigBytes -= o;
        }
      }, r.pad.Iso10126;
    });
  })(ee)), ee.exports;
}
var re = { exports: {} }, Ea = re.exports, ur;
function ma() {
  return ur || (ur = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(Ea, function(r) {
      return r.pad.Iso97971 = {
        pad: function(e, o) {
          e.concat(r.lib.WordArray.create([2147483648], 1)), r.pad.ZeroPadding.pad(e, o);
        },
        unpad: function(e) {
          r.pad.ZeroPadding.unpad(e), e.sigBytes--;
        }
      }, r.pad.Iso97971;
    });
  })(re)), re.exports;
}
var te = { exports: {} }, Fa = te.exports, dr;
function ga() {
  return dr || (dr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(Fa, function(r) {
      return r.pad.ZeroPadding = {
        pad: function(e, o) {
          var c = o * 4;
          e.clamp(), e.sigBytes += c - (e.sigBytes % c || c);
        },
        unpad: function(e) {
          for (var o = e.words, c = e.sigBytes - 1, c = e.sigBytes - 1; c >= 0; c--)
            if (o[c >>> 2] >>> 24 - c % 4 * 8 & 255) {
              e.sigBytes = c + 1;
              break;
            }
        }
      }, r.pad.ZeroPadding;
    });
  })(te)), te.exports;
}
var ae = { exports: {} }, Da = ae.exports, vr;
function ya() {
  return vr || (vr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(Da, function(r) {
      return r.pad.NoPadding = {
        pad: function() {
        },
        unpad: function() {
        }
      }, r.pad.NoPadding;
    });
  })(ae)), ae.exports;
}
var ne = { exports: {} }, ba = ne.exports, pr;
function _a() {
  return pr || (pr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), K());
    })(ba, function(r) {
      return (function(e) {
        var o = r, c = o.lib, E = c.CipherParams, d = o.enc, x = d.Hex, t = o.format;
        t.Hex = {
          /**
           * Converts the ciphertext of a cipher params object to a hexadecimally encoded string.
           *
           * @param {CipherParams} cipherParams The cipher params object.
           *
           * @return {string} The hexadecimally encoded string.
           *
           * @static
           *
           * @example
           *
           *     var hexString = CryptoJS.format.Hex.stringify(cipherParams);
           */
          stringify: function(a) {
            return a.ciphertext.toString(x);
          },
          /**
           * Converts a hexadecimally encoded ciphertext string to a cipher params object.
           *
           * @param {string} input The hexadecimally encoded string.
           *
           * @return {CipherParams} The cipher params object.
           *
           * @static
           *
           * @example
           *
           *     var cipherParams = CryptoJS.format.Hex.parse(hexString);
           */
          parse: function(a) {
            var u = x.parse(a);
            return E.create({ ciphertext: u });
          }
        };
      })(), r.format.Hex;
    });
  })(ne)), ne.exports;
}
var oe = { exports: {} }, wa = oe.exports, Br;
function ka() {
  return Br || (Br = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), h0(), u0(), l0(), K());
    })(wa, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.BlockCipher, E = e.algo, d = [], x = [], t = [], a = [], u = [], i = [], l = [], p = [], C = [], v = [];
        (function() {
          for (var h = [], B = 0; B < 256; B++)
            B < 128 ? h[B] = B << 1 : h[B] = B << 1 ^ 283;
          for (var A = 0, m = 0, B = 0; B < 256; B++) {
            var y = m ^ m << 1 ^ m << 2 ^ m << 3 ^ m << 4;
            y = y >>> 8 ^ y & 255 ^ 99, d[A] = y, x[y] = A;
            var b = h[A], k = h[b], g = h[k], D = h[y] * 257 ^ y * 16843008;
            t[A] = D << 24 | D >>> 8, a[A] = D << 16 | D >>> 16, u[A] = D << 8 | D >>> 24, i[A] = D;
            var D = g * 16843009 ^ k * 65537 ^ b * 257 ^ A * 16843008;
            l[y] = D << 24 | D >>> 8, p[y] = D << 16 | D >>> 16, C[y] = D << 8 | D >>> 24, v[y] = D, A ? (A = b ^ h[h[h[g ^ b]]], m ^= h[h[m]]) : A = m = 1;
          }
        })();
        var F = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], f = E.AES = c.extend({
          _doReset: function() {
            var h;
            if (!(this._nRounds && this._keyPriorReset === this._key)) {
              for (var B = this._keyPriorReset = this._key, A = B.words, m = B.sigBytes / 4, y = this._nRounds = m + 6, b = (y + 1) * 4, k = this._keySchedule = [], g = 0; g < b; g++)
                g < m ? k[g] = A[g] : (h = k[g - 1], g % m ? m > 6 && g % m == 4 && (h = d[h >>> 24] << 24 | d[h >>> 16 & 255] << 16 | d[h >>> 8 & 255] << 8 | d[h & 255]) : (h = h << 8 | h >>> 24, h = d[h >>> 24] << 24 | d[h >>> 16 & 255] << 16 | d[h >>> 8 & 255] << 8 | d[h & 255], h ^= F[g / m | 0] << 24), k[g] = k[g - m] ^ h);
              for (var D = this._invKeySchedule = [], _ = 0; _ < b; _++) {
                var g = b - _;
                if (_ % 4)
                  var h = k[g];
                else
                  var h = k[g - 4];
                _ < 4 || g <= 4 ? D[_] = h : D[_] = l[d[h >>> 24]] ^ p[d[h >>> 16 & 255]] ^ C[d[h >>> 8 & 255]] ^ v[d[h & 255]];
              }
            }
          },
          encryptBlock: function(h, B) {
            this._doCryptBlock(h, B, this._keySchedule, t, a, u, i, d);
          },
          decryptBlock: function(h, B) {
            var A = h[B + 1];
            h[B + 1] = h[B + 3], h[B + 3] = A, this._doCryptBlock(h, B, this._invKeySchedule, l, p, C, v, x);
            var A = h[B + 1];
            h[B + 1] = h[B + 3], h[B + 3] = A;
          },
          _doCryptBlock: function(h, B, A, m, y, b, k, g) {
            for (var D = this._nRounds, _ = h[B] ^ A[0], w = h[B + 1] ^ A[1], P = h[B + 2] ^ A[2], W = h[B + 3] ^ A[3], q = 4, O = 1; O < D; O++) {
              var G = m[_ >>> 24] ^ y[w >>> 16 & 255] ^ b[P >>> 8 & 255] ^ k[W & 255] ^ A[q++], I = m[w >>> 24] ^ y[P >>> 16 & 255] ^ b[W >>> 8 & 255] ^ k[_ & 255] ^ A[q++], U = m[P >>> 24] ^ y[W >>> 16 & 255] ^ b[_ >>> 8 & 255] ^ k[w & 255] ^ A[q++], M = m[W >>> 24] ^ y[_ >>> 16 & 255] ^ b[w >>> 8 & 255] ^ k[P & 255] ^ A[q++];
              _ = G, w = I, P = U, W = M;
            }
            var G = (g[_ >>> 24] << 24 | g[w >>> 16 & 255] << 16 | g[P >>> 8 & 255] << 8 | g[W & 255]) ^ A[q++], I = (g[w >>> 24] << 24 | g[P >>> 16 & 255] << 16 | g[W >>> 8 & 255] << 8 | g[_ & 255]) ^ A[q++], U = (g[P >>> 24] << 24 | g[W >>> 16 & 255] << 16 | g[_ >>> 8 & 255] << 8 | g[w & 255]) ^ A[q++], M = (g[W >>> 24] << 24 | g[_ >>> 16 & 255] << 16 | g[w >>> 8 & 255] << 8 | g[P & 255]) ^ A[q++];
            h[B] = G, h[B + 1] = I, h[B + 2] = U, h[B + 3] = M;
          },
          keySize: 256 / 32
        });
        e.AES = c._createHelper(f);
      })(), r.AES;
    });
  })(oe)), oe.exports;
}
var ie = { exports: {} }, Sa = ie.exports, Cr;
function Ma() {
  return Cr || (Cr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), h0(), u0(), l0(), K());
    })(Sa, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.WordArray, E = o.BlockCipher, d = e.algo, x = [
          57,
          49,
          41,
          33,
          25,
          17,
          9,
          1,
          58,
          50,
          42,
          34,
          26,
          18,
          10,
          2,
          59,
          51,
          43,
          35,
          27,
          19,
          11,
          3,
          60,
          52,
          44,
          36,
          63,
          55,
          47,
          39,
          31,
          23,
          15,
          7,
          62,
          54,
          46,
          38,
          30,
          22,
          14,
          6,
          61,
          53,
          45,
          37,
          29,
          21,
          13,
          5,
          28,
          20,
          12,
          4
        ], t = [
          14,
          17,
          11,
          24,
          1,
          5,
          3,
          28,
          15,
          6,
          21,
          10,
          23,
          19,
          12,
          4,
          26,
          8,
          16,
          7,
          27,
          20,
          13,
          2,
          41,
          52,
          31,
          37,
          47,
          55,
          30,
          40,
          51,
          45,
          33,
          48,
          44,
          49,
          39,
          56,
          34,
          53,
          46,
          42,
          50,
          36,
          29,
          32
        ], a = [1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28], u = [
          {
            0: 8421888,
            268435456: 32768,
            536870912: 8421378,
            805306368: 2,
            1073741824: 512,
            1342177280: 8421890,
            1610612736: 8389122,
            1879048192: 8388608,
            2147483648: 514,
            2415919104: 8389120,
            2684354560: 33280,
            2952790016: 8421376,
            3221225472: 32770,
            3489660928: 8388610,
            3758096384: 0,
            4026531840: 33282,
            134217728: 0,
            402653184: 8421890,
            671088640: 33282,
            939524096: 32768,
            1207959552: 8421888,
            1476395008: 512,
            1744830464: 8421378,
            2013265920: 2,
            2281701376: 8389120,
            2550136832: 33280,
            2818572288: 8421376,
            3087007744: 8389122,
            3355443200: 8388610,
            3623878656: 32770,
            3892314112: 514,
            4160749568: 8388608,
            1: 32768,
            268435457: 2,
            536870913: 8421888,
            805306369: 8388608,
            1073741825: 8421378,
            1342177281: 33280,
            1610612737: 512,
            1879048193: 8389122,
            2147483649: 8421890,
            2415919105: 8421376,
            2684354561: 8388610,
            2952790017: 33282,
            3221225473: 514,
            3489660929: 8389120,
            3758096385: 32770,
            4026531841: 0,
            134217729: 8421890,
            402653185: 8421376,
            671088641: 8388608,
            939524097: 512,
            1207959553: 32768,
            1476395009: 8388610,
            1744830465: 2,
            2013265921: 33282,
            2281701377: 32770,
            2550136833: 8389122,
            2818572289: 514,
            3087007745: 8421888,
            3355443201: 8389120,
            3623878657: 0,
            3892314113: 33280,
            4160749569: 8421378
          },
          {
            0: 1074282512,
            16777216: 16384,
            33554432: 524288,
            50331648: 1074266128,
            67108864: 1073741840,
            83886080: 1074282496,
            100663296: 1073758208,
            117440512: 16,
            134217728: 540672,
            150994944: 1073758224,
            167772160: 1073741824,
            184549376: 540688,
            201326592: 524304,
            218103808: 0,
            234881024: 16400,
            251658240: 1074266112,
            8388608: 1073758208,
            25165824: 540688,
            41943040: 16,
            58720256: 1073758224,
            75497472: 1074282512,
            92274688: 1073741824,
            109051904: 524288,
            125829120: 1074266128,
            142606336: 524304,
            159383552: 0,
            176160768: 16384,
            192937984: 1074266112,
            209715200: 1073741840,
            226492416: 540672,
            243269632: 1074282496,
            260046848: 16400,
            268435456: 0,
            285212672: 1074266128,
            301989888: 1073758224,
            318767104: 1074282496,
            335544320: 1074266112,
            352321536: 16,
            369098752: 540688,
            385875968: 16384,
            402653184: 16400,
            419430400: 524288,
            436207616: 524304,
            452984832: 1073741840,
            469762048: 540672,
            486539264: 1073758208,
            503316480: 1073741824,
            520093696: 1074282512,
            276824064: 540688,
            293601280: 524288,
            310378496: 1074266112,
            327155712: 16384,
            343932928: 1073758208,
            360710144: 1074282512,
            377487360: 16,
            394264576: 1073741824,
            411041792: 1074282496,
            427819008: 1073741840,
            444596224: 1073758224,
            461373440: 524304,
            478150656: 0,
            494927872: 16400,
            511705088: 1074266128,
            528482304: 540672
          },
          {
            0: 260,
            1048576: 0,
            2097152: 67109120,
            3145728: 65796,
            4194304: 65540,
            5242880: 67108868,
            6291456: 67174660,
            7340032: 67174400,
            8388608: 67108864,
            9437184: 67174656,
            10485760: 65792,
            11534336: 67174404,
            12582912: 67109124,
            13631488: 65536,
            14680064: 4,
            15728640: 256,
            524288: 67174656,
            1572864: 67174404,
            2621440: 0,
            3670016: 67109120,
            4718592: 67108868,
            5767168: 65536,
            6815744: 65540,
            7864320: 260,
            8912896: 4,
            9961472: 256,
            11010048: 67174400,
            12058624: 65796,
            13107200: 65792,
            14155776: 67109124,
            15204352: 67174660,
            16252928: 67108864,
            16777216: 67174656,
            17825792: 65540,
            18874368: 65536,
            19922944: 67109120,
            20971520: 256,
            22020096: 67174660,
            23068672: 67108868,
            24117248: 0,
            25165824: 67109124,
            26214400: 67108864,
            27262976: 4,
            28311552: 65792,
            29360128: 67174400,
            30408704: 260,
            31457280: 65796,
            32505856: 67174404,
            17301504: 67108864,
            18350080: 260,
            19398656: 67174656,
            20447232: 0,
            21495808: 65540,
            22544384: 67109120,
            23592960: 256,
            24641536: 67174404,
            25690112: 65536,
            26738688: 67174660,
            27787264: 65796,
            28835840: 67108868,
            29884416: 67109124,
            30932992: 67174400,
            31981568: 4,
            33030144: 65792
          },
          {
            0: 2151682048,
            65536: 2147487808,
            131072: 4198464,
            196608: 2151677952,
            262144: 0,
            327680: 4198400,
            393216: 2147483712,
            458752: 4194368,
            524288: 2147483648,
            589824: 4194304,
            655360: 64,
            720896: 2147487744,
            786432: 2151678016,
            851968: 4160,
            917504: 4096,
            983040: 2151682112,
            32768: 2147487808,
            98304: 64,
            163840: 2151678016,
            229376: 2147487744,
            294912: 4198400,
            360448: 2151682112,
            425984: 0,
            491520: 2151677952,
            557056: 4096,
            622592: 2151682048,
            688128: 4194304,
            753664: 4160,
            819200: 2147483648,
            884736: 4194368,
            950272: 4198464,
            1015808: 2147483712,
            1048576: 4194368,
            1114112: 4198400,
            1179648: 2147483712,
            1245184: 0,
            1310720: 4160,
            1376256: 2151678016,
            1441792: 2151682048,
            1507328: 2147487808,
            1572864: 2151682112,
            1638400: 2147483648,
            1703936: 2151677952,
            1769472: 4198464,
            1835008: 2147487744,
            1900544: 4194304,
            1966080: 64,
            2031616: 4096,
            1081344: 2151677952,
            1146880: 2151682112,
            1212416: 0,
            1277952: 4198400,
            1343488: 4194368,
            1409024: 2147483648,
            1474560: 2147487808,
            1540096: 64,
            1605632: 2147483712,
            1671168: 4096,
            1736704: 2147487744,
            1802240: 2151678016,
            1867776: 4160,
            1933312: 2151682048,
            1998848: 4194304,
            2064384: 4198464
          },
          {
            0: 128,
            4096: 17039360,
            8192: 262144,
            12288: 536870912,
            16384: 537133184,
            20480: 16777344,
            24576: 553648256,
            28672: 262272,
            32768: 16777216,
            36864: 537133056,
            40960: 536871040,
            45056: 553910400,
            49152: 553910272,
            53248: 0,
            57344: 17039488,
            61440: 553648128,
            2048: 17039488,
            6144: 553648256,
            10240: 128,
            14336: 17039360,
            18432: 262144,
            22528: 537133184,
            26624: 553910272,
            30720: 536870912,
            34816: 537133056,
            38912: 0,
            43008: 553910400,
            47104: 16777344,
            51200: 536871040,
            55296: 553648128,
            59392: 16777216,
            63488: 262272,
            65536: 262144,
            69632: 128,
            73728: 536870912,
            77824: 553648256,
            81920: 16777344,
            86016: 553910272,
            90112: 537133184,
            94208: 16777216,
            98304: 553910400,
            102400: 553648128,
            106496: 17039360,
            110592: 537133056,
            114688: 262272,
            118784: 536871040,
            122880: 0,
            126976: 17039488,
            67584: 553648256,
            71680: 16777216,
            75776: 17039360,
            79872: 537133184,
            83968: 536870912,
            88064: 17039488,
            92160: 128,
            96256: 553910272,
            100352: 262272,
            104448: 553910400,
            108544: 0,
            112640: 553648128,
            116736: 16777344,
            120832: 262144,
            124928: 537133056,
            129024: 536871040
          },
          {
            0: 268435464,
            256: 8192,
            512: 270532608,
            768: 270540808,
            1024: 268443648,
            1280: 2097152,
            1536: 2097160,
            1792: 268435456,
            2048: 0,
            2304: 268443656,
            2560: 2105344,
            2816: 8,
            3072: 270532616,
            3328: 2105352,
            3584: 8200,
            3840: 270540800,
            128: 270532608,
            384: 270540808,
            640: 8,
            896: 2097152,
            1152: 2105352,
            1408: 268435464,
            1664: 268443648,
            1920: 8200,
            2176: 2097160,
            2432: 8192,
            2688: 268443656,
            2944: 270532616,
            3200: 0,
            3456: 270540800,
            3712: 2105344,
            3968: 268435456,
            4096: 268443648,
            4352: 270532616,
            4608: 270540808,
            4864: 8200,
            5120: 2097152,
            5376: 268435456,
            5632: 268435464,
            5888: 2105344,
            6144: 2105352,
            6400: 0,
            6656: 8,
            6912: 270532608,
            7168: 8192,
            7424: 268443656,
            7680: 270540800,
            7936: 2097160,
            4224: 8,
            4480: 2105344,
            4736: 2097152,
            4992: 268435464,
            5248: 268443648,
            5504: 8200,
            5760: 270540808,
            6016: 270532608,
            6272: 270540800,
            6528: 270532616,
            6784: 8192,
            7040: 2105352,
            7296: 2097160,
            7552: 0,
            7808: 268435456,
            8064: 268443656
          },
          {
            0: 1048576,
            16: 33555457,
            32: 1024,
            48: 1049601,
            64: 34604033,
            80: 0,
            96: 1,
            112: 34603009,
            128: 33555456,
            144: 1048577,
            160: 33554433,
            176: 34604032,
            192: 34603008,
            208: 1025,
            224: 1049600,
            240: 33554432,
            8: 34603009,
            24: 0,
            40: 33555457,
            56: 34604032,
            72: 1048576,
            88: 33554433,
            104: 33554432,
            120: 1025,
            136: 1049601,
            152: 33555456,
            168: 34603008,
            184: 1048577,
            200: 1024,
            216: 34604033,
            232: 1,
            248: 1049600,
            256: 33554432,
            272: 1048576,
            288: 33555457,
            304: 34603009,
            320: 1048577,
            336: 33555456,
            352: 34604032,
            368: 1049601,
            384: 1025,
            400: 34604033,
            416: 1049600,
            432: 1,
            448: 0,
            464: 34603008,
            480: 33554433,
            496: 1024,
            264: 1049600,
            280: 33555457,
            296: 34603009,
            312: 1,
            328: 33554432,
            344: 1048576,
            360: 1025,
            376: 34604032,
            392: 33554433,
            408: 34603008,
            424: 0,
            440: 34604033,
            456: 1049601,
            472: 1024,
            488: 33555456,
            504: 1048577
          },
          {
            0: 134219808,
            1: 131072,
            2: 134217728,
            3: 32,
            4: 131104,
            5: 134350880,
            6: 134350848,
            7: 2048,
            8: 134348800,
            9: 134219776,
            10: 133120,
            11: 134348832,
            12: 2080,
            13: 0,
            14: 134217760,
            15: 133152,
            2147483648: 2048,
            2147483649: 134350880,
            2147483650: 134219808,
            2147483651: 134217728,
            2147483652: 134348800,
            2147483653: 133120,
            2147483654: 133152,
            2147483655: 32,
            2147483656: 134217760,
            2147483657: 2080,
            2147483658: 131104,
            2147483659: 134350848,
            2147483660: 0,
            2147483661: 134348832,
            2147483662: 134219776,
            2147483663: 131072,
            16: 133152,
            17: 134350848,
            18: 32,
            19: 2048,
            20: 134219776,
            21: 134217760,
            22: 134348832,
            23: 131072,
            24: 0,
            25: 131104,
            26: 134348800,
            27: 134219808,
            28: 134350880,
            29: 133120,
            30: 2080,
            31: 134217728,
            2147483664: 131072,
            2147483665: 2048,
            2147483666: 134348832,
            2147483667: 133152,
            2147483668: 32,
            2147483669: 134348800,
            2147483670: 134217728,
            2147483671: 134219808,
            2147483672: 134350880,
            2147483673: 134217760,
            2147483674: 134219776,
            2147483675: 0,
            2147483676: 133120,
            2147483677: 2080,
            2147483678: 131104,
            2147483679: 134350848
          }
        ], i = [
          4160749569,
          528482304,
          33030144,
          2064384,
          129024,
          8064,
          504,
          2147483679
        ], l = d.DES = E.extend({
          _doReset: function() {
            for (var F = this._key, f = F.words, h = [], B = 0; B < 56; B++) {
              var A = x[B] - 1;
              h[B] = f[A >>> 5] >>> 31 - A % 32 & 1;
            }
            for (var m = this._subKeys = [], y = 0; y < 16; y++) {
              for (var b = m[y] = [], k = a[y], B = 0; B < 24; B++)
                b[B / 6 | 0] |= h[(t[B] - 1 + k) % 28] << 31 - B % 6, b[4 + (B / 6 | 0)] |= h[28 + (t[B + 24] - 1 + k) % 28] << 31 - B % 6;
              b[0] = b[0] << 1 | b[0] >>> 31;
              for (var B = 1; B < 7; B++)
                b[B] = b[B] >>> (B - 1) * 4 + 3;
              b[7] = b[7] << 5 | b[7] >>> 27;
            }
            for (var g = this._invSubKeys = [], B = 0; B < 16; B++)
              g[B] = m[15 - B];
          },
          encryptBlock: function(F, f) {
            this._doCryptBlock(F, f, this._subKeys);
          },
          decryptBlock: function(F, f) {
            this._doCryptBlock(F, f, this._invSubKeys);
          },
          _doCryptBlock: function(F, f, h) {
            this._lBlock = F[f], this._rBlock = F[f + 1], p.call(this, 4, 252645135), p.call(this, 16, 65535), C.call(this, 2, 858993459), C.call(this, 8, 16711935), p.call(this, 1, 1431655765);
            for (var B = 0; B < 16; B++) {
              for (var A = h[B], m = this._lBlock, y = this._rBlock, b = 0, k = 0; k < 8; k++)
                b |= u[k][((y ^ A[k]) & i[k]) >>> 0];
              this._lBlock = y, this._rBlock = m ^ b;
            }
            var g = this._lBlock;
            this._lBlock = this._rBlock, this._rBlock = g, p.call(this, 1, 1431655765), C.call(this, 8, 16711935), C.call(this, 2, 858993459), p.call(this, 16, 65535), p.call(this, 4, 252645135), F[f] = this._lBlock, F[f + 1] = this._rBlock;
          },
          keySize: 64 / 32,
          ivSize: 64 / 32,
          blockSize: 64 / 32
        });
        function p(F, f) {
          var h = (this._lBlock >>> F ^ this._rBlock) & f;
          this._rBlock ^= h, this._lBlock ^= h << F;
        }
        function C(F, f) {
          var h = (this._rBlock >>> F ^ this._lBlock) & f;
          this._lBlock ^= h, this._rBlock ^= h << F;
        }
        e.DES = E._createHelper(l);
        var v = d.TripleDES = E.extend({
          _doReset: function() {
            var F = this._key, f = F.words;
            if (f.length !== 2 && f.length !== 4 && f.length < 6)
              throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");
            var h = f.slice(0, 2), B = f.length < 4 ? f.slice(0, 2) : f.slice(2, 4), A = f.length < 6 ? f.slice(0, 2) : f.slice(4, 6);
            this._des1 = l.createEncryptor(c.create(h)), this._des2 = l.createEncryptor(c.create(B)), this._des3 = l.createEncryptor(c.create(A));
          },
          encryptBlock: function(F, f) {
            this._des1.encryptBlock(F, f), this._des2.decryptBlock(F, f), this._des3.encryptBlock(F, f);
          },
          decryptBlock: function(F, f) {
            this._des3.decryptBlock(F, f), this._des2.encryptBlock(F, f), this._des1.decryptBlock(F, f);
          },
          keySize: 192 / 32,
          ivSize: 64 / 32,
          blockSize: 64 / 32
        });
        e.TripleDES = E._createHelper(v);
      })(), r.TripleDES;
    });
  })(ie)), ie.exports;
}
var se = { exports: {} }, Ra = se.exports, Ar;
function za() {
  return Ar || (Ar = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), h0(), u0(), l0(), K());
    })(Ra, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.StreamCipher, E = e.algo, d = E.RC4 = c.extend({
          _doReset: function() {
            for (var a = this._key, u = a.words, i = a.sigBytes, l = this._S = [], p = 0; p < 256; p++)
              l[p] = p;
            for (var p = 0, C = 0; p < 256; p++) {
              var v = p % i, F = u[v >>> 2] >>> 24 - v % 4 * 8 & 255;
              C = (C + l[p] + F) % 256;
              var f = l[p];
              l[p] = l[C], l[C] = f;
            }
            this._i = this._j = 0;
          },
          _doProcessBlock: function(a, u) {
            a[u] ^= x.call(this);
          },
          keySize: 256 / 32,
          ivSize: 0
        });
        function x() {
          for (var a = this._S, u = this._i, i = this._j, l = 0, p = 0; p < 4; p++) {
            u = (u + 1) % 256, i = (i + a[u]) % 256;
            var C = a[u];
            a[u] = a[i], a[i] = C, l |= a[(a[u] + a[i]) % 256] << 24 - p * 8;
          }
          return this._i = u, this._j = i, l;
        }
        e.RC4 = c._createHelper(d);
        var t = E.RC4Drop = d.extend({
          /**
           * Configuration options.
           *
           * @property {number} drop The number of keystream words to drop. Default 192
           */
          cfg: d.cfg.extend({
            drop: 192
          }),
          _doReset: function() {
            d._doReset.call(this);
            for (var a = this.cfg.drop; a > 0; a--)
              x.call(this);
          }
        });
        e.RC4Drop = c._createHelper(t);
      })(), r.RC4;
    });
  })(se)), se.exports;
}
var xe = { exports: {} }, Ha = xe.exports, Er;
function Pa() {
  return Er || (Er = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), h0(), u0(), l0(), K());
    })(Ha, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.StreamCipher, E = e.algo, d = [], x = [], t = [], a = E.Rabbit = c.extend({
          _doReset: function() {
            for (var i = this._key.words, l = this.cfg.iv, p = 0; p < 4; p++)
              i[p] = (i[p] << 8 | i[p] >>> 24) & 16711935 | (i[p] << 24 | i[p] >>> 8) & 4278255360;
            var C = this._X = [
              i[0],
              i[3] << 16 | i[2] >>> 16,
              i[1],
              i[0] << 16 | i[3] >>> 16,
              i[2],
              i[1] << 16 | i[0] >>> 16,
              i[3],
              i[2] << 16 | i[1] >>> 16
            ], v = this._C = [
              i[2] << 16 | i[2] >>> 16,
              i[0] & 4294901760 | i[1] & 65535,
              i[3] << 16 | i[3] >>> 16,
              i[1] & 4294901760 | i[2] & 65535,
              i[0] << 16 | i[0] >>> 16,
              i[2] & 4294901760 | i[3] & 65535,
              i[1] << 16 | i[1] >>> 16,
              i[3] & 4294901760 | i[0] & 65535
            ];
            this._b = 0;
            for (var p = 0; p < 4; p++)
              u.call(this);
            for (var p = 0; p < 8; p++)
              v[p] ^= C[p + 4 & 7];
            if (l) {
              var F = l.words, f = F[0], h = F[1], B = (f << 8 | f >>> 24) & 16711935 | (f << 24 | f >>> 8) & 4278255360, A = (h << 8 | h >>> 24) & 16711935 | (h << 24 | h >>> 8) & 4278255360, m = B >>> 16 | A & 4294901760, y = A << 16 | B & 65535;
              v[0] ^= B, v[1] ^= m, v[2] ^= A, v[3] ^= y, v[4] ^= B, v[5] ^= m, v[6] ^= A, v[7] ^= y;
              for (var p = 0; p < 4; p++)
                u.call(this);
            }
          },
          _doProcessBlock: function(i, l) {
            var p = this._X;
            u.call(this), d[0] = p[0] ^ p[5] >>> 16 ^ p[3] << 16, d[1] = p[2] ^ p[7] >>> 16 ^ p[5] << 16, d[2] = p[4] ^ p[1] >>> 16 ^ p[7] << 16, d[3] = p[6] ^ p[3] >>> 16 ^ p[1] << 16;
            for (var C = 0; C < 4; C++)
              d[C] = (d[C] << 8 | d[C] >>> 24) & 16711935 | (d[C] << 24 | d[C] >>> 8) & 4278255360, i[l + C] ^= d[C];
          },
          blockSize: 128 / 32,
          ivSize: 64 / 32
        });
        function u() {
          for (var i = this._X, l = this._C, p = 0; p < 8; p++)
            x[p] = l[p];
          l[0] = l[0] + 1295307597 + this._b | 0, l[1] = l[1] + 3545052371 + (l[0] >>> 0 < x[0] >>> 0 ? 1 : 0) | 0, l[2] = l[2] + 886263092 + (l[1] >>> 0 < x[1] >>> 0 ? 1 : 0) | 0, l[3] = l[3] + 1295307597 + (l[2] >>> 0 < x[2] >>> 0 ? 1 : 0) | 0, l[4] = l[4] + 3545052371 + (l[3] >>> 0 < x[3] >>> 0 ? 1 : 0) | 0, l[5] = l[5] + 886263092 + (l[4] >>> 0 < x[4] >>> 0 ? 1 : 0) | 0, l[6] = l[6] + 1295307597 + (l[5] >>> 0 < x[5] >>> 0 ? 1 : 0) | 0, l[7] = l[7] + 3545052371 + (l[6] >>> 0 < x[6] >>> 0 ? 1 : 0) | 0, this._b = l[7] >>> 0 < x[7] >>> 0 ? 1 : 0;
          for (var p = 0; p < 8; p++) {
            var C = i[p] + l[p], v = C & 65535, F = C >>> 16, f = ((v * v >>> 17) + v * F >>> 15) + F * F, h = ((C & 4294901760) * C | 0) + ((C & 65535) * C | 0);
            t[p] = f ^ h;
          }
          i[0] = t[0] + (t[7] << 16 | t[7] >>> 16) + (t[6] << 16 | t[6] >>> 16) | 0, i[1] = t[1] + (t[0] << 8 | t[0] >>> 24) + t[7] | 0, i[2] = t[2] + (t[1] << 16 | t[1] >>> 16) + (t[0] << 16 | t[0] >>> 16) | 0, i[3] = t[3] + (t[2] << 8 | t[2] >>> 24) + t[1] | 0, i[4] = t[4] + (t[3] << 16 | t[3] >>> 16) + (t[2] << 16 | t[2] >>> 16) | 0, i[5] = t[5] + (t[4] << 8 | t[4] >>> 24) + t[3] | 0, i[6] = t[6] + (t[5] << 16 | t[5] >>> 16) + (t[4] << 16 | t[4] >>> 16) | 0, i[7] = t[7] + (t[6] << 8 | t[6] >>> 24) + t[5] | 0;
        }
        e.Rabbit = c._createHelper(a);
      })(), r.Rabbit;
    });
  })(xe)), xe.exports;
}
var ce = { exports: {} }, Wa = ce.exports, mr;
function qa() {
  return mr || (mr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), h0(), u0(), l0(), K());
    })(Wa, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.StreamCipher, E = e.algo, d = [], x = [], t = [], a = E.RabbitLegacy = c.extend({
          _doReset: function() {
            var i = this._key.words, l = this.cfg.iv, p = this._X = [
              i[0],
              i[3] << 16 | i[2] >>> 16,
              i[1],
              i[0] << 16 | i[3] >>> 16,
              i[2],
              i[1] << 16 | i[0] >>> 16,
              i[3],
              i[2] << 16 | i[1] >>> 16
            ], C = this._C = [
              i[2] << 16 | i[2] >>> 16,
              i[0] & 4294901760 | i[1] & 65535,
              i[3] << 16 | i[3] >>> 16,
              i[1] & 4294901760 | i[2] & 65535,
              i[0] << 16 | i[0] >>> 16,
              i[2] & 4294901760 | i[3] & 65535,
              i[1] << 16 | i[1] >>> 16,
              i[3] & 4294901760 | i[0] & 65535
            ];
            this._b = 0;
            for (var v = 0; v < 4; v++)
              u.call(this);
            for (var v = 0; v < 8; v++)
              C[v] ^= p[v + 4 & 7];
            if (l) {
              var F = l.words, f = F[0], h = F[1], B = (f << 8 | f >>> 24) & 16711935 | (f << 24 | f >>> 8) & 4278255360, A = (h << 8 | h >>> 24) & 16711935 | (h << 24 | h >>> 8) & 4278255360, m = B >>> 16 | A & 4294901760, y = A << 16 | B & 65535;
              C[0] ^= B, C[1] ^= m, C[2] ^= A, C[3] ^= y, C[4] ^= B, C[5] ^= m, C[6] ^= A, C[7] ^= y;
              for (var v = 0; v < 4; v++)
                u.call(this);
            }
          },
          _doProcessBlock: function(i, l) {
            var p = this._X;
            u.call(this), d[0] = p[0] ^ p[5] >>> 16 ^ p[3] << 16, d[1] = p[2] ^ p[7] >>> 16 ^ p[5] << 16, d[2] = p[4] ^ p[1] >>> 16 ^ p[7] << 16, d[3] = p[6] ^ p[3] >>> 16 ^ p[1] << 16;
            for (var C = 0; C < 4; C++)
              d[C] = (d[C] << 8 | d[C] >>> 24) & 16711935 | (d[C] << 24 | d[C] >>> 8) & 4278255360, i[l + C] ^= d[C];
          },
          blockSize: 128 / 32,
          ivSize: 64 / 32
        });
        function u() {
          for (var i = this._X, l = this._C, p = 0; p < 8; p++)
            x[p] = l[p];
          l[0] = l[0] + 1295307597 + this._b | 0, l[1] = l[1] + 3545052371 + (l[0] >>> 0 < x[0] >>> 0 ? 1 : 0) | 0, l[2] = l[2] + 886263092 + (l[1] >>> 0 < x[1] >>> 0 ? 1 : 0) | 0, l[3] = l[3] + 1295307597 + (l[2] >>> 0 < x[2] >>> 0 ? 1 : 0) | 0, l[4] = l[4] + 3545052371 + (l[3] >>> 0 < x[3] >>> 0 ? 1 : 0) | 0, l[5] = l[5] + 886263092 + (l[4] >>> 0 < x[4] >>> 0 ? 1 : 0) | 0, l[6] = l[6] + 1295307597 + (l[5] >>> 0 < x[5] >>> 0 ? 1 : 0) | 0, l[7] = l[7] + 3545052371 + (l[6] >>> 0 < x[6] >>> 0 ? 1 : 0) | 0, this._b = l[7] >>> 0 < x[7] >>> 0 ? 1 : 0;
          for (var p = 0; p < 8; p++) {
            var C = i[p] + l[p], v = C & 65535, F = C >>> 16, f = ((v * v >>> 17) + v * F >>> 15) + F * F, h = ((C & 4294901760) * C | 0) + ((C & 65535) * C | 0);
            t[p] = f ^ h;
          }
          i[0] = t[0] + (t[7] << 16 | t[7] >>> 16) + (t[6] << 16 | t[6] >>> 16) | 0, i[1] = t[1] + (t[0] << 8 | t[0] >>> 24) + t[7] | 0, i[2] = t[2] + (t[1] << 16 | t[1] >>> 16) + (t[0] << 16 | t[0] >>> 16) | 0, i[3] = t[3] + (t[2] << 8 | t[2] >>> 24) + t[1] | 0, i[4] = t[4] + (t[3] << 16 | t[3] >>> 16) + (t[2] << 16 | t[2] >>> 16) | 0, i[5] = t[5] + (t[4] << 8 | t[4] >>> 24) + t[3] | 0, i[6] = t[6] + (t[5] << 16 | t[5] >>> 16) + (t[4] << 16 | t[4] >>> 16) | 0, i[7] = t[7] + (t[6] << 8 | t[6] >>> 24) + t[5] | 0;
        }
        e.RabbitLegacy = c._createHelper(a);
      })(), r.RabbitLegacy;
    });
  })(ce)), ce.exports;
}
var fe = { exports: {} }, Oa = fe.exports, Fr;
function Ta() {
  return Fr || (Fr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), h0(), u0(), l0(), K());
    })(Oa, function(r) {
      return (function() {
        var e = r, o = e.lib, c = o.BlockCipher, E = e.algo;
        const d = 16, x = [
          608135816,
          2242054355,
          320440878,
          57701188,
          2752067618,
          698298832,
          137296536,
          3964562569,
          1160258022,
          953160567,
          3193202383,
          887688300,
          3232508343,
          3380367581,
          1065670069,
          3041331479,
          2450970073,
          2306472731
        ], t = [
          [
            3509652390,
            2564797868,
            805139163,
            3491422135,
            3101798381,
            1780907670,
            3128725573,
            4046225305,
            614570311,
            3012652279,
            134345442,
            2240740374,
            1667834072,
            1901547113,
            2757295779,
            4103290238,
            227898511,
            1921955416,
            1904987480,
            2182433518,
            2069144605,
            3260701109,
            2620446009,
            720527379,
            3318853667,
            677414384,
            3393288472,
            3101374703,
            2390351024,
            1614419982,
            1822297739,
            2954791486,
            3608508353,
            3174124327,
            2024746970,
            1432378464,
            3864339955,
            2857741204,
            1464375394,
            1676153920,
            1439316330,
            715854006,
            3033291828,
            289532110,
            2706671279,
            2087905683,
            3018724369,
            1668267050,
            732546397,
            1947742710,
            3462151702,
            2609353502,
            2950085171,
            1814351708,
            2050118529,
            680887927,
            999245976,
            1800124847,
            3300911131,
            1713906067,
            1641548236,
            4213287313,
            1216130144,
            1575780402,
            4018429277,
            3917837745,
            3693486850,
            3949271944,
            596196993,
            3549867205,
            258830323,
            2213823033,
            772490370,
            2760122372,
            1774776394,
            2652871518,
            566650946,
            4142492826,
            1728879713,
            2882767088,
            1783734482,
            3629395816,
            2517608232,
            2874225571,
            1861159788,
            326777828,
            3124490320,
            2130389656,
            2716951837,
            967770486,
            1724537150,
            2185432712,
            2364442137,
            1164943284,
            2105845187,
            998989502,
            3765401048,
            2244026483,
            1075463327,
            1455516326,
            1322494562,
            910128902,
            469688178,
            1117454909,
            936433444,
            3490320968,
            3675253459,
            1240580251,
            122909385,
            2157517691,
            634681816,
            4142456567,
            3825094682,
            3061402683,
            2540495037,
            79693498,
            3249098678,
            1084186820,
            1583128258,
            426386531,
            1761308591,
            1047286709,
            322548459,
            995290223,
            1845252383,
            2603652396,
            3431023940,
            2942221577,
            3202600964,
            3727903485,
            1712269319,
            422464435,
            3234572375,
            1170764815,
            3523960633,
            3117677531,
            1434042557,
            442511882,
            3600875718,
            1076654713,
            1738483198,
            4213154764,
            2393238008,
            3677496056,
            1014306527,
            4251020053,
            793779912,
            2902807211,
            842905082,
            4246964064,
            1395751752,
            1040244610,
            2656851899,
            3396308128,
            445077038,
            3742853595,
            3577915638,
            679411651,
            2892444358,
            2354009459,
            1767581616,
            3150600392,
            3791627101,
            3102740896,
            284835224,
            4246832056,
            1258075500,
            768725851,
            2589189241,
            3069724005,
            3532540348,
            1274779536,
            3789419226,
            2764799539,
            1660621633,
            3471099624,
            4011903706,
            913787905,
            3497959166,
            737222580,
            2514213453,
            2928710040,
            3937242737,
            1804850592,
            3499020752,
            2949064160,
            2386320175,
            2390070455,
            2415321851,
            4061277028,
            2290661394,
            2416832540,
            1336762016,
            1754252060,
            3520065937,
            3014181293,
            791618072,
            3188594551,
            3933548030,
            2332172193,
            3852520463,
            3043980520,
            413987798,
            3465142937,
            3030929376,
            4245938359,
            2093235073,
            3534596313,
            375366246,
            2157278981,
            2479649556,
            555357303,
            3870105701,
            2008414854,
            3344188149,
            4221384143,
            3956125452,
            2067696032,
            3594591187,
            2921233993,
            2428461,
            544322398,
            577241275,
            1471733935,
            610547355,
            4027169054,
            1432588573,
            1507829418,
            2025931657,
            3646575487,
            545086370,
            48609733,
            2200306550,
            1653985193,
            298326376,
            1316178497,
            3007786442,
            2064951626,
            458293330,
            2589141269,
            3591329599,
            3164325604,
            727753846,
            2179363840,
            146436021,
            1461446943,
            4069977195,
            705550613,
            3059967265,
            3887724982,
            4281599278,
            3313849956,
            1404054877,
            2845806497,
            146425753,
            1854211946
          ],
          [
            1266315497,
            3048417604,
            3681880366,
            3289982499,
            290971e4,
            1235738493,
            2632868024,
            2414719590,
            3970600049,
            1771706367,
            1449415276,
            3266420449,
            422970021,
            1963543593,
            2690192192,
            3826793022,
            1062508698,
            1531092325,
            1804592342,
            2583117782,
            2714934279,
            4024971509,
            1294809318,
            4028980673,
            1289560198,
            2221992742,
            1669523910,
            35572830,
            157838143,
            1052438473,
            1016535060,
            1802137761,
            1753167236,
            1386275462,
            3080475397,
            2857371447,
            1040679964,
            2145300060,
            2390574316,
            1461121720,
            2956646967,
            4031777805,
            4028374788,
            33600511,
            2920084762,
            1018524850,
            629373528,
            3691585981,
            3515945977,
            2091462646,
            2486323059,
            586499841,
            988145025,
            935516892,
            3367335476,
            2599673255,
            2839830854,
            265290510,
            3972581182,
            2759138881,
            3795373465,
            1005194799,
            847297441,
            406762289,
            1314163512,
            1332590856,
            1866599683,
            4127851711,
            750260880,
            613907577,
            1450815602,
            3165620655,
            3734664991,
            3650291728,
            3012275730,
            3704569646,
            1427272223,
            778793252,
            1343938022,
            2676280711,
            2052605720,
            1946737175,
            3164576444,
            3914038668,
            3967478842,
            3682934266,
            1661551462,
            3294938066,
            4011595847,
            840292616,
            3712170807,
            616741398,
            312560963,
            711312465,
            1351876610,
            322626781,
            1910503582,
            271666773,
            2175563734,
            1594956187,
            70604529,
            3617834859,
            1007753275,
            1495573769,
            4069517037,
            2549218298,
            2663038764,
            504708206,
            2263041392,
            3941167025,
            2249088522,
            1514023603,
            1998579484,
            1312622330,
            694541497,
            2582060303,
            2151582166,
            1382467621,
            776784248,
            2618340202,
            3323268794,
            2497899128,
            2784771155,
            503983604,
            4076293799,
            907881277,
            423175695,
            432175456,
            1378068232,
            4145222326,
            3954048622,
            3938656102,
            3820766613,
            2793130115,
            2977904593,
            26017576,
            3274890735,
            3194772133,
            1700274565,
            1756076034,
            4006520079,
            3677328699,
            720338349,
            1533947780,
            354530856,
            688349552,
            3973924725,
            1637815568,
            332179504,
            3949051286,
            53804574,
            2852348879,
            3044236432,
            1282449977,
            3583942155,
            3416972820,
            4006381244,
            1617046695,
            2628476075,
            3002303598,
            1686838959,
            431878346,
            2686675385,
            1700445008,
            1080580658,
            1009431731,
            832498133,
            3223435511,
            2605976345,
            2271191193,
            2516031870,
            1648197032,
            4164389018,
            2548247927,
            300782431,
            375919233,
            238389289,
            3353747414,
            2531188641,
            2019080857,
            1475708069,
            455242339,
            2609103871,
            448939670,
            3451063019,
            1395535956,
            2413381860,
            1841049896,
            1491858159,
            885456874,
            4264095073,
            4001119347,
            1565136089,
            3898914787,
            1108368660,
            540939232,
            1173283510,
            2745871338,
            3681308437,
            4207628240,
            3343053890,
            4016749493,
            1699691293,
            1103962373,
            3625875870,
            2256883143,
            3830138730,
            1031889488,
            3479347698,
            1535977030,
            4236805024,
            3251091107,
            2132092099,
            1774941330,
            1199868427,
            1452454533,
            157007616,
            2904115357,
            342012276,
            595725824,
            1480756522,
            206960106,
            497939518,
            591360097,
            863170706,
            2375253569,
            3596610801,
            1814182875,
            2094937945,
            3421402208,
            1082520231,
            3463918190,
            2785509508,
            435703966,
            3908032597,
            1641649973,
            2842273706,
            3305899714,
            1510255612,
            2148256476,
            2655287854,
            3276092548,
            4258621189,
            236887753,
            3681803219,
            274041037,
            1734335097,
            3815195456,
            3317970021,
            1899903192,
            1026095262,
            4050517792,
            356393447,
            2410691914,
            3873677099,
            3682840055
          ],
          [
            3913112168,
            2491498743,
            4132185628,
            2489919796,
            1091903735,
            1979897079,
            3170134830,
            3567386728,
            3557303409,
            857797738,
            1136121015,
            1342202287,
            507115054,
            2535736646,
            337727348,
            3213592640,
            1301675037,
            2528481711,
            1895095763,
            1721773893,
            3216771564,
            62756741,
            2142006736,
            835421444,
            2531993523,
            1442658625,
            3659876326,
            2882144922,
            676362277,
            1392781812,
            170690266,
            3921047035,
            1759253602,
            3611846912,
            1745797284,
            664899054,
            1329594018,
            3901205900,
            3045908486,
            2062866102,
            2865634940,
            3543621612,
            3464012697,
            1080764994,
            553557557,
            3656615353,
            3996768171,
            991055499,
            499776247,
            1265440854,
            648242737,
            3940784050,
            980351604,
            3713745714,
            1749149687,
            3396870395,
            4211799374,
            3640570775,
            1161844396,
            3125318951,
            1431517754,
            545492359,
            4268468663,
            3499529547,
            1437099964,
            2702547544,
            3433638243,
            2581715763,
            2787789398,
            1060185593,
            1593081372,
            2418618748,
            4260947970,
            69676912,
            2159744348,
            86519011,
            2512459080,
            3838209314,
            1220612927,
            3339683548,
            133810670,
            1090789135,
            1078426020,
            1569222167,
            845107691,
            3583754449,
            4072456591,
            1091646820,
            628848692,
            1613405280,
            3757631651,
            526609435,
            236106946,
            48312990,
            2942717905,
            3402727701,
            1797494240,
            859738849,
            992217954,
            4005476642,
            2243076622,
            3870952857,
            3732016268,
            765654824,
            3490871365,
            2511836413,
            1685915746,
            3888969200,
            1414112111,
            2273134842,
            3281911079,
            4080962846,
            172450625,
            2569994100,
            980381355,
            4109958455,
            2819808352,
            2716589560,
            2568741196,
            3681446669,
            3329971472,
            1835478071,
            660984891,
            3704678404,
            4045999559,
            3422617507,
            3040415634,
            1762651403,
            1719377915,
            3470491036,
            2693910283,
            3642056355,
            3138596744,
            1364962596,
            2073328063,
            1983633131,
            926494387,
            3423689081,
            2150032023,
            4096667949,
            1749200295,
            3328846651,
            309677260,
            2016342300,
            1779581495,
            3079819751,
            111262694,
            1274766160,
            443224088,
            298511866,
            1025883608,
            3806446537,
            1145181785,
            168956806,
            3641502830,
            3584813610,
            1689216846,
            3666258015,
            3200248200,
            1692713982,
            2646376535,
            4042768518,
            1618508792,
            1610833997,
            3523052358,
            4130873264,
            2001055236,
            3610705100,
            2202168115,
            4028541809,
            2961195399,
            1006657119,
            2006996926,
            3186142756,
            1430667929,
            3210227297,
            1314452623,
            4074634658,
            4101304120,
            2273951170,
            1399257539,
            3367210612,
            3027628629,
            1190975929,
            2062231137,
            2333990788,
            2221543033,
            2438960610,
            1181637006,
            548689776,
            2362791313,
            3372408396,
            3104550113,
            3145860560,
            296247880,
            1970579870,
            3078560182,
            3769228297,
            1714227617,
            3291629107,
            3898220290,
            166772364,
            1251581989,
            493813264,
            448347421,
            195405023,
            2709975567,
            677966185,
            3703036547,
            1463355134,
            2715995803,
            1338867538,
            1343315457,
            2802222074,
            2684532164,
            233230375,
            2599980071,
            2000651841,
            3277868038,
            1638401717,
            4028070440,
            3237316320,
            6314154,
            819756386,
            300326615,
            590932579,
            1405279636,
            3267499572,
            3150704214,
            2428286686,
            3959192993,
            3461946742,
            1862657033,
            1266418056,
            963775037,
            2089974820,
            2263052895,
            1917689273,
            448879540,
            3550394620,
            3981727096,
            150775221,
            3627908307,
            1303187396,
            508620638,
            2975983352,
            2726630617,
            1817252668,
            1876281319,
            1457606340,
            908771278,
            3720792119,
            3617206836,
            2455994898,
            1729034894,
            1080033504
          ],
          [
            976866871,
            3556439503,
            2881648439,
            1522871579,
            1555064734,
            1336096578,
            3548522304,
            2579274686,
            3574697629,
            3205460757,
            3593280638,
            3338716283,
            3079412587,
            564236357,
            2993598910,
            1781952180,
            1464380207,
            3163844217,
            3332601554,
            1699332808,
            1393555694,
            1183702653,
            3581086237,
            1288719814,
            691649499,
            2847557200,
            2895455976,
            3193889540,
            2717570544,
            1781354906,
            1676643554,
            2592534050,
            3230253752,
            1126444790,
            2770207658,
            2633158820,
            2210423226,
            2615765581,
            2414155088,
            3127139286,
            673620729,
            2805611233,
            1269405062,
            4015350505,
            3341807571,
            4149409754,
            1057255273,
            2012875353,
            2162469141,
            2276492801,
            2601117357,
            993977747,
            3918593370,
            2654263191,
            753973209,
            36408145,
            2530585658,
            25011837,
            3520020182,
            2088578344,
            530523599,
            2918365339,
            1524020338,
            1518925132,
            3760827505,
            3759777254,
            1202760957,
            3985898139,
            3906192525,
            674977740,
            4174734889,
            2031300136,
            2019492241,
            3983892565,
            4153806404,
            3822280332,
            352677332,
            2297720250,
            60907813,
            90501309,
            3286998549,
            1016092578,
            2535922412,
            2839152426,
            457141659,
            509813237,
            4120667899,
            652014361,
            1966332200,
            2975202805,
            55981186,
            2327461051,
            676427537,
            3255491064,
            2882294119,
            3433927263,
            1307055953,
            942726286,
            933058658,
            2468411793,
            3933900994,
            4215176142,
            1361170020,
            2001714738,
            2830558078,
            3274259782,
            1222529897,
            1679025792,
            2729314320,
            3714953764,
            1770335741,
            151462246,
            3013232138,
            1682292957,
            1483529935,
            471910574,
            1539241949,
            458788160,
            3436315007,
            1807016891,
            3718408830,
            978976581,
            1043663428,
            3165965781,
            1927990952,
            4200891579,
            2372276910,
            3208408903,
            3533431907,
            1412390302,
            2931980059,
            4132332400,
            1947078029,
            3881505623,
            4168226417,
            2941484381,
            1077988104,
            1320477388,
            886195818,
            18198404,
            3786409e3,
            2509781533,
            112762804,
            3463356488,
            1866414978,
            891333506,
            18488651,
            661792760,
            1628790961,
            3885187036,
            3141171499,
            876946877,
            2693282273,
            1372485963,
            791857591,
            2686433993,
            3759982718,
            3167212022,
            3472953795,
            2716379847,
            445679433,
            3561995674,
            3504004811,
            3574258232,
            54117162,
            3331405415,
            2381918588,
            3769707343,
            4154350007,
            1140177722,
            4074052095,
            668550556,
            3214352940,
            367459370,
            261225585,
            2610173221,
            4209349473,
            3468074219,
            3265815641,
            314222801,
            3066103646,
            3808782860,
            282218597,
            3406013506,
            3773591054,
            379116347,
            1285071038,
            846784868,
            2669647154,
            3771962079,
            3550491691,
            2305946142,
            453669953,
            1268987020,
            3317592352,
            3279303384,
            3744833421,
            2610507566,
            3859509063,
            266596637,
            3847019092,
            517658769,
            3462560207,
            3443424879,
            370717030,
            4247526661,
            2224018117,
            4143653529,
            4112773975,
            2788324899,
            2477274417,
            1456262402,
            2901442914,
            1517677493,
            1846949527,
            2295493580,
            3734397586,
            2176403920,
            1280348187,
            1908823572,
            3871786941,
            846861322,
            1172426758,
            3287448474,
            3383383037,
            1655181056,
            3139813346,
            901632758,
            1897031941,
            2986607138,
            3066810236,
            3447102507,
            1393639104,
            373351379,
            950779232,
            625454576,
            3124240540,
            4148612726,
            2007998917,
            544563296,
            2244738638,
            2330496472,
            2058025392,
            1291430526,
            424198748,
            50039436,
            29584100,
            3605783033,
            2429876329,
            2791104160,
            1057563949,
            3255363231,
            3075367218,
            3463963227,
            1469046755,
            985887462
          ]
        ];
        var a = {
          pbox: [],
          sbox: []
        };
        function u(v, F) {
          let f = F >> 24 & 255, h = F >> 16 & 255, B = F >> 8 & 255, A = F & 255, m = v.sbox[0][f] + v.sbox[1][h];
          return m = m ^ v.sbox[2][B], m = m + v.sbox[3][A], m;
        }
        function i(v, F, f) {
          let h = F, B = f, A;
          for (let m = 0; m < d; ++m)
            h = h ^ v.pbox[m], B = u(v, h) ^ B, A = h, h = B, B = A;
          return A = h, h = B, B = A, B = B ^ v.pbox[d], h = h ^ v.pbox[d + 1], { left: h, right: B };
        }
        function l(v, F, f) {
          let h = F, B = f, A;
          for (let m = d + 1; m > 1; --m)
            h = h ^ v.pbox[m], B = u(v, h) ^ B, A = h, h = B, B = A;
          return A = h, h = B, B = A, B = B ^ v.pbox[1], h = h ^ v.pbox[0], { left: h, right: B };
        }
        function p(v, F, f) {
          for (let y = 0; y < 4; y++) {
            v.sbox[y] = [];
            for (let b = 0; b < 256; b++)
              v.sbox[y][b] = t[y][b];
          }
          let h = 0;
          for (let y = 0; y < d + 2; y++)
            v.pbox[y] = x[y] ^ F[h], h++, h >= f && (h = 0);
          let B = 0, A = 0, m = 0;
          for (let y = 0; y < d + 2; y += 2)
            m = i(v, B, A), B = m.left, A = m.right, v.pbox[y] = B, v.pbox[y + 1] = A;
          for (let y = 0; y < 4; y++)
            for (let b = 0; b < 256; b += 2)
              m = i(v, B, A), B = m.left, A = m.right, v.sbox[y][b] = B, v.sbox[y][b + 1] = A;
          return !0;
        }
        var C = E.Blowfish = c.extend({
          _doReset: function() {
            if (this._keyPriorReset !== this._key) {
              var v = this._keyPriorReset = this._key, F = v.words, f = v.sigBytes / 4;
              p(a, F, f);
            }
          },
          encryptBlock: function(v, F) {
            var f = i(a, v[F], v[F + 1]);
            v[F] = f.left, v[F + 1] = f.right;
          },
          decryptBlock: function(v, F) {
            var f = l(a, v[F], v[F + 1]);
            v[F] = f.left, v[F + 1] = f.right;
          },
          blockSize: 64 / 32,
          keySize: 128 / 32,
          ivSize: 64 / 32
        });
        e.Blowfish = c._createHelper(C);
      })(), r.Blowfish;
    });
  })(fe)), fe.exports;
}
var Ia = k0.exports, gr;
function La() {
  return gr || (gr = 1, (function(s, n) {
    (function(r, e, o) {
      s.exports = e(L(), le(), qt(), Tt(), h0(), Gt(), u0(), Sr(), ge(), Xt(), Mr(), Yt(), Qt(), ea(), De(), aa(), l0(), K(), sa(), ca(), la(), ua(), va(), Ba(), Aa(), ma(), ga(), ya(), _a(), ka(), Ma(), za(), Pa(), qa(), Ta());
    })(Ia, function(r) {
      return r;
    });
  })(k0)), k0.exports;
}
var Ga = La();
const Ua = /* @__PURE__ */ wt(Ga), $a = "KMED1W0N50YIWIYJCUNLYPMJ49JDLASE", Na = "UQ30SC5R5YTM1TEHHDB8QB20NUYOAQY6", me = {
  room: { fillcolor: "#8daed3", strokecolor: "#6d8fb5", height: 0.1 },
  wall: { height: 2, opacity: 0.6, fillcolor: "#3452B4", strokecolor: "#38AEBA" },
  floor: { fillcolor: "#F1F7F9", strokecolor: "#EEEEEE", height: 0.05 },
  plane: { fillcolor: "#4C4C54", strokecolor: "#3C3C3C", height: 0.1 },
  window: { fillcolor: "#AADDEE", strokecolor: "#5FA7C7", height: 1.5, opacity: 0.85 },
  door: { fillcolor: "#64C1EB", strokecolor: "#38AEBA", height: 0.1 },
  logo: { height: 1 },
  desk: { fillcolor: "#87CEFA", strokecolor: "#38AEBA", height: 0.5 },
  seat: { fillcolor: "#87CEFA", strokecolor: "#38AEBA", height: 0.3 },
  default: { fillcolor: "#0088FF", strokecolor: "#38AEBA", height: 1, eheight: 0, opacity: 1, size: 1.4, logo: "" },
  unknown: { fillcolor: "#F00", height: 2 }
}, Va = { floor: 1, plane: 2, wall: 10, window: 11, door: 12, desk: 14, seat: 15, room: 18 }, Xa = 10;
function Ka(s) {
  if (typeof s != "string") {
    const r = new Uint8Array(s.slice ? s.slice(0, 2) : s);
    if (r[0] === 80 && r[1] === 75) return "buildingosmap";
    s = new TextDecoder().decode(s);
  }
  return s.trimStart().startsWith("{") ? "acmap-plain" : "acmap";
}
function ja(s, n, { key: r = $a, iv: e = Na } = {}) {
  if (s.trimStart().startsWith("{")) return JSON.parse(s);
  const o = n.AES.decrypt(
    { ciphertext: n.enc.Base64.parse(s) },
    n.enc.Utf8.parse(r),
    { iv: n.enc.Utf8.parse(e), mode: n.mode.CBC, padding: n.pad.Pkcs7 }
  ).toString(n.enc.Utf8);
  if (!o) throw new Error(".acmap 解密失败（密钥不对或文件损坏）");
  return JSON.parse(o);
}
function Rr(s) {
  return {
    version: s.MAP_VERSION || s.version || "unknown",
    id: s.id ?? s.name,
    name: s.name,
    buildingName: s.building_name,
    offset: Array.isArray(s.iv) ? s.iv : [0, 0],
    // 楼栋平面偏移（旧引擎 building.position.x/z），不是加密 IV
    floors: s.floors || []
  };
}
function Ya(s, n, r) {
  const e = Object.assign({}, me[s] || me.default);
  r?.moduleStyle?.[s] && Object.assign(e, r.moduleStyle[s]);
  const o = r?.itemStyle?.find?.((c) => c.sType === n.type?.sType);
  if (o) {
    const { sType: c, ...E } = o;
    Object.assign(e, E);
  }
  return Object.assign(e, n.properties);
}
function Za(s, { theme: n, unknownLayers: r = [] } = {}) {
  const e = Rr(s), o = new S.Group();
  o.name = `v1:${e.id}`, o.userData.semantic = { id: String(e.id), type: "building", name: e.name }, o.position.set(e.offset[0], 0, e.offset[1]);
  const c = { floors: 0, meshes: 0, items: 0, triangles: 0, skipped: {} }, E = {};
  let d = 0;
  return e.floors.forEach((x, t) => {
    const a = x.floorHeight || Xa, u = new S.Group();
    u.name = `floor:${t}`, u.position.y = d, d += a, u.userData.semantic = { id: `${e.id}-${x.name || t}`, type: "floor", name: x.name, index: t }, o.add(u), c.floors++;
    for (const [i, l] of Object.entries(x.floor || {})) {
      if (!l?.length) continue;
      if (i === "logo") {
        c.skipped.logo = (c.skipped.logo || 0) + l.length;
        continue;
      }
      const p = [], C = [], v = [];
      let F = 1, f = 0;
      if (l.forEach((m, y) => {
        if (!m.line || m.line.length < 3) return;
        const b = Ya(i, m, n), k = Number(b.height) || 0, g = Number(b.eheight) || 0;
        F = b.opacity === void 0 ? 1 : Number(b.opacity);
        const D = new S.Shape();
        D.moveTo(m.line[0][0], -m.line[0][1]);
        for (let O = 1; O < m.line.length; O++) D.lineTo(m.line[O][0], -m.line[O][1]);
        const _ = new S.ExtrudeGeometry(D, { depth: Math.max(k, 1e-3), bevelEnabled: !1 }), P = (_.toNonIndexed && _.index ? _.toNonIndexed() : _).attributes.position, W = new S.Color(b.fillcolor || "#888");
        for (let O = 0; O < P.count; O++)
          p.push(P.getX(O), P.getY(O), P.getZ(O) + g), C.push(W.r, W.g, W.b);
        const q = P.count / 3;
        v.push({ start: f, count: q, id: m.id ?? `${i}-${y}`, layer: i, name: m.name || m.properties?.name || "" }), f += q, c.items++, _.dispose();
      }), !p.length) continue;
      const h = new S.BufferGeometry();
      h.setAttribute("position", new S.Float32BufferAttribute(p, 3)), h.setAttribute("color", new S.Float32BufferAttribute(C, 3)), h.computeVertexNormals();
      const B = new S.MeshLambertMaterial({
        vertexColors: !0,
        transparent: F < 1,
        opacity: F,
        side: F < 1 ? S.DoubleSide : S.FrontSide,
        depthWrite: F >= 1
      }), A = new S.Mesh(h, B);
      A.rotation.x = -Math.PI / 2, A.renderOrder = Va[i] ?? 5, A.name = `${u.userData.semantic.id}|v1.${i}`, A.userData.semantic = u.userData.semantic.id, A.visible = F > 0, A.userData.layer = i, E[A.uuid] = v, u.add(A), c.meshes++, c.triangles += f, me[i] || r.push(i);
    }
  }), { root: o, stats: c, pick: E, meta: e };
}
async function Qa(s) {
  if (s instanceof Uint8Array) return s;
  if (s instanceof ArrayBuffer) return new Uint8Array(s);
  if (typeof Blob < "u" && s instanceof Blob) return new Uint8Array(await s.arrayBuffer());
  const n = await fetch(s);
  if (!n.ok) throw new Error("模型文件下载失败：" + n.status + " " + s);
  return new Uint8Array(await n.arrayBuffer());
}
async function Ja(s, n, r = {}) {
  const e = await Qa(s);
  return Ka(e) === "buildingosmap" ? en(e, n, r) : rn(e, r);
}
let Be = null;
function zr() {
  return Be || (Be = typeof WebAssembly == "object" && typeof WebAssembly.compile == "function" ? WebAssembly.compile(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0])).then(() => !0, () => !1) : Promise.resolve(!1)), Be;
}
async function en(s, n, { palette: r = {}, decoderPath: e = "/vendor/draco/" } = {}) {
  const o = _t(s), c = JSON.parse(Ee(o["manifest.json"]));
  if (c.format !== "buildingosmap" || c.version !== 1) throw new Error("不支持的 .buildingosmap：" + c.format + " v" + c.version);
  const E = JSON.parse(Ee(o[c.entries.semantics])), d = o[c.entries.scene], x = new jr();
  if (c.compression && c.compression.geometry === "draco") {
    const l = new Yr();
    l.setDecoderPath(e), await zr() || l.setDecoderConfig({ type: "js" }), x.setDRACOLoader(l), n.addDisposable && n.addDisposable(l);
  }
  const a = (await new Promise((l, p) => x.parse(d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength), "", l, p))).scene;
  a.name = c.id;
  const u = E.envMaps || {}, i = /* @__PURE__ */ new Map();
  return a.traverse((l) => {
    if (!l.isMesh) return;
    if (!l.userData.semantic) {
      const F = l.name.indexOf("|");
      F > 0 && (l.userData.semantic = l.name.slice(0, F));
    }
    l.castShadow = l.receiveShadow = !0;
    const p = l.material, C = p && p.name;
    if (!C) return;
    const v = n.presets.bySlot(C);
    if (v) {
      l.material = v;
      return;
    }
    i.has(C) || (r[C] !== void 0 && p.color && p.color.set(r[C]).convertSRGBToLinear(), u[C] !== void 0 && (p.envMap = n.presets.smartFacade().reflection, p.envMapIntensity = u[C], p.needsUpdate = !0), i.set(C, p));
  }), { root: a, model: { id: c.id, name: c.name, viewer: c.viewer, home: c.home, semantics: E }, stats: { format: "buildingosmap", bytes: s.byteLength } };
}
function rn(s, { key: n, iv: r } = {}) {
  const e = new TextDecoder().decode(s), o = ja(e, Ua, { ...n ? { key: n } : {}, ...r ? { iv: r } : {} }), c = Rr(o), { root: E, stats: d, pick: x } = Za(o, {}), t = new S.Box3().setFromObject(E), a = t.getCenter(new S.Vector3()), u = t.getSize(new S.Vector3()), i = Math.max(u.x, u.z) * 1.1 || 50, l = { position: [a.x, a.y + i, a.z + i * 0.6], target: [a.x, a.y, a.z] }, p = [{
    id: String(c.id),
    type: "building",
    name: c.name,
    pickable: !0,
    children: E.children.map((C) => ({ id: C.userData.semantic.id, type: "floor", name: C.userData.semantic.name, pickable: !0 }))
  }];
  return {
    root: E,
    model: {
      id: String(c.id),
      name: c.name,
      home: l,
      viewer: { fov: 45, near: 0.1, far: Math.max(2e3, i * 20), controls: { minDistance: 1, maxDistance: i * 6, maxPolarAngle: Math.PI / 2 } },
      semantics: { tree: p, cameras: [{ id: "home", ...l }, { id: "top", position: [a.x, a.y + i * 1.6, a.z + 0.01], target: [a.x, a.y, a.z] }], anchors: [], behaviors: [], pickRanges: x }
    },
    stats: { format: "acmap", version: c.version, ...d }
  };
}
const sn = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  loadMap: Ja,
  wasmAllowed: zr
}, Symbol.toStringTag, { value: "Module" }));
export {
  tt as B,
  xt as C,
  nt as G,
  Le as V,
  qe as a,
  st as c,
  Zr as i,
  Ja as l,
  sn as m,
  w0 as s,
  zr as w
};
