var d = Object.defineProperty;
var u = (r, i, e) => i in r ? d(r, i, { enumerable: !0, configurable: !0, writable: !0, value: e }) : r[i] = e;
var n = (r, i, e) => u(r, typeof i != "symbol" ? i + "" : i, e);
import "./h2z-viewer-compat.js";
import { V as c, l as p } from "./chunks/map-BLYArnh8.js";
const f = `
  <style>
    :host { display: block; position: relative; overflow: hidden; background: #0b0f13; }
    :host([hidden]) { display: none; }
    .host { position: absolute; inset: 0; }
    .msg {
      position: absolute; inset: 0; display: none; place-items: center;
      color: #cfe0f0; font: 13px/1.6 'Segoe UI', 'Microsoft YaHei', system-ui, sans-serif;
      background: rgba(11, 15, 19, .92); padding: 16px; text-align: center; white-space: pre-wrap;
    }
    .msg.on { display: grid; }
  </style>
  <div class="host" part="stage"></div>
  <div class="msg" part="message"></div>
`;
class l extends HTMLElement {
  constructor() {
    super();
    /** 未加载完成时排队的调用：[方法名, 参数] */
    n(this, "_queue", []);
    const e = this.attachShadow({ mode: "open" });
    e.innerHTML = f, this._stage = e.querySelector(".host"), this._msg = e.querySelector(".msg"), this._viewer = null, this._loading = null;
  }
  static get observedAttributes() {
    return ["src", "decoder-path", "mode", "layers", "studio", "paused"];
  }
  connectedCallback() {
    this._boot();
  }
  disconnectedCallback() {
    this._destroy();
  }
  attributeChangedCallback(e, a, t) {
    if (a !== t) {
      if (e === "src") {
        this._boot();
        return;
      }
      !this._viewer || !this._viewer.model || (e === "mode" && this._viewer.mode(t), e === "layers" && this._applyLayers(t), e === "studio" && this._viewer.studio(t !== null && t !== "false"), e === "paused" && this._viewer.pause(t !== null && t !== "false"));
    }
  }
  /** 直接拿到底层的 Viewer（需要细粒度控制时用） */
  get viewer() {
    return this._viewer;
  }
  get ready() {
    return this._loading || Promise.resolve(null);
  }
  /** 图层属性写法：`roof=0,racks=1`（只有列出来的层会被改） */
  _applyLayers(e) {
    for (const a of String(e || "").split(",")) {
      const [t, s] = a.split("=").map((o) => o.trim());
      t && this._viewer.layer(t, s !== "0" && s !== "false");
    }
  }
  async _boot() {
    const e = this.getAttribute("src");
    if (this._destroy(), !e) return;
    this._say("正在加载地图…");
    const a = (s, o) => {
      s === "labels" ? this.dispatchEvent(new CustomEvent("h2z-labels", { detail: o })) : s === "select" ? this.dispatchEvent(new CustomEvent("h2z-select", { detail: o })) : s === "error" && (this._say(`加载失败：
` + o), this.dispatchEvent(new CustomEvent("h2z-error", { detail: o })));
    }, t = new c(this._stage, { emit: a, emitSelect: !0 });
    this._viewer = t;
    try {
      this._loading = p(e, t, { decoderPath: this.getAttribute("decoder-path") || "/vendor/draco/" });
      const s = await this._loading;
      if (this._viewer !== t) return;
      t.setModel(s), this._say("");
      for (const [o, h] of this._queue.splice(0)) t[o](...h);
      this._applyLayers(this.getAttribute("layers")), this.hasAttribute("mode") && t.mode(this.getAttribute("mode")), this.hasAttribute("studio") && this.getAttribute("studio") !== "false" && t.studio(!0), this.hasAttribute("paused") && this.getAttribute("paused") !== "false" && t.pause(!0);
    } catch (s) {
      this._say(`加载失败：
` + String(s && s.message || s)), this.dispatchEvent(new CustomEvent("h2z-error", { detail: String(s && s.message || s) }));
    }
  }
  _say(e) {
    this._msg.textContent = e || "", this._msg.classList.toggle("on", !!e);
  }
  _destroy() {
    this._viewer && (this._viewer.dispose(), this._viewer = null), this._loading = null, this._queue.length = 0;
  }
}
for (const r of ["focus", "reset", "top", "orbit", "pause", "view", "labels", "studio", "environment", "snapshots", "mode", "layer", "highlight", "setVisible", "pickAt"])
  l.prototype[r] = function(...i) {
    if (this._viewer && this._viewer.model) return this._viewer[r](...i);
    this._queue.push([r, i]);
  };
typeof customElements < "u" && !customElements.get("h2z-map") && customElements.define("h2z-map", l);
export {
  l as H2zMapElement,
  l as default
};
